declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const UnityEngine: any;

let rigidbody = null
let hue = 0;
let lastRunTime = 0;

let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let buttonSound = 66;

let walkPos = null;
let walkNormal = null;

let previousNoclipKey = false;
let perviousDestroyKey = false;

let bgColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
let bgColor2: [number, number, number, number] = [9.0, 9.0, 9.0, 1.0];
let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];
let buttonColor: [number, number, number, number] = [0.1, 0.1, 0.1, 1.0];
let buttonPressedColor: [number, number, number, number] = [0.7, 0.7, 0.7, 1.0];

let menuName: string = "J0ker Client";
let themeIndex = 0;

let gravityMode = 0;
let gravityChangeDelay = 0;

let previousGhostKey = false;
let previousInvisKey = false;

class XRInputHandler {
  private InputDevices: any;
  private tryGetFeatureValue: any;
  private buttonStates: Map<string, boolean>;

  constructor() {
    this.InputDevices = Il2Cpp.domain
      .assembly("UnityEngine.XRModule")
      .image.class("UnityEngine.XR.InputDevices");

    this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
    this.buttonStates = new Map();
  }

  update() {
    this.updateControllerStates(1); // left controller
    this.updateControllerStates(2); // right controller
  }

  private updateControllerStates(controllerId: number) {
    const features = [
      "PrimaryButton",
      "SecondaryButton",
      "GripButton",
      "TriggerButton",
      "MenuButton"
    ];

    features.forEach(feature => {
      const key = `${controllerId}_${feature}`;
      this.buttonStates.set(key, this.getButtonState(controllerId, feature));
    });
  }

  private getButtonState(deviceId: number, featureName: string): boolean {
    try {
      const valuePtr = Il2Cpp.alloc(1);
      const feature = Il2Cpp.string(featureName);
      const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
      if (success) {
        return valuePtr.readU8() !== 0;
      }
    } catch (_) { }
    return false;
  }

  isButtonPressed(controllerId: number, feature: string): boolean {
    return this.buttonStates.get(`${controllerId}_${feature}`) || false;
  }

  get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
  get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
  get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
  get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
  get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
  get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
  get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
  get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
  get controllerMenuButton(): boolean {
    return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
  }
}

Il2Cpp.initialize();
Il2Cpp.perform(() => {
  const images = {
    "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
    "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
    "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
    "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
    "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
    "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
    "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
    "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image
  };

  const AssemblyCSharp = images["Assembly-CSharp"];
  const UnityEngineCore = images["UnityEngine.CoreModule"];
  const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
  const UnityEngineUI = images["UnityEngine.UI"];
  const UnityEngineUIModule = images["UnityEngine.UIModule"];
  const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
  const PhotonUnityNetworking = images["PhotonUnityNetworking"];
  const GTPlayerClass = AssemblyCSharp.class("GorillaLocomotion.GTPlayer");
  const GorillaReportButton = AssemblyCSharp.class("GorillaReportButton");
  const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
  const NetworkSystemClass = AssemblyCSharp.class("NetworkSystem");
  const GTPlayer = GTPlayerClass.method("get_Instance").invoke();
  const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
  const Object = UnityEngineCore.class("UnityEngine.Object");
  const Component = UnityEngineCore.class("UnityEngine.Component");
  const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
  const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
  const Time = UnityEngineCore.class("UnityEngine.Time");
  const Resources = UnityEngineCore.class("UnityEngine.Resources");
  const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
  const Shader = UnityEngineCore.class("UnityEngine.Shader");
  const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
  const MeshCollider = UnityEnginePhysics.class("UnityEngine.MeshCollider");
  const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
  const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
  const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
  const Physics = UnityEnginePhysics.class("UnityEngine.Physics");
  const SystemObject = Il2Cpp.corlib.class("System.Object");
  const GorillaTaggerClass = AssemblyCSharp.class("GorillaTagger");
  const NetworkSystem = NetworkSystemClass.field("Instance").value;


  const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
  const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
  const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
  const Text = UnityEngineUI.class("UnityEngine.UI.Text");
  const Font = UnityEngineTextRendering.class("UnityEngine.Font");
  const GorillaTagger = GorillaTaggerClass.field("_instance").value;

  const LocalRig = GorillaTagger.field("offlineVRRig").value;


  for (const field of GTPlayerClass.fields) {
    if (field.type.name == "UnityEngine.Rigidbody") {
      rigidbody = GTPlayer.field(field.name).value
    }
  }

  const MenuShader = Shader.method("Find").invoke(Il2Cpp.string("GorillaTag/UberShader"));
  const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

  const zeroVector = Vector3.field("zeroVector").value;
  const oneVector = Vector3.field("oneVector").value;
  const identityQuaternion = Quaternion.field("identityQuaternion").value;

  const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
  const rightHandTransform = GorillaTagger.field("rightHandTransform").value;

  const arial = Resources
    .method("GetBuiltinResource", 1)
    .inflate(Font)
    .invoke(Il2Cpp.string("Arial.ttf"));

  function Destroy(object) {
    Object.method("Destroy", 1).invoke(object);
  }

  function getComponent(obj: any, type) {
    return obj.method("GetComponent", 1).inflate(type).invoke();
  }

  function addComponent(obj: any, type) {
    return obj.method("AddComponent", 1).inflate(type).invoke();
  }

  function getComponentInParent(obj: any, type) {
    return obj.method("GetComponentInParent", 0).inflate(type).invoke();
  }

  function getTransform(obj: any) {
    return obj.method("get_transform").invoke();
  }

  function sendAllOutgoing() { PhotonNetwork.method("SendAllOutgoingCommands").invoke(); }

  function hsl2Rgb(h, s, l) {
    s /= 100;
    l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [
      Math.round(255 * f(0)),
      Math.round(255 * f(8)),
      Math.round(255 * f(4))
    ];
  }

  function getSmoothColor() {
    hue = (hue + 0.5) % 360;
    const [r, g, b] = hsl2Rgb(hue, 100, 50);
    return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
  }

  function renderMenuText(canvasObject, text: string = "", color: [number, number, number, number] = [1, 1, 1, 1], pos = zeroVector, size = oneVector) {
    const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
    getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
    title.method("set_text").invoke(Il2Cpp.string(text));
    title.method("set_font").invoke(arial);
    title.method("set_fontSize").invoke(1);
    title.method("set_color").invoke(color);
    title.method("set_fontStyle").invoke(3);
    title.method("set_alignment").invoke(4);
    title.method("set_resizeTextForBestFit").invoke(true);
    title.method("set_resizeTextMinSize").invoke(0);

    const rectTransform = getComponent(title, RectTransform);
    rectTransform.method("set_sizeDelta").invoke(size);
    rectTransform.method("set_position").invoke(pos);
    rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0))
  }
  function createObject(
    pos = zeroVector,
    rot = identityQuaternion,
    scale = oneVector,
    primitiveType: number = 3,
    colorArr: [number, number, number, number] = [1, 1, 1, 1],
    parent = null
  ) {
    const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);

    const renderer = getComponent(obj, Renderer);

    if (colorArr[3] == 0) {
      renderer.method("set_enabled").invoke(false);
    } else {
      const material = renderer.method("get_material").invoke();
      material.method("set_shader").invoke(MenuShader);
      material.method("set_color").invoke(colorArr);
    }

    const transform = getTransform(obj);
    if (parent != null) {
      transform.method("SetParent", 2).invoke(parent, false);
    }

    transform.method("set_position").invoke(pos);
    transform.method("set_rotation").invoke(rot);
    transform.method("set_localScale").invoke(scale);

    return obj;
  }

  function renderMenu() {
    menu = createObject(zeroVector, Quaternion.Euler, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
    Destroy(getComponent(menu, BoxCollider))

    const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu))
    Destroy(getComponent(menuBackground, BoxCollider))

    const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu))
    Destroy(getComponent(menuBackground2, BoxCollider))

    const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
    const canvas = addComponent(canvasObject, Canvas);
    Destroy(getComponent(canvasObject, BoxCollider))

    const canvasScaler = addComponent(canvasObject, CanvasScaler);
    addComponent(canvasObject, GraphicRaycaster);
    canvas.method("set_renderMode").invoke(2);
    canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);

    const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
    const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
    homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));

    addComponent(homeButton, GorillaReportButton);
    getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);

    renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

    const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
    const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
    leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));

    addComponent(leaveButton, GorillaReportButton);
    getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);

    renderMenuText(canvasObject, "Leave", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);
    renderMenuText(canvasObject, "linktr.ee/j0kermodz", textColor, [0.107, 0, -0.120], [.5, .5]);

    renderMenuText(canvasObject, menuName, textColor, [0.11, 0, 0.155], [1, .1]);
    {
      const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
      const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
      pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));


      addComponent(pageButton, GorillaReportButton);
      getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, "←", textColor, [0.11, 0.17, 0], [1, 0.1]);
    }

    {
      const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
      const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
      pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));


      addComponent(pageButton, GorillaReportButton);
      getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, "→", textColor, [0.11, -0.17, 0], [1, 0.1]);
    }

    let i = 0;
    const targetMods = buttons[currentCategory]
      .slice(currentPage * 6)
      .slice(0, 6);


    targetMods.forEach((buttonData) => {
      const button = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
      const button2 = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.08, 0.82, 0.09], 3, bgColor2, getTransform(menu));

      button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));

      addComponent(button, GorillaReportButton);
      getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.11 - (i * 0.04)], [1, 0.1]);
      updateButtonColor(button, buttonData);
      i++;
    });

    recenterMenu();
  }

  function renderReference() {
    reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, rightHandTransform)
    referenceCollider = getComponent(reference, Collider);
    getTransform(reference).method("set_localPosition").invoke([0.02, -0.120, 0.033]);
    reference.method("set_layer").invoke(2);
    addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
  }

  function playButtonSound() {
    LocalRig.method("PlayHandTapLocal").invoke(buttonSound, false, 0.3);
    GorillaTagger.method("StartVibration").invoke(false, 0.5, 0.075);
  }

  let gunLocked = false;
  let lockTarget = null;
  let GunPointer = null;
  let GunLine = null;
  let soundDelay = 0;


  function renderGun(overrideLayerMask = null) {
    const StartPosition = rightHandTransform.method("get_position").invoke();
    let Direction = rightHandTransform.method("get_up").invoke();
    Direction = Vector3.method("op_Multiply", 2).invoke(Direction, -1);

    const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
    const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);

    const layerMask = overrideLayerMask || -3180559;

    const hits = Physics.method("RaycastAll", 4).invoke(rayStartPosition, Direction, 512.0, layerMask);
    let finalDistance = Infinity;
    let finalRay = null;
    for (const hit of hits) {
      const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
      if (distance < finalDistance) {
        finalRay = hit;
        finalDistance = distance;
      }
    }

    let EndPosition;
    if (gunLocked) {
      EndPosition = getTransform(lockTarget).method("get_position").invoke();
    } else {
      EndPosition = finalRay.method("get_point").invoke();
    }

    if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
      const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
      EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
    }

    if (GunPointer == null) {
      GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
    }

    GunPointer.method("SetActive").invoke(true);
    const pointerTransform = getTransform(GunPointer);
    pointerTransform.method("set_position").invoke(EndPosition);

    const PointerRenderer = getComponent(GunPointer, Renderer);
    const material = PointerRenderer.method("get_material").invoke();

    material.method("set_shader").invoke(TextShader);

    const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
    material.method("set_color").invoke(pointerColor);

    const collider = getComponent(GunPointer, Collider);
    if (collider != null) {
      Destroy(collider);
    }


    if (rightTrigger || gunLocked) {
      const Step = 10;
      for (let i = 1; i < (Step - 1); i++) {
        const t = i / (Step - 1);
        const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);

        const randomValue = Math.random();
        let offset = zeroVector;

        if (randomValue > 0.75) {
          offset = [
            (Math.random() * 0.2) - 0.1,
            (Math.random() * 0.2) - 0.1,
            (Math.random() * 0.2) - 0.1
          ];
        }

      }

    }
    return { ray: finalRay, gunPointer: GunPointer };
  }

  function recenterMenu() {
    let menuPosition = leftHandTransform.method("get_position").invoke();
    let menuRotation = leftHandTransform.method("get_rotation").invoke();

    menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(140, 180, 180))

    const menuTransform = getTransform(menu);
    menuTransform.method("set_position").invoke(menuPosition);
    menuTransform.method("set_rotation").invoke(menuRotation);
  }

  function reloadMenu() {
    if (menu != null) {
      Object.method("Destroy", 1).invoke(menu);
      menu = null;
    }
  }

  function updateButtonColor(button, buttonData) {
    const RendererClass = Il2Cpp.domain
      .assembly("UnityEngine.CoreModule")
      .image
      .class("UnityEngine.Renderer");

    const renderer = getComponent(button, RendererClass);
    if (!renderer) {
      return;
    }

    const material = renderer.method("get_material").invoke();
    material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
  }

  interface ButtonInfoConfig {
    buttonText: string;
    method?: () => void;
    enableMethod?: () => void;
    disableMethod?: () => void;
    keepOn?: boolean;
    enabled?: boolean;
  }

  class ButtonInfo {
    buttonText: string;
    method?: () => void;
    enableMethod?: () => void;
    disableMethod?: () => void;
    keepOn: boolean;
    enabled: boolean;

    constructor(config: ButtonInfoConfig) {
      this.buttonText = config.buttonText;
      this.method = config.method;
      this.enableMethod = config.enableMethod;
      this.disableMethod = config.disableMethod;
      this.keepOn = config.keepOn ?? true;
      this.enabled = config.enabled ?? false;
    }
  }

  let currentCategory = 0;
  let currentPage = 0;

  //#region Mods

  //#region Player
  let flyspeed = 5.0;
  let ghost = false;
  let spawnedRig = null;

  function Fly() {
    if (rightSecondary) {
      rigidbody.method("set_velocity").invoke(Vector3.field("zeroVector").value);

      const transform = getTransform(GorillaTagger);

      let forward = getTransform(rightHandTransform).method("get_up").invoke();

      // 🔥 invert direction
      forward = Vector3.method("op_Multiply", 2).invoke(forward, -1);

      let position = transform.method("get_position").invoke();

      forward = Vector3.method("op_Multiply", 2).invoke(forward, flyspeed * deltaTime);

      position = Vector3.method("op_Addition", 2).invoke(position, forward);

      transform.method("set_position").invoke(position);
    }
  }
  //#region  Platforms
  let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
  const platColors: [number, number, number, number][] = [
    [0.0, 0.0, 0.0, 1.0],       // Black
    [9.0, 9.0, 9.0, 1.0],       // Bright white
    [9.0, 0.0, 0.0, 1.0],       // Red
    [0.0, 9.0, 0.0, 1.0],       // Green
    [0.0, 0.0, 9.0, 1.0],       // Blue
    [5.0, 5.0, 0.0, 1.0],       // Yellow
    [9.0, 0.5, 9.0, 1.0],       // Magenta
  ];
  let platL = null;
  let platR = null;
  let plater = 0;

  function Platforms() {
    if (leftGrab) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightGrab) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  //#endregion

  //#region  NoClip

  function Noclip() {
    if (rightTrigger && !previousNoclipKey) {
      toggleColliders(false);
    }

    if (!rightTrigger && previousNoclipKey) {
      toggleColliders(true);
    }

    previousNoclipKey = rightTrigger;
  }

  function toggleColliders(enabled) {
    const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();

    for (let i = 0; i < meshColliders.length; i++) {
      const meshCollider = meshColliders.get(i);
      meshCollider.method("set_enabled").invoke(enabled);
    }
  }

  //#endregion

  //#endregion

  const buttons: ButtonInfo[][] = [

    [ // Home
      new ButtonInfo({
        buttonText: "Settings",
        method: () => currentCategory = 2,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Movement Mods",
        method: () => currentCategory = 3,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Rig Mods",
        method: () => currentCategory = 4,
        keepOn: false,
      }),
    ],

    [ // Menu Buttons
      new ButtonInfo({
        buttonText: "Leave",
        method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Home",
        method: () => {
          currentCategory = 0
          currentPage = 0
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "PreviousPage",
        method: () => {
          const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

          currentPage--;
          if (currentPage < 0)
            currentPage = lastPage;
        },
        keepOn: false
      }),
      new ButtonInfo({
        buttonText: "NextPage",
        method: () => {
          const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

          currentPage++;
          currentPage %= lastPage + 1;
        },
        keepOn: false
      })
    ],

    [ // Settings
      new ButtonInfo({
        buttonText: `Fly Speed+`,
        method: () => {
          flyspeed += 1
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: `Fly Speed-`,
        method: () => {
          flyspeed -= 1
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Platform Color",
        method: () => {
          plater = (plater + 1) % platColors.length;
          platColor = platColors[plater];
        },
        keepOn: false,
      }),
    ],

    [ // Movement Mods
      new ButtonInfo({
        buttonText: "Fly [B]",
        method: () => {
          Fly()
        },
      }),

      new ButtonInfo({
        buttonText: "Iron Man [G]",
        method: () => {
          if (leftGrab) {
            const leftRightVector = leftHandTransform.method("get_right").invoke();
            const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, -15.0 * deltaTime);
            rigidbody.method("AddForce", 2).invoke(leftForce, 2);
            LocalRig.method("PlayHandTapLocal").invoke(115, true, 0.3);
          }
          if (rightGrab) {
            const leftRightVector = rightHandTransform.method("get_right").invoke();
            const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, 15.0 * deltaTime);
            rigidbody.method("AddForce", 2).invoke(leftForce, 2);
            LocalRig.method("PlayHandTapLocal").invoke(115, false, 0.3);
          }
        },
      }),

      new ButtonInfo({
        buttonText: "Long Arms",
        method: () => {
          getTransform(GorillaTagger).method("set_localScale").invoke([1.25, 1.25, 1.25]);
        },
        disableMethod: () => {
          getTransform(GorillaTagger).method("set_localScale").invoke(oneVector);
        },
      }),

      new ButtonInfo({
        buttonText: "Platforms [G]",
        method: () => {
          Platforms()
        },
      }),

      new ButtonInfo({
        buttonText: "No Clip [T]",
        method: () => {
          Noclip()
        },
      }),

      new ButtonInfo({
        buttonText: "Low Gravity",
        method: () => {
          const force = Vector3.method("op_Multiply", 2).invoke(Vector3.field("upVector").value, (deltaTime * (6.66 / deltaTime)));
          rigidbody.method("AddForce", 2).invoke(force, 5);
        },
      }),

      new ButtonInfo({
        buttonText: "Zero Gravity",
        method: () => {
          const force = Vector3.method("op_Multiply", 2).invoke(Vector3.field("upVector").value, (deltaTime * (9.81 / deltaTime)));
          rigidbody.method("AddForce", 2).invoke(force, 5);
        },
      }),

      new ButtonInfo({
        buttonText: "High Gravity",
        method: () => {
          const force = Vector3.method("op_Multiply", 2).invoke(Vector3.field("downVector").value, (deltaTime * (7.77 / deltaTime)));
          rigidbody.method("AddForce", 2).invoke(force, 5);
        },
      }),

      new ButtonInfo({
        buttonText: "Speed Boost",
        method: () => {
          GTPlayer.field("maxJumpSpeed").value = 9.0;
          GTPlayer.method("set_jumpMultiplier").invoke(1.5);
        },
      }),

      new ButtonInfo({
        buttonText: "Wall Walk [G]",
        method: () => {
          if (GTPlayer.method("IsHandTouching").invoke(true) || GTPlayer.method("IsHandTouching").invoke(false)) {
            const ray = GTPlayer.field("lastHitInfoHand").value;
            walkPos = ray.method("get_point").invoke();
            walkNormal = ray.method("get_normal").invoke();
          }
          if (walkPos != Vector3.field("zeroVector").value && rightGrab) {
            const force = Vector3.method("op_Multiply", 2).invoke(walkNormal, -9.81);
            rigidbody.method("AddForce").invoke(force, 5);
            const zeroForce = Vector3.method("op_Multiply", 2).invoke(Vector3.field("upVector").value, (deltaTime * (9.81 / deltaTime)));
            rigidbody.method("AddForce", 2).invoke(zeroForce, 5);
          }
        },
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Ghost [B]",
        method: () => {
          if (rightSecondary && !previousGhostKey) {
            LocalRig.method("set_enabled").invoke(!LocalRig.method("get_enabled").invoke());
          }
          previousGhostKey = rightSecondary;
        },
      }),

      new ButtonInfo({
        buttonText: "Invisible [B]",
        method: () => {
          if (rightSecondary && !previousInvisKey) {
            LocalRig.method("set_enabled").invoke(!LocalRig.method("get_enabled").invoke());
          }
          if (!LocalRig.method("get_enabled").invoke()) {
            getTransform(LocalRig).method("set_position").invoke([0, -99999, 0]);
          }
          previousInvisKey = rightSecondary;

        },
      }),
      new ButtonInfo({
        buttonText: "Rig Gun",
        disableMethod: () => {
          LocalRig.method("set_enabled").invoke(true);
        },
        method: () => {
          if (rightGrab) {
            const gunData = renderGun();
            const gunPointer = gunData.gunPointer;

            if (rightTrigger) {
              LocalRig.method("set_enabled").invoke(false);
              const position = Vector3.method("op_Addition", 2).invoke([0, 1, 0], getTransform(gunPointer).method("get_position").invoke());
              getTransform(LocalRig).method("set_position").invoke(position);
            } else {
              LocalRig.method("set_enabled").invoke(true);
            }
          }
        },
      }),
      new ButtonInfo({
        buttonText: "Grab Rig [G]",
        disableMethod: () => { LocalRig.method("set_enabled").invoke(true); },
        method: () => {
          if (rightGrab) {
            LocalRig.method("set_enabled").invoke(false);
            getTransform(LocalRig).method("set_position").invoke(rightHandTransform.method("get_position").invoke());
            getTransform(LocalRig).method("set_rotation").invoke(rightHandTransform.method("get_rotation").invoke());
          }
          else {
            LocalRig.method("set_enabled").invoke(true);
          }
        },
        keepOn: true,
      }),

      new ButtonInfo({
        buttonText: "Spaz Rig",
        method: () => {
          const trackingRotationOffset = LocalRig.field("head").value.field("trackingRotationOffset").value;
          trackingRotationOffset.field("x").value = Math.random() * 360.0;
          trackingRotationOffset.field("y").value = Math.random() * 360.0;
          trackingRotationOffset.field("z").value = Math.random() * 360.0;
        },
        disableMethod: () => {
          const trackingRotationOffset = LocalRig.field("head").value.field("trackingRotationOffset").value;
          trackingRotationOffset.field("x").value = 0.0;
          trackingRotationOffset.field("y").value = 0.0;
          trackingRotationOffset.field("z").value = 0.0;
        },
      }),
      new ButtonInfo({
        buttonText: "Spin Head X",
        method: () => {
          const trackingRotationOffset = LocalRig.field("head").value.field("trackingRotationOffset").value;
          trackingRotationOffset.field("x").value += 15.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("x").value = 0.0;
        },
      }),

      new ButtonInfo({
        buttonText: "Spin Head Y",
        method: () => {
          const trackingRotationOffset = LocalRig.field("head").value.field("trackingRotationOffset").value;
          trackingRotationOffset.field("y").value += 15.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("y").value = 0.0;
        },
      }),

      new ButtonInfo({
        buttonText: "Spin Head Z",
        method: () => {
          const trackingRotationOffset = LocalRig.field("head").value.field("trackingRotationOffset").value;
          trackingRotationOffset.field("z").value += 15.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("z").value = 0.0;
        },
      }),
      new ButtonInfo({
        buttonText: "Upside Down Head",
        method: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("z").value = 180.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("z").value = 0.0;
        },
      }),

      new ButtonInfo({
        buttonText: "Broken Neck",
        method: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("z").value = 90.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("z").value = 0.0;
        },
      }),

      new ButtonInfo({
        buttonText: "Backwards Head",
        method: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("y").value = 180.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("y").value = 0.0;
        },
      }),

      new ButtonInfo({
        buttonText: "Sideways Head",
        method: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("y").value = 90.0;
        },
        disableMethod: () => {
          LocalRig.field("head").value.field("trackingRotationOffset").value.field("y").value = 0.0;
        },
      }),
    ],
  ];

  let buttonMap: Map<string, ButtonInfo> = new Map();
  buttons.flat().forEach(button => {
    buttonMap.set(button.buttonText, button);
  });

  function getIndex(buttonText: string): ButtonInfo {
    return buttonMap.get(buttonText);
  }

  const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
  ButtonActivation.implementation = function (collider) {
    const rawName = this.method("get_name").invoke().toString();

    if (rawName.length > 1 && rawName[1] == "@") {
      if (collider.handle.equals(referenceCollider.handle)) {
        const goName = rawName.substring(2, rawName.length - 1);
        const _time = Time.method("get_time").invoke();

        if (_time > buttonClickDelay) {
          buttonClickDelay = _time + 0.2;

          const button = getIndex(goName)
          playButtonSound();
          if (button) {
            if (button.keepOn) {
              button.enabled = !button.enabled;

              if (button?.enabled) {
                button.enableMethod?.();
              } else {
                button?.disableMethod?.();
              }

            } else {
              button?.method?.();
            }

            reloadMenu();
          }
        }
      }

      return;
    }

    return this.method("OnTriggerEnter").invoke(collider);
  };

  const LateUpdate = GTPlayer.method("LateUpdate");

  LateUpdate.implementation = function () {

    const ControllerInputPoller = AssemblyCSharp.class("ControllerInputPoller").field("instance").value; ``

    leftPrimary = ControllerInputPoller.field("leftControllerPrimaryButton").value;
    rightPrimary = ControllerInputPoller.field("rightControllerPrimaryButton").value;

    leftSecondary = ControllerInputPoller.field("leftControllerSecondaryButton").value;
    rightSecondary = ControllerInputPoller.field("rightControllerSecondaryButton").value;

    leftGrab = ControllerInputPoller.field("leftGrab").value;
    rightGrab = ControllerInputPoller.field("rightGrab").value;

    leftTrigger = ControllerInputPoller.field("leftControllerTriggerButton").value;
    rightTrigger = ControllerInputPoller.field("rightControllerTriggerButton").value;

    deltaTime = Time.method("get_deltaTime").invoke();
    time = Time.method("get_time").invoke();

    if (leftSecondary) {
      if (menu == null) {
        renderMenu();
      } else {
        recenterMenu();
      }
    } else {
      if (menu != null) {
        Destroy(menu);
        menu = null;
      }
    }

    if (menu == null) {
      if (reference != null) {
        Destroy(reference);
        reference = null;
      }
    } else {
      if (reference == null) {
        renderReference();
      }
    }

    try {
      if (GunPointer != null) {
        if (!(GunPointer.method("get_activeSelf").invoke())) {
          Destroy(GunPointer);
          GunPointer = null;
        }
        else
          GunPointer.method("SetActive").invoke(false);
      }

      let lineObj = GunLine.method("get_gameObject").invoke();
      if (lineObj != null) {
        if (!(lineObj.method("get_activeSelf").invoke())) {
          Destroy(lineObj);
          GunLine = null;
        }
        else
          lineObj.method("SetActive").invoke(false);
      }
    } catch { }

    buttons.flat()
      .filter(button => button.enabled)
      .forEach(button => {
        if (button.method) {
          try {
            button.method();
          } catch (error) {
            console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
            console.error('Error stack:', error.stack);
            console.error('Button object:', button);

            if (error.stack) {
              const stackLines = error.stack.split('\n');
              if (stackLines.length > 1) {
                console.error('Error occurred at:', stackLines[1].trim());
              }
            }
          }
        }
      });

    return LateUpdate.invoke();
  };
  console.log(`Compiled ${new Date().toISOString()}`);

}, "main");