@echo off
title Frida Injector - Gorilla Tag
echo =====================================
echo     Frida Injection Tool (Quest)
echo =====================================
echo.

:retry
echo [*] Starting Frida injection for Gorilla Tag...
echo.

frida -U -l frida-il2cpp-bridge.js -l gorilla_tag_menu.ts "Gorilla Tag"

echo.
echo =====================================
echo [!] If you see "access violation"
echo     just run this again.
echo =====================================
echo.

choice /c RQ /m "Press R to retry or Q to quit: "
if errorlevel 2 goto end
if errorlevel 1 goto retry

:end
echo.
echo Closing...
pause
