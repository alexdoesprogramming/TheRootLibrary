declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const UnityEngine: any;

let rigidbody = null

let thingforfling = null

let hue = 0;

let lastRunTime = 0;
const strobecooldown = 500;
const rgbcooldown = 300;
const destroycooldown = 250;

let invisible = false

let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let previousGhostKey = false;
let previousInvisKey = false;
let previousNoclipKey = false;
let perviousTeleportKey = false;

let closePosition = null;
let tagGunDelay = 0.0;

let leftPlatform = null;
let rightPlatform = null;

let lvT = null;
let rvT = null;

let bgColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];

let bgColor2: [number, number, number, number] = [9.0, 9.0, 9.0, 1.0];

let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];

let buttonColor: [number, number, number, number] = [0.1, 0.1, 0.1, 1.0];
let buttonPressedColor: [number, number, number, number] = [0.7, 0.7, 0.7, 1.0];

let menuName: string = "J0ker Client";
let themeIndex = 0;
class XRInputHandler {
  private InputDevices: any;
  private tryGetFeatureValue: any;
  private buttonStates: Map<string, boolean>;

  constructor() {
    this.InputDevices = Il2Cpp.domain
      .assembly("UnityEngine.XRModule")
      .image.class("UnityEngine.XR.InputDevices");

    this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
    this.buttonStates = new Map();
  }

  update() {
    this.updateControllerStates(1); // left controller
    this.updateControllerStates(2); // right controller
  }

  private updateControllerStates(controllerId: number) {
    const features = [
      "PrimaryButton",
      "SecondaryButton",
      "GripButton",
      "TriggerButton",
      "MenuButton"
    ];

    features.forEach(feature => {
      const key = `${controllerId}_${feature}`;
      this.buttonStates.set(key, this.getButtonState(controllerId, feature));
    });
  }

  private getButtonState(deviceId: number, featureName: string): boolean {
    try {
      const valuePtr = Il2Cpp.alloc(1);
      const feature = Il2Cpp.string(featureName);
      const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
      if (success) {
        return valuePtr.readU8() !== 0;
      }
    } catch (_) { }
    return false;
  }

  isButtonPressed(controllerId: number, feature: string): boolean {
    return this.buttonStates.get(`${controllerId}_${feature}`) || false;
  }

  // Renamed getters
  get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
  get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
  get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
  get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
  get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
  get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
  get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
  get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
  get controllerMenuButton(): boolean {
    return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
  }
}

Il2Cpp.perform(() => {
  const images = {
    "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
    "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
    "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
    "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
    "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
    "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
    "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
    "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image
  };
  const AssemblyCSharp = images["Assembly-CSharp"];
  const EnverGardenGame = Il2Cpp.domain.assembly("Enver.GardenGame").image;
  const UnityEngineCore = images["UnityEngine.CoreModule"];
  const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
  const UnityEngineUI = images["UnityEngine.UI"];
  const UnityEngineUIModule = images["UnityEngine.UIModule"];
  const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
  const PhotonUnityNetworking = images["PhotonUnityNetworking"];

  const GTPlayerClass = EnverGardenGame.class("GorillaLocomotion.PlayerBwah");
  const GorillaReportButton = EnverGardenGame.class("VirtualKeyboardButton");
  const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
  const GTPlayer = GTPlayerClass.method("get_Instance").invoke();
  const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
  const Object = UnityEngineCore.class("UnityEngine.Object");
  const Component = UnityEngineCore.class("UnityEngine.Component");
  const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
  const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
  const Time = UnityEngineCore.class("UnityEngine.Time");
  const Resources = UnityEngineCore.class("UnityEngine.Resources");
  const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
  const Shader = UnityEngineCore.class("UnityEngine.Shader");
  const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
  const MeshCollider = UnityEnginePhysics.class("UnityEngine.Collider");
  const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
  const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
  const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
  const Physics = UnityEnginePhysics.class("UnityEngine.Physics");

  const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
  const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
  const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
  const Text = UnityEngineUI.class("UnityEngine.UI.Text");
  const Font = UnityEngineTextRendering.class("UnityEngine.Font");
  const GorillaTagger = GTPlayer
  const NetworkPlayerSpawnerClass = EnverGardenGame.class("NetworkPlayerSpawner");
  const CropControllerClass = EnverGardenGame.class("Enver.Features.CropController");
  const PlantControllerClass = EnverGardenGame.class("Enver.Features.PlantController");
  const SeedControllerClass = EnverGardenGame.class("Enver.Features.SeedController");


  for (const field of GTPlayerClass.fields) {
    if (field.type.name == "UnityEngine.Rigidbody") {
      rigidbody = GTPlayer.field(field.name).value
    }
  }


  const UberShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Lit"));
  const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

  const zeroVector = Vector3.field("zeroVector").value;
  const oneVector = Vector3.field("oneVector").value;
  const identityQuaternion = Quaternion.field("identityQuaternion").value;

  const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
  const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
  const headCollider = GorillaTagger.field("headCollider").value;
  let mutationName: string = "None";

  const OVRInputHandler = new XRInputHandler();

  const arial = Resources
    .method("GetBuiltinResource", 1)
    .inflate(Font)
    .invoke(Il2Cpp.string("Arial.ttf"));

  function Destroy(object) {
    Object.method("Destroy", 1).invoke(object);
  }


  function getComponent(obj: any, type) {
    return obj.method("GetComponent", 1).inflate(type).invoke();
  }

  function addComponent(obj: any, type) {
    return obj.method("AddComponent", 1).inflate(type).invoke();
  }

  function getComponentInParent(obj: any, type) {
    return obj.method("GetComponentInParent", 0).inflate(type).invoke();
  }


  function getTransform(obj: any) {
    return obj.method("get_transform").invoke();
  }

  function sendAllOutgoing() {
    PhotonNetwork.method("SendAllOutgoingCommands").invoke();
  }

  function hsl2Rgb(h, s, l) {
    s /= 100;
    l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [
      Math.round(255 * f(0)),
      Math.round(255 * f(8)),
      Math.round(255 * f(4))
    ];
  }
  function getSmoothColor() {
    hue = (hue + 0.5) % 360;
    const [r, g, b] = hsl2Rgb(hue, 100, 50);
    return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
  }


  function makeVector3(x: number, y: number, z: number): any {
    const vec = Il2Cpp.domain
      .assembly("UnityEngine.CoreModule")
      .image
      .class("UnityEngine.Vector3")
      .alloc();
    vec.field("x").value = x;
    vec.field("y").value = y;
    vec.field("z").value = z;
    return vec;
  }

  function renderMenuText(
    canvasObject,
    text: string = "",
    color: [number, number, number, number] = [1, 1, 1, 1],
    pos = zeroVector,
    size = oneVector
  ) {
    const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
    getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
    title.method("set_text").invoke(Il2Cpp.string(text));
    title.method("set_font").invoke(arial);
    title.method("set_fontSize").invoke(1);
    title.method("set_color").invoke(color);
    title.method("set_fontStyle").invoke(3);
    title.method("set_alignment").invoke(4);
    title.method("set_resizeTextForBestFit").invoke(true);
    title.method("set_resizeTextMinSize").invoke(0);

    const rectTransform = getComponent(title, RectTransform);
    rectTransform.method("set_sizeDelta").invoke(size);
    rectTransform.method("set_position").invoke(pos);
    rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0))
  }
  function createObject(
    pos = zeroVector,
    rot = identityQuaternion,
    scale = oneVector,
    primitiveType: number = 3,
    colorArr: [number, number, number, number] = [1, 1, 1, 1],
    parent = null
  ) {
    const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);

    const renderer = getComponent(obj, Renderer);

    if (colorArr[3] == 0) {
      renderer.method("set_enabled").invoke(false);
    } else {
      const material = renderer.method("get_material").invoke();
      material.method("set_shader").invoke(UberShader);
      material.method("set_color").invoke(colorArr);
    }

    const transform = getTransform(obj);
    if (parent != null) {
      transform.method("SetParent", 2).invoke(parent, false);
    }

    transform.method("set_position").invoke(pos);
    transform.method("set_rotation").invoke(rot);
    transform.method("set_localScale").invoke(scale);

    return obj;
  }

  function renderMenu() {
    menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
    Destroy(getComponent(menu, BoxCollider))

    const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu))
    Destroy(getComponent(menuBackground, BoxCollider))

    const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu))
    Destroy(getComponent(menuBackground2, BoxCollider))

    const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
    const canvas = addComponent(canvasObject, Canvas);
    Destroy(getComponent(canvasObject, BoxCollider))

    const canvasScaler = addComponent(canvasObject, CanvasScaler);
    addComponent(canvasObject, GraphicRaycaster);
    canvas.method("set_renderMode").invoke(2);
    canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);

    const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
    const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
    homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));

    addComponent(homeButton, GorillaReportButton);
    getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);

    renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

    const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
    const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
    leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));

    addComponent(leaveButton, GorillaReportButton);
    getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);

    renderMenuText(canvasObject, "Leave", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);

    renderMenuText(canvasObject, menuName + ` - Page [ <color=cyan>${currentPage + 1} </color>]`, textColor, [0.11, 0, 0.155], [1, .1]);
    {
      const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
      const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
      pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));


      addComponent(pageButton, GorillaReportButton);
      getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, "<", textColor, [0.11, 0.17, 0], [1, 0.1]);
    }

    {
      const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
      const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
      pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));


      addComponent(pageButton, GorillaReportButton);
      getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, ">", textColor, [0.11, -0.17, 0], [1, 0.1]);
    }

    let i = 0;
    const targetMods = buttons[currentCategory]
      .slice(currentPage * 6)
      .slice(0, 6);

    targetMods.forEach((buttonData) => {
      const button = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
      button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));

      addComponent(button, GorillaReportButton);
      getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
      renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.11 - (i * 0.04)], [1, 0.1]);
      updateButtonColor(button, buttonData);
      i++;
    });

    recenterMenu();
  }

  function renderReference() {
    reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, rightHandTransform)
    referenceCollider = getComponent(reference, Collider);

    getTransform(reference).method("set_localPosition").invoke([0.01, 0, 0.2]);
    reference.method("set_layer").invoke(2);
    addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
  }

  let gunLocked = false;
  let lockTarget = null;
  let GunPointer = null;
  let GunLine = null;
  function renderGun(overrideLayerMask = null) {
    const StartPosition = rightHandTransform.method("get_position").invoke();
    const Direction = rightHandTransform.method("get_forward").invoke();

    const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
    const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);

    const layerMask = overrideLayerMask || -3180559;

    const hits = Physics.method("RaycastAll", 4).invoke(
      rayStartPosition,  // origin (Vector3)
      Direction,         // direction (Vector3)
      512.0,            // maxDistance (float)
      layerMask         // layerMask (int)
    );

    let finalDistance = Infinity;
    let finalRay = null;
    for (const hit of hits) {
      const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
      if (distance < finalDistance) {
        finalRay = hit;
        finalDistance = distance;
      }
    }

    let EndPosition;
    if (gunLocked) {
      EndPosition = getTransform(lockTarget).method("get_position").invoke();
    } else {
      EndPosition = finalRay.method("get_point").invoke();
    }

    if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
      const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
      EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
    }

    if (GunPointer == null) {
      GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
    }

    GunPointer.method("SetActive").invoke(true);
    const pointerTransform = getTransform(GunPointer);
    pointerTransform.method("set_position").invoke(EndPosition);

    const PointerRenderer = getComponent(GunPointer, Renderer);
    const material = PointerRenderer.method("get_material").invoke();

    material.method("set_shader").invoke(TextShader);

    const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
    material.method("set_color").invoke(pointerColor);

    const collider = getComponent(GunPointer, Collider);
    if (collider != null) {
      Destroy(collider);
    }


    if (rightTrigger || gunLocked) {
      const Step = 10;
      for (let i = 1; i < (Step - 1); i++) {
        const t = i / (Step - 1);
        const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);

        const randomValue = Math.random();
        let offset = zeroVector;

        if (randomValue > 0.75) {
          offset = [
            (Math.random() * 0.2) - 0.1,
            (Math.random() * 0.2) - 0.1,
            (Math.random() * 0.2) - 0.1
          ];
        }

      }

    }

    return { ray: finalRay, gunPointer: GunPointer };
  }

  function recenterMenu() {
    let menuPosition = leftHandTransform.method("get_position").invoke();
    let menuRotation = leftHandTransform.method("get_rotation").invoke();

    menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0))

    const menuTransform = getTransform(menu);
    menuTransform.method("set_position").invoke(menuPosition);
    menuTransform.method("set_rotation").invoke(menuRotation);
  }

  function reloadMenu() {
    if (menu != null) {
      Object.method("Destroy", 1).invoke(menu);
      menu = null;
    }
  }

  function changeWeatherByKey(weatherName: string) {
    // Method 2: via WeatherActivator.ChangeWeatherByKey (calls ChangeWeatherByKeyRPC internally)
    const WeatherActivator = EnverGardenGame.class("Enver.Features.GameMods.PlayerMods.WeatherActivator");
    const instances = Il2Cpp.gc.choose(WeatherActivator) as any;

    for (let i = 0; i < instances.length; i++) {
      const inst = instances[i] as any;
      if (!inst || inst.isNull()) continue;
      try {
        inst.method("ChangeWeatherByKey", 1).invoke(Il2Cpp.string(weatherName));
        console.log("[Weather] ChangeWeatherByKey called on instance " + i);
      } catch (e) {
        console.log("[Weather] Error: " + e);
      }
    }
  }

  function getModEffectInstances(): any[] {
    const NetworkedModEffect = EnverGardenGame.class("Enver.Features.GameMods.PlayerMods.NetworkedModEffect");
    return Il2Cpp.gc.choose(NetworkedModEffect) as any;
  }

  function setScale(scale: number) {
    const instances = getModEffectInstances();
    for (let i = 0; i < instances.length; i++) {
      const inst = instances[i] as any;
      if (!inst || inst.isNull()) continue;
      try {
        inst.method("SetScale", 1).invoke(scale);
      } catch (e) {
        console.log("[Scale] Error: " + e);
      }
    }
  }

  function setArmScale(scale: number) {
    const instances = getModEffectInstances();
    for (let i = 0; i < instances.length; i++) {
      const inst = instances[i] as any;
      if (!inst || inst.isNull()) continue;
      try {
        inst.method("SetArmScale", 1).invoke(scale);
      } catch (e) {
        console.log("[ArmScale] Error: " + e);
      }
    }
  }

  function setInvisibility(invisible: boolean) {
    const instances = getModEffectInstances();
    for (let i = 0; i < instances.length; i++) {
      const inst = instances[i] as any;
      if (!inst || inst.isNull()) continue;
      try {
        inst.method("SetInvisibility", 2).invoke(invisible, true);
      } catch (e) {
        console.log("[Invis] Error: " + e);
      }
    }
  }

  function addCurrency(amount: number) {
    const CurrencyManagerClass = EnverGardenGame.class("Enver.Features.CurrencyManager");

    const softCurrency = CurrencyManagerClass.method("get_SoftCurrency").invoke() as any;
    const hardCurrency = CurrencyManagerClass.method("get_HardCurrency").invoke() as any;

    if (!softCurrency || softCurrency.isNull()) {
      console.log("[Currency] SoftCurrency is null");
      return;
    }

    // AddCurrency takes a UInt64
    softCurrency.method("Enver.Features.ICurrencyHandler.AddCurrency", 1).invoke(amount);
    hardCurrency.method("Enver.Features.ICurrencyHandler.AddCurrency", 1).invoke(amount);

    console.log("[Currency] Added " + amount + " to both currencies");
  }

  function updateButtonColor(button, buttonData) {
    const RendererClass = Il2Cpp.domain
      .assembly("UnityEngine.CoreModule")
      .image
      .class("UnityEngine.Renderer");

    const renderer = getComponent(button, RendererClass);
    if (!renderer) {
      return;
    }

    const material = renderer.method("get_material").invoke();
    material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
  }

  function playButtonSound() {
    PrefabAtHand("ThumpNutPlanted");
  }

  function toggleColliders(enabled) {
    const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();

    for (let i = 0; i < meshColliders.length; i++) {
      const meshCollider = meshColliders.get(i);
      meshCollider.method("set_enabled").invoke(enabled);
    }
  }

  function PrefabAtHand(prefabName: string) {
    const pos = rightHandTransform.method("get_position").invoke()
    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(prefabName), rightHandTransform.method("get_position").invoke(), rightHandTransform.method("get_rotation").invoke(), 0, NULL)
    sendAllOutgoing()
  }

  //#region  Movement

  let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
  const platColors: [number, number, number, number][] = [
    [0.0, 0.0, 0.0, 1.0],       // Black
    [9.0, 9.0, 9.0, 1.0],       // Bright white
    [9.0, 0.0, 0.0, 1.0],       // Red
    [0.0, 9.0, 0.0, 1.0],       // Green
    [0.0, 0.0, 9.0, 1.0],       // Blue
    [5.0, 5.0, 0.0, 1.0],       // Yellow
    [9.0, 0.5, 9.0, 1.0],       // Magenta
  ];
  let platL = null;
  let platR = null;
  let plater = 0;

  function Platforms() {
    if (leftGrab) {
      if (platL == null) {
        const handTransform = leftHandTransform;
        platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platL != null) {
        Destroy(platL);
        platL = null;
      }
    }

    if (rightGrab) {
      if (platR == null) {
        const handTransform = rightHandTransform;
        platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
      }
    } else {
      if (platR != null) {
        Destroy(platR);
        platR = null;
      }
    }
  }

  //#endregion

  interface ButtonInfoConfig {
    buttonText: string;
    method?: () => void;
    enableMethod?: () => void;
    disableMethod?: () => void;
    keepOn?: boolean;
    enabled?: boolean;
  }

  class ButtonInfo {
    buttonText: string;
    method?: () => void;
    enableMethod?: () => void;
    disableMethod?: () => void;
    keepOn: boolean;
    enabled: boolean;

    constructor(config: ButtonInfoConfig) {
      this.buttonText = config.buttonText;
      this.method = config.method;
      this.enableMethod = config.enableMethod;
      this.disableMethod = config.disableMethod;
      this.keepOn = config.keepOn ?? true;
      this.enabled = config.enabled ?? false;
    }
  }

  let currentCategory = 0;
  let currentPage = 0;
  let flyspeed = 5.0;

  const buttons: ButtonInfo[][] = [

    [
      // Main [0]
      new ButtonInfo({
        buttonText: "Settings",
        method: () => currentCategory = 2,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Movement",
        method: () => currentCategory = 3,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Rig",
        method: () => currentCategory = 4,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Misc",
        method: () => currentCategory = 5,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "OP",
        method: () => currentCategory = 6,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Prefab",
        method: () => currentCategory = 7,
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Effects",
        method: () => { currentCategory = 8, currentPage = 0 },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Weather",
        method: () => { currentCategory = 9, currentPage = 0 },
        keepOn: false,
      }),
    ],

    [ // Hidden [1]
      new ButtonInfo({
        buttonText: "Leave",
        method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Home",
        method: () => {
          currentCategory = 0
          currentPage = 0
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "PreviousPage",
        method: () => {
          const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

          currentPage--;
          if (currentPage < 0)
            currentPage = lastPage;
        },
        keepOn: false
      }),
      new ButtonInfo({
        buttonText: "NextPage",
        method: () => {
          const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

          currentPage++;
          currentPage %= lastPage + 1;
        },
        keepOn: false
      })
    ],

    [ // Settings
      new ButtonInfo({
        buttonText: `Fly Speed+`,
        method: () => {
          flyspeed += 1;
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: `Fly Speed-`,
        method: () => {
          flyspeed -= 1;
          reloadMenu();
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Platform Color",
        method: () => {
          plater = (plater + 1) % platColors.length;
          platColor = platColors[plater];
        },
        keepOn: false
      }),
    ],

    [ // Movement Mods
      new ButtonInfo({
        buttonText: "Fly",
        method: () => {
          if (rightSecondary) {
            const leftRightVector = rightHandTransform.method("get_forward").invoke();
            const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, flyspeed);
            rigidbody.method("set_velocity").invoke(leftForce);
          }
        },
      }),

      new ButtonInfo({
        buttonText: "Platforms [G]",
        method: () => {
          Platforms()
        },
      }),

      new ButtonInfo({
        buttonText: "No Clip",
        method: () => {
          if (rightTrigger && !previousNoclipKey) {
            toggleColliders(false);
          }

          if (!rightTrigger && previousNoclipKey) {
            toggleColliders(true);
          }

          previousNoclipKey = rightTrigger;
        },
      }),
    ],
    [ // Rig
      new ButtonInfo({ buttonText: "Giant", method: () => setScale(5.0), keepOn: false }),
      new ButtonInfo({ buttonText: "Tiny", method: () => setScale(0.1), keepOn: false }),
      new ButtonInfo({ buttonText: "Normal Size", method: () => setScale(1.0), keepOn: false }),
      new ButtonInfo({ buttonText: "Big Arms", method: () => setArmScale(5.0), keepOn: false }),
      new ButtonInfo({ buttonText: "Tiny Arms", method: () => setArmScale(0.1), keepOn: false }),
      new ButtonInfo({ buttonText: "Normal Arms", method: () => setArmScale(1.0), keepOn: false }),
      new ButtonInfo({ buttonText: "Invisible", method: () => setInvisibility(true), keepOn: false }),
      new ButtonInfo({ buttonText: "Visible", method: () => setInvisibility(false), keepOn: false }),
    ],
    [ // Misc Mods
      new ButtonInfo({
        buttonText: "Open Staff",
        method: () => {
          try {
            // Disable the staff door
            const door = GameObject.method("Find").invoke(Il2Cpp.string("StaffRooomDoors")) as any;
            if (door && !door.isNull()) {
              Destroy(door);
              console.log("[StaffRoom] Door destroyed");
            }

            const staffControllers = Object.method("FindObjectsOfType")
              .inflate(EnverGardenGame.class("Enver.Features.StaffManagement.StaffAccessController"))
              .invoke() as any;

            for (let i = 0; i < staffControllers.length; i++) {
              (staffControllers.get(i) as any).method("SetStaffDoors").invoke();
            }

            // Enable barn and weapons
            const eventsGo = GameObject.method("Find").invoke(Il2Cpp.string("Events")) as any;
            const eventsTf = eventsGo.method("get_transform").invoke() as any;
            const staffRoomTf = eventsTf.method("Find").invoke(Il2Cpp.string("Staff_Room")) as any;
            staffRoomTf.method("get_gameObject").invoke().method("SetActive").invoke(true);

            const barnTf = staffRoomTf.method("Find").invoke(Il2Cpp.string("Staff_Room_barn")) as any;
            barnTf.method("get_gameObject").invoke().method("SetActive").invoke(true);

            const weapons = ["Staff_Room_missile_launcher", "Staff_Room_revolver", "Staff_Room_hammer"];
            for (const name of weapons) {
              const tf = barnTf.method("Find").invoke(Il2Cpp.string(name)) as any;
              if (tf && !tf.isNull()) {
                tf.method("get_gameObject").invoke().method("SetActive").invoke(true);
                console.log("[StaffRoom] Enabled: " + name);
              }
            }

          } catch (e) {
            console.log("[StaffRoom] Error: " + e);
          }
        },
        keepOn: false,
      }),
      new ButtonInfo({ buttonText: "Add 1000 Coins", method: () => addCurrency(1000), keepOn: false }),
      new ButtonInfo({ buttonText: "Add 5000 Coins", method: () => addCurrency(5000), keepOn: false }),
      new ButtonInfo({ buttonText: "Add 10000 Coins", method: () => addCurrency(10000), keepOn: false }),
      new ButtonInfo({ buttonText: "Add MAX Coins", method: () => addCurrency(9223372036854775807), keepOn: false }),

      new ButtonInfo({
        buttonText: "J0kerModZ Name",
        method: () => {
          const name = "<size=30><sprite=12>J0kerModZ<sprite=12>"
          PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Buy All Shop Items",
        method: () => {
          const ShopRestockManagerClass = EnverGardenGame.class("Enver.Features.Shop.ShopRestockManager");
          const instances = Il2Cpp.gc.choose(ShopRestockManagerClass) as any;
          console.log("[Shop] Found " + instances.length + " instances");

          for (let i = 0; i < instances.length; i++) {
            const inst = instances[i] as any;
            if (!inst || inst.isNull()) continue;

            try {
              const items = inst.field("_items").value as any;
              const count = items.method("get_Count").invoke() as number;
              console.log("[Shop] Instance " + i + " has " + count + " items");

              for (let j = 0; j < count; j++) {
                try {
                  const item = items.method("get_Item").invoke(j) as any;
                  if (!item || item.isNull()) continue;

                  const name = item.method("get_ItemName").invoke();
                  const price = item.method("get_ItemPrice").invoke();
                  console.log("[Shop] Item " + j + ": " + name + " | price: " + price);

                  // Call TryPurchase(item, spawnPoint)
                  const spawnPoint = inst.field("_spawnPoint").value as any;
                  inst.method("TryPurchase", 2).invoke(item, spawnPoint);
                  console.log("[Shop] Purchased: " + name);
                } catch (e) {
                  console.log("[Shop] Error on item " + j + ": " + e);
                }
              }
            } catch (e) {
              console.log("[Shop] Error on instance " + i + ": " + e);
            }
          }
        },
        keepOn: false,
      }),
    ],
    [ // OP Mods
      new ButtonInfo({
        buttonText: "Set Master",
        method: () => {
          PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Destroy All",
        method: () => {
          const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
          if (others && others.length > 0) {
            for (let i = 0; i < others.length; i++) {
              const player = others.get(i);
              PhotonNetwork.method("DestroyPlayerObjects").invoke(player);
            }
          }
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Crash All",
        method: () => {
          for (let i = 0; i < 1500; i++) {
            const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("specialitems/BoomboxItem"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
            Destroy(thingforlag)
          }
          sendAllOutgoing()
        },
        keepOn: false,
      }),

      new ButtonInfo({
        buttonText: "Lag All",
        method: () => {
          for (let i = 0; i < 4000; i++) {

            const now = Date.now();
            if (now - lastRunTime >= 0.1) {
              lastRunTime = now;
              const pos = rightHandTransform.method("get_position").invoke();
              const chaos = [
                "specialitems/BoomboxItem", "specialitems/ArmyGrenadeItem", "specialitems/BasePotionItem", "specialitems/GrapplingHookItem", "specialitems/HighJumpPotionItem Variant",
                "specialitems/MolotovItem", "specialitems/PaintBombItem", "specialitems/ShurikenIce Variant", "specialitems/SpecialShovel",
                "moditems/NukeMissile", "staffitems/RocketLauncherItem"
              ];
              const item = chaos[Math.floor(Math.random() * chaos.length)];
              const chaosPos = [
                pos[0] + (Math.random() - 0.5) * 8,
                pos[1] + (Math.random() - 0.5) * 4,
                pos[2] + (Math.random() - 0.5) * 8
              ];
              const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(item), chaosPos, identityQuaternion, 0, NULL);
              Destroy(thingforlag)
              try { } catch (_) { }
            }
          }
        },
        keepOn: false,
      }),
    ],
    [ // Prefabs      
      new ButtonInfo({
        buttonText: "BoomboxItem",
        method: () => {
          PrefabAtHand("specialitems/BoomboxItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "ArmyGrenadeItem",
        method: () => {
          PrefabAtHand("specialitems/ArmyGrenadeItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "BaseBlock",
        method: () => {
          PrefabAtHand("specialitems/BaseBlock")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "BasePlacedBlock",
        method: () => {
          PrefabAtHand("specialitems/BasePlacedBlock")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "BasePotionItem",
        method: () => {
          PrefabAtHand("specialitems/BasePotionItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "BoopBatItem",
        method: () => {
          PrefabAtHand("specialitems/BoopBatItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "CrazyPotionItemVariant",
        method: () => {
          PrefabAtHand("specialitems/CrazyPotionItemVariant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "CrossBowItem",
        method: () => {
          PrefabAtHand("specialitems/CrossBowItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "DirtySnowBallItem",
        method: () => {
          PrefabAtHand("specialitems/DirtySnowBallItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "GrapplingHookItem",
        method: () => {
          PrefabAtHand("specialitems/GrapplingHookItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "HighJumpPotionItem Variant",
        method: () => {
          PrefabAtHand("specialitems/HighJumpPotionItem Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "InvisiblePotionItem Variant",
        method: () => {
          PrefabAtHand("specialitems/InvisiblePotionItem Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "MolotovItem",
        method: () => {
          PrefabAtHand("specialitems/MolotovItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "MolotovItemUltimate Variant",
        method: () => {
          PrefabAtHand("specialitems/MolotovItemUltimate Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "MolotovItemUltra Variant",
        method: () => {
          PrefabAtHand("specialitems/MolotovItemUltra Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "PaintBombItem",
        method: () => {
          PrefabAtHand("specialitems/PaintBombItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "PetHouse",
        method: () => {
          PrefabAtHand("specialitems/PetHouse")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Shuriken2 Variant",
        method: () => {
          PrefabAtHand("specialitems/Shuriken2 Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Shuriken3 Variant",
        method: () => {
          PrefabAtHand("specialitems/Shuriken3 Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "ShurikenBaseItem",
        method: () => {
          PrefabAtHand("specialitems/ShurikenBaseItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "ShurikenIce Variant",
        method: () => {
          PrefabAtHand("specialitems/ShurikenIce Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "ShurikenPyro Variant",
        method: () => {
          PrefabAtHand("specialitems/ShurikenPyro Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "SkateBoardItem",
        method: () => {
          PrefabAtHand("specialitems/SkateBoardItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "SnowBallItem",
        method: () => {
          PrefabAtHand("specialitems/SnowBallItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "SpecialShovel",
        method: () => {
          PrefabAtHand("specialitems/SpecialShovel")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "StickyGrenadeItem",
        method: () => {
          PrefabAtHand("specialitems/StickyGrenadeItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "TomatoTrampolineItem",
        method: () => {
          PrefabAtHand("specialitems/TomatoTrampolineItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "TrampolineItem",
        method: () => {
          PrefabAtHand("specialitems/TrampolineItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "WoodySkateBoardItem",
        method: () => {
          PrefabAtHand("specialitems/WoodySkateBoardItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Nuke Missile",
        method: () => {
          PrefabAtHand("moditems/NukeMissile")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "JetSki",
        method: () => {
          PrefabAtHand("vehicles/JetSki")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "SpaceCar",
        method: () => {
          PrefabAtHand("vehicles/SpaceCar Variant")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Tractor",
        method: () => {
          PrefabAtHand("vehicles/Tractor")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Kick Hammer",
        method: () => {
          PrefabAtHand("staffitems/KickHammerItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "RPG",
        method: () => {
          PrefabAtHand("staffitems/RocketLauncherItem")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Staff Gun",
        method: () => {
          PrefabAtHand("staffitems/StaffGunItem")
        },
        keepOn: false,
      }),
    ],
    [ // Effects
      new ButtonInfo({
        buttonText: "BreakBlock",
        method: () => {
          PrefabAtHand("BreakBlock")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "Dink",
        method: () => {
          PrefabAtHand("Dink")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "FlintRootPlanted",
        method: () => {
          PrefabAtHand("FlintRootPlanted")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "PlantedAnimation",
        method: () => {
          PrefabAtHand("PlantedAnimation")
        },
        keepOn: false,
      }),
      new ButtonInfo({
        buttonText: "ThumpNutPlanted",
        method: () => {
          PrefabAtHand("ThumpNutPlanted")
        },
        keepOn: false,
      }),
    ],
    [ // Event
      new ButtonInfo({ buttonText: "Rain", method: () => changeWeatherByKey("Rain"), keepOn: false }),
      new ButtonInfo({ buttonText: "Snow", method: () => changeWeatherByKey("Snow"), keepOn: false }),
      new ButtonInfo({ buttonText: "Volcano", method: () => changeWeatherByKey("Volcano"), keepOn: false }),
      new ButtonInfo({ buttonText: "Wavy", method: () => changeWeatherByKey("Wavy"), keepOn: false }),
      new ButtonInfo({ buttonText: "Blood Moon", method: () => changeWeatherByKey("BloodMoon"), keepOn: false }),
      new ButtonInfo({ buttonText: "Disco", method: () => changeWeatherByKey("Disco"), keepOn: false }),
    ]
  ];

  let buttonMap: Map<string, ButtonInfo> = new Map();
  buttons.flat().forEach(button => {
    buttonMap.set(button.buttonText, button);
  });

  function getIndex(buttonText: string): ButtonInfo {
    return buttonMap.get(buttonText);
  }

  const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
  ButtonActivation.implementation = function (collider) {
    const rawName = this.method("get_name").invoke().toString();

    if (rawName.length > 1 && rawName[1] == "@") {
      if (collider.handle.equals(referenceCollider.handle)) {
        const goName = rawName.substring(2, rawName.length - 1);
        const _time = Time.method("get_time").invoke();

        if (_time > buttonClickDelay) {
          buttonClickDelay = _time + 0.2;

          const button = getIndex(goName)
          if (button) {
            if (button.keepOn) {
              button.enabled = !button.enabled;

              if (button?.enabled) {
                button.enableMethod?.();
              } else {
                button?.disableMethod?.();
              }

            } else {
              button?.method?.();
            }

            reloadMenu();
            playButtonSound();
          }
        }
      }

      return;
    }

    return this.method("OnTriggerEnter").invoke(collider);
  };

  const LateUpdate = GorillaTagger.method("LateUpdate");

  LateUpdate.implementation = function () {

    OVRInputHandler.update();

    leftPrimary = OVRInputHandler.leftControllerPrimaryButton
    leftSecondary = OVRInputHandler.leftControllerSecondaryButton;

    rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
    rightSecondary = OVRInputHandler.rightControllerSecondaryButton;

    leftGrab = OVRInputHandler.leftGrab;
    rightGrab = OVRInputHandler.rightGrab;

    leftTrigger = OVRInputHandler.leftControllerTriggerButton;
    rightTrigger = OVRInputHandler.rightControllerTriggerButton;

    deltaTime = Time.method("get_deltaTime").invoke();
    time = Time.method("get_time").invoke();

    if (leftGrab) {
      if (menu == null) {
        renderMenu();
      } else {
        recenterMenu();
      }
    } else {
      if (menu != null) {
        Destroy(menu);
        menu = null;
      }
    }

    if (menu == null) {
      if (reference != null) {
        Destroy(reference);
        reference = null;
      }
    } else {
      if (reference == null) {
        renderReference();
      }
    }

    try {
      if (GunPointer != null) {
        if (!(GunPointer.method("get_activeSelf").invoke())) {
          Destroy(GunPointer);
          GunPointer = null;
        }
        else
          GunPointer.method("SetActive").invoke(false);
      }

      let lineObj = GunLine.method("get_gameObject").invoke();
      if (lineObj != null) {
        if (!(lineObj.method("get_activeSelf").invoke())) {
          Destroy(lineObj);
          GunLine = null;
        }
        else
          lineObj.method("SetActive").invoke(false);
      }
    } catch { }

    buttons.flat()
      .filter(button => button.enabled)
      .forEach(button => {
        if (button.method) {
          try {
            button.method();
          } catch (error) {
            console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
            console.error('Error stack:', error.stack);
            console.error('Button object:', button);

            if (error.stack) {
              const stackLines = error.stack.split('\n');
              if (stackLines.length > 1) {
                console.error('Error occurred at:', stackLines[1].trim());
              }
            }
          }
        }
      });

    return LateUpdate.invoke();
  };
  console.log(`Compiled ${new Date().toISOString()}`);

}, "main");