declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const send: any;
declare const recv: any;

let rigidbody = null

let thingforfling = null

let hue = 0;

let lastRunTime = 0;
const strobecooldown = 300;
const rgbcooldown = 300;
const destroycooldown = 250;

let playerScale = 1.0;

let invisible = false

let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let previousGhostKey = false;
let previousInvisKey = false;
let previousNoclipKey = false;
let perviousTeleportKey = false;

let closePosition = null;
let tagGunDelay = 0.0;

let leftPlatform = null;
let rightPlatform = null;

let lastKickTime = 0;
let frozenTargets: number[] = [];

let lvT = null;
let rvT = null;



let bgColor: [number, number, number, number] = [0.035, 0.008, 0.055, 1.0];
let bgColor2: [number, number, number, number] = [0.16, 0.045, 0.26, 1.0];

let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];
let textPressedColor: [number, number, number, number] = [1.0, 0.55, 0.85, 1.0];

let buttonColor: [number, number, number, number] = [0.10, 0.025, 0.17, 1.0];
let buttonPressedColor: [number, number, number, number] = [1.0, 0.3, 0.72, 1.0];

let accentColor: [number, number, number, number] = [1.0, 0.32, 0.85, 1.0];
let accentCornerColor: [number, number, number, number] = [1.0, 0.62, 0.95, 1.0];

Il2Cpp.$config.exports = {
	il2cpp_init: () => Il2Cpp.module.findExportByName("il2cpp_init"),
	il2cpp_init_utf16: () => Il2Cpp.module.findExportByName("il2cpp_init_utf16"),
	il2cpp_shutdown: () => Il2Cpp.module.findExportByName("il2cpp_shutdown"),
	il2cpp_set_config_dir: () => Il2Cpp.module.findExportByName("il2cpp_set_config_dir"),
	il2cpp_set_data_dir: () => Il2Cpp.module.findExportByName("il2cpp_set_data_dir"),
	il2cpp_set_temp_dir: () => Il2Cpp.module.findExportByName("il2cpp_set_temp_dir"),
	il2cpp_set_commandline_arguments: () => Il2Cpp.module.findExportByName("il2cpp_set_commandline_arguments"),
	il2cpp_set_commandline_arguments_utf16: () => Il2Cpp.module.findExportByName("il2cpp_set_commandline_arguments_utf16"),
	il2cpp_set_config_utf16: () => Il2Cpp.module.findExportByName("il2cpp_set_config_utf16"),
	il2cpp_set_config: () => Il2Cpp.module.findExportByName("il2cpp_set_config"),
	il2cpp_set_memory_callbacks: () => Il2Cpp.module.findExportByName("il2cpp_set_memory_callbacks"),
	il2cpp_memory_pool_set_region_size: () => Il2Cpp.module.findExportByName("il2cpp_memory_pool_set_region_size"),
	il2cpp_memory_pool_get_region_size: () => Il2Cpp.module.findExportByName("il2cpp_memory_pool_get_region_size"),
	il2cpp_get_corlib: () => Il2Cpp.module.findExportByName("il2cpp_get_corlib"),
	il2cpp_add_internal_call: () => Il2Cpp.module.findExportByName("il2cpp_add_internal_call"),
	il2cpp_resolve_icall: () => Il2Cpp.module.findExportByName("il2cpp_resolve_icall"),
	il2cpp_alloc: () => Il2Cpp.module.findExportByName("il2cpp_alloc"),
	il2cpp_free: () => Il2Cpp.module.findExportByName("il2cpp_free"),
	il2cpp_array_class_get: () => Il2Cpp.module.findExportByName("il2cpp_array_class_get"),
	il2cpp_array_length: () => Il2Cpp.module.findExportByName("il2cpp_array_length"),
	il2cpp_array_get_byte_length: () => Il2Cpp.module.findExportByName("il2cpp_array_get_byte_length"),
	il2cpp_array_new: () => Il2Cpp.module.findExportByName("il2cpp_array_new"),
	il2cpp_array_new_specific: () => Il2Cpp.module.findExportByName("il2cpp_array_new_specific"),
	il2cpp_array_new_full: () => Il2Cpp.module.findExportByName("il2cpp_array_new_full"),
	il2cpp_bounded_array_class_get: () => Il2Cpp.module.findExportByName("il2cpp_bounded_array_class_get"),
	il2cpp_array_element_size: () => Il2Cpp.module.findExportByName("il2cpp_array_element_size"),
	il2cpp_assembly_get_image: () => Il2Cpp.module.findExportByName("il2cpp_assembly_get_image"),
	il2cpp_class_enum_basetype: () => Il2Cpp.module.findExportByName("il2cpp_class_enum_basetype"),
	il2cpp_class_from_system_type: () => Il2Cpp.module.findExportByName("il2cpp_class_from_system_type"),
	il2cpp_class_is_inited: () => Il2Cpp.module.findExportByName("il2cpp_class_is_inited"),
	il2cpp_class_is_generic: () => Il2Cpp.module.findExportByName("il2cpp_class_is_generic"),
	il2cpp_class_is_inflated: () => Il2Cpp.module.findExportByName("il2cpp_class_is_inflated"),
	il2cpp_class_is_assignable_from: () => Il2Cpp.module.findExportByName("il2cpp_class_is_assignable_from"),
	il2cpp_class_is_subclass_of: () => Il2Cpp.module.findExportByName("il2cpp_class_is_subclass_of"),
	il2cpp_class_has_parent: () => Il2Cpp.module.findExportByName("il2cpp_class_has_parent"),
	il2cpp_class_from_il2cpp_type: () => Il2Cpp.module.findExportByName("il2cpp_class_from_il2cpp_type"),
	il2cpp_class_from_name: () => Il2Cpp.module.findExportByName("il2cpp_class_from_name"),
	il2cpp_class_get_element_class: () => Il2Cpp.module.findExportByName("il2cpp_class_get_element_class"),
	il2cpp_class_get_events: () => Il2Cpp.module.findExportByName("il2cpp_class_get_events"),
	il2cpp_class_get_fields: () => Il2Cpp.module.findExportByName("il2cpp_class_get_fields"),
	il2cpp_class_get_nested_types: () => Il2Cpp.module.findExportByName("il2cpp_class_get_nested_types"),
	il2cpp_class_get_interfaces: () => Il2Cpp.module.findExportByName("il2cpp_class_get_interfaces"),
	il2cpp_class_get_properties: () => Il2Cpp.module.findExportByName("il2cpp_class_get_properties"),
	il2cpp_class_get_property_from_name: () => Il2Cpp.module.findExportByName("il2cpp_class_get_property_from_name"),
	il2cpp_class_get_field_from_name: () => Il2Cpp.module.findExportByName("il2cpp_class_get_field_from_name"),
	il2cpp_class_get_methods: () => Il2Cpp.module.findExportByName("il2cpp_class_get_methods"),
	il2cpp_class_get_method_from_name: () => Il2Cpp.module.findExportByName("il2cpp_class_get_method_from_name"),
	il2cpp_class_get_name: () => Il2Cpp.module.findExportByName("il2cpp_class_get_name"),
	il2cpp_class_get_namespace: () => Il2Cpp.module.findExportByName("il2cpp_class_get_namespace"),
	il2cpp_class_get_parent: () => Il2Cpp.module.findExportByName("il2cpp_class_get_parent"),
	il2cpp_class_get_declaring_type: () => Il2Cpp.module.findExportByName("il2cpp_class_get_declaring_type"),
	il2cpp_class_instance_size: () => Il2Cpp.module.findExportByName("il2cpp_class_instance_size"),
	il2cpp_class_num_fields: () => Il2Cpp.module.findExportByName("il2cpp_class_num_fields"),
	il2cpp_class_is_valuetype: () => Il2Cpp.module.findExportByName("il2cpp_class_is_valuetype"),
	il2cpp_class_is_blittable: () => Il2Cpp.module.findExportByName("il2cpp_class_is_blittable"),
	il2cpp_class_value_size: () => Il2Cpp.module.findExportByName("il2cpp_class_value_size"),
	il2cpp_class_get_flags: () => Il2Cpp.module.findExportByName("il2cpp_class_get_flags"),
	il2cpp_class_is_abstract: () => Il2Cpp.module.findExportByName("il2cpp_class_is_abstract"),
	il2cpp_class_is_interface: () => Il2Cpp.module.findExportByName("il2cpp_class_is_interface"),
	il2cpp_class_array_element_size: () => Il2Cpp.module.findExportByName("il2cpp_class_array_element_size"),
	il2cpp_class_from_type: () => Il2Cpp.module.findExportByName("il2cpp_class_from_type"),
	il2cpp_class_get_type: () => Il2Cpp.module.findExportByName("il2cpp_class_get_type"),
	il2cpp_class_get_type_token: () => Il2Cpp.module.findExportByName("il2cpp_class_get_type_token"),
	il2cpp_class_has_attribute: () => Il2Cpp.module.findExportByName("il2cpp_class_has_attribute"),
	il2cpp_class_has_references: () => Il2Cpp.module.findExportByName("il2cpp_class_has_references"),
	il2cpp_class_is_enum: () => Il2Cpp.module.findExportByName("il2cpp_class_is_enum"),
	il2cpp_class_get_image: () => Il2Cpp.module.findExportByName("il2cpp_class_get_image"),
	il2cpp_class_get_assemblyname: () => Il2Cpp.module.findExportByName("il2cpp_class_get_assemblyname"),
	il2cpp_class_get_rank: () => Il2Cpp.module.findExportByName("il2cpp_class_get_rank"),
	il2cpp_class_get_data_size: () => Il2Cpp.module.findExportByName("il2cpp_class_get_data_size"),
	il2cpp_class_get_static_field_data: () => Il2Cpp.module.findExportByName("il2cpp_class_get_static_field_data"),
	il2cpp_stats_dump_to_file: () => Il2Cpp.module.findExportByName("il2cpp_stats_dump_to_file"),
	il2cpp_stats_get_value: () => Il2Cpp.module.findExportByName("il2cpp_stats_get_value"),
	il2cpp_domain_get: () => Il2Cpp.module.findExportByName("il2cpp_domain_get"),
	il2cpp_domain_assembly_open: () => Il2Cpp.module.findExportByName("il2cpp_domain_assembly_open"),
	il2cpp_domain_get_assemblies: () => Il2Cpp.module.findExportByName("il2cpp_domain_get_assemblies"),
	il2cpp_raise_exception: () => Il2Cpp.module.findExportByName("il2cpp_raise_exception"),
	il2cpp_exception_from_name_msg: () => Il2Cpp.module.findExportByName("il2cpp_exception_from_name_msg"),
	il2cpp_get_exception_argument_null: () => Il2Cpp.module.findExportByName("il2cpp_get_exception_argument_null"),
	il2cpp_format_exception: () => Il2Cpp.module.findExportByName("il2cpp_format_exception"),
	il2cpp_format_stack_trace: () => Il2Cpp.module.findExportByName("il2cpp_format_stack_trace"),
	il2cpp_unhandled_exception: () => Il2Cpp.module.findExportByName("il2cpp_unhandled_exception"),
	il2cpp_native_stack_trace: () => Il2Cpp.module.findExportByName("il2cpp_native_stack_trace"),
	il2cpp_field_get_name: () => Il2Cpp.module.findExportByName("il2cpp_field_get_name"),
	il2cpp_field_get_flags: () => Il2Cpp.module.findExportByName("il2cpp_field_get_flags"),
	il2cpp_field_get_from_reflection: () => Il2Cpp.module.findExportByName("il2cpp_field_get_from_reflection"),
	il2cpp_field_get_parent: () => Il2Cpp.module.findExportByName("il2cpp_field_get_parent"),
	il2cpp_field_get_object: () => Il2Cpp.module.findExportByName("il2cpp_field_get_object"),
	il2cpp_field_get_offset: () => Il2Cpp.module.findExportByName("il2cpp_field_get_offset"),
	il2cpp_field_get_type: () => Il2Cpp.module.findExportByName("il2cpp_field_get_type"),
	il2cpp_field_get_value: () => Il2Cpp.module.findExportByName("il2cpp_field_get_value"),
	il2cpp_field_get_value_object: () => Il2Cpp.module.findExportByName("il2cpp_field_get_value_object"),
	il2cpp_field_has_attribute: () => Il2Cpp.module.findExportByName("il2cpp_field_has_attribute"),
	il2cpp_field_set_value: () => Il2Cpp.module.findExportByName("il2cpp_field_set_value"),
	il2cpp_field_set_value_object: () => Il2Cpp.module.findExportByName("il2cpp_field_set_value_object"),
	il2cpp_field_static_get_value: () => Il2Cpp.module.findExportByName("il2cpp_field_static_get_value"),
	il2cpp_field_static_set_value: () => Il2Cpp.module.findExportByName("il2cpp_field_static_set_value"),
	il2cpp_field_is_literal: () => Il2Cpp.module.findExportByName("il2cpp_field_is_literal"),
	il2cpp_gc_collect: () => Il2Cpp.module.findExportByName("il2cpp_gc_collect"),
	il2cpp_gc_collect_a_little: () => Il2Cpp.module.findExportByName("il2cpp_gc_collect_a_little"),
	il2cpp_gc_start_incremental_collection: () => Il2Cpp.module.findExportByName("il2cpp_gc_start_incremental_collection"),
	il2cpp_gc_enable: () => Il2Cpp.module.findExportByName("il2cpp_gc_enable"),
	il2cpp_gc_disable: () => Il2Cpp.module.findExportByName("il2cpp_gc_disable"),
	il2cpp_gc_is_disabled: () => Il2Cpp.module.findExportByName("il2cpp_gc_is_disabled"),
	il2cpp_gc_set_mode: () => Il2Cpp.module.findExportByName("il2cpp_gc_set_mode"),
	il2cpp_gc_is_incremental: () => Il2Cpp.module.findExportByName("il2cpp_gc_is_incremental"),
	il2cpp_gc_get_max_time_slice_ns: () => Il2Cpp.module.findExportByName("il2cpp_gc_get_max_time_slice_ns"),
	il2cpp_gc_set_max_time_slice_ns: () => Il2Cpp.module.findExportByName("il2cpp_gc_set_max_time_slice_ns"),
	il2cpp_gc_get_used_size: () => Il2Cpp.module.findExportByName("il2cpp_gc_get_used_size"),
	il2cpp_gc_get_heap_size: () => Il2Cpp.module.findExportByName("il2cpp_gc_get_heap_size"),
	il2cpp_gc_foreach_heap: () => Il2Cpp.module.findExportByName("il2cpp_gc_foreach_heap"),
	il2cpp_stop_gc_world: () => Il2Cpp.module.findExportByName("il2cpp_stop_gc_world"),
	il2cpp_start_gc_world: () => Il2Cpp.module.findExportByName("il2cpp_start_gc_world"),
	il2cpp_gc_alloc_fixed: () => Il2Cpp.module.findExportByName("il2cpp_gc_alloc_fixed"),
	il2cpp_gc_free_fixed: () => Il2Cpp.module.findExportByName("il2cpp_gc_free_fixed"),
	il2cpp_gchandle_new: () => Il2Cpp.module.findExportByName("il2cpp_gchandle_new"),
	il2cpp_gchandle_new_weakref: () => Il2Cpp.module.findExportByName("il2cpp_gchandle_new_weakref"),
	il2cpp_gchandle_get_target: () => Il2Cpp.module.findExportByName("il2cpp_gchandle_get_target"),
	il2cpp_gchandle_foreach_get_target: () => Il2Cpp.module.findExportByName("il2cpp_gchandle_foreach_get_target"),
	il2cpp_gc_wbarrier_set_field: () => Il2Cpp.module.findExportByName("il2cpp_gc_wbarrier_set_field"),
	il2cpp_gc_has_strict_wbarriers: () => Il2Cpp.module.findExportByName("il2cpp_gc_has_strict_wbarriers"),
	il2cpp_gc_set_external_allocation_tracker: () => Il2Cpp.module.findExportByName("il2cpp_gc_set_external_allocation_tracker"),
	il2cpp_gc_set_external_wbarrier_tracker: () => Il2Cpp.module.findExportByName("il2cpp_gc_set_external_wbarrier_tracker"),
	il2cpp_gchandle_free: () => Il2Cpp.module.findExportByName("il2cpp_gchandle_free"),
	il2cpp_object_header_size: () => Il2Cpp.module.findExportByName("il2cpp_object_header_size"),
	il2cpp_array_object_header_size: () => Il2Cpp.module.findExportByName("il2cpp_array_object_header_size"),
	il2cpp_offset_of_array_length_in_array_object_header: () => Il2Cpp.module.findExportByName("il2cpp_offset_of_array_length_in_array_object_header"),
	il2cpp_offset_of_array_bounds_in_array_object_header: () => Il2Cpp.module.findExportByName("il2cpp_offset_of_array_bounds_in_array_object_header"),
	il2cpp_allocation_granularity: () => Il2Cpp.module.findExportByName("il2cpp_allocation_granularity"),
	il2cpp_unity_liveness_allocate_struct: () => Il2Cpp.module.findExportByName("il2cpp_unity_liveness_allocate_struct"),
	il2cpp_unity_liveness_calculation_from_root: () => Il2Cpp.module.findExportByName("il2cpp_unity_liveness_calculation_from_root"),
	il2cpp_unity_liveness_calculation_from_statics: () => Il2Cpp.module.findExportByName("il2cpp_unity_liveness_calculation_from_statics"),
	il2cpp_unity_liveness_finalize: () => Il2Cpp.module.findExportByName("il2cpp_unity_liveness_finalize"),
	il2cpp_unity_liveness_free_struct: () => Il2Cpp.module.findExportByName("il2cpp_unity_liveness_free_struct"),
	il2cpp_method_get_return_type: () => Il2Cpp.module.findExportByName("il2cpp_method_get_return_type"),
	il2cpp_method_get_from_reflection: () => Il2Cpp.module.findExportByName("il2cpp_method_get_from_reflection"),
	il2cpp_method_get_object: () => Il2Cpp.module.findExportByName("il2cpp_method_get_object"),
	il2cpp_method_get_name: () => Il2Cpp.module.findExportByName("il2cpp_method_get_name"),
	il2cpp_method_is_generic: () => Il2Cpp.module.findExportByName("il2cpp_method_is_generic"),
	il2cpp_method_is_inflated: () => Il2Cpp.module.findExportByName("il2cpp_method_is_inflated"),
	il2cpp_method_is_instance: () => Il2Cpp.module.findExportByName("il2cpp_method_is_instance"),
	il2cpp_method_get_param_count: () => Il2Cpp.module.findExportByName("il2cpp_method_get_param_count"),
	il2cpp_method_get_param: () => Il2Cpp.module.findExportByName("il2cpp_method_get_param"),
	il2cpp_method_get_class: () => Il2Cpp.module.findExportByName("il2cpp_method_get_class"),
	il2cpp_method_has_attribute: () => Il2Cpp.module.findExportByName("il2cpp_method_has_attribute"),
	il2cpp_method_get_declaring_type: () => Il2Cpp.module.findExportByName("il2cpp_method_get_declaring_type"),
	il2cpp_method_get_flags: () => Il2Cpp.module.findExportByName("il2cpp_method_get_flags"),
	il2cpp_method_get_token: () => Il2Cpp.module.findExportByName("il2cpp_method_get_token"),
	il2cpp_method_get_param_name: () => Il2Cpp.module.findExportByName("il2cpp_method_get_param_name"),
	il2cpp_profiler_install: () => Il2Cpp.module.findExportByName("il2cpp_profiler_install"),
	il2cpp_profiler_set_events: () => Il2Cpp.module.findExportByName("il2cpp_profiler_set_events"),
	il2cpp_profiler_install_enter_leave: () => Il2Cpp.module.findExportByName("il2cpp_profiler_install_enter_leave"),
	il2cpp_profiler_install_allocation: () => Il2Cpp.module.findExportByName("il2cpp_profiler_install_allocation"),
	il2cpp_profiler_install_gc: () => Il2Cpp.module.findExportByName("il2cpp_profiler_install_gc"),
	il2cpp_profiler_install_fileio: () => Il2Cpp.module.findExportByName("il2cpp_profiler_install_fileio"),
	il2cpp_profiler_install_thread: () => Il2Cpp.module.findExportByName("il2cpp_profiler_install_thread"),
	il2cpp_property_get_name: () => Il2Cpp.module.findExportByName("il2cpp_property_get_name"),
	il2cpp_property_get_get_method: () => Il2Cpp.module.findExportByName("il2cpp_property_get_get_method"),
	il2cpp_property_get_set_method: () => Il2Cpp.module.findExportByName("il2cpp_property_get_set_method"),
	il2cpp_property_get_parent: () => Il2Cpp.module.findExportByName("il2cpp_property_get_parent"),
	il2cpp_property_get_flags: () => Il2Cpp.module.findExportByName("il2cpp_property_get_flags"),
	il2cpp_object_get_class: () => Il2Cpp.module.findExportByName("il2cpp_object_get_class"),
	il2cpp_object_get_size: () => Il2Cpp.module.findExportByName("il2cpp_object_get_size"),
	il2cpp_object_get_virtual_method: () => Il2Cpp.module.findExportByName("il2cpp_object_get_virtual_method"),
	il2cpp_object_new: () => Il2Cpp.module.findExportByName("il2cpp_object_new"),
	il2cpp_object_unbox: () => Il2Cpp.module.findExportByName("il2cpp_object_unbox"),
	il2cpp_value_box: () => Il2Cpp.module.findExportByName("il2cpp_value_box"),
	il2cpp_monitor_enter: () => Il2Cpp.module.findExportByName("il2cpp_monitor_enter"),
	il2cpp_monitor_try_enter: () => Il2Cpp.module.findExportByName("il2cpp_monitor_try_enter"),
	il2cpp_monitor_exit: () => Il2Cpp.module.findExportByName("il2cpp_monitor_exit"),
	il2cpp_monitor_pulse: () => Il2Cpp.module.findExportByName("il2cpp_monitor_pulse"),
	il2cpp_monitor_pulse_all: () => Il2Cpp.module.findExportByName("il2cpp_monitor_pulse_all"),
	il2cpp_monitor_wait: () => Il2Cpp.module.findExportByName("il2cpp_monitor_wait"),
	il2cpp_monitor_try_wait: () => Il2Cpp.module.findExportByName("il2cpp_monitor_try_wait"),
	il2cpp_runtime_invoke_convert_args: () => Il2Cpp.module.findExportByName("il2cpp_runtime_invoke_convert_args"),
	il2cpp_runtime_invoke: () => Il2Cpp.module.findExportByName("il2cpp_runtime_invoke"),
	il2cpp_runtime_class_init: () => Il2Cpp.module.findExportByName("il2cpp_runtime_class_init"),
	il2cpp_runtime_object_init: () => Il2Cpp.module.findExportByName("il2cpp_runtime_object_init"),
	il2cpp_runtime_object_init_exception: () => Il2Cpp.module.findExportByName("il2cpp_runtime_object_init_exception"),
	il2cpp_runtime_unhandled_exception_policy_set: () => Il2Cpp.module.findExportByName("il2cpp_runtime_unhandled_exception_policy_set"),
	il2cpp_string_length: () => Il2Cpp.module.findExportByName("il2cpp_string_length"),
	il2cpp_string_chars: () => Il2Cpp.module.findExportByName("il2cpp_string_chars"),
	il2cpp_string_new: () => Il2Cpp.module.findExportByName("il2cpp_string_new"),
	il2cpp_string_new_wrapper: () => Il2Cpp.module.findExportByName("il2cpp_string_new_wrapper"),
	il2cpp_string_new_utf16: () => Il2Cpp.module.findExportByName("il2cpp_string_new_utf16"),
	il2cpp_string_new_len: () => Il2Cpp.module.findExportByName("il2cpp_string_new_len"),
	il2cpp_string_intern: () => Il2Cpp.module.findExportByName("il2cpp_string_intern"),
	il2cpp_string_is_interned: () => Il2Cpp.module.findExportByName("il2cpp_string_is_interned"),
	il2cpp_thread_current: () => Il2Cpp.module.findExportByName("il2cpp_thread_current"),
	il2cpp_thread_attach: () => Il2Cpp.module.findExportByName("il2cpp_thread_attach"),
	il2cpp_thread_detach: () => Il2Cpp.module.findExportByName("il2cpp_thread_detach"),
	il2cpp_is_vm_thread: () => Il2Cpp.module.findExportByName("il2cpp_is_vm_thread"),
	il2cpp_current_thread_walk_frame_stack: () => Il2Cpp.module.findExportByName("il2cpp_current_thread_walk_frame_stack"),
	il2cpp_thread_walk_frame_stack: () => Il2Cpp.module.findExportByName("il2cpp_thread_walk_frame_stack"),
	il2cpp_current_thread_get_top_frame: () => Il2Cpp.module.findExportByName("il2cpp_current_thread_get_top_frame"),
	il2cpp_thread_get_top_frame: () => Il2Cpp.module.findExportByName("il2cpp_thread_get_top_frame"),
	il2cpp_current_thread_get_frame_at: () => Il2Cpp.module.findExportByName("il2cpp_current_thread_get_frame_at"),
	il2cpp_thread_get_frame_at: () => Il2Cpp.module.findExportByName("il2cpp_thread_get_frame_at"),
	il2cpp_current_thread_get_stack_depth: () => Il2Cpp.module.findExportByName("il2cpp_current_thread_get_stack_depth"),
	il2cpp_thread_get_stack_depth: () => Il2Cpp.module.findExportByName("il2cpp_thread_get_stack_depth"),
	il2cpp_set_default_thread_affinity: () => Il2Cpp.module.findExportByName("il2cpp_set_default_thread_affinity"),
	il2cpp_override_stack_backtrace: () => Il2Cpp.module.findExportByName("il2cpp_override_stack_backtrace"),
	il2cpp_type_get_object: () => Il2Cpp.module.findExportByName("il2cpp_type_get_object"),
	il2cpp_type_get_type: () => Il2Cpp.module.findExportByName("il2cpp_type_get_type"),
	il2cpp_type_get_class_or_element_class: () => Il2Cpp.module.findExportByName("il2cpp_type_get_class_or_element_class"),
	il2cpp_type_get_name: () => Il2Cpp.module.findExportByName("il2cpp_type_get_name"),
	il2cpp_type_get_assembly_qualified_name: () => Il2Cpp.module.findExportByName("il2cpp_type_get_assembly_qualified_name"),
	il2cpp_type_get_reflection_name: () => Il2Cpp.module.findExportByName("il2cpp_type_get_reflection_name"),
	il2cpp_type_is_byref: () => Il2Cpp.module.findExportByName("il2cpp_type_is_byref"),
	il2cpp_type_get_attrs: () => Il2Cpp.module.findExportByName("il2cpp_type_get_attrs"),
	il2cpp_type_equals: () => Il2Cpp.module.findExportByName("il2cpp_type_equals"),
	il2cpp_type_is_static: () => Il2Cpp.module.findExportByName("il2cpp_type_is_static"),
	il2cpp_type_is_pointer_type: () => Il2Cpp.module.findExportByName("il2cpp_type_is_pointer_type"),
	il2cpp_image_get_assembly: () => Il2Cpp.module.findExportByName("il2cpp_image_get_assembly"),
	il2cpp_image_get_name: () => Il2Cpp.module.findExportByName("il2cpp_image_get_name"),
	il2cpp_image_get_filename: () => Il2Cpp.module.findExportByName("il2cpp_image_get_filename"),
	il2cpp_image_get_entry_point: () => Il2Cpp.module.findExportByName("il2cpp_image_get_entry_point"),
	il2cpp_image_get_class_count: () => Il2Cpp.module.findExportByName("il2cpp_image_get_class_count"),
	il2cpp_image_get_class: () => Il2Cpp.module.findExportByName("il2cpp_image_get_class"),
	il2cpp_capture_memory_snapshot: () => Il2Cpp.module.findExportByName("il2cpp_capture_memory_snapshot"),
	il2cpp_free_captured_memory_snapshot: () => Il2Cpp.module.findExportByName("il2cpp_free_captured_memory_snapshot"),
	il2cpp_set_find_plugin_callback: () => Il2Cpp.module.findExportByName("il2cpp_set_find_plugin_callback"),
	il2cpp_register_log_callback: () => Il2Cpp.module.findExportByName("il2cpp_register_log_callback"),
	il2cpp_debugger_set_agent_options: () => Il2Cpp.module.findExportByName("il2cpp_debugger_set_agent_options"),
	il2cpp_is_debugger_attached: () => Il2Cpp.module.findExportByName("il2cpp_is_debugger_attached"),
	il2cpp_register_debugger_agent_transport: () => Il2Cpp.module.findExportByName("il2cpp_register_debugger_agent_transport"),
	il2cpp_debug_foreach_method: () => Il2Cpp.module.findExportByName("il2cpp_debug_foreach_method"),
	il2cpp_debug_get_method_info: () => Il2Cpp.module.findExportByName("il2cpp_debug_get_method_info"),
	il2cpp_unity_install_unitytls_interface: () => Il2Cpp.module.findExportByName("il2cpp_unity_install_unitytls_interface"),
	il2cpp_custom_attrs_from_class: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_from_class"),
	il2cpp_custom_attrs_from_method: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_from_method"),
	il2cpp_custom_attrs_from_field: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_from_field"),
	il2cpp_custom_attrs_has_attr: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_has_attr"),
	il2cpp_custom_attrs_get_attr: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_get_attr"),
	il2cpp_custom_attrs_construct: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_construct"),
	il2cpp_custom_attrs_free: () => Il2Cpp.module.findExportByName("il2cpp_custom_attrs_free"),
	il2cpp_type_get_name_chunked: () => Il2Cpp.module.findExportByName("il2cpp_type_get_name_chunked"),
	il2cpp_class_set_userdata: () => Il2Cpp.module.findExportByName("il2cpp_class_set_userdata"),
	il2cpp_class_get_userdata_offset: () => Il2Cpp.module.findExportByName("il2cpp_class_get_userdata_offset"),
	il2cpp_class_for_each: () => Il2Cpp.module.findExportByName("il2cpp_class_for_each"),
	il2cpp_unity_set_android_network_up_state_func: () => Il2Cpp.module.findExportByName("il2cpp_unity_set_android_network_up_state_func"),
};

let menuName: string = "NEXON";
let themeIndex = 0;
class XRInputHandler {
    private InputDevices: any;
    private tryGetFeatureValue: any;
    private tryGetFeatureValueVec2: any;
    private ovrInputClass: any;
    private buttonStates: Map<string, boolean>;
    private lastStickLog = 0;

    constructor() {
        this.InputDevices = Il2Cpp.domain
            .assembly("UnityEngine.XRModule")
            .image.class("UnityEngine.XR.InputDevices");

        this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
        this.tryGetFeatureValueVec2 = this.InputDevices.method("TryGetFeatureValue_Vector2f", 3);
        try {
            this.ovrInputClass = Il2Cpp.domain.assembly("Assembly-CSharp").image.class("OVRInput");
        } catch (_) { this.ovrInputClass = null; }
        this.buttonStates = new Map();
    }

    private getOvrStick(axis: number, controller: number): number[] {
        if (this.ovrInputClass == null) return null;
        try {
            let get = null;
            for (const m of this.ovrInputClass.methods) {
                if (m.name != "Get" || m.parameterCount != 2) continue;
                const p0 = m.parameterTypes[0] != null ? m.parameterTypes[0].name : "";
                const p1 = m.parameterTypes[1] != null ? m.parameterTypes[1].name : "";
                if (p0.indexOf("Axis2D") != -1 && p1.indexOf("Controller") != -1) { get = m; break; }
            }
            if (get == null) return null;
            const v = get.invoke(uint64(axis), uint64(controller));
            return [v.field("x").value, v.field("y").value];
        } catch (_) { return null; }
    }

    update() {
        this.updateControllerStates(1); // left controller
        this.updateControllerStates(2); // right controller
    }

    private updateControllerStates(controllerId: number) {
        const features = [
            "PrimaryButton",
            "SecondaryButton",
            "GripButton",
            "TriggerButton",
            "MenuButton"
        ];

        features.forEach(feature => {
            const key = `${controllerId}_${feature}`;
            this.buttonStates.set(key, this.getButtonState(controllerId, feature));
        });
    }

    private getButtonState(deviceId: number, featureName: string): boolean {
        try {
            const valuePtr = Il2Cpp.alloc(1);
            const feature = Il2Cpp.string(featureName);
            const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
            if (success) {
                return valuePtr.readU8() !== 0;
            }
        } catch (_) { }
        return false;
    }

    isButtonPressed(controllerId: number, feature: string): boolean {
        return this.buttonStates.get(`${controllerId}_${feature}`) || false;
    }

    // Renamed getters
    get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
    get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
    get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
    get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
    get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
    get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
    get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
    private getFeatureVec2(deviceId: number, featureName: string): number[] {
        try {
            const valuePtr = Il2Cpp.alloc(8);
            const feature = Il2Cpp.string(featureName);
            const success = this.tryGetFeatureValueVec2.invoke(uint64(deviceId), feature, valuePtr);
            if (success) {
                const x = valuePtr.readFloat();
                const y = valuePtr.readFloat(4);
                if (Math.abs(x) > 0.001 || Math.abs(y) > 0.001) return [x, y];
            }
        } catch (_) { }
        return null;
    }

    get leftThumbstick(): number[] {
        return this.readStick();
    }
    get rightThumbstick(): number[] {
        return this.readStick();
    }

    private readStick(): number[] {
        let best: number[] = [0, 0];
        let bestSource = "none";
        const consider = (v: number[], label: string) => {
            if (v == null) return;
            if (Math.abs(v[0]) > Math.abs(best[0]) || Math.abs(v[1]) > Math.abs(best[1])) {
                best[0] = v[0];
                best[1] = v[1];
                bestSource = label;
            }
        };
        consider(this.getOvrStick(0, 1), "ovr(0,1)");
        consider(this.getOvrStick(1, 1), "ovr(1,1)");
        consider(this.getOvrStick(2, 1), "ovr(2,1)");
        consider(this.getOvrStick(0, 2), "ovr(0,2)");
        consider(this.getOvrStick(0, 4), "ovr(0,4)");
        consider(this.getOvrStick(0, 8), "ovr(0,8)");
        consider(this.getFeatureVec2(1, "Primary2DAxis"), "xr(1,Primary2DAxis)");
        consider(this.getFeatureVec2(2, "Primary2DAxis"), "xr(2,Primary2DAxis)");
        consider(this.getFeatureVec2(1, "Secondary2DAxis"), "xr(1,Secondary2DAxis)");
        consider(this.getFeatureVec2(2, "Secondary2DAxis"), "xr(2,Secondary2DAxis)");
        if (Math.abs(best[0]) + Math.abs(best[1]) > 0.2) {
            const stime = Date.now();
            if (stime - this.lastStickLog > 1500) {
                this.lastStickLog = stime;
                const primary = this.getFeatureVec2(1, "Primary2DAxis");
                const secondary = this.getFeatureVec2(2, "Primary2DAxis");
                console.log("[stick] src=" + bestSource + " best=" + best[0].toFixed(2) + "," + best[1].toFixed(2) +
                    " xr1P=" + (primary != null ? primary[0].toFixed(2) + "," + primary[1].toFixed(2) : "null") +
                    " xr2P=" + (secondary != null ? secondary[0].toFixed(2) + "," + secondary[1].toFixed(2) : "null"));
            }
        }
        return best;
    }
    get controllerMenuButton(): boolean {
        return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
    }
}

const FAKE_PLAYFAB_ID = "BFA71";

Il2Cpp.perform(() => {
    console.log("[+] SpoofPlayFabId v2 starting...");
    console.log("[+] Fake ID: " + FAKE_PLAYFAB_ID);

    const PhotonUnityNetworking = Il2Cpp.domain.assembly("PhotonUnityNetworking").image;

    let PhotonRealtime: any = null;
    try {
        PhotonRealtime = Il2Cpp.domain.assembly("PhotonRealtime").image;
    } catch (_) {
        try {
            PhotonRealtime = Il2Cpp.domain.assembly("Photon3Unity3D").image;
        } catch (_) {}
    }

    const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");

    function getLocalPlayer(): any {
        try {
            return PhotonNetwork.method("get_LocalPlayer").invoke();
        } catch (_) {
            try {
                return PhotonNetwork.field("LocalPlayer").value;
            } catch (_) {
                return null;
            }
        }
    }

    const player = getLocalPlayer();
    if (!player || player.isNull()) {
        console.log("[!] LocalPlayer null â€” join a room first, then reload");
        return;
    }

    // ========== DUMP Player methods (so we know the real names) ==========
    console.log("\n[+] Photon.Realtime.Player methods containing 'Custom' or 'Propert' or 'Set':");
    try {
        const playerClass = player.method("GetType").invoke();
        // use Il2Cpp class from object
        const cls = player.class;
        for (const m of cls.methods) {
            const n = m.name;
            if (
                n.toLowerCase().includes("custom") ||
                n.toLowerCase().includes("propert") ||
                n.toLowerCase().includes("set") ||
                n.toLowerCase().includes("user")
            ) {
                console.log("  - " + n + " (" + m.parameterCount + " params)");
            }
        }
    } catch (e) {
        console.log("[-] Method dump failed: " + e);
        try {
            const cls = Il2Cpp.domain.assembly("PhotonRealtime").image.class("Photon.Realtime.Player");
            for (const m of cls.methods) {
                const n = m.name;
                if (
                    n.toLowerCase().includes("custom") ||
                    n.toLowerCase().includes("propert") ||
                    n.toLowerCase().includes("set") ||
                    n.toLowerCase().includes("user")
                ) {
                    console.log("  - " + n + " (" + m.parameterCount + " params)");
                }
            }
        } catch (e2) {
            console.log("[-] Class dump failed: " + e2);
        }
    }

    // ========== DUMP PhotonNetwork methods ==========
    console.log("\n[+] PhotonNetwork methods containing Custom/Player/Propert:");
    try {
        for (const m of PhotonNetwork.methods) {
            const n = m.name;
            if (
                n.toLowerCase().includes("custom") ||
                n.toLowerCase().includes("player") ||
                n.toLowerCase().includes("propert")
            ) {
                console.log("  - " + n + " (" + m.parameterCount + " params)");
            }
        }
    } catch (_) {}

    const fakeStr = Il2Cpp.string(FAKE_PLAYFAB_ID);

    // ========== 1. UserId ==========
    try {
        player.method("set_UserId").invoke(fakeStr);
        console.log("[+] set_UserId OK");
    } catch (e) {
        console.log("[-] set_UserId: " + e);
    }

    // ========== 2. Get / patch CustomProperties Hashtable ==========
    let props: any = null;
    try {
        props = player.method("get_CustomProperties").invoke();
        console.log("[+] Got CustomProperties");
    } catch (e) {
        console.log("[-] get_CustomProperties: " + e);
    }

    if (props && !props.isNull()) {
        // Dump current keys
        console.log("\n[+] Current CustomProperties:");
        try {
            const keys = props.method("get_Keys").invoke();
            const en = keys.method("GetEnumerator").invoke();
            while (en.method("MoveNext").invoke()) {
                try {
                    const k = en.method("get_Current").invoke();
                    const ks = k.toString();
                    let vs = "?";
                    try {
                        vs = props.method("get_Item").invoke(k).toString();
                    } catch (_) {}
                    console.log("    \"" + ks + "\" = " + vs);
                } catch (_) {}
            }
        } catch (e) {
            console.log("[-] enumerate: " + e);
        }

        const keysToSpoof = [
            "PlayFabId", "PlayFabID", "playFabId", "playfabId",
            "PlayFab_ID", "playfab_id", "PFID", "pfid",
            "UserId", "userId", "PlayerId", "playerId"
        ];

        for (const key of keysToSpoof) {
            try {
                props.method("set_Item").invoke(Il2Cpp.string(key), fakeStr);
                console.log("[+] props[\"" + key + "\"] = " + FAKE_PLAYFAB_ID);
            } catch (_) {
                try {
                    props.method("Add").invoke(Il2Cpp.string(key), fakeStr);
                    console.log("[+] props.Add(\"" + key + "\")");
                } catch (_) {}
            }
        }

        // ========== 3. Try every likely sync method ==========
        const tryMethods: { target: any; name: string; args: any[] }[] = [];

        // On player instance â€” various arities
        for (const name of [
            "SetCustomProperties",
            "set_CustomProperties",
            "SetProperties",
            "OpSetCustomProperties",
            "InternalCacheProperties"
        ]) {
            for (const argc of [1, 2, 3]) {
                tryMethods.push({ target: player, name, args: argc === 1 ? [props] : argc === 2 ? [props, null] : [props, null, null] });
            }
        }

        // On PhotonNetwork static
        for (const name of [
            "SetPlayerCustomProperties",
            "SetCustomProperties",
            "LocalPlayerSetCustomProperties"
        ]) {
            tryMethods.push({ target: PhotonNetwork, name, args: [props] });
            tryMethods.push({ target: PhotonNetwork, name, args: [props, null] });
        }

        let synced = false;
        for (const t of tryMethods) {
            try {
                t.target.method(t.name, t.args.length).invoke(...t.args);
                console.log("[+] SUCCESS: " + t.name + "(" + t.args.length + ")");
                synced = true;
                break;
            } catch (_) {}
        }

        // Last resort: write field directly if it exists
        if (!synced) {
            try {
                player.field("CustomProperties").value = props;
                console.log("[+] Wrote CustomProperties field directly");
                synced = true;
            } catch (_) {}
        }

        // Try LoadBalancingClient path
        if (!synced) {
            try {
                let client: any = null;
                try {
                    client = PhotonNetwork.method("get_NetworkingClient").invoke();
                } catch (_) {
                    try {
                        client = PhotonNetwork.field("NetworkingClient").value;
                    } catch (_) {}
                }

                if (client && !client.isNull()) {
                    console.log("[+] Got NetworkingClient");
                    // Dump useful methods
                    for (const m of client.class.methods) {
                        if (m.name.toLowerCase().includes("custom") || m.name.toLowerCase().includes("propert") || m.name.toLowerCase().includes("actor")) {
                            console.log("  client." + m.name + " (" + m.parameterCount + ")");
                        }
                    }

                    const actorNum = player.method("get_ActorNumber").invoke();
                    for (const name of ["OpSetCustomPropertiesOfActor", "OpSetPropertiesOfActor"]) {
                        try {
                            client.method(name).invoke(actorNum, props, null, null);
                            console.log("[+] SUCCESS: client." + name);
                            synced = true;
                            break;
                        } catch (_) {
                            try {
                                client.method(name, 2).invoke(actorNum, props);
                                console.log("[+] SUCCESS: client." + name + "(2)");
                                synced = true;
                                break;
                            } catch (_) {}
                        }
                    }
                }
            } catch (e) {
                console.log("[-] NetworkingClient path: " + e);
            }
        }

        if (!synced) {
            console.log("[!] Could not sync to network â€” local props patched only");
            console.log("[!] Paste the method dump above so we can target the exact name");
        }
    }

    console.log("\n[+] Done");
});

Il2Cpp.perform(() => {
    const Application = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Application");
    const Environment = Il2Cpp.domain.assembly("mscorlib").image.class("System.Environment");

    const quit = Application.method("Quit");
    const exit = Environment.method("Exit");
    const failFast = Environment.method("FailFast");

    quit.implementation = function () {};
    exit.implementation = function (code) {};
    failFast.implementation = function (message) {};

    const a = Il2Cpp.domain.assembly("Assembly-CSharp").image;
    ["KickHammer","KickHammer1"].forEach(n => {
        let c;
        try { c = a.class(n); } catch (e) { c = null; }
        if (c != null) c.method("OnTriggerEnter").implementation = () => {};
    });
    try { a.class("KickHammer1").method("KillPlayer").implementation = () => {}; } catch (e) {
        try { a.class("KickHammer").method("KillPlayer").implementation = () => {}; } catch (e2) {}
    }
    try { a.class("LightningHammer").method("OnTriggerEnter", 1).implementation = function (_) {}; } catch (e) {}
    try { a.class("Kill").method("OnTriggerEnter", 1).implementation = function (_) {}; } catch (e) {}

    console.log("[+] Anti kick initied");
});

Il2Cpp.perform(() => {
    const AssemblyCSharp = Il2Cpp.domain.assembly("Assembly-CSharp").image;

    let boogie = null;

    for (const klass of AssemblyCSharp.classes) {
        if (klass.name == "LightningBoltScript") {
            boogie = klass;
            break;
        }
    }

    if (boogie == null) {
        console.log("LightningBoltScript class not found");
        return;
    }

    console.log("=== Found LightningBoltScript ===");
    console.log("Namespace:", boogie.namespace);

    console.log("=== Methods ===");
    for (const method of boogie.methods) {
        console.log(
            "[METHOD]",
            method.name,
            "Args:",
            method.parameterCount
        );
    }

    console.log("=== Fields ===");
    for (const field of boogie.fields) {
        console.log(
            "[FIELD]",
            field.name
        );
    }
});

Il2Cpp.perform(() => {
    const images = {
        "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
        "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
        "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
        "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
        "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
        "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
        "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
        "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image
    };
    const AssemblyCSharp = images["Assembly-CSharp"];
    const UnityEngineCore = images["UnityEngine.CoreModule"];
    const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
    const UnityEngineUI = images["UnityEngine.UI"];
    const UnityEngineUIModule = images["UnityEngine.UIModule"];
    const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
    const PhotonUnityNetworking = images["PhotonUnityNetworking"];

    const GTPlayerClass = AssemblyCSharp.class("GorillaLocomotion.Player");
    const GorillaReportButton = (() => { for (const n of ["DownElevatorButton", "UpElevatorButton", "SetActivedButton", "ElevatorButton"]) { try { return AssemblyCSharp.class(n); } catch (e) {} } return null; })();
    const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
    const PhotonViewClass = (() => { try { return PhotonUnityNetworking.class("Photon.Pun.PhotonView"); } catch (e) { return null; } })();
    const GTPlayer = Il2Cpp.gc.choose(GTPlayerClass)[0];
    const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
    const Object = UnityEngineCore.class("UnityEngine.Object");
    const Component = UnityEngineCore.class("UnityEngine.Component");
    const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
    const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
    const Time = UnityEngineCore.class("UnityEngine.Time");
    const Resources = UnityEngineCore.class("UnityEngine.Resources");
    const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
    const Shader = UnityEngineCore.class("UnityEngine.Shader");
    const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
    const MeshCollider = UnityEnginePhysics.class("UnityEngine.Collider");
    const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
    const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
    const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
    const Physics = UnityEnginePhysics.class("UnityEngine.Physics");
    const Material = UnityEngineCore.class("UnityEngine.Material");

    const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
    const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
    const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
    const Text = UnityEngineUI.class("UnityEngine.UI.Text");
const Image = UnityEngineUI.class("UnityEngine.UI.Image");
    const Font = UnityEngineTextRendering.class("UnityEngine.Font");
    const GorillaTagger = GTPlayer

    for (const field of GTPlayerClass.fields) {
        if (field.type.name == "UnityEngine.Rigidbody") {
            rigidbody = GTPlayer.field(field.name).value
        }
    }

    const UberShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Unlit"));
    const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

    const zeroVector = Vector3.field("zeroVector").value;
    const oneVector = Vector3.field("oneVector").value;
    const identityQuaternion = Quaternion.field("identityQuaternion").value;

    const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
    const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
    const headCollider = GorillaTagger.field("headCollider").value;

    const OVRInputHandler = new XRInputHandler();

    let arial = null;
    try {
        arial = Resources
            .method("GetBuiltinResource", 1)
            .inflate(Font)
            .invoke(Il2Cpp.string("Arial.ttf"));
    } catch (e) {
        arial = null;
        console.log("[Font] GetBuiltinResource failed: " + e);
    }

    function Destroy(object) {
        Object.method("Destroy", 1).invoke(object);
    }

    function getComponent(obj: any, type) {
        return obj.method("GetComponent", 1).inflate(type).invoke();
    }

    function addComponent(obj: any, type) {
        return obj.method("AddComponent", 1).inflate(type).invoke();
    }

    function getComponentInParent(obj: any, type) {
        return obj.method("GetComponentInParent", 0).inflate(type).invoke();
    }

    function getTransform(obj: any) {
        return obj.method("get_transform").invoke();
    }

    function sendAllOutgoing() {
        PhotonNetwork.method("SendAllOutgoingCommands").invoke();
    }

    function renderMenuText(
        canvasObject,
        text: string = "",
        color: [number, number, number, number] = [1, 1, 1, 1],
        pos = zeroVector,
        size = oneVector
    ) {
        const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
        getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
        title.method("set_text").invoke(Il2Cpp.string(text));
        if (arial != null) title.method("set_font").invoke(arial);
        title.method("set_fontSize").invoke(1);
        title.method("set_color").invoke(color);
        title.method("set_fontStyle").invoke(3);
        title.method("set_alignment").invoke(4);
        title.method("set_resizeTextForBestFit").invoke(true);
        title.method("set_resizeTextMinSize").invoke(0);

        const rectTransform = getComponent(title, RectTransform);
        rectTransform.method("set_sizeDelta").invoke(size);
        rectTransform.method("set_position").invoke(pos);
        rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0))
    }
    let cachedShader = null;
    function getCachedShader() {
        if (cachedShader != null) return cachedShader;
        try {
            cachedShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Unlit"));
            if (cachedShader == null) cachedShader = Shader.method("Find").invoke(Il2Cpp.string("Unlit/Color"));
            if (cachedShader == null) cachedShader = Shader.method("Find").invoke(Il2Cpp.string("Sprites/Default"));
            if (cachedShader == null) cachedShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));
        } catch (e) {}
        return cachedShader;
    }

    function createObject(
        pos = zeroVector,
        rot = identityQuaternion,
        scale = oneVector,
        primitiveType: number = 3,
        colorArr: [number, number, number, number] = [1, 1, 1, 1],
        parent = null
    ) {
        const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);

        const renderer = getComponent(obj, Renderer);

        if (colorArr[3] == 0) {
            renderer.method("set_enabled").invoke(false);
        } else {
            const material = renderer.method("get_material").invoke();
            try {
                const shader = getCachedShader();
                if (shader != null) Material.method("CreateWithShader").invoke(material, shader);
            } catch (e) {}
            material.method("set_color").invoke(colorArr);
        }

        const transform = getTransform(obj);
        if (parent != null) {
            transform.method("SetParent", 2).invoke(parent, false);
        }

        transform.method("set_position").invoke(pos);
        transform.method("set_rotation").invoke(rot);
        transform.method("set_localScale").invoke(scale);

        return obj;
    }

    //#region Mods

    //#region  Movement

    let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
    const platColors: [number, number, number, number][] = [
        [0.0, 0.0, 0.0, 1.0],       // Black
        [9.0, 9.0, 9.0, 1.0],       // Bright white
        [9.0, 0.0, 0.0, 1.0],       // Red
        [0.0, 9.0, 0.0, 1.0],       // Green
        [0.0, 0.0, 9.0, 1.0],       // Blue
        [5.0, 5.0, 0.0, 1.0],       // Yellow
        [9.0, 0.5, 9.0, 1.0],       // Magenta
    ];
    let platL = null;
    let platR = null;
    let plater = 0;

    function Platforms() {
        if (leftGrab) {
            if (platL == null) {
                const handTransform = leftHandTransform;
                platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platL != null) {
                Destroy(platL);
                platL = null;
            }
        }

        if (rightGrab) {
            if (platR == null) {
                const handTransform = rightHandTransform;
                platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platR != null) {
                Destroy(platR);
                platR = null;
            }
        }
    }

    //#endregion

    //#region  Server
    function ClearRPC() {
    }

    function getLocalNetworkPlayer() {
        try {
            const localPhotonPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localPlayerId = localPhotonPlayer.method("get_UserId").invoke().toString();

            const allPhotonViews = PhotonNetwork.method("get_PhotonViewList").invoke();

            for (let i = 0; i < allPhotonViews.length; i++) {
                try {
                    const photonView = allPhotonViews.get(i);

                    if (photonView != null) {
                        const owner = photonView.method("get_Owner").invoke();

                        if (owner != null) {
                            const ownerId = owner.method("get_UserId").invoke().toString();

                            if (ownerId === localPlayerId) {
                                return photonView;
                            }
                        }
                    }
                } catch (e) {
                    continue;
                }
            }

            return null;
        } catch (e) {
            return null;
        }
    }
    //#endregion

    const aa = [
    'Kick2', 'ThorKickHammer', 'RPG2', 'Pee', 'Fling2',
    'Owner', 'Tect', 'Admin', 'Mod', 'Developer',
    'Management', 'Tank', 'JmanLauncher2', 'KittyLauncher3',
    'YtBadge2', 'TiktokBadge', 'VideoStarBadge1', 'VideoStarBadge2',
    'VideoStarBadge3', 'VideoStarBadge4', 'VideoStarBadge5',
    'VideoStarBadge6', 'BanHammer', 'BanHammer2'
];

function staffItems() {
    // 1. Helper to enable toggles
    function makeToggleUsable(toggle) {
        if (!toggle || toggle.isNull()) return;
        try {
            toggle.field('IsInteractable').value = true;
            toggle.field('useSetInteractable').value = false;
            toggle.method('SetInteractable').invoke(true, false);
        } catch(e) {}
    }

    // 2. Helper to send network enablement via TemporaryCosmeticHandler
    function setCosmeticState(cosmeticName, enable) {
        try {
            const handlerClass = AssemblyCSharp.class('TemporaryCosmeticHandler');
            const localPlayer = AssemblyCSharp.class('Photon.Pun.PhotonNetwork').method('get_LocalPlayer').invoke();
            const fieldName = enable ? 'CosmeticEnable' : 'CosmeticDisable';
            const rpcField = handlerClass.field(fieldName);

            if (rpcField && rpcField.value && !rpcField.value.isNull()) {
                rpcField.value.invoke(localPlayer, Il2Cpp.string(cosmeticName));
                return;
            }

            const instances = UnityEngine.method('FindObjectsOfType').inflate(handlerClass).invoke();
            if (instances && instances.length > 0) {
                const methodName = enable ? 'OnCosmeticEnable' : 'OnCosmeticDisable';
                instances.get(0).method(methodName).invoke(localPlayer, Il2Cpp.string(cosmeticName));
            }
        } catch(e) {
            console.log('[Staff] Cosmetic RPC error: ' + e);
        }
    }

    // 3. Inventory Hook
    try {
        const invClass = AssemblyCSharp.class('InventoryController');
        const refreshMethod = invClass.method('Refresh');
        refreshMethod.implementation = function(arg) {
            const result = refreshMethod.invoke(this, arg);
            try {
                const ownedItems = this.field('ownedItems').value;
                const ownedCosmetics = this.field('ownedCosmeticsList').value;

                for (let i = 0; i < aa.length; i++) {
                    const strId = aa[i];
                    const cppStr = Il2Cpp.string(strId);

                    if (!ownedItems.method('ContainsKey').invoke(cppStr).content) {
                        ownedItems.method('Add').invoke(cppStr, Il2Cpp.array('System.String', [cppStr]));
                        ownedCosmetics.method('Add').invoke(cppStr);
                    }
                }
            } catch(e) {
                console.log('[Staff] Inventory error: ' + e);
            }
            return result;
        };
    } catch(e) {
        console.log('[Staff] Inventory hook failed: ' + e);
    }

    // 4. StaffModController Bypasses & Event Handling
    try {
        const staffClass = AssemblyCSharp.class('ScaryBaboon.Interactions.Staff.StaffModController');
        
        staffClass.method('OwnItem').implementation = function() { return true; };
        staffClass.method('OnNotOwned').implementation = function() {};
        
        staffClass.method('RefreshOwnedState').implementation = function() {
            this.field('owned').value = true;
            makeToggleUsable(this.field('physicalToggle').value);
            try {
                this.field('buttonText').value.method('set_text').invoke(Il2Cpp.string('OFF'));
            } catch(e) {}
        };

        staffClass.method('OnToggleValueChanged').implementation = function(state) {
            try {
                this.field('OnToggleValueChangedEvent').value.method('Invoke').invoke(state);
            } catch(e) {}
            try {
                this.field('buttonText').value.method('set_text').invoke(Il2Cpp.string(state ? 'ON' : 'OFF'));
            } catch(e) {}
        };

        const awakeMethod = staffClass.method('Awake');
        awakeMethod.implementation = function() {
            awakeMethod.invoke(this);
            this.field('owned').value = true;
            makeToggleUsable(this.field('physicalToggle').value);
        };
    } catch(e) {
        console.log('[Staff] StaffModController hooks failed: ' + e);
    }

    // 5. Cosmetic Manager & Toggle Behavior Bypasses
    try {
        const cosmeticManager = AssemblyCSharp.class('ScaryBaboon.Features2_0.Cosmetics.CosmeticManager');
        const toggleClass = AssemblyCSharp.class('ScaryBaboon.Features2_0.Cosmetics.Behaviours.StaffCosmeticBehaviourToggle');

        cosmeticManager.method('OwnsCosmetic').implementation = function(obj, cosmetic) {
            const name = cosmetic.content || cosmetic.toString();
            if (aa.includes(name)) return true;
            return cosmeticManager.method('OwnsCosmetic').invoke(obj, cosmetic);
        };

        cosmeticManager.method('CanUseCosmetic').implementation = function() { return true; };
        cosmeticManager.method('CanEquip').implementation = function() { return true; };
        cosmeticManager.method('get_CanChangeCosmetic').implementation = function() { return true; };

        toggleClass.method('HasInventoryPermission').implementation = function() { return true; };
        
        toggleClass.method('ToggleCosmetic').implementation = function(value) {
            const cosmeticId = this.field('cosmeticId').value;
            this.field('currentValue').value = value;
            this.field('canToggle').value = true;

            // Trigger physical networking enablement
            setCosmeticState(cosmeticId, value);

            try {
                const manager = cosmeticManager.method('get_Manager').invoke();
                if (manager && !manager.isNull()) {
                    manager.method('SetCosmeticOverride').invoke(cosmeticId, value);
                }
            } catch(e) {}

            try { this.method('SyncToggle').invoke(true); } catch(e) {}
            try { this.method('UpdateLabel').invoke(); } catch(e) {}
        };
    } catch(e) {
        console.log('[Staff] Cosmetic bypasses failed: ' + e);
    }

    // 6. Force immediate application to scene objects
    try {
        const staffClass = AssemblyCSharp.class('ScaryBaboon.Interactions.Staff.StaffModController');
        const objects = UnityEngine.method('FindObjectsOfType').inflate(staffClass).invoke();
        for (let i = 0; i < objects.length; i++) {
            const obj = objects.get(i);
            obj.field('owned').value = true;
            makeToggleUsable(obj.field('physicalToggle').value);
        }
    } catch(e) {}

    console.log('[Staff] Loaded successfully');
}

//#endregion

    function renderLockScreen() {
        menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
        Destroy(getComponent(menu, BoxCollider))
        const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, [0.01, 0.01, 0.01, 1.0], getTransform(menu))
        Destroy(getComponent(menuBackground, BoxCollider))
        const bgRenderer = getComponent(menuBackground, Renderer);
        const bgMat = bgRenderer.method("get_material").invoke();
        bgMat.method("SetColor").invoke(Il2Cpp.string("_Color"), [0.01, 0.01, 0.01, 1.0]);
        const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
        const canvas = addComponent(canvasObject, Canvas);
        Destroy(getComponent(canvasObject, BoxCollider))
        const canvasScaler = addComponent(canvasObject, CanvasScaler);
        addComponent(canvasObject, GraphicRaycaster);
        try { canvas.method("set_renderMode").invoke(2); } catch (e) {}
        canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);
        renderMenuText(canvasObject, `<color=#3DFFB0>go to Discord.gg/nexonmodz to generate your buyer key</color>`, textColor, [0.11, 0.38, 0.11], [1.2, .07]);
        const displayBox = createObject([0.105, 0.15, 0.11], identityQuaternion, [0.08, 0.025, 0.32], 3, [0.02, 0.05, 0.16, 0.95], getTransform(menu));
        Destroy(getComponent(displayBox, BoxCollider));
        renderMenuText(canvasObject, (passwordInput == "" ? " " : passwordInput) + "_", textColor, [0.11, 0.15, 0.11], [1, .09]);
        const now = Time.method("get_time").invoke();
        if (now < __huss_lockUntil) {
            renderMenuText(canvasObject, `<color=#FF4D4D>${__huss_lockMsg}</color> <color=#8A9BFF>try again in</color> <color=#3DFFB0>${Math.ceil(__huss_lockUntil - now)}s</color>`, [1, 0.3, 0.3, 1], [0.11, 0, 0.11], [1.2, .08]);
        }
        const kbPlate = createObject([0.1, -0.02, 0.295], identityQuaternion, [0.095, 0.44, 0.13], 3, [0.02, 0.05, 0.16, 0.95], getTransform(menu));
        Destroy(getComponent(kbPlate, BoxCollider));
        const kbRows = [
            ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
            ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
            ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
            ["Z", "X", "C", "V", "B", "N", "M", "BKS", "CLR"]
        ];
        const kbRowZ = [0.36, 0.32, 0.28, 0.24];
        for (let r = 0; r < kbRows.length; r++) {
            const row = kbRows[r];
            const zOff = kbRowZ[r];
            const yStart = -(row.length - 1) * 0.05 / 2;
            for (let ci = 0; ci < row.length; ci++) {
                const yOff = yStart + (ci * 0.05);
                const isCtrl = row[ci] == "BKS" || row[ci] == "CLR";
                const keyBox = createObject([0.1, yOff, zOff], identityQuaternion, [0.05, 0.045, 0.016], 3, isCtrl ? accentCornerColor : buttonColor, getTransform(menu));
                keyBox.method("set_name").invoke(Il2Cpp.string("@" + row[ci]));
                addComponent(keyBox, GorillaReportButton);
                getComponent(keyBox, BoxCollider).method("set_isTrigger").invoke(true);
                renderMenuText(canvasObject, row[ci], isCtrl ? textPressedColor : textColor, [0.095, yOff, zOff], [0.05, 0.05]);
            }
        }
        const enterKey = createObject([0.105, -0.32, 0.11], identityQuaternion, [0.09, 0.09, 0.35], 3, accentCornerColor, getTransform(menu));
        enterKey.method("set_name").invoke(Il2Cpp.string("@ENTER"));
        addComponent(enterKey, GorillaReportButton);
        getComponent(enterKey, BoxCollider).method("set_isTrigger").invoke(true);
        renderMenuText(canvasObject, `<color=#FF4DD8>ENTER KEY</color>`, textColor, [0.11, -0.32, 0.11], [1, .08]);
        neutralizeMenuColliders();
        recenterMenu();
    }

    function renderMenu() {
        if (!__huss_unlocked) {
            renderLockScreen();
            return;
        }
        menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
        Destroy(getComponent(menu, BoxCollider))

        const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu))
        Destroy(getComponent(menuBackground, BoxCollider))

        const renderer = getComponent(menuBackground, Renderer);
        const mat = renderer.method("get_material").invoke();
        const color = mat.method("GetColor").invoke(Il2Cpp.string("_Color"));
        mat.method("SetColor").invoke(Il2Cpp.string("_Color"), bgColor);

        const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu))
        Destroy(getComponent(menuBackground2, BoxCollider))

        const shellTop = createObject([0.1, 0.462, 0], identityQuaternion, [0.096, 0.01, 0.76], 3, [0.0, 0.3, 0.55, 1.0], getTransform(menu));
        Destroy(getComponent(shellTop, BoxCollider));
        const shellBottom = createObject([0.1, -0.462, 0], identityQuaternion, [0.096, 0.01, 0.76], 3, [0.0, 0.3, 0.55, 1.0], getTransform(menu));
        Destroy(getComponent(shellBottom, BoxCollider));
        const shellLeft = createObject([0.1, 0, -0.385], identityQuaternion, [0.096, 0.94, 0.01], 3, [0.0, 0.3, 0.55, 1.0], getTransform(menu));
        Destroy(getComponent(shellLeft, BoxCollider));
        const shellRight = createObject([0.1, 0, 0.385], identityQuaternion, [0.096, 0.94, 0.01], 3, [0.0, 0.3, 0.55, 1.0], getTransform(menu));
        Destroy(getComponent(shellRight, BoxCollider));

        const frameTop = createObject([0.1, 0.452, 0], identityQuaternion, [0.093, 0.014, 0.74], 3, accentColor, getTransform(menu));
        Destroy(getComponent(frameTop, BoxCollider));
        const frameBottom = createObject([0.1, -0.452, 0], identityQuaternion, [0.093, 0.014, 0.74], 3, accentColor, getTransform(menu));
        Destroy(getComponent(frameBottom, BoxCollider));
        const frameLeft = createObject([0.1, 0, -0.375], identityQuaternion, [0.093, 0.92, 0.014], 3, accentColor, getTransform(menu));
        Destroy(getComponent(frameLeft, BoxCollider));
        const frameRight = createObject([0.1, 0, 0.375], identityQuaternion, [0.093, 0.92, 0.014], 3, accentColor, getTransform(menu));
        Destroy(getComponent(frameRight, BoxCollider));

        const bracketTR1 = createObject([0.1, 0.45, 0.3], identityQuaternion, [0.014, 0.022, 0.13], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketTR1, BoxCollider));
        const bracketTR2 = createObject([0.1, 0.38, 0.37], identityQuaternion, [0.014, 0.13, 0.022], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketTR2, BoxCollider));
        const bracketTL1 = createObject([0.1, 0.45, -0.3], identityQuaternion, [0.014, 0.022, 0.13], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketTL1, BoxCollider));
        const bracketTL2 = createObject([0.1, 0.38, -0.37], identityQuaternion, [0.014, 0.13, 0.022], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketTL2, BoxCollider));
        const bracketBR1 = createObject([0.1, -0.45, 0.3], identityQuaternion, [0.014, 0.022, 0.13], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketBR1, BoxCollider));
        const bracketBR2 = createObject([0.1, -0.38, 0.37], identityQuaternion, [0.014, 0.13, 0.022], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketBR2, BoxCollider));
        const bracketBL1 = createObject([0.1, -0.45, -0.3], identityQuaternion, [0.014, 0.022, 0.13], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketBL1, BoxCollider));
        const bracketBL2 = createObject([0.1, -0.38, -0.37], identityQuaternion, [0.014, 0.13, 0.022], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(bracketBL2, BoxCollider));

        const ledTop = createObject([0.1, 0.452, 0], identityQuaternion, [0.02, 0.02, 0.02], 0, accentColor, getTransform(menu));
        Destroy(getComponent(ledTop, BoxCollider)); Destroy(getComponent(ledTop, Collider));
        const ledBottom = createObject([0.1, -0.452, 0], identityQuaternion, [0.02, 0.02, 0.02], 0, accentColor, getTransform(menu));
        Destroy(getComponent(ledBottom, BoxCollider)); Destroy(getComponent(ledBottom, Collider));
        const ledLeft = createObject([0.1, 0, -0.382], identityQuaternion, [0.02, 0.02, 0.02], 0, accentColor, getTransform(menu));
        Destroy(getComponent(ledLeft, BoxCollider)); Destroy(getComponent(ledLeft, Collider));
        const ledRight = createObject([0.1, 0, 0.382], identityQuaternion, [0.02, 0.02, 0.02], 0, accentColor, getTransform(menu));
        Destroy(getComponent(ledRight, BoxCollider)); Destroy(getComponent(ledRight, Collider));

        const cornerNode1 = createObject([0.1, 0.47, -0.385], identityQuaternion, [0.03, 0.03, 0.03], 0, accentCornerColor, getTransform(menu));
        Destroy(getComponent(cornerNode1, BoxCollider)); Destroy(getComponent(cornerNode1, Collider));
        const cornerNode2 = createObject([0.1, 0.47, 0.385], identityQuaternion, [0.03, 0.03, 0.03], 0, accentCornerColor, getTransform(menu));
        Destroy(getComponent(cornerNode2, BoxCollider)); Destroy(getComponent(cornerNode2, Collider));
        const cornerNode3 = createObject([0.1, -0.47, -0.385], identityQuaternion, [0.03, 0.03, 0.03], 0, accentCornerColor, getTransform(menu));
        Destroy(getComponent(cornerNode3, BoxCollider)); Destroy(getComponent(cornerNode3, Collider));
        const cornerNode4 = createObject([0.1, -0.47, 0.385], identityQuaternion, [0.03, 0.03, 0.03], 0, accentCornerColor, getTransform(menu));
        Destroy(getComponent(cornerNode4, BoxCollider)); Destroy(getComponent(cornerNode4, Collider));

        const headerPlate = createObject([0.1, 0.4, 0.155], identityQuaternion, [0.098, 0.17, 0.42], 3, [0.09, 0.06, 0.28, 1.0], getTransform(menu));
        Destroy(getComponent(headerPlate, BoxCollider));
        const headerGlow = createObject([0.1, 0.432, 0.155], identityQuaternion, [0.096, 0.012, 0.41], 3, accentColor, getTransform(menu));
        Destroy(getComponent(headerGlow, BoxCollider));
        const headerMagenta = createObject([0.1, 0.406, 0.155], identityQuaternion, [0.096, 0.006, 0.41], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(headerMagenta, BoxCollider));
        const headerLine = createObject([0.1, 0.372, 0.155], identityQuaternion, [0.098, 0.008, 0.42], 3, accentColor, getTransform(menu));
        Destroy(getComponent(headerLine, BoxCollider));
        const headerEdgeL = createObject([0.1, 0.4, 0.365], identityQuaternion, [0.098, 0.17, 0.014], 3, accentColor, getTransform(menu));
        Destroy(getComponent(headerEdgeL, BoxCollider));
        const headerEdgeR = createObject([0.1, 0.4, -0.055], identityQuaternion, [0.098, 0.17, 0.014], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(headerEdgeR, BoxCollider));
        const headerCapT = createObject([0.1, 0.483, 0.155], identityQuaternion, [0.105, 0.012, 0.45], 3, accentColor, getTransform(menu));
        Destroy(getComponent(headerCapT, BoxCollider));
        const headerCapB = createObject([0.1, -0.483, 0.155], identityQuaternion, [0.105, 0.012, 0.45], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(headerCapB, BoxCollider));
        const headerDivider = createObject([0.1, 0.42, 0.04], identityQuaternion, [0.1, 0.006, 0.3], 3, [0.35, 0.25, 0.9, 1.0], getTransform(menu));
        Destroy(getComponent(headerDivider, BoxCollider));

        const neonRibbonTop = createObject([0.1, 0.468, 0], identityQuaternion, [0.099, 0.022, 0.79], 3, accentColor, getTransform(menu));
        Destroy(getComponent(neonRibbonTop, BoxCollider));
        const neonRibbonMid = createObject([0.1, 0.449, 0], identityQuaternion, [0.099, 0.008, 0.79], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(neonRibbonMid, BoxCollider));
        const neonCrownL = createObject([0.1, 0.47, -0.372], identityQuaternion, [0.024, 0.024, 0.11], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(neonCrownL, BoxCollider));
        const neonCrownR = createObject([0.1, 0.47, 0.372], identityQuaternion, [0.024, 0.024, 0.11], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(neonCrownR, BoxCollider));
        const neonRailL = createObject([0.1, 0, -0.394], identityQuaternion, [0.008, 0.8, 0.008], 3, accentColor, getTransform(menu));
        Destroy(getComponent(neonRailL, BoxCollider));
        const neonRailR = createObject([0.1, 0, 0.394], identityQuaternion, [0.008, 0.8, 0.008], 3, [0.35, 0.25, 0.9, 1.0], getTransform(menu));
        Destroy(getComponent(neonRailR, BoxCollider));
        const neonFootL = createObject([0.1, -0.47, 0.372], identityQuaternion, [0.024, 0.024, 0.11], 3, accentColor, getTransform(menu));
        Destroy(getComponent(neonFootL, BoxCollider));
        const neonFootR = createObject([0.1, -0.47, -0.372], identityQuaternion, [0.024, 0.024, 0.11], 3, accentColor, getTransform(menu));
        Destroy(getComponent(neonFootR, BoxCollider));
        const neonBottomBand = createObject([0.1, -0.458, 0], identityQuaternion, [0.099, 0.009, 0.79], 3, accentCornerColor, getTransform(menu));
        Destroy(getComponent(neonBottomBand, BoxCollider));
        const neonSeparator = createObject([0.1, 0.36, 0], identityQuaternion, [0.099, 0.007, 0.77], 3, [0.35, 0.25, 0.9, 1.0], getTransform(menu));
        Destroy(getComponent(neonSeparator, BoxCollider));

        const totalMods = buttons.flat().length;
        let pageList = buttons[currentCategory];
        if (searchMode) {
            searchResults = [];
            const q = searchQuery.toLowerCase();
            if (q != "") {
                for (let c = 2; c < buttons.length; c++) {
                    for (const btn of buttons[c]) {
                        if (btn.buttonText.toLowerCase().startsWith(q)) searchResults.push(btn);
                    }
                }
            }
            pageList = searchResults;
        }
        const pageCount = Math.ceil(pageList.length / 6);
        for (let pd = 0; pd < pageCount; pd++) {
            const pageDot = createObject([0.1, -0.415, 0.12 - (pd * 0.035)], identityQuaternion, [0.014, 0.014, 0.014], 0, pd == currentPage ? accentCornerColor : accentColor, getTransform(menu));
            Destroy(getComponent(pageDot, BoxCollider)); Destroy(getComponent(pageDot, Collider));
        }

        const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
        const canvas = addComponent(canvasObject, Canvas);
        Destroy(getComponent(canvasObject, BoxCollider))

        const canvasScaler = addComponent(canvasObject, CanvasScaler);
        addComponent(canvasObject, GraphicRaycaster);
        try { canvas.method("set_renderMode").invoke(2); } catch (e) {}
        canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);
        try { const menuPanel = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Image); Destroy(getComponent(menuPanel, BoxCollider)); const menuPanelRect = getComponent(menuPanel, RectTransform); menuPanelRect.method("set_sizeDelta").invoke([0.9, 0.7]); menuPanelRect.method("set_position").invoke([0.105, 0, 0]); menuPanelRect.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0)); menuPanel.method("set_color").invoke(bgColor); } catch (e) { console.log("menuPanel failed: " + e); }


        const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        Destroy(getComponent(homeButton2, BoxCollider));
        homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));

        addComponent(homeButton, GorillaReportButton);
        getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);

        renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

        const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        Destroy(getComponent(leaveButton2, BoxCollider));
        leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));

        addComponent(leaveButton, GorillaReportButton);
        getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);

        renderMenuText(canvasObject, "Leave", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);

        const searchButton = createObject([0.105, -0.32, 0.24], identityQuaternion, [0.08, 0.12, 0.06], 3, searchMode ? accentCornerColor : buttonColor, getTransform(menu));
        searchButton.method("set_name").invoke(Il2Cpp.string("@SearchKey"));
        addComponent(searchButton, GorillaReportButton);
        getComponent(searchButton, BoxCollider).method("set_isTrigger").invoke(true);
        renderMenuText(canvasObject, searchMode ? "X" : "SEARCH", textColor, [0.11, -0.32, 0.24], [0.1, 0.05]);

        renderMenuText(canvasObject, searchMode ? `<color=#FF4DD8>SEARCH</color> <color=#8A9BFF>[</color><color=#00D4FF>${searchQuery == "" ? " " : searchQuery}</color><color=#8A9BFF>]</color>  <color=#3DFFB0>${searchResults.length}</color><color=#8A9BFF> hits</color>` : `<color=#00D4FF>[ ${menuName} ]</color> <color=#FF4DD8>BABOONMENU</color>  <color=#8A9BFF>Page</color> <color=#3DFFB0>${currentPage + 1}</color><color=#8A9BFF>/${pageCount}</color>`, textColor, [0.11, 0, 0.155], [1, .1]);
        renderMenuText(canvasObject, searchMode ? `<color=#00D4FF>TOTAL</color> <color=#3DFFB0>${totalMods}</color> <color=#8A9BFF>mods</color> <color=#FF4DD8>|</color> <color=#8A9BFF>tab</color> <color=#3DFFB0>${buttons[currentCategory].length}</color>` : `<color=#3DFFB0>${buttons[currentCategory].length}</color> <color=#8A9BFF>mods in this tab</color> <color=#FF4DD8>·</color> <color=#00D4FF>${totalMods}</color> <color=#8A9BFF>total</color>`, textColor, [0.11, 0, -0.17], [1, .1]);
        if (searchMode) {
            const kbRows = [
                ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
                ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
                ["Z", "X", "C", "V", "B", "N", "M", "BKS", "CLR", "SPC"]
            ];
            const kbRowZ = [0.355, 0.305, 0.255];
            const kbPlate = createObject([0.1, 0, 0.305], identityQuaternion, [0.095, 0.44, 0.115], 3, [0.02, 0.05, 0.16, 0.95], getTransform(menu));
            Destroy(getComponent(kbPlate, BoxCollider));
            const kbEdgeT = createObject([0.1, 0, 0.375], identityQuaternion, [0.098, 0.44, 0.008], 3, accentColor, getTransform(menu));
            Destroy(getComponent(kbEdgeT, BoxCollider));
            const kbEdgeB = createObject([0.1, 0, 0.235], identityQuaternion, [0.098, 0.44, 0.008], 3, accentCornerColor, getTransform(menu));
            Destroy(getComponent(kbEdgeB, BoxCollider));
            const kbGlow = createObject([0.1, 0, 0.305], identityQuaternion, [0.1, 0.44, 0.002], 3, accentColor, getTransform(menu));
            Destroy(getComponent(kbGlow, BoxCollider));
            for (let r = 0; r < kbRows.length; r++) {
                const row = kbRows[r];
                const zOff = kbRowZ[r];
                const yStart = -(row.length - 1) * 0.05 / 2;
                for (let ci = 0; ci < row.length; ci++) {
                    const yOff = yStart + (ci * 0.05);
                    const isCtrl = row[ci] == "BKS" || row[ci] == "CLR" || row[ci] == "SPC";
                    const keyBox = createObject([0.1, yOff, zOff], identityQuaternion, [0.05, 0.045, 0.016], 3, isCtrl ? accentCornerColor : buttonColor, getTransform(menu));
                    keyBox.method("set_name").invoke(Il2Cpp.string("@" + row[ci]));
                    addComponent(keyBox, GorillaReportButton);
                    getComponent(keyBox, BoxCollider).method("set_isTrigger").invoke(true);
                    renderMenuText(canvasObject, row[ci], textColor, [0.095, yOff, zOff], [0.05, 0.05]);
                }
            }
        }

        {
            const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            Destroy(getComponent(pageButton2, BoxCollider));
            pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));


            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, "<", textColor, [0.11, 0.17, 0], [1, 0.1]);
        }

        {
            const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            Destroy(getComponent(pageButton2, BoxCollider));
            pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));


            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, ">", textColor, [0.11, -0.17, 0], [1, 0.1]);
        }


        let i = 0;
        const targetMods = pageList
            .slice(currentPage * 6)
            .slice(0, 6);

        targetMods.forEach((buttonData) => {
            const button = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
            const button2 = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.08, 0.84, 0.09], 3, bgColor2, getTransform(menu));
            const btnEdge = createObject([0.105, 0.4, 0.11 - (i * 0.04)], identityQuaternion, [0.085, 0.01, 0.04], 3, buttonData.enabled ? accentCornerColor : accentColor, getTransform(menu));
            const btnEdgeB = createObject([0.105, -0.4, 0.11 - (i * 0.04)], identityQuaternion, [0.085, 0.01, 0.04], 3, [0.35, 0.25, 0.9, 1.0], getTransform(menu));
            Destroy(getComponent(button2, BoxCollider));
            Destroy(getComponent(btnEdge, BoxCollider));
            Destroy(getComponent(btnEdgeB, BoxCollider));
            button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));

            addComponent(button, GorillaReportButton);
            getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.11 - (i * 0.04)], [1, 0.1]);
            updateButtonColor(button, buttonData);
            i++;
        });

        neutralizeMenuColliders();

        recenterMenu();
    }

    function neutralizeMenuColliders() {
        const stack = [getTransform(menu)];
        while (stack.length > 0) {
            const t = stack.pop();
            try {
                const go = t.method("get_gameObject").invoke();
                const raw = go.method("get_name").invoke().toString();
                const isKey = raw.length > 1 && raw[1] == "@";
                const c = getComponent(go, Collider);
                if (c != null && !c.isNull()) {
                    if (isKey) {
                        try { c.method("set_isTrigger").invoke(true); } catch (e) {}
                    } else {
                        try { Destroy(c); } catch (e) {}
                    }
                }
                const count = t.method("get_childCount").invoke();
                for (let i = 0; i < count; i++) {
                    const ch = t.method("GetChild").invoke(i);
                    if (ch != null && !ch.isNull()) stack.push(ch);
                }
            } catch (e) {}
        }
    }

  let refDot = null;

function findPointerTip() {
        const stack = [rightHandTransform];
        let best = null;
        while (stack.length > 0) {
            const t = stack.pop();
            try {
                const n = t.method("get_name").invoke().toString().toLowerCase();
                if (n.indexOf("index") != -1 || n.indexOf("pointer") != -1) best = t;
                const count = t.method("get_childCount").invoke();
                for (let i = 0; i < count; i++) {
                    const c = t.method("GetChild").invoke(i);
                    if (c != null && !c.isNull()) stack.push(c);
                }
            } catch (e) {}
        }
        return best;
    }

    function renderReference() {
        const tip = findPointerTip();
        const parent = tip != null ? tip : rightHandTransform;
        const tipOffset = tip != null ? [0.0, 0.0, 0.0] : [0.01, 0, 0.2];
        reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, parent)

        referenceCollider = getComponent(reference, Collider);

        getTransform(reference).method("set_localPosition").invoke(tipOffset);
        reference.method("set_layer").invoke(2);
        addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);

        try {
            refDot = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], parent);
            Destroy(getComponent(refDot, BoxCollider));
            const refCanvas = addComponent(refDot, Canvas);
            addComponent(refDot, CanvasScaler);
            addComponent(refDot, GraphicRaycaster);
            try { refCanvas.method("set_renderMode").invoke(2); } catch (e) {}
            const refImg = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(refDot)), Image);
            Destroy(getComponent(refImg, BoxCollider));
            const rr = getComponent(refImg, RectTransform);
            rr.method("set_sizeDelta").invoke([0.042, 0.042]);
            rr.method("set_localPosition").invoke(tipOffset);
            refImg.method("set_color").invoke([1.0, 0.32, 0.78, 1.0]);
        } catch (e) { console.log("refDot error: " + e); }
    }

    let gunLocked = false;
    let lockTarget = null;
    let GunPointer = null;
    let GunLine = null;
    function renderGun(overrideLayerMask = null) {
        const StartPosition = rightHandTransform.method("get_position").invoke();
        const Direction = rightHandTransform.method("get_forward").invoke();

        const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
        const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);

        const layerMask = overrideLayerMask || -3180559;

        const hits = Physics.method("RaycastAll", 4).invoke(
            rayStartPosition,  // origin (Vector3)
            Direction,         // direction (Vector3)
            512.0,            // maxDistance (float)
            layerMask         // layerMask (int)
        );

        let finalDistance = Infinity;
        let finalRay = null;
        for (const hit of hits) {
            const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
            if (distance < finalDistance) {
                finalRay = hit;
                finalDistance = distance;
            }
        }

        let EndPosition;
        if (gunLocked) {
            EndPosition = getTransform(lockTarget).method("get_position").invoke();
        } else {
            EndPosition = finalRay.method("get_point").invoke();
        }

        if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
            const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
            EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
        }

        if (GunPointer == null) {
            GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
        }

        GunPointer.method("SetActive").invoke(true);
        const pointerTransform = getTransform(GunPointer);
        pointerTransform.method("set_position").invoke(EndPosition);

        const PointerRenderer = getComponent(GunPointer, Renderer);
        const material = PointerRenderer.method("get_material").invoke();

        if (TextShader != null) {
            Material.method("CreateWithShader").invoke(material, TextShader);
        }

        const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
        material.method("set_color").invoke(pointerColor);

        const collider = getComponent(GunPointer, Collider);
        if (collider != null) {
            Destroy(collider);
        }


        if (rightTrigger || gunLocked) {
            const Step = 10;
            for (let i = 1; i < (Step - 1); i++) {
                const t = i / (Step - 1);
                const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);

                const randomValue = Math.random();
                let offset = zeroVector;

                if (randomValue > 0.75) {
                    offset = [
                        (Math.random() * 0.2) - 0.1,
                        (Math.random() * 0.2) - 0.1,
                        (Math.random() * 0.2) - 0.1
                    ];
                }

            }

        }

        return { ray: finalRay, gunPointer: GunPointer };
    }

   function recenterMenu() {
        let menuPosition = leftHandTransform.method("get_position").invoke();
        let menuRotation = leftHandTransform.method("get_rotation").invoke();
        menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0));
        const menuTransform = getTransform(menu);
        menuTransform.method("set_position").invoke(menuPosition);
        menuTransform.method("set_rotation").invoke(menuRotation);
    }

    function reloadMenu() {
        if (menu != null) {
            Object.method("Destroy", 1).invoke(menu);
            menu = null;
        }
    }

    let cachedRendererClass = null;
    function updateButtonColor(button, buttonData) {
        if (cachedRendererClass == null) {
            cachedRendererClass = Il2Cpp.domain
                .assembly("UnityEngine.CoreModule")
                .image
                .class("UnityEngine.Renderer");
        }

        const renderer = getComponent(button, cachedRendererClass);
        if (!renderer) {
            return;
        }

        const material = renderer.method("get_material").invoke();
        material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
    }

    function updateButtonTextColor(text, buttonData) {
        if (!text) {
            return;
        }

        text.method("set_color").invoke(
            buttonData.enabled ? textPressedColor : textColor
        );
    }

    function toggleColliders(enabled) {
        const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();

        for (let i = 0; i < meshColliders.length; i++) {
            const meshCollider = meshColliders.get(i);
            meshCollider.method("set_enabled").invoke(enabled);
        }
    }

    let armLength = 1.0;

    function toggleLongArms() {
        const on = armLength <= 1.0;
        const scale = on ? [1.15, 1.15, 1.15] : [1, 1, 1];
        for (const hand of [leftHandTransform, rightHandTransform]) {
            let t = hand;
            for (let i = 0; i < 2; i++) {
                try {
                    const p = t.method("get_parent").invoke();
                    if (p == null || p.isNull()) break;
                    p.method("set_localScale").invoke(scale);
                    t = p;
                } catch (e) { break; }
            }
        }
        armLength = on ? 1.15 : 1.0;
        if (reference != null) {
            Destroy(reference);
            reference = null;
        }
        if (refDot != null) {
            Destroy(refDot);
            refDot = null;
        }
    }

    interface ButtonInfoConfig {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn?: boolean;
        enabled?: boolean;
    }

    class ButtonInfo {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn: boolean;
        enabled: boolean;

        constructor(config: ButtonInfoConfig) {
            this.buttonText = config.buttonText;
            this.method = config.method;
            this.enableMethod = config.enableMethod;
            this.disableMethod = config.disableMethod;
            this.keepOn = config.keepOn ?? true;
            this.enabled = config.enabled ?? false;
        }
    }

    function hsl2Rgb(h, s, l) {
    s /= 100;
    l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [
      Math.round(255 * f(0)),
      Math.round(255 * f(8)),
      Math.round(255 * f(4))
    ];
  }

  function getSmoothColor() {
    hue = (hue + 0.5) % 360;
    const [r, g, b] = hsl2Rgb(hue, 100, 50);
    return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
  }

    let lockdownActive = false;
    let trapRigs: any[] = [];

    function distSq(a, b) {
        const dx = a.field("x").value - b.field("x").value;
        const dy = a.field("y").value - b.field("y").value;
        const dz = a.field("z").value - b.field("z").value;
        return dx * dx + dy * dy + dz * dz;
    }

    function addToPos(v, x, y, z) {
        return Vector3.method("op_Addition", 2).invoke(v, [x, y, z]);
    }

    function startLockdown() {
        lockdownActive = true;
        try {
            PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke());
        } catch (e) { console.log("[Lockdown] set master error: " + e); }
        try {
            const Lockdown = AssemblyCSharp.class("LOCKDOWNNNNNN");
            const lockdown = Il2Cpp.gc.choose(Lockdown)[0];
            if (lockdown != null && !lockdown.isNull()) {
                lockdown.method("RPC_StartLockdown").invoke();
            }
        } catch (e) { console.log("[Lockdown] start rpc error: " + e); }
        try {
            const room = PhotonNetwork.method("get_CurrentRoom").invoke();
            if (room != null && !room.isNull()) {
                room.method("set_IsOpen").invoke(false);
                room.method("set_IsVisible").invoke(false);
            }
        } catch (e) { console.log("[Lockdown] close room error: " + e); }
        try { sendAllOutgoing(); } catch (e) {}
    }

    function stopLockdown() {
        lockdownActive = false;
        try {
            const Lockdown = AssemblyCSharp.class("LOCKDOWNNNNNN");
            const lockdown = Il2Cpp.gc.choose(Lockdown)[0];
            if (lockdown != null && !lockdown.isNull()) {
                for (const m of ["RPC_StopLockdown", "StopLockdown", "RPC_EndLockdown", "EndLockdown"]) {
                    try { lockdown.method(m).invoke(); console.log("[Lockdown] stop via " + m); break; } catch (e) {}
                }
            }
        } catch (e) { console.log("[Lockdown] stop rpc error: " + e); }
        try {
            const room = PhotonNetwork.method("get_CurrentRoom").invoke();
            if (room != null && !room.isNull()) {
                room.method("set_IsOpen").invoke(true);
                room.method("set_IsVisible").invoke(true);
            }
        } catch (e) { console.log("[Lockdown] open room error: " + e); }
        try { sendAllOutgoing(); } catch (e) {}
    }

    function collectRoomButtonPositions() {
        const positions = [];
        try {
            const all = Resources.method("FindObjectsOfTypeAll").invoke(GameObject);
            const names = ["room", "join", "private", "code", "cell", "computer", "keypad"];
            for (let i = 0; i < all.length; i++) {
                const obj = all.get(i);
                try {
                    if (!obj.method("get_activeInHierarchy").invoke()) continue;
                    const nm = obj.method("get_name").invoke().toString().toLowerCase();
                    let hit = false;
                    for (const k of names) {
                        if (nm.indexOf(k) != -1) { hit = true; break; }
                    }
                    if (!hit) continue;
                    const t = obj.method("get_transform").invoke();
                    if (t == null || t.isNull()) continue;
                    const p = t.method("get_position").invoke();
                    if (p == null || p.isNull()) continue;
                    positions.push(p);
                } catch (e) {}
            }
        } catch (e) { console.log("[Trap] scan error: " + e); }

        if (positions.length == 0) {
            try {
                const cells = Object.method("FindObjectsOfType").inflate(AssemblyCSharp.class("RoomListCell")).invoke();
                for (let i = 0; i < cells.length; i++) {
                    const t = cells.get(i).method("get_transform").invoke();
                    positions.push(t.method("get_position").invoke());
                }
            } catch (e) { console.log("[Trap] class scan error: " + e); }
        }

        const unique = [];
        for (const p of positions) {
            let dup = false;
            for (const q of unique) {
                if (distSq(p, q) < 0.09) { dup = true; break; }
            }
            if (!dup) unique.push(p);
        }
        return unique;
    }

    function TrapAll() {
        try {
            for (const r of trapRigs) {
                try { if (r != null && !r.isNull()) Destroy(r); } catch (e) {}
            }
            trapRigs = [];

            const positions = collectRoomButtonPositions();
            console.log("[Trap] room buttons found: " + positions.length);

            let KickHammerClass = null;
            try { KickHammerClass = AssemblyCSharp.class("KickHammer"); } catch (e) { console.log("[Trap] no KickHammer class: " + e); }

            for (const pos of positions) {
                try {
                    const spawnPos = addToPos(pos, 0, 0.35, 0);
                    const rig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer"), spawnPos, identityQuaternion, 0, NULL);
                    trapRigs.push(rig);

                    if (KickHammerClass != null) {
                        const hammer = createObject(pos, identityQuaternion, [0.55, 0.55, 0.55], 3, [0, 0, 0, 0]);
                        const coll = getComponent(hammer, BoxCollider);
                        coll.method("set_isTrigger").invoke(true);
                        const kh = addComponent(hammer, KickHammerClass);
                        const pv = getComponentInParent(rig, PhotonViewClass);
                        if (pv != null && !pv.isNull()) { try { kh.field("playerview").value = pv; } catch (e) {} }
                        try { kh.field("thisthincolider").value = coll; } catch (e) {}
                    }
                } catch (e) { console.log("[Trap] spawn error: " + e); }
            }
            sendAllOutgoing();
        } catch (e) { console.log("[Trap] error: " + e); }
    }

    let killGunObj = null;
    let killGunTip = null;
    let killGunLastFire = 0;

    function removeKillGun() {
        if (killGunObj != null) {
            try { Destroy(killGunObj); } catch (e) {}
            killGunObj = null;
        }
        if (killGunTip != null) {
            try { Destroy(killGunTip); } catch (e) {}
            killGunTip = null;
        }
    }

    function spawnKillGun() {
        if (killGunObj != null) return;
        try {
            const handPos = rightHandTransform.method("get_position").invoke();
            const handRot = rightHandTransform.method("get_rotation").invoke();
            killGunObj = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SMGCommon"), handPos, handRot, 0, NULL);
            if (killGunObj == null || killGunObj.isNull()) throw "no prefab";
            try { Destroy(getComponent(killGunObj, Rigidbody)); } catch (e) {}
            try {
                const cols = killGunObj.method("GetComponentsInChildren", 1).inflate(Collider).invoke();
                if (cols != null) { for (const col of cols) { try { Destroy(col); } catch (e) {} } }
            } catch (e) {}
        } catch (e) {
            console.log("[Gun] real SMG failed, using built-in gun");
            try {
                killGunObj = createObject(zeroVector, identityQuaternion, [0.045, 0.045, 0.17], 1, [0.0, 0.95, 1.0, 1.0]);
                try { Destroy(getComponent(killGunObj, BoxCollider)); } catch (e) {}
                const barrel = createObject(zeroVector, identityQuaternion, [0.025, 0.025, 0.24], 2, [0.18, 0.18, 0.2, 1.0], getTransform(killGunObj));
                try { Destroy(getComponent(barrel, BoxCollider)); } catch (e) {}
                const grip = createObject(zeroVector, identityQuaternion, [0.025, 0.05, 0.03], 1, [0.0, 0.55, 1.0, 1.0], getTransform(killGunObj));
                try { Destroy(getComponent(grip, BoxCollider)); } catch (e) {}
            } catch (e2) { console.log("[Gun] spawn error: " + e2); }
        }
        if (killGunTip == null) {
            killGunTip = createObject(zeroVector, identityQuaternion, [0.015, 0.015, 0.015], 0, [1.0, 0.3, 0.0, 1.0]);
            try { Destroy(getComponent(killGunTip, BoxCollider)); } catch (e) {}
        }
        updateKillGun();
    }

    function updateKillGun() {
        if (killGunObj == null) return;
        try {
            const handPos = rightHandTransform.method("get_position").invoke();
            const handRot = rightHandTransform.method("get_rotation").invoke();
            const fwd = rightHandTransform.method("get_forward").invoke();
            const gunPos = Vector3.method("op_Addition", 2).invoke(handPos, Vector3.method("op_Multiply", 2).invoke(fwd, 0.12));
            const t = getTransform(killGunObj);
            t.method("set_position").invoke(gunPos);
            t.method("set_rotation").invoke(handRot);
            if (killGunTip != null) {
                const tipPos = Vector3.method("op_Addition", 2).invoke(gunPos, Vector3.method("op_Multiply", 2).invoke(fwd, 0.3));
                getTransform(killGunTip).method("set_position").invoke(tipPos);
            }
        } catch (e) {}
    }

    function fireKillGun() {
        try {
            const now = Date.now();
            if (now - killGunLastFire < 200) return;
            killGunLastFire = now;
            let spawnPos = null;
            try {
                const start = rightHandTransform.method("get_position").invoke();
                const dir = rightHandTransform.method("get_forward").invoke();
                const hits = Physics.method("RaycastAll", 4).invoke(start, dir, 512.0, -3180559);
                let best = null;
                let bestD = Infinity;
                for (const h of hits) {
                    const d = Vector3.method("Distance").invoke(h.method("get_point").invoke(), start);
                    if (d < bestD) { bestD = d; best = h; }
                }
                if (best != null) {
                    spawnPos = best.method("get_point").invoke();
                    spawnPos = Vector3.method("op_Addition", 2).invoke(spawnPos, Vector3.method("op_Multiply", 2).invoke(dir, 0.25));
                }
            } catch (e) {}
            if (spawnPos == null) {
                const dir = rightHandTransform.method("get_forward").invoke();
                const base = (killGunTip != null) ? getTransform(killGunTip).method("get_position").invoke() : rightHandTransform.method("get_position").invoke();
                spawnPos = Vector3.method("op_Addition", 2).invoke(base, Vector3.method("op_Multiply", 2).invoke(dir, 3.0));
            }
            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), spawnPos, identityQuaternion, 0, NULL);
            sendAllOutgoing();
        } catch (e) { console.log("[Gun] fire error: " + e); }
    }

    let currentCategory = 0;
    let currentPage = 0;
    let searchMode = false;
    let searchQuery = "";
    let searchResults: ButtonInfo[] = [];
    let __huss_unlocked = true; // NEXON ONLY BUILD - no key lock
    let passwordInput = "";
    let __huss_lockUntil = 0;
    let __huss_lockMsg = "WRONG KEY";
    let __huss_pendingKey = false;
    let __huss_pendingAt = 0;
    let __huss_pendingReply = null;
    recv("validate-reply", (msg) => { __huss_pendingReply = msg; });
    let flyspeed = 5.0;
    let hussFlyLastLog = 0;
    let ghost = false;
    let thorKickEnabled = false;
    let thorKickLastPrimary = false;
    let lightningHammerEnabled = false;
    let lightningHammerLastPrimary = false;

    // --- New Mods state ---
    let ghostMonkeyOn = false;
    let brokenNeckOn = false;
    let brokenNeckHeadT = null;
    let brokenNeckBase = null;
    let scaryGhostArmed = false;
    let scaryGhostActive = false;
    let scaryGhostRig = null;
    let scaryGhostFrozen = null;
    let invisMonkeyArmed = false;
    let invisMonkeyActive = false;
    let invisMonkeyRig = null;
    let ghostNameSpamOn = false;
    let ghostNameLast = 0;
    let daisyLast = 0;
    const DAISY09_B64 = "SUQzBAAAAAFIRlRJVDIAAAAdAAADRGFpc3kwOSBUcm9sbCBNdXNpYyAgKFNjYXJ5KVRQRTEAAAAJAAADQXVzdGluR1RBUElDAAFIAgAAA2ltYWdlL2pwZWcAAwD/2P/gABBKRklGAAEBAAABAAEAAP/bAIQABQMECAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKEA0ICA4JBwcNFQ0OERETExMHCxYYFhIYEBITEgEFBQUIBwgPCQkPEg8QDxISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhIVFRISEhIVFRUe/8AAEQgB4AKAAwEiAAIRAQMRAf/EAB0AAQABBQEBAQAAAAAAAAAAAAAFAQMEBgcCCAn/xABPEAACAQMCAwQFCQYCBgkDBQAAAQIDBBEFIQYSMQcTQVEIImFxgRQyM4KRk6Gy0hUjQlKx0ZLBJVNUYnLhFiQ0Q3OiwvDxY6PUJjV0g7P/xAAcAQEAAQUBAQAAAAAAAAAAAAAABgECAwQFBwj/xAAzEQACAgIBAwIEBQQCAgMAAAAAAQIDBBEFEiExE0EGIlFhFDJScZEVI4HRQqEzkoKxwf/aAAwDAQACEQMRAD8A+MgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAX6tpUinKUcJYy8xfV48GWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACuCqg/IFUtnkF+FpUayoNrz2KK1qP+F/gU6kX+jP9L/hlkGbS0u4l82jN/Ay6XDF/L5trUf+Ff1ZTrj9UXLHtfiMv4ZDglq3Dd7B4nQlF+TlTX/qPK0C7/1X/wByl+os9ev9S/lGxHjMuXdVWP8AaEv9EWDZ+HOAdW1GsreztO+qy6Q+UWtPP1qtWK/E2DX+w3imwp99d6YqNNfxO+02a/8At3LZcrYPw1/Jinh3wl0yhJP6OLT/AI0c4BI1NEuovDpb+ypTl+KkZ+kcGaldz5Le27yXl31vD8alRIp60P1L+UZFxuU/FVj/APhL/Rr4N/o9jfEk3iOnKT8le6f/APkFy97E+J6MHUq6Y4QXWXyywa/C4Ctg/dfyjG8LIT065/8Aq/8ARzwEnqWg3dtPu61LkmvDvKUvxhJov6XwrqF1tQtpVPdKmvzSRX1IfVfyVWFkN6Vc/wD1f+iFBMf9Gb7vHSdDFRPDi6lFPK9rngvahwdqVvSVatayhSfSfeUpL/yzbHqR8bX8iWFkRW5VzS+ri/8ARAgq4sYLzVKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnNU+in9X8yIMnNU+in9X8yIMqwAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACBcp03JpJZbeEATHDGizuqqSjJxT9bCzsb5qvB1tyr5PzNqPr82PneJKdjOgXtGpBul+6rNbyjs0/Jnce0jh7S9JslXnS9erTy3n+KS/uc7Ksk3qJM+Ew8eCTyFvq8HyrcWkl+7wkltsSvDPc29WM6sFNeWMkfxBdx55Sh0bbSI3TtTcKsZT3in0MSjOS3s6Vl2Lj2aUd//SPqjgD9l3Np38qNCHL4TjGLePYzC4n40srTMaNtQk15RT/ocG1XiiVRxVCUqUMJOKeEyltWc0nKbb9rbMF0ZRXlnQwVRbZvSaNg4z4h+WVO87qENukdjXqVVPfJYvpZ6ENcXko+qmWV09Zt5nIxxpfZHbOFrSrZ2b1O3fr00t+n9CC1ztTv75OjcTbp53WW/wAGajYcb3kLSVnzpUpLdFi2ubZW8lOD715fMbEaWk0ci3kFbJWaTL3y2n38WllZ3WCcvK06FLv6U3Tz4RaUjR9MuowrxnPeKb2JbV7r5RvD1Y/y52LLKF2NjF5WUlJRS2/BP8Jdo91Z1+8lUnUXlJtnXuKu19XWjyilTU3FdPnHzVWo4RjSo1ZbJvHv2+wzRrgcnJutb21t/YlLq/d1X5p9WzbNI1l2MOajtJrc57TTpPJ6qanKXq5KWY7k10sz4XLxx4NWL5pHb+wzR46rq7ndKLjKLk01lZNq7YOD6tWtOzt5QjRS9WOdvsPnvQeMb/TpqpaVe7kljOCcpdo+oXM+8r1uao9nLDRfKtxjteTFj5sLbnCb0pLx7GncYaFOwrSpTabTxlMgmdM1/RvllCV3UuIufXlbyzm9enytryeDcx7euOiMctgvHtevD8FkFcDBnOSUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOap9FP6v5kQZOap9FP6v5kQZVgAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVwAVwTHDOk1rqpiik5R9bd+BEwjl4OicEaBdUXTuI/Mm0njK2Ziun0x2dHjMX17lF+DvPo8qtW5qNysKhjlz0WFnZs1v0me0ajfRlYU1iVCXI2v93bOyN9rXkNE0qndzi26sG249eh8p8Q3vyy8rV1sqtRz39r8TSr8Nsk+co9ajD27IwacZSWXn4mFcTw8Imq9SMaePEhZ0uZsy1PvtmlnVuKUYvbLVKs8k3pteUsIwLG2XMubZeJsV7GhSjB0t3/ABZLb3Foy8TCyD6m+y8nu4woZ8SKhYSqttRbXngzqtxGoko+W5u/Cd9aW9rUpVYZqVItRljZN+80lL00yS2UxzJL9KOY16HdSWSZtLCFek55w0umcHriCzXNnKwyH7ydPaMng2IS61s5N1H4axprcSX0jhW4uFKVKnKSj4pZMPUo1LV93UWH5dDvXo+a9Tp2F3z04SlGGzksvODjHaJqSur2tOSSanJJLZFyX1MM5KEd19jG06VGdPM5Yl5MpNwinjciLGhOrUjTp9ZPC95uXD/C1eN7Qp3K9WpJbfFFkq1vyZ8fOk46Udv6mqVqDkm8P+hDP1ZHZO3vQKWmzpKisRlTi3jzaONcjnLZGzV4OJyElKS6V82zKbTRjKThLboZUaEordFueGXRfsYbYPSl4aNi4duVXkqM58sWRvGmkwtq3LTnzprOSPtZ8k08436pm4/Ibeta95OWamNlnLLFquXb3N7pnnVdL/NE520DJvaPLJ+WWYxuLuRaytwbTPIK4KFTGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATmqfRT+r+ZEGTmqfRT+r+ZEGVYAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHrJRHqMMvCQCW+xm6PZyrVIwj1yfRHYVpk51+4unzUoJNKWy+1nFODtNqSqxaTz7Dp2s8Tzs7VUIJ06yW8ukvtOZl27aiidcFxzqpd0vPsbP6QnHlGVKWl04JKguVNPKPnKNziRd17U6lerKdSTlKT3k92zDtKXNLfJsQhqPc42RkudvTX9TOp81V48DZ9P0ij3eZyw8Z3TLHDGkTr1FCnjO3XH+Zs3GXyanShb0W1cRxCovDmNSyTb1EkuDRCqDstW212NDqwXfKnDfMsLHibpd8C3at6VRwwqi2eVkjNU4PuLOhC8qOOJ4ccP1l49C9ouoXt01TdeooQXqpye3u3L5+Ea2M25yTX5jzqPClawpxrVfmv3f3IO+1PPRl7ie+uHN0qlWc4p4Scsr+pCzprAjWpd2W25k6d1VdtF2tezk0m8l+SXJllnTbVSeWzIuLZy9WO5dJxT0YqldODnLvvwiQ4e4ynYU6lOCyqiw3noazdXUq1WU31m8mRf6TVgk3HqWbGnyy3RsJxS2jjzhdKxQntI6h2ScJTquF68clH12njdeJuPGnFttUnB0aWJ0VhSXmuhDdl2iXt7SlTtqqhDHrJyxlfabHecMR0ylVVxyTnNN5ymcq217J3x2LXGGk9vRxvjbiG61Cp+/qOeNop+C8EbjwH2dUq9hUvKlRRlTjzcr8TQNTkldOSWEpvY3WHHM6Vo6EEkpRw8eJt9XyHChRB3Sm/wDj4NQ4lqw55RikuXMffg1xxbySVeMq9XEfnVJYS9rfQndQ4TuLGnGpc0+WNT5raxnJki+hbNG+LybdeDUKVGTZJ6fKSeHnBkW9Fc/sySWoUaWYuHgln3lllyZtYXHSrfUmWrnh2deDqU455Vl/+2aheW7hJp+Gx0jTrrZUoya5tuvnsQ/H/C87VRquUZKa5tmm9yuLc96ZX4h4qtQVtfn3NHKMqwzokHPIKoMFCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJzVPop/V/MiDJzVPop/V/MiDKsAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAekS/DlBurGcoOUE/WXsIlLPQ3/hLWKVtbTpVKCc5xwptYxnyMdstI3cCrrtWzaNEu6FKca8IqKh/B5mXxdplXUoO/VNwpqPLnG2xpOnVpVKvKsqMpeBv2v8AG07Cw/ZqpKSlHPO+vrI5Ci3M9GuyoKldK7Jd/Y5Jdaa51OSG7zjY2mz4EvI2zuZUZd2v4sbEfwRWg7yE6rxDmyzv1LjTT3a/JHP92+uxnsscVo5eHhwsm7YpfscO0q+natypvEl7PIpZXcZ3Eq1wnKUnzN+02DiDTaNzduFljkk9vBZNe1aydpN06jXNHrhrBrQe+6O3dX0669JDiLXqtwlScs0o/Ni87I8W+qQp0koRxPG7NevLuPNsYde8yjajS5Ij9nJ11Tck+5mXc3WqZznLJi20qHJmTxsatRveV5M641qUo8q22L7KZ9kjXxORxV1WW95Mu3daNOXLFrBtPZ/cWTqSd04pY2y8bnOKlZyeSiqPzM34ba0znw52VdnVFdvZHU+PdWspJRoNbdMbnP6lzHqiLdRlOb2lYY6ijFl85ZfLqaS/wbxwnxrXsPopuKfXBM6z2jTuI4m23jBy/mKNso8SLZfT8RZFUemJK3l9zzcltl5PXyjKSIg9KbMjpS7GmuSsbbl7nT+y61tqlelKvKKcasWub2NH0z2jcOW+sWNGEIxm6ME1y+xHxZo+oypyWHjDTyfS/YJxTO4nKE6uyitpPH9TSsi4v7EnwJVZFW12kv8As4trekTt7mrS5WlTk0skbUuIxeGfSXpDULCFp3lCFNVmszlHGW37j5dr05SnnD3Zj6E2b0shwr+Vd/BclXnGSkm+udift6UtSg41aqiox25m/BGz9lnAVLVVU+UVHRUFmLlspbe01viDTY2dzUoU580YzcVLzWS7qS7oxRrdjcX3TRoerWipVZQTyl0fmYJ0Difh2hC1jcQqOVSW7iaDKO50Kp9SIVn4jpsf38HhBlSjMpoFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATmqfRT+r+ZEGTmqfRT+r+ZEGVYAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAArgoACqCK4Kgz9Jtqk6kZQg5qLT2Wehudxz3cUo08d2lnCX4kZwJq6tXLMFLmTW/hn3k/pmqKjObWEqmcr3nOyrXvRMeAwFKPVIkuD6FjSpVKly8VYZ5N8b+GxpHFGqzu67cntFuMWv5fAkOLrilLDpveXzsEJaUPF/iWVrS2zZ5D5rfSg+y8nq1jyLbOSSsq78ZfiR86sUYV1eY+aV9N2FizIYiT2T9xrjpfMeJLo09zXtQ1SrVk5Sk5N+LbyYM5yk/ErSt5S6JmzVjwrW2cbN5bIzJajvX2PE6jfieUSdto9WfSLM+nw/UxvF/YXSvhH3MNPEZV/dRZruGelTb8GbTZcPSlLHKbbpPAk5JN0/wNeefXE62N8IZd3drX7nKu5l5B0peR2O64BcFlxSRGXXB8VHmMX9Ths3H8D5Hszl6pN+DL1KxqS6Rb+B0a14Si93sTOjaJRoz3w0Wy5SK8GzjfAWRN/O9HLaWiXEulOX2FZaFWXWEl8Dv1rY00uaMY4IDXHT5mtsp+w15cq/ZHXr+Aa/+czjz0Wr/K/sMW4spw8Dr9rSpS+dgi9W0mjKUsYwXw5R77oxZnwFCMP7cjlcU0TnDfElxZybozcW9nuZur6GlvE1u4t3FnShbC5EHysDK42zv4N4vOLbi8jyVqjl722U7+CjHCTaab2NHoVpRZtvBkI16qjUlhe01r6Onujt8Zynrvoku5vi4jqXVvTt7anOEoLDdNcufe0QD0ivWqOHLKVTq08uR12ho1nYafG5tZqdeUcuKS6kf2Gv5VrrVeKzKMsxaNF7k9JknUoV0uUo+P8ABxniChVpt0ZqSa/heTWp6dPyZ9C+kFwfVpahWqwpYpqOU0iC4Z7NLq8tflEINrGenh8Tahc6+xxMjj6sxqyT6U/BxupotVQ58beWCLq0nF4ex1y3svk167a5jmK8Gah2iWtKNxLuopR8kbVWT1PTODn8Iqq3OHdI00FWUNwjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOap9FP6v5kQZOap9FP6v5kQZVgAAoAAAAAVwAUB6UW+iz7i9CxrPpTm/dFlUmyqTZjgzf2Vc/6ip/hZZqWlWPzqc174tDTK9L+hYBXlGChaUAAAAAAAAAAABXIRQqgCQ0e3jUliTwiZjokZP1d0a9Zv1tmfXPYJ2Y2moWEa9enzNwzl+41L3L/AIkj4hUNf3l2Pm6lYcmyW66mdb6bOqmotLHmdlsuzmP7Ru6cofu4OfKn7OhyHjmtKxu6tCm+XlZoR3KWiVWehRTtdtmRwbwNW1OrUhGcIunn5zx095AcR2crSc6TabhJxyujxsNA167o1E6NRxc2k379vAmuP9Cq0beF1Unzd5v8Zbm5rukR/wBWPpzkvc5/Urt+JesrSVV7bmNTjzPB0PgXQpvE3BtdfgZMi5VR2aXDcfLPyFCW9HjQeEYShzVNtsl2vp1tRliOGbNr1ZpRp0er2wupJ6F2ZXl1bSrSoyy947dTkq2dvlnol2Di8fqMIpv6s022vqVPbCx7jKlqdFrp+B0zgzs0oqlJXlLFTLxnYvan2Y27klRiot+0xypT92bFHKTi9RUUjmdtew2a2OhcJXsJ04rmWfeWr7sirQg5xrJJJvGxzy4qXOn13HdqD6owfh+/Y6n9bXRqST+6OjcVTm06alheaZpVStKnLlcuZe15Mm319XEHF5TfiYlajvnqas/lemdzEirYKcO5n29TnjlvBg393Gm8ZRh3l26UWkzB0fSbvUqvJQhKe/gsmWnHc+5r8rzscWPSvzEjPierGPJDoR9jSur6tyU160junB/ZnY2tmqup0uWaWZc22xa/a/DdjU7ygoc0em6N+NPStIhl3LO17ba/bwcbnoV9C4Vs01N+3YprGjXlrLlqRk/as4Oi6tx/pMrnvowUpro01sbXw1xNpmqtUpUUqkljnfgVdeuzRjqz5NbUnI4DTln1ZrHvIzWtIUk2jtnaT2YOjGV5RqJwTzyJHLYSxmE1jdrcxblU9o34Roz63XYu/wBTm99aunLBsfZuoSr4m8Is8U0knlEFZXUqUsrY7MZetUecXVR47O7eEz6U4e1OwjONKvU/d48zC4Y1u0s+II1beT7rfc4LPVJzwuZ/azeeCNPcqffNvK8fE0ZVejHbJXVyD5O9Vx/Lo+seMb2zv7GdeWHmH+RP9iVtQr6fOFNbKLXT2Hz1acSNWjtnP5yaS8TpfYJxvR09/JK8sSq/NbeDFj3qUu5sczxFmNjNQe2mcb9IOzdrrkorbbKwcj4qqOW73O0+lFdUq2tqpSkpRcFuumTivEMXj7TZgl6qORa5Pj2n5NXaKHpnk6x5+wAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJzVPop/V/MiDJzVPop/V/MiDKsAAFAAD1GDbwAXLWhOpJQhFylJ4SRvmgcBwwql7U5E/+7j84y+DtCjbwjWlHNWayn/L7F7TYpUJzfrLrvls7uBxLtXVPwSbjeEdi67Ee7TTNNoLFG3Ta/imst/aZDrRS9SNOP1UYioMfJ37SSU8bUl4RLKOLqS10ovO8l4tNe5f2Kxqwl8+nTn7JQTLDtm+h7hbmf+m1v/ijM+Jrb/KixqHDlhcp81FU5P8Aip7fgajrfZ9OCc7ap3sV/C/nG9xo48cHpTlHbLNHM4SuS+VaZoZvw7TNdlpnDLq3nSk4zi4yXVPYtNHZtb0WheQaqRSnj1aiWJJ+3zOV67pFW0qd3U6eDXRoieXgWY77+CEZ/GW4r7919SLBXBQ0TmgAAAAAAqihVAGXp8cyPtbsop6hU4cjHTtqqpLo8M+KLCWJH3b6Ims0pWHcSazy4x8DXs/MdvDeqexyK+u9VhXnSnUlC43U/WZzrjzhmunK4rSUpPdvOWdq7frZ215UrQym5Pf4kPZcHxv9Mjd1a63TymzkfNC1s9Esjj5OHBNfNo+dqNZQlH/dkn9jybdx/wAYxvtPo2qpqLp4bkurwiN4s0Hua8o08SjnZroYGp2FKFspZ/eeKOlXZFkMzMO2ClGS0iB0yP7xe87Dw7rPdUUlFbxwci0xfvIr2nTb3T5UranNZ3SNTkU5aR2vg2cKuqTWzp/ZFwlR1CtUrXD5Yw9Zf1PHap2py0yo7OylmNP1ZPp06ENwFXv6VKUoTSjKPQ4z2hV5yva7m8yc3ktxIJ9jZ+IcicN2vw/CNh1PtV1CpLPeyXubMGn2lak5Z+U1PtNDbbCOn+Hjogv9Wu6tpnW9K7Qr+bj3l1UlFNZjnqvFHT6Nva6pp9SrGEVW5NvPPmfMNrcyjsmdH7POJq9FxpU8ycnhR65NC+jo7kv4rlY3pQa/c83NlVs6vJNNZe3tRL0pvlz7Dzx3Vu6lanK5pOn/ACprGUZNnb5pZ9hyMqHuei/D92+pJ9l4Nb1aTnNQXV7HcOw60paZZTvLhpSW6XsOFajCXfRUNpZ2N1u7q+tbHu6kswnDK9iwblGowRGOVi78iafsZPbL2uzu51aVCX7qSccHDbvUJS8SurVXKcva2R84NHXqqjrbPPM/Ns6nCHhGx8JU4VbiEKjwpSSydzr8MULKynd0LlRqQipRUZLOT5st68ovMW0/PoTNHXLhrllWqOL2cXJtfYY78bqezf4rmvSh0NeT6k4R4kq3Oi1FNd9NdObc4hxK6nymXPDu229lsjfuyC/lDTKs+qjk1TiC8+WVpTkkmm1svI5d0uh6ZOOMod8VKPbZo/EFNtbmp1lubrxTiKwaVVe7OngvcCEfFdahkdPuZumWzm0bjp2oTtoKPM0vFGsaJJprG5udrw5UuaMquVHlWcPbojFkvql0s3uCXo1erX+ZFNL1hVbujHzmupufHlCpQdGrScoy5U+aPVfE5FpdR0LynJv6Op/RnWuJeMaNW0jSUczccJ49hisxlBJxOtg8vbkykre6NKr1Z3FxT76pKXNKMXKXVJ7HntL06jbKKpz58rw9xL8OaHTuLerXq1FTlHmcU3h7Zxg5xr1zKVSSc3JJtLL8DLj17kmcnmMxV1OCWuoipdTyypQ6hA/JQAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATmqfRT+r+ZEGTmqfRT+r+ZEGVYAAKA906blJRisuTSS9r2Oh6T2f3FuqdxeR5FLDjH+5pnDMoq9tXPHKq9NvPTCksn1Hx9pEqlpSqKSwsSS6rGNvcbeFWp2pM3cCpTtSZo9jarHM+iW3u8CltbVrubhRfJFPDljOC/Rw4NZ3wTvZrtUmtsRlmSa2fnkl2XN0UrpJvyF08ahOHYgp8J32fUqSn/AL3K+UtvRtRi16kanlvg99pfHeqWt+4U5RpW2YKKhFcrXjlmz2vFdpO2pzrXEHUmo7Q2mn8DgrlLV7kShz+TB+TVr61vKCzWtJpYz6nrf0MOhe1ZPELeq3/ws6fDU61NU4qUKtKtH1edet+JHV7uffq3pqFOc3jmcUbH9duSN2PxZkJeTVKWi39SHP3CjHznJL8DAv8AS72Ecru37E9/gbZxfxXY6VDu6lV3l0/nU08KP/Iz+A+ILTUKHe3FOhHfEaafrpeZZLmrpGvP4myJvyc10y6kpqlXXdyfTPj8TM4s4ep3NrLKzUjHmhIn+0+xtoVId3HOZRcZeKyeY1OWNKD3UsL3o24XvIrfWtnYxs38ZS42LZ85XNGVOUoSWGm017i0b321aZSttRXdRcY1aMZtP+bxZohF5rpk0Q+2HRNx+hQAFhjAAAAAAMi0puUkl19h2/sE4qraXe0lJyVN/wAL2Rx3hm7hQuKdWouaMZJtYzsdI4r1i2u40q1pinKKWVHZv7DVyE/Y73D9D2n5Oxdues0761lWi0m/Jmi6TxP/AKIVBPeKfj/kc5u+IavculOcpe9sjrPVeSLjlmlKE2mSyrIoqtjt9kv8E7Xu5T2x9prvEEGZtC/zuWrpOruzHSnCXc2eSujlUtR7tmv6btUj/wASO2VZd/Y0kusVH+hxSa5Ki96/qdy4VdOtZRSkublX9DJyG3FSRz/hFxjkSqkbN2PzVepO3nvyroce7X9K7rUrlKLUed4ZtOm6xPTLucoPGWstG48eaJS1Oyp3NOKnVlHmly7yz7TXxp9Pc7fOYrubjLx7HzZUssLKMOcMG06xplWg5KUJLHmjXbik2+h16reo85z8L0npIsR2Z1nsV0KrVr07lLMaL5n5Y9pzXTtPnUnFJN5aSPpfs3VPRtNnO5WO+hiD9uDFl2LR0OAw7PU62uxD9uGs07irbKOG6aUZY8PeYujQjUoPGPm/5Gla7cu4vKkllxc8x9xOafVlCCSeM+RwcuaSPWPh6iW5NeCA1aTp108dJf5nULSUNTseSC5pU6T/AARoet2fNHm6smuyLiWFjcd1VXq1HyvPTfYy0WKcUjS5bFnj3Sl+pHJdc02dKrPmi0lJrf3mNOEOXwyfTXalwLb3dKNa2SlKS53Gnh9d98HBtT4NvIzlGNGo0nj5rOrXdvSPP8nj5R3KK3s0qqt9iW4a0upc1YUoLLk8I2HTuAb2U481CaTfjFnbezvs3o2NN3dynFxSlDbHtM9ly12NLC4mbs659l9DD4etFpGm1Le69SdVNxT67rY5jO65JVJe14+Ju/afr8b2uo0/m01yfBHMuIqnLHqcd/3bNHoSn+CxvVXbRFcS6h3jxk1+mss9V6nM3kytFsnXrU6ces5KK97Z2q61XDSPLc3Lnm5Dk/c6n2Q8C0r2MridRKNHfle3N7DL7VNUhbYpWqUEo8ssPr4EdrGl3uiUYN1JwjWS2i2k0Q1haT1Lmbbk4pvrnoaUk5TTJVRKNeO4RfzNGlVK0pT5s7t5+JM2NSphObeF5mPc2ipVXFr5rPepX8VBRj1wbE/n7I5OP/Y6p2S/wXtX1yXLyQbS6bPqazUk28t5FSpzM8GzXWoI4ebmyyJbfgHkrkoZDRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJzVPop/V/MiDJzVPop/V/MiDKsAFcAoD0njDz06ew61wf2mVatvHT7pc2FyUqq67LZSORszdHli4pP/fj/UzUTcJpo2MW112Jr6na7G4fPnwR5hqtW3qyqU88r+dBePvMSz269WZEoLy38SfeisinuenyxVl0af0NmsJWOr0lTrwU5rDTb5Z+7cl9K4G0y35akbecqqfqpvME/A5vKHLJODcJLxi8G/dnmvV6zlbVJqpLGzfVR8H7yMZ3HOp9iAcrwssZ7Xg2K+0a5nKNRwWILEIx6JezHiYt5p0nOFXHJWhhrPQztI0TU43EZRupOi5fMl0wX+ONGv6ko91VjGON2kcvRHjS+KeDNP1H99X56Ff+KpDeL+BjaRwjp+kf9ZdxKo8erFvCXwMriXUathRhTnNVKtTZPpj4Gm3kKldr5TUcl/Ktkb2JhTvfY6vHcXPJl2KavfVr+8jv+4jPmTXRrw/Ane9iqsG/m02n9hGWdvGGOTZLwPdxN+s/YySLj/w9TbJ/i8Osaht/Q5z2xa2r3UpSiuWFKCpr/M0szdbnzXFaWc/vJfgzCIRY9yf7nnN8t2Sf3ZQFShjMQAAAAAB6TMuzvJQa3eDDRVFHHZkrtlW9xNrpKFaGfEipUXz4XngxrCvJPCeCf4XjGd5RjPeLms5NaUOg71WSsnW+zRv/AArwdGpptW4lF5ispnPr2tyylHwUmvxO48Sa5b2Vn8np7KpDounQ4XqFSLqSl5yb/E0ofNJkkyYejUuhkVfLLyTXCuv1KLUeZ46YyYFaHP8ANWfgYsrCvD1+7ko+eHg2mlZHpZH42WYuQrof5Ok1ZK4ipp5bJnhLi+pp2YSTnFrGHukc54e1t02oy6G0rkuN1hHHsrlRLv4PTMTLp5SpOOutextOgXFnq13UV4406b3TeyyyUueBtFhNydSDg3s87M0Who83LFPqZeqWl7GklKL5F7yscj6MwZPEd92o6rpHCfD1CCrS5GuqefE1HtP1ylX5Le2eaVN+qomqxqXMqKpz+YvayV0DSFU6rLMVuQze4/hl58L9iDtrRL1mZUZkrqeh1oZwvV8ERMLWecNbmlLv5JRTFV/LWv3Paq83qlvWND7qCrxll7P2l+NHHXqX7i9fJyvdYFdnS+xdl4frV6nokuAeO6ti3GonNSSj626S+JvlTjeylDnfdqTWcNLqchp0Y1XjoYuoaNJb8z9iyb0b+/zEWyeLmo/211HQrftN7yrKLUIxg3y+qtzG4h7QL29g6EH+7XksbGl6Fo9PnzVbS/zJHXL63tYNUn62Crt6nqDMVeB6MPUvikkQV/X7nmlPHM+vvNJ17UXUk0uhc17V51ZPfqyDkzq4mJ0/NLyQD4i+IPX3TT2iitKOZJeeDoHDOjq0lQu5PmjGcZcvTphmm6NQ5pLJPajqM4wVPmbS6LwM982/lRzuJx41x9ew6F22cdUNUtrelSpd26KSb89iH7FLhRlVTWcxl/RnN61y5vfLNr4Nv5Wqc4+KMU/kh3NzF1kZO4dkjB4weLyrt/E/6mtX3Um+ILvva8pvqyEvepnp9mc3kvdfcxBkMobJwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACc1T6Kf1fzIgyc1T6Kf1fzIhMFWCqRctredWSjCLk34IztB0md1PlW0V86Xgl/c6no/DdtRhinKPPjeT65NrHw7LvC7HRw+Otv7pdvqaFYcI1JYdWShnwRN2HD9Ck1JLmmt8vz/APk2O70+UVtJSXhuYcISXgdqnjq4NN9zvU8bVU02tk5a0lOgpL6SPXBiusy/wzeKFRwl0kuj9pIavpCpvvIr1JeJIceel0olOJb26SCmm+huXYzp9J3NSvKfK0uVJs12MEs/hkyeD9dt6NxK3rLkUstVM49Y0+Wg+jZzfiKr+3s+gqSUo7SUMLOc7GFql5ywxs3nHmanR0apUgpR1HMHukpLODD1DSriMM0rzx353n+pD+k8ylF9RB9smmqVGndwliUN3HyNH0+rKqoyfksk7xlqbjSdvUrKtVnts019hgaTCNKmsr1sdCT8HW/cnnwpCTfcvwg0Y9/cQimvFpoyp1U9zDuaPN5Emy6vVh0oneXV6kOmJxzWrGrTqVHKDSc5NPG2G8ojztL0xS2nHmT81kh9U4DpVU5Un3cvBeBBcvg7qntfMjzfO+Gr623D5l/2ctZQmde0CvaSanHMfCS6f8iHOJOEoPUlpkbtqlW+mS0/uUBXBQtMYAABVFTyeioL1m/WRK29d06kZx6p5Iq0+cjPrL1kkYbe50sKXT3Rsmo61OvCPO84WCAqJtknbWbUMyTSxncw7hrOEaMPL0SnKUpwjKb7aJ3hGFJVod5jHjk3/ivUrNWcqVNU22uqSznBx/vGuhcUpy6yf2lOhp72Zq82HpupQTf1MOtbyzKUfPJJ6Bq8qUkpM9wp5htuQNzCUZMypRtXSzmudnHzjdU39zq2g8QKM+ZYybdU4hpV6XdyS5mupwKy1KcGtzbtF1VTS39Y5d+A4Pa8E64n4qrzNRs/N9zflYym8RawSWh2zt5tzex64OSnTXM1kj+0DVHQ9RLGPE56qcmTK7OhCvb7I22jXp1HjKbfgW7jQVh1Fh58MHINI4zlSqpvfB2TgXXad5BNtJvwM8sacV3ONXzdNsv7Uu5pevWbg34ewjZ933eW1ny8Ta+010aXeNTXP5HFb7WZOeF5irCc/BXkPiSvHiuvyze7Olh83g+hl3Em0skDoF9OcEmyXuJ4i2+iNW2txl0kh4/Kqtx/VS7a33PEb6FLLn0NH4r1WNSc+V7MpxRqjy4pmq1Krl1O5gYWl1M8q+K/idzk6K/B4qyy2eEXKcMnqdI7HUl2PNvTlL5jItKrj0MitVct2YlJGVDGNzBPW9nWx5ScOnfYx4L1jerTQLiNqq7pyVNraWNjV9I02pcVVCnFyllYS+06bqXENzTsFYVafKopb+41smW0dvhKZKUmcsv1ioyPveqJO7TnUePMw9SpcuMmxU/Bx+Qrb6n7bI5lCrQNo4BQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE5qn0U/q/mRDQg5NJbttJfEmtU+in9X8yKcE2Pyi9ow8FLml7orP9i5Lqei+uHXJR+pv+gaTG2oU4YxJxUpvzb8DOqSWNnj3Hu+uG5yS6dNvIxJyZO8ClVVLZ6fgU11UqOg5z/mKU7qS2aPPMeakljcvshEx3VJ+C9GKc4yjtuvsN1o6vRjRVGqm1jbxwc+lUw1hPqTug03cS9VSk4+C3K0aT7lmLqE/mZLvT4T+jqfCXgRGr8M8+76+cXv8AgSd1aXCeFSn9jLVKjXXzlVivib1rqsjptHVyfRvioto15Wd5Q9Wnc1orwTbaR7lb6jVXLK6qtezKJypfVEt4t+1xK07yv5JLyUenxOW8CnfscaXEYrlvsQuncOuFRVakpSkunO98/ElJRbkstL4lvU6tSos+vJ+SX9iNo06jlupfHJtVdFXaJvY6pxl0w0bHcUcU1y4eerMNQwXrKvinKnLwW2epjSqbnUqmtbO3jWKS8mbTnjyPNSbxsYkapWdczSlBrubG4e4urWFWDjUSkpLDTWTlfGfD0rOpzRWaUt4vy9jOp0rteKLOq2lO6pSo1FtJeq/Jke5jj4Xw6orTX09yN89xdeXW5Q/MvBw4Gfremzta0qU01h+q34rwZgECaaemeWzi4PpfZooAChaCqKFUAXrV+siVnLlmpY6YIil1JhR5qfmzFb2Olgw6t/YnNS1tV6UIQik4xw8IgKjeT3pqaeC5WjmRq9lI7vz2Vpv27C2hnqZcKLlKNOKzKTSXxLE68UtuosbtwmpxeJRacX7S1ptmdTjGPSn3+ps70Ktbckay5efGM+0kqnZ5Wq287mLhyR6ohdW126u+SVWafJjlwvJYJLSeLrilbVLaU8xmYNPe0dXrUqlXZFa+pz/U7B05SS8HgtWVxKnJG3abpvyu4jTzjvJpc3lkp2mcKLTZwipqfN5G1C1T+Vkey8CWO/Wq2kjYOCdYnhYk/DxJriykrqDk9pYNJ4BnuvedBq01Occ7J4ycTJ/t2dj1/gOnNwF6ndtaZzK44cquWYJv3G/9l2j3dKpGb5uTK8zaKWmwp0nPC5V1ZL6Zd5s5u3w5rpjzMn4mU1pnJlwePi2udb7/AENQ7SdCuKtSpVTfLjc5zb8K1Jy5vBM7zpFOvcW043MXzPzRrWraPUpN93HC8sFqulWuxnXD4+ZNSt8r2NR0/Te5jv4Elr1GKsZzXXBI1rR9xmS3NZ4gupfJ5U/DDNWD6rU2d7PrjThyjX20jlmp1nKbz5mLCOXgvX/zn7ytjHMkS2OlBaPna7duQ035ZmWlrtkpc0fYTVvSXKbpbcMWc9LnczrQVZRbUPHJpK7ciSy4xRp2jkzlyiNfLFxH1mvaxSt3nobfbXcjn9zq1E6D2OXdKhf0atZZgnubx2pXtlcSnOisP2GucLafaKy5nhV8fHJA65dNPkTyce6bnZpex6Rx2LHGxPVs8tFyx4Zq1aE7iOMRTePHBpuqQqOT9SWF7DtnZUoqi3XTlRx60OmxJ6pHSJxqqnbpOWeV7fA2674xfc4OTxt+VHpqj2Pm6UceB5wbJxbo/cVZY3Tbax5PojXZROjCakuxDcrFnRPokeMFD1gpguNYoCuCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABO6p9FP6v5kbR2TWSjC6u57csO7g/a1vg1fVPop/V/NE6PwvaKlo9BY3q/vX8f/g3cCvrtSOlxVPqXr7dy1CpjPtZ4qVC9Vjhe0xsZ2JpppJE/acUked2e1F43PcqvKi5by5pblYw2+5dCDk9Hqja5jlo3DskdOlfKnUaSmtjXpPEdimg1pU7ulUX8MkVy6dQ3Etz8VKp9Pk+ibiypYl6q36PBrGqaNJPbDi/DGTY9O1CNajSy482E/aZEqSkn6yykRGy6yM9bPNbsq2FjW3/ACc/1Kyio47tP3pGDa2dOcWsRTN1uLFzTi/iyIXDby5xl0fQs/E2fVlq5C79TNchb/JpZcYte7qX9OoQrTacIrOfBGfr1F8uMbowdOjKHrJeBjeTZvyy38dc3+ZmHxLoMXFyiuWWPA0uVLHwOl3UJzjPn/leDmt5UanKPtZJ+IypSXzMnPw5nOztJnjJbqnhvcuRWSQt7RMOrZZgZKrY8Nzz3eD3yFqjuLTChtaIXjLS1e0HOK/fU03FpfOXkcqlFptNYa2aO6Uo8u+OpzLtD0vuLjvIrFOruvLPiQvmuP8ASfqR9yA/EnG+nL1ort7/AOzVQVwMEfIiEekiiRK6HZKdRc20Sknoy1VOyWkebPT5Nc0k0vM6b2P8M2t7VqQuZuMFHKwanfXaUe5jjGdmupvnZxCNmu/rZUJfA5992iZ8VxsZbS+hovGlnCzv69Kk804Tai/YRfK5LmOpdpWnWNajO4oRfeT9bOTmml1MTVOXi8FsbFNbRluw3TPol4l4ZIcJcH3WoqpKik1TWXl4ILUaLoVpU5dacnF+9HRqNO80yk6lrNYrLdL3HPtSjOpWlOp86UuaXvZfCxM0snDnV4/kkLCopRI68qPnwmXHXUIYXUj6NZzqfEthX3cvYz5WYnGFfudO7OrWPJ3j+dHdEV2rXLrSg284ybf2eaVGra1JvKcabezx4HMeLbiUqsoZzhtGnR1O7fsSHlFVVx6g/wAzJHs+Sckm/wCJHW6ulZinHrhHNOzTRpzkpOLxF5On3GsQouEH7vsNXO72diQ/DFlleFGL7HirVlGk7eWyl1Zn8K3NC3h3ed3Lx9pctoU7uPMuq8iM1HRqkZ88dktzWW0d7067PPk2+5vYpYh4kJrGoxjFqWeZrYi7W6lzrmzszH4zrKcoOPTBWU9orTiONi0WLev3tOUFlybwjVOKrGVKLUk84ZsOg3Cp16aeOq9xN8c2NO4ipRxjl3x7iyqXdMv5KD6XV9UfN2pRxN7eJ6035yJjimxVOUsdMshtPaUiUwn117R4HlYssbNcZ/U2B1MIty1Obi6ak0ntjOxfqKPd7+RBtrnya1UUzuZ106+lJ9mTGlaM600kt2/EldY4dqW1WnTklmeMfHBG6TqbpNOLw0T8KtzqD7yUt6Syn7v/AIMcpSUu/g2qoY/pro11e5mX1KNnR5Z452vB+aNZ0ep31zFzTcc7+XUxOJdSqzlyyllrb7De+yLQ1c21RvCll4bKqpQTn7sWZ8sq6NC8R+h3Pgjh6yudPqKEqUH3W/rRT6e05Dx9pMbGbhTqqWejUsmvca1LvTsxp3MlGTaajJo02lrVWc06lSU8P+KTZZ6HXHqNiPLyxL5VPwzJ1dVJTTqZeemUZen8OUq0JTlLleNkS1RSvlGVOm2opZaXgupLaTY0XCSnNQcV0bwyyWS4LpRs08NVlOVs+68nNbnQKrnJU4uSj/Qh7ijKDcZLDR0qGrO1nUjTSknlZe/U0TX6jnVcsbtt/adHHuc13IZzPFwx25Q8EWyhVlDbI4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT1+s03HzcF9s4o7FdwVKxtopJclGmkvdD++Tj90/V+tT/wD9InZdapKVnSef4Y4/w/8AM7XCrdrZI/h2Kdkn9EjV6lZyKKJdp0MM91Yewl3ptsm/pN+THjTT6mXSopFLWk87ozIwM9dXc2aad9ylLoX6FLrjaXRFIiNxyyTfmZ71FQMuVBKt7+h0jhK5py09qtGdOdo+ZSTzOv4KL81uZmjXMoU/lNZTrSrVnBW8p8kaNN4Xep+LX+RautFzaUrmnLGYKTS8XjxRgVJOpGMaqeI75ex55mdrXo8d5JL1mkbRb3trG/VtVuale3cF+8jhJSfhnxaKapQnY3LjTue/pSxOLXhF+D82ag7OjKpGSi9vJ4NnpRg4+1fE1t7OcjC4r1mmqWHBKTXxya1pWot9XsOOYy2cIt4+JCcP3M91KOz9hRoyxNtu9aWVGMVvtnqaHrFB9/N42ZtNOnipHEU03uWuLLaKkpLC80dzhpfPolXw1NRt0zVKduvEq0o9DJaz1LNSC8ybdCS2enKKSMeVRhVGXJRR4Rh0Y1vZ6zKTSyYfFGju5sq0X606a54Px23wSMUsLGxeo3TT5XjElh+1M1c7FVtTTNPkcaN1Moy90cFcWnh9TyTnGlkqF5ViliLblHHk/wDmQZ5vOHTJr6HkNsHCbi/Z6PUEbVpNunScvFI1RE/pVy+XlXkaWUn09jtcFOEbWpLfYv21P1/iTWoavVVJUub1V4EdS2WfEpVp86NF/M1sllcXXW1Dyy9DXpOnyTk2umCHrVG5qUfeWLqHLLBsFppqlbd7le4z9EYLa9zkO+3Jl6c3+U33srqu8Tp1fXUU8J+BpXGtt3VzWSjhKckZXZ1xXHTa0pSSaZa454ip3cpzikudt7LzMSramdGWdCzG1J6cf+zSrmo+hl6FQzNN+ZHVJ5ZLaXLBuW9odiM4GrMlSl3SZ0i04jVjQlCnvzxw/ijnNxcd7cKUvGeX9pITpymnkh401Gql7TUxoKKf1JHzOVO2UFrS2kfRHACtadCHK1zOCz7zM4k0y2nTlKKTnjKx5nN9IuK9GlCUVlYX2Gz6JxLTbUK2U2vE5Nq3Nk/wumNUU37GTwbb3MHJZajnp7De5qPKlJbtGuLVLeiuZTjh74TIfXuOqEly085XkVjAz23Qj4ZIcVUFT5XD8DVb6vKbWc7ew8WPFq5m6icl4ZWcGRU163rZWFHHwMNtTfg6OHyFaS6n/kxadP14vON+psN3UhTo4c8trzNNu9UhlpeD2MGV1UqNes8ZLIVOPkvzM2uXat7ZAcZJtyeNm2alafPSXmb1xhvTW3Q0Om+WafkyRYL3WeLfFMJQzU5GyalRnTpx5ljK2ITkfXxN2062nqMIJcq5Ypb+wxNe0CVrFSlh522EbVFtGa/j7LYK3fbRqUKjiybsNclRg1CWMrBBXnztjG5jZdSmR78bOiTSJa0hK5uIrxnL+p27Q6EtGtfWX0sMpvbGUcf4Lp4rwqYzytM6j2l8VK5tqUIrDhTUenkjSyp91FEs4CqVcHkTW0c34x1CdecuaTlu8ew1WUmnsSN1VcnuYVSm8m3QumOmRvlLfWtc4m/dnHFStKdSnKClzRay/DJjVbp1aspJ4TbeDTqOY9HglrC5ccb9TXyKt90drieRcUq577G48N6MrmpKEnjZv8DTeNrFULiVNb4Opdk1nO4r4ju3Fmjds1lOhqFSE+qMOG316N/4krh+F6l5ZobPJ6KM7B5uUAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPX7/dy9jj+eJ2y5p95Y27j0dOm/8AyrP9DiOpv91P6v54nZNGvs6VbSx/3cV/kdzg5pWtMkvwzNK6Sf0RjO3jFGPOXsPFSu5e490oMm8Xs9H7S8F6g9sNFxvBZweatVdMmVTSMm1BCrXSyYNe4lJr2NFas85K0YpOPvNW+TktHOypucWjrmkWV3Us6TTbhyRxFPwwV1G1qOHLhxlj7TYezaUp2kPFJJYNiq6bCp1WH7v8yEZsemxnlXLR6bmcl02jWhPlnFvyNjipJcuMPx8za56SqT5uRSw+uDUuMYS53KLx7EaOjmIuUoUnlVo7LxMGVpbRn6rSRf0xyrU2n1xgh7m2lTnyye4KryZtvauU2oLaJH8TWMnBya3SNh0OtFZS643MPiW7jy8u2ZPc6PGNqw6/DykshaOaVm18DCnNknrEeWpJLoYVGgmydwbcUes1SlKCLMZNmTSj4l1RguqMevPfESr7GfTiu5WtXXRFKVBzazsjzRorOZMu17jCxEtfddzDvaezTe1nTlHua8d8rll/kc+OncVKVxaVYdZQ9dfDyOZYPO+Sq9O9/c8u5ylV5Ta9+5RE1o8G+iIaJt/BN5ShJKcU8+Zyb/ylOHS9dbejxcNw2ezJrTtErVbd10nyJZe3geOP1T54Omkk474N/wCCuJ6ENErWsqcHOVNxUn85ZRz3FKOyWqx+v0LujjeoUfWfsFLUJxj3efVLmqeq2iK5GbNaTj3OJmTdVr6f8nu7e7aMV1W9jJqrYxIrc2IJHHyZPq7PszIoW+WT9pQjGKz1L/AtjCvXhCXRskONNN+T1HGCeF9hqW2dUukkvG4aqp9bWyJ+VN7IiK8+Wqn5M8fKJxbZiV67k8mSqrRzM7kVNLz2Z3jsrvaF0lRqRTxE8cccNOlOVWnLEW9kjkHD2t1baadOTj7vI7Fw5xPC7oRpVZKUsdZHNycZwltE44Llq8qvok9NI0jFzUainJ748TYtK4UnJKVR4z5kzwbc0KV5UVSMJR5njOMG76/cW86WYOEfZFo1py0jt4tEfV791+5of/RenjaabIfVOHHBNweX7CZo3XLVl623vJi6uLdU1JzWfFZNRWybJDkYuOoLq7HOIaTJS9bJnSpRpRz4knq1/bvdSRqvE2pw5Goy3wZ4wsslo5l2Vh4VMpxa2vuQ3E+o82Y52NWpPMvie7qs5t5FtSbeyJHTSq4aPFuS5CWdldf8G4aFfzt6eYPGxH63rNWvtKWV4IxpTlGGDFjHLyzWjWups7WTmTdaqj27GNOLZjuO+CVq01y7GNRt3KXQ2oz0cG/Ebkku7Z03sd4cjdRqSqTUFFZWdiH44qKnUqUoyTUZNZ88Gw0v3GnUXRnyVJR9fl6/E53rVWc5vLbbfXzOckp27JnO2zGwVXrs0RscyexJ0LDMU2V0myaxNrYkq9dNqKM1tj30xOZgYEXD1Lff2L3CmlUKlSSrNYS2yYGv2apVpKmvVT2wZCq91v4k/wAEWdO/uo06mEpMxeq9bOi8Gnp6F2kyY7DNVlSv4Rzj1cEH6QknPU5ze+Yoldf079lXbnRl06YNC401SV1Pnm25dCuNJOfYw81TKvF1Y/2NXKM9M8s6x56UAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOan9FP6v5kdS4SrqpolLxcOaG3seDl2qfRT+r+ZHQOx+tGtZVaDe8Jt8vmpL+50eNn03o7fAT6clL6oyLZZ+wzaUl1/wAzxe28qbaw0v8AIjqtfqk9yeq1QPRnb6aMq6ufIwnOTfieGm3ue038DVnc2+xqyyHMuxx4l6jvhJdWWIUmSGmUsyUY+L6mVtqO2X7ag2zuXZBWSt+Tq1jY3OvUfNjGxz/gClOhDmSePF77nQLe5hUxtv4kQzpJzPMuYlu1srJ+q8/YadrVunVfib1c0l0RrOurlbwl7zR0chM06UZ0Zp/w58DGv6cqknU8MeJL31ZLHMjzDFaLUVslnbyKaL0iD0bvISy3s3+Br+v6jzXSw9k8YJ2/vY29OrzrLw1Hw3OZd/OVXvG/4ub8Tt8XVt7JZwGIpy6jYNfpNuM+ifUj1UjGPUlbySr0o9dkavdQcZYySv1elE+jb0LRlu4j4mPUuFn1TDb9hT1l0Rgle2YbMlt6Mnv2+oqXGF0LGH4rA7vJa5ySHW2ux7pVY75jnmWPgcx1+27q4qRWy5m17mdVt7XdZNF7S6Ead2lHHzE2Rrm6eymRP4jpXQp+5qsTd+AuFql9Gc4Sx3ayaQmdK7KuI1ZwqxaXroi171E4PFQ67kjXr6ElcOhUfzZ8uW/aSN01b4jCaafl+JeutIq3lWrWpQyuZybX2kLc0JJ4ecrbc0W1JaJVGu2lt+foz3cxU9y3b2XMTvDdjTnBqp85/NMnUdIqW27WE+hjdvT2Ru14Prf3Jr9zTbm2aeCxOxl4Jk5K2dSWF4s7nwDwHb1NFrXFWnBzjnDeM9DPG9pHJt4uEp9+yPn3Rb+drUUo7NNYO0WelUNR0qdzPDr7YefM5PxPZwU58ixiUl+Jd4R4mr21SNN1H3OVmHgw0rF1IRtswp+g+8WbhrHZPWp6d+0OdcuWuXxOSXlHlk0fUeqcYULvRFQiorbpleXkcC1PTYvLTXVlYZHS9MZfDO2pzjo1JPBn2Op1KXzZNFq7teVmM4M3H0zXcjEXdjS+XsTsNfqJtqTz55L0OKKy/jk/e2a4oFeQxPGg/Y3o8zlrupM2WXE9R+Ji3XENWf8AE8e8hOQryBYlS76MlvO5ti05sya2o1G/nP7SxUuZS6vJ57soomZQivY5lmRdP80m9/cydPs3WliKNlsNM7rHMjH4C1ChbV+evFSj5MnOItft6lWUqSSi+iRo5Tm3qJJ+BjiQj12vUiI1mnHGxDOuksGZfX8Z9CIqtZ6l1EHr5jDyuVW7OqskdHoOtUjF9G8bnZbLsx/0eruEeZ+w4xpd7Gk1JPdPJ13Re2521h8i7lS2frFt1c5PsZ+PzMeiCcu8t+5r9zRnH928pr1cMytO7OL66xUjQm4PfmUdjWNS4ydWt3vKlvnBvejdv1xa20beFFYSS5tjXpxZpts7HI8/jWwWtPXsZnEegWVjp7hUxC7jF5i3vnwOf6Pw5dV49/GLcE92R3GvGlTU7iVeonFy8Cumcc3FCj3MG+V9UbKx3p/U48+YplYnvsvYmdY4crqg6zi+VbGDwVOp38Y0nyzzs/aYF7xrc1aTpOT5HnYhtP1apQqKpTbUlvn2lI40ulpjI5mj1lOHg65xJoV06UqtaopPGTk2sQ3fsbJO741vKseWdWTXka/c3TnnPiXUY8oPZi5bmasqHSvoYoZVnlm+RIYKFcjALSgAAAAAAAAAAAAAAAAAAAAAAAAAAJ3VPop/V/MivBmuTsbiFRP1JNKovOJ51T6Kf1fzIhUi6MnF7XsZKrJVyUo+UfQeoThc23fUZqS5c5NS7l7+a8TB4HrXFC0qRnnkm804vy8yYto8z3JrgXSugnI9Dwb55NacizCDMqhbvG6MiMVBZPCutzq11RXk7FVMYvuXY0djN0acadT2keq+SqrYakuq8TNLTjoz2qLg0dC0ftI+SN0p0VKJJ2na1bJ+vQmvcc3vVSnQlXef3cW5Y9hpX/Sqyb3518CLZioVmpshGdjY3qP1WkfSNPtXsXjMai9+St52h6fUeUpP2YPnWHFNp/N7sorHiy1x897eSKQjhvzJGKODx/vJfydt1fjCzmnywln2kXZ8b06WV3Lec4OQ1uNbXynLHs8COuuOYt+pRz5czLLLMKP5XspbHjq12ezp3E+tK8w0uReWTXJVYU160ope1o59ecW3E8qOKafkQtxfVajzOpJ/FmFcvGv/AMaKR5uqiPTTH/8ADrumcU20andd4t3j2Z95K6pZKSdSG/8ATD8fccIjJp5y8ne+Eqv+jKM6j5pShjfyXQ2cHlp3T6Zm5xnM2ZFjjMgXF5xguUotHmU/W+0vqeCRQSZKq4xktmPeTMRVWjLrNMsOmYrU/YxXJ/8AE9afVlOqlnZb+zY5vxReOvdVZt59Zpe5bHQoxx0eNmvtNE4n0qVCo5LeE23nyfkRflo2PTfgh3OQta296TIRGXaXDg9jFBwmk1pkbrslXJSib1w5xxOzpzpxjFqSa3SfUg77V+8k5ebbIHmGTD6EUdF8ve1psnrfXZQaa6roZep8XVq8VGfhjBquRkfh4eSv9ayUtKRNU9alFprwNgtu0m/pUJW8JtU5dVlmi5GSqpiYpcpkS8yJW61WdRtvx3MNXDznxMbIyXKuKWkYLMyyx9Un4JanrdaMeRTfL5ZPFTVKj8WRgyU9KPnReuQvS11PRk1bmUurLXOy0C9RSNaVspPbLnOyvOWgVLepnvmZXmZbK5GinUz1zsOTPIGh1M9qTRXnftLeRkokivU/qe+ZhnjIyXLRRyf1PWQecjJQbPTZQoMgbKlMlAVKHoFBkoCoKZDYADKAAFclAAAAAAAAAAAAAAAAAAAAAAAAAAAAATmqfRT+r+ZFOC9NV3fUaMniLk5S90N8HrVPop/V/MjO7MM/tCnj+Sa+1GamKlYl9WZ8aPVbFP3aOiXVmnLZpKO0V4JLwweYx5fIyqlN8z95YuIpHo2PTCFa0j1vEoUK1ot1o5RiOO5lxlsWbh4Mk/sX268nlzwWZTb6hF6lR5upge32NZpy7Iv6DzVJyoy+ZUjJSXsaOUcTWLtruvQ8ITaWfJ7o7boNCKqbLweGcj7SH/pGv70vwIxzeP06l/ghvxFj9GpP9jXMjJQEeIqVbPJUoUAAAB6idx0Wf+j6EV4U1+Jw1HZOEr2FaxhjrGPK14rC2OpxTSu7nb4KUVc9/QvRjHHtMarPyLdSck8HjfO6Jmp/Qn6tWux75S5GOUeE35FyEmXxe/JkS2O4efAx9Qso1YOE0mn09j8zL52INsttx4WxcWiy7FhZFxa8nKNYsJW9SUJLbOz9hgnROPtPUqCqpYlH8Uc8ZA87G9C1wPNOSw3jXOHs+6PIANM54AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABO6p9FP6v5kSHZVNLUIt/6uf8AQj9U+in9X8yMzswjnUKa84yX4Gej/wAkf3NjFf8Aej+6Om3NzzTeNi04rxM24pQUnhLJRwWOiPS8WO4I9hw4N0rZHzgjGq02/BknPlXXBjVajl81F9sUi62C0Yaj7D3Sz7S5GGOp6hcR8jXjrZrR0mS2hp83XbBx7tAnzahcPym19h1vRa/7zbyOP8a/9vuf/EZG/iCfZL7kQ+KLE4x19SEABFiGAAAAAAFTeuy2/jGpKhL/ALz5vvRopl6TeOhWp1Y9YyT+HiZqLHXNSNjFudVikdj1W3UHt7TAlOXTBL2VWN3RVWKTTjlfYYDjvgnuLJWQ2el4bVsE0WqNKbM2jbeeBSnyl5VV4HQrrSOtTWkW3bnuFCMVk9d5k8zbx7zP0x9jalCPkgeL3OdvOK3WMnK5rGx2O6oc2z8U0zlvElm6FecWsJvKIT8QY7jJT/wec/FGK1YrPbwRYAI2RIAAAArgoAAVKAAAAAAAAAAAAAAAAAAAAqETOjcNXl3vQt6lRecYtoAhQbrDs11VtJW1Tf8A3H/Yy6/ZLrEKbqO2nyxTk3yPogDn4Mi9t5UpuE1yyi8NMsgHkFUhgu0CgK4PUYt9EOkHgGV8jqYzySx/ws8xtaj6Qb9yHSU2Y5UuVKEo/Oi170XrGxrVnilTlN/7qyNFTEK4JG80S7ormq29SnHzlFpGDTg5PEVl+wtB4KE9pvCV/cNKna1nno+R4JiXZhq6Wfk1X/A/eAaSDM1WwqW1R06qcZrqmsYMMAAAAAAAAAAAAAAAAAAAAAAnNU+in9X8yL/Z1X7vUbd+cmvtTLOqfRT+r+ZGJw7UcLuhJbYqx/F4MtT1NP7mWl6nF/dHZr26SnJvCeSz8vWCxxDSxUjJdGskXKPvJ/TlNQWj1DGzmq0iSndRZjV71LotzGl0LcIZe5bPJkzFbmTn2R7nXlPxZSm3nc9Sjg8vYxdctmBymmTXDs/XfsRyfi2eb24f/wBSR1Lh6W8/cck12Wbmu/8A6k/zEf5mbetkX5ybbSMEAHCI8AAAVweoRz038CiOg9hnD1HUNSpUquHHm3T8ceRckDUpcP3apd93Mu6/nw8f0IxxPvC9q6J3y0KpSo03OjtNpL1nsstnzB259mtTRbluEee3qSbhOPrLD36pYLtAxuzHVM0Z0JS3i/VXsJq8m1N+RzHhi9+T3VObfq82JL2M6veRjUgpxaw1lNeRJOIytx6H7Ew4LNbj0N+CxR3L6wnuWFU5cHiVRyJRGXYmddvYkKdSPkXJTTRhUYsuzqRS6mwp6RtK3t3PNZ4NH7Q7Zy5KuMY2bNvq3K8CH4og6ltU9ib+w4fMJW0v7Ee5yEbseS913OZAqCBnmZQHpHpQb6LPu3GgeSmD3KDXVNe9HkaBRFQAAUKlGAUAAAAAAAAAAAAAABVH3h6FWjW1fTYyqU4yljq0n/U+D0ffvoNY/ZnwLkDrnGl5pGk0u+uo06cF4yUTQtY7auGp21Wmq1H1oNYSXlgy/Sb0uN7aRoVHiM2lnx6mh6Z6MumVLSNZznl01Lw8s+Rfoxuejk/B3ZVb8Vane1berGFJSzFpbbs3p+iNSTw7uOfLlRuvo78NUtJvr63pNuMPH3Gs8TdplxDiunaOvKFupcrjnbrjcpop1kTrfot0bG2q151Y1HGLaWPIlOzT0e9MvbaM6sItteKPovjCtGrpFaaw06Gc/VNE9HW+qVqN3CXSEnGO/Qrop1M12n6MuiPZU4P3I512t9i2maTXtO7pxxVklL7UfU2m6RO2qVK0qk5p5ag22vM4R6Q+vyubyzpRpySpz3fK/PzKpFvUyYu+xrSVo/fxoR7x0HJPHjy5Rrvo/dlGl3VtUd3bRlUVSpjPkpPB3Gkn+w6W2f8Aq69/zTX+w9LFVbL1pbfFgo5HyX6WvCNnplzCNrSVOLz0MD0SLSjc6mqFWClHCe6Xmbz6eNLluaGF1TNJ9DP/APel/wAKKaM0HtH0d6TfBFlDSZyp04wkqb3SS8PcfDHDMadK/pRnhx72MX7uY/Rz0kbRT0WvP+Wl/kfm3T/7fD/x4/mRTRVM/SHs80nS6GlUbudCmoxpxk5NLwSNtsqNhe2s61vCm4OnLDUV5P2EB2Y0aM9CoRuGu67pc/N0awvM27R6FtC0nG05e6VOeOXGOj8ijRRPufmd6QNJQ1m5ikkuefT3s50dK9IqLWt3OU168+v/ABM5symi8oAC0AAAAAAAAAAAAAAAAAAE7qn0U/q/mRFWU+WpTflOL/8AMiV1T6Kf1fzIhE90XJ6ZVPTO8apR723pSjv6q3+BFKwl4k1w3WjcWFCeVjusPHg0t8kdc1nlxT2RP8FKdWz0/jVGylMxZ2yieHbPwLsZZ6s9u4UfFP3G10QN511mDK2kj2rV4y2XZ33kkeFdewwyUTDKFZl6ZyxjNR68r/ocf1Vfv6uevPLP2nZdBppc83/K2cb1afNXqy86kn+JF+a/MiFfECSktGGADhEcAAAKo6T6O7f7atsNr1jmp0r0dF/py2/4i9MG/elBGVrf0rmnKUakYrDTa8TfeyTiSw4n0yOlX7i7qEcQqSxzNtbGpemhSUa9DHjTT+04TwPxFV027pXNOTThJPZ+Rf5LT6mufR70ewnJ31eEeZtwy8LDNH4u4Yhp1XuaFSNa2a/dVIvKx5e86zo2oWvGulOEq6pXdKCw8+s2kc9tuzTXLeFdVMVqNHmlHM05cq8Ujaw7fTsT9jdwcn0rVL2Zz24ouMtxTqpeCM2+oSWeqw8bmB3W5OKZ9UVo9MxpdUE0ZCqvwLUqTZlW9MylSRvRqckdSNLkiJjaSe5janaylSqRw3mLSXTdon6kuVGG6jyn5NPHxNPMoSraNHOxv7Uv2OQfs2s6vdKnJz5scqRt1v2V6tOj38bapKOM45fA+neBeCdNqXdC6nRpy721VblwscyX9SBpcd3MeI46bTg1bOahyY9XlzjyPPpV9zyKb1Jo5R2Fdlk9Wvp0bmlJU6akp7P1ZLwexsuj9mNvb69Usa1JuC+Z7dz6C0i2paXrKhQ5Yq5pyqTSxnmwcu0zUa9bi+o6nM8SxHKwvnFOgs6zQeN+xG9q3tw7elKNKO8VjqseBy+z4HvKt98hVOSq82GuV+eOmD6j4242vLfiajawnKNKbxKC6PZE5wvpdtLiHvpxjGcqbl0Wc+ZRwLtnz7cdgGoRi+WalUUeZ0lH1ka/wr2XXd7c1bVQaq0pcsljdNH1lr+pytNUlKjOdWb2cHH1ceG5rHZxdzes3tfkjTlKU5NLzwW9IbPnXtP7NpaLRjKrKPeN7x8TmrOo+kPrtxc6pWhUqSlBSeI+WGcuZjZUoACgAAAAAAAAAAAAPR92egtqMHZOj/Go7nwkmfV/oX8U2tlOqq9WMMx2y1/cqij8H0N6Q1tWnSo9zCU2pR+avajeOE6clp1KM1h91FNe3lNe1XtI0VQ5q9enJLfdp/5kXLtv4fiuX5VFJLZbf3L0zXcWQXBNyqOv3tH/AFksfaaX2/di1xWvY6jpyfeqSk1FNtvOfAidJ7U9MhxDXuHWTpSnmMjrFTt90ff99Hbp08C4ppoyuHXeLhurC8jKNaFFxfN12WCD9F2q+TUc42qP8CH4t9I7R3Sq0FKLUotdPM0Psn7ddK013rm4xVaUnFeeQV02d54e41rXGuVbF/RQi9tjD7edMpuFGqoRzFpt4S8fM4Do3bXYW+t1L9TzCcWl7yQ7VPSKtLy27ujiUvIeC702fUWg4npEMYa+T/8ApNE7HJyV3cR8OaW3xZwTQfSllbWfyb5NGWKfInn2YIHgb0ha9ldVqzt21Vy0t8LLyCnps7x6SXY5dcRVaU6FSMFBfxLJzPsj7LrrhnWabrzU1PljssdWUuvSluHnFFr7TnnF/bzfXd3GvCm/Uaaxnw9wLktI+6e0rQJanpdW2g8Sq00k3vjKPkTi30c6mn01ezqRclWi+ntyRdr6TestKmrebxsvneHuIzjHt51i+odxVt6kU3nOH1+wJFUfVNjP/wDSlSMZZnGi1s8PZEx2E1m9LSnP1uV7SeX456nxdbdrusxs5WkaNXklHGeWXivcQ2m9pnEVrBwpTuIx8cRlgMqvJN+mHRhDW5cuFmLe2OufYcNJ7jPX7rUK7rXcpSqdMyzn8SCLDIUABYwAAAAAAAAAAAAAAAAAATmqfRT+r+ZEGTmqfRT+r+ZEGVYOq9kmrRdvUtm1zReYxfVqXX4ElfQcZP2tnJtG1CdrWhWpveL3XmvFHVrfUKd3RjcU+uMTj4xfk0Sjh82Lj6UvYmXAcinH0pPuizKPtLc15LJnU6cGs5PanTXRYJE6+r3JS6+r3MCjbSlv0L07PDwXaldexGRps1J5bWxjdcI9yxwhBbbPGrT+SWdSbaT5Glnq8+BxepLLb82bp2la33s/k8JepB+t5NmkEL5S9WWtLwjz3mMlW3aXhFAAcw5IAAAN57FdTp2mrW9Wo1GEZLLyaMZNjl1I4eMyS925cgfYPb1wNX4lhb19Pr0HBU45y849jOdaX6ON04/vrmhGfjiTR1Xsh7PtRlpdOtT1LkpSim08vGV5tmdddnl9Obl+3Ywy8dP+Zei01DgvsR1Cwlz21/Sp+a73CfvNvuuEdYhHD1O3xJNP971z1yQnG3Z5rdrY1bq01b5S6e/LBPp8GfNWp8eazGpOnVuqicJNNNvqviXJldHZeMOGq9lP99OnVU8OM6T5o5fXPkzXVaryObabxff1qsIVK8pxcllS6dfedTvrerQ7t1FtVhGUZeEljfHtJdwvIR16c/KPQfhnloSj6NnlePuWlSwesLBSdZFrnJapJrsTyM4+xS5SMSmt3kzasUYTnuaeTrpezRzpRUXs3LTeItSh8jq2dCpKnQg6dRqMpJrOcJomLHi7T3ffKVZ1VqCxhSgsc3uIGnxvdaVPTbKnBqlXcZzzHqpS8X7jo/H1na0tR0q7p0oqdxOHPjC3aWdjzu1rrf7s8TzNetJrx1M5vV4r1S416F5OEl3PMlSSe8c+XuNjXFsbzUFUsrOcbqnh1HyeXXJFceajVs+JaFShDmjN4lBJNPPmdyv9Go2mn1b+0oRhezoOUkll7xyWbRq6Pn7iXR9Xv9W/aVOMXKg8uCT5l70TErfW5V439HkdWlHDgs5wt3lYMz0eNeubrUL/AOUTxKU2mpJer8Dda3EdDSa913eLmc41MpLHK37yyTL0cm1zt+uaEqlKvbUlcpcrk6azttk5Vpvapf213Xu6UlzV220/DPkQvahqfyvUq9dx5HKT9X4s1ZmCTMuiU4l1qpfV5XFXHNJ5ZFMoDEAAAAAAAAAAAAAAAAZdnqFWj9FUnBv+WTRiAqmCTq65dyWJV6rXtm3/AJmJK7qvrUn/AImWBkbBdVaaeVJp+eXk9u8q/wCsl9rMfJQbYLs6jlvJtvzbPOTyCvUCrYSKDI2Do3YJwta6tqlO2u5YpNZ8t8n27ovo/wCgqlBKKlsvJtn526DrFeyqqtbzcKkekkfVnom9q2o31+7a8rSqrEVHL6fiVTKHa9U7CuH6VOTnGMPVb5pYS2RzngHsv0G41OrbSjzxSbTjhx6m9+lvq9e10mTozcJOPVbdUcl9C/U53N7OdWo51OVp/aXpmFs7rpPZDw9a1lyU4Smn82STNZ7buCdNoU6MoW9KP76mvVgltk61LRqfyrvub1m84z/kcu9KyvKlZUJQeH8opfZzIqW9Ruun8GaRTs6dWdrR5Y0oybdOP8qb3NQ1XXeEF3lKpTtU0mntBNdUbXQuJVOHJyk9/kiy/qnGex3sv03VneVbqm5yU3h80vNlrMkXs+ZvSIhp61NvTsdy03t0y/ccyO8elVwFa6Rdf9Wjyxfhls4Oy0ylAAWsAAFAAAAAAAAAAAAAAAATmqfRT+r+ZEGTmp/RT+r+aJBlQembb2dWt1UrPum1Rz+9b+bj3eLNc0yxqXFSNKmuaUnheXvb8Edq4Z0qlaW0aUVmfWpLPVvrv4I6PHYsrbE/CR1uJxJ3XJrskX6el20H605SXhFPCL8p2tNf9n5n7Wea0Y08Se/vwerepGonzR2XVom8FqKWz0CqPbuzzSt7essqkokfxDSjbWtadGPrcu2N+pmXN/SorEVzfEx56lzxacVh9VszFfT6kWky3Jp9SDimcPuKkpSlKWeZtt58/Et4Oi6rwpb1pOcJum228YyjXtT4Qr0oucJRqwSy3F7pe5kLyOOurb2t/c89yeMvqb2t/c1kFZLHXwKHP0c0AAAHunLDyvDD/E8FUVQPq30Zu0X5Tby0e5rOkpRahPmSxthbs17ti4G4h0+tUr2l3cVrWTcoyjNy6vwwfP8ApepVbaaqUZOE08pptHb+z/0gbqhShaX8VcW/TDjl49rZcmUMvsE4/wBTtL1W2o/KKtrVzGXeRk1vt4roTfpH9lEJQ/aum033c8ynGMcLfdslK/bZw2uTOn5eM5ioJ5Np4P7edL1N/sn5M4Uqy5I9408OW3UvTKHxbawcK0IvKaqRXl/Fg+qeObaP/Rm1qvapRUJQl49N1nyZofpCdls9LvaVzRXNQuKkZx5EmknLPgdY7QrKnHg2jVksS5IL8C+Njg9xZkhY4PqT00cV0q9+UUVVWyeV7couUrxLbqaFwZrNSFb5P86lObXL5Z8UbxWocjbaXwyS7jc53Q+56Jw3JzvrW/KMqdwmupbppS9x4pKDWP7F9QcFlLbzOjLclqTOtbB2LUmdB0fiyh+4d5Z0bn5PFRhLCjUSj067Nmu8e8f3F9qtm6NGVOlRqR7tSa5E15tGt95LOz/EyY2vP47rz/8Aexx7+G69uBHMn4ZhZt1Pz9CV4v4vrWWo0b27pUpNRzFLDi/LoW4+kdeK5nUdOLozp933b+aljBrHFHD1S9SXetTh81SzJe7Jz3W+Grq13qRUo/zQeV8fI4eRh30v5k9EVyuIvx3qUXr6m8aB2pzs9VqX9KEYxqS5p0+kX8Da+Lu3qNzGSpWdCMpxalJR3y+rycB/94GTnuRz9GVqt669WVWSw5Nv7fAxGGULWVAALQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVR3P0O3/AKaXvh/VHDDfexjjiOhXqupRc0mnheS8iqB9u+l5p9Spo05xjlRgsv4HDPQaeNSqxx0T/qU7T/Sao6tp1Wyjb1I95HGW08bY33OS9jfaXPQbuVxBP185XvfgXplnSfY3EOvXUOJqNBVJKk6iThn1cHv0st9Oof8A8il/VHy5r/bvXralG+hFqUJKS23PHaD2+Xer0IUayeITjNbY3i8rJXqLeg+6eD7FXGjQoPpUt4xb8sxW47NeEaekKulUUlVectrZ+w+MNH9JzUaFtG3w+WMVFbY2Sx5luXpL6hvhy9nUo2XxibN6dUUrmOHnp0PlRm5dpPH93rdXvLiTljot+hprLWXFAAWgAAAAAAAAAAAAAAAAAAyJ3lRrDkmvJxg19mDx38vKH3dP9JaABlW2oVqT5qc+7l/NTUYS/wAUUmjLXEV/0+WXOPLvZ/3IoFynJeG0XxslH8ra/Zkm+IL7/a7j72f9yseIb5LCu7hLy72ePsyRYLvWn+p/yy717P1P+WSP7cvP9prf42Frl5/tNb/GyOA9af6n/LHrWfqf8skf25ef7TW+8kP23edPlNbHlzsjgU9Wf1f8lHbN+W/5ZelcSe75G3493T/SU7+XlD7un+ktAsMZd7+XlD7un+kd/Lyh93T/AEloAF3v5eUPu6f6R38vKH3dP9JaABd7+XlD7un+kd/Lyh93T/SWgAXe/l5Q+7p/pLttf1qUlOlN0pp5U6SjTmn5qcEmvtMUDYNgu+N9arRUK2r6nVhH5sKt/dVIx90Z1GkUvONdYr0Vb19V1KvbrpQrXtzVoL/+mpUcPwIAAGTQv6tN81OfJJfxQjGMv8UVkyZa9evrdV376kv7kaC+Nko+G1/kvjZKP5W1+zJFa5ef7TW/xsT1u8e0rmtL/im3/UjgV9af6n/LLvXs/U/5ZIR1u7XS4qr3Sa/oXI8Q3y6Xdx97P+5Fgr69n6n/ACyqyLV4lL+WSv8A0jv/APbLn72f9zxPXb2Wea6rST6qVSTT96ZGgo7rH5k/5ZSV9kvMm/8ALL0riT3fI3/4dP8ASU7+XlD7un+ktAxmIu9/Lyh93T/SO/l5Q+7p/pLQALvfy8ofd0/0jv5eUPu6f6S0AC738vKH3dP9I7+XlD7un+ktAAu9/Lyh93T/AEjv5eUPu6f6S0AC738vKH3dP9I7+XlD7un+ktAAu9/Lyh93T/SO/l5Q+7p/pLQALvfy8ofd0/0jv5eUPu6f6S0AC738vKH3dP8ASO/l5Q+7p/pLQALvfy8ofd0/0jv5eUPu6f6S0AC738vKH3dP9I7+XlD7un+ktAAu9/Lyh93T/SO/l5Q+7p/pLQALvfy8ofd0/wBI7+XlD7un+ktAAu9/Lyh93T/SO/l5Q+7p/pLQALvfy8ofd0/0jv5eUPu6f6S0AC738vKH3dP9IVeXlD7un+ktAAu9/Lyh93T/AEjv5eUPu6f6S0AC738vKH3dP9I7+XlD7un+ktAAu9/Lyh93T/SO/l5Q+7p/pLQALvfy8ofd0/0jv5eUPu6f6S0AC738vKH3dP8ASO/l5Q+7p/pLQALvfy8ofd0/0jv5eUPu6f6S0AC738vKH3dP9I7+XlD7un+ktAAu9/Lyh93T/SO/l5Q+7p/pLQALvfy8ofd0/wBI7+XlD7un+ktAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//Z//vgZAAP8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAETEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//viZAAP8AAAaQAAAAgAAA0gAAABAAABpAAAACAAADSAAAAETEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/74mQAD/AAAGkAAAAIAAANIAAAAQAAAaQAAAAgAAA0gAAABExBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/++JEAA/gAABpAAAACAAADSAAAAEAAAGkAAAAJqG1DUms7nkW/wp6SH2cAEaFHRsgZ4HRm55pQQkkERIwg8y4QzCEjJHfNm0OGXImQPBVOY0YaQcYNmcZAT+cwBvpmU8XBWuWXT8X5L3beCWqGK9AIK7krI0sIIyTBANoQx1RUYQGhjx0qmRUaQJvmiIgOEUfDB2EjjIG6OYIzRSzic71orCzA0gLHmgoMtk15lDM5UDTrCpIYMahgVVBQSFIhCMgEe3BXZpGJvlny8w8wZ5IISCDTWKBqo68ah55omMsAiBAaHfgLcIIARYAMGBUBytKY5AIF2jOlDn40wuMfQTBRoWMC/641Y4yi4RBhiY6DQwOJB0EAAyZ0BmjipkRUWpMFCRCGGFCZkogAog1wgM1GzFhiARwLMtEzFDQxIBAoUYObAawNdWTBFQyAlMlAjEgkxccBUIaogGIp5mIEZoJGJipiBkFVcy1cN6CT3kw5+ZCywBmwxVHM3ODlFg1OjN3GzWbM5MgOueDPYEghjRHE4UqOMCTnR85U1NQBjKxo0YvAYWcxAGPtpmISYeHCUkZYLmpgpoiAIhExMbMLGgFAGYjICFzDgJh8qpRiYgpqKZlxiYGCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqrvB95co6UJn/eFRMQORyjIZshGeBRjS8bkwG2PBxrKbq5mdhIVCg5YByWZcoAKIBooZCIGJB4CLzBQI1h2NCBzFyg3h0MEUzlj4z+DNdCjcHIxhFNpLTGA40WFA10cG8mErRvjAaY1HFRAtYmWgRsz4a0UF2kAZhiAbtBGvGhgQWZGMjg8BkgRkJjIYAjQBABd8RB5sL6aeGmAiJqUAb4UGMgpjwsFgYxoYAAOaHAnEnoIADDC04eTN5fzhWU119ODSwMJmDJxz7uaGJgQeBx4YynnAwppICKhZpL2c0LGyxZoogYsLg5HAI2GHZihwbQ9GzkxxDoKu5w6Gg+W2QpMcdjiDQ0yINyXjYhw3m7Huc0yIOOODQ4k49tBFmf3VgkaNTrzeRw46YNqMgILmbmphBaBksRlRxFAacOmRmxthwYqunFwZwjEcFGGrAxfwyuJOhbTIwAyoqBAqagiCIxJi+Hh0FFQJTA0iOOEQhouMFMzCSYCLpx6mZZEG9FibhlisciSmrJgFE2QGGKRuxQbLGmzy57+Cd03GuIAVNzMQ0zKYO6ljiJo4x2N6ZjKRQcMzOQcLCBnQsa/JmsjZhoOWzNQfjahoRgxoDscUmGUwZwq2aSkgZXUrhcTv8E6PgAiMe71ovWiI9k0MsmTTYEjEv1KH8jFmNt3U+vowAAM//viRP+M8AAAAAAAAAncjURwBzsUHXjQQGN78oYTNFUBnOp5TAnAeBgQJgwhnGHEQmaG4yZsSQvGY8wGbcch8G3c8VJ6UIQ0eqRqaGUITp5zeJqaZtESgGMli+phwwdcYVMEkGBMgM5gIwBQYA+APqTYAqRdD8Vn8chyJZybf993NepR1axAABjgBwNASBgGIAqn+YDqDOmD+ElhnFQ6Ial3QwnXFsOZoPzgYZk0ivmeknxhp3BeWb5wInnQWz6ZnqJOEYb0QtmCuHQxnxwmYZT+WymEZHixjlwQcYt0KhGAQBcpgy4G4BgfwrAP///7yH0qCBETxOt0AeEgRsLAE0LpLfFMB8MBUgUg1gAhMDSAqcyRQY0Y4wjfApwGwATwiBMSoCJBGpMeB0DMmEChnEtJBW5iCihQcqATEKxEgBgzRbQmBFwCYSqAASmAOWSwEIoNNN8EGigYUhaMIk2xwamboIGdAJwRQKiGCKaAACjMxwyBhZQQCluDOWCBD2YLBZeQkLEABjtmWI8Re80RTJVLXhxJimHEIWpJSx6EywgsmATjcAAhS4Cao1SF5gAcYGMVsMbME0xQgqOHTA4EePHMKBC8RhiUSGFUvzPFQoOM+HMQZB3coJgY4jSgWENQMGMgIJi5kB5jxwIKiw8FIA5IRDzFBTOjwqvGpwMGAQMZ4MkUZgEDQJeYyQQKDjOBBoMBhJjCxgAZWXMAFJRxETAAdFpZQjEGzugKuY82YcIIg5sIBYekV8EFQMPNAuNIWBjQW8BA8eUGJBm1OiEOYsUZ4YYECbh4gjAIs0osMLmSDmbFonCAeEDAgUYYk5EMR1YQAAf//+s68AmaUcTJqoGMWacBmHgU4GGjrwXSERowgZa67AKSYQgiRVUMUhGUYkCSmghtGbDAa5kYPQAYxMBOYaQEiJsi5idISE1iOAQV4TqCjALJtEHROhwLwLPAKgs80wIKiGQEeI6pSCPIWUF8ksAq0wOAVzWs0COJQQY0hOQg85sAbwj3xchPsjANeB5BrYukHaNZA8JvIbjmMBoKDzCCYBUZ1ASIFcIEgLxJcG6IYitAa4heFLCFpicbXiJxpKcIGggC2ZBRrinEAELm0ADpxqRJEtkNMi0QG8AyRRAaIwCVHsCK41izREBDoKeNA0GNAxEYXMcgEIiNQLJkqRVdCigFRISRxAcVMBBFszkDJHNAAzwTPJA0gODBThqghjhEsBuQisSSHvQdsAqSuMxCThCOAE1ShM4IpAywEfMtICLisQARMFQSOHRzRKMQ0CQDMJKsBVRRIEEGSuW8MskwggUuaySq/EiAAD///3hUgIzCzjYNRExyjShM04CHg0wcfCyYjMGUTKWXeBCDDFEaCq5jmIiDMwQQ0lNgjacDUP/74mTRh3tVZ60rOMzxaoz1pWcZnicBoLYBmwQM5TSWwYxm+MrR6YDAJjJyjSwkJNoXKV1CPGZoHsJdB4gUkBaNgw6R1MBOhdwAWF3GiJDQQTArhFRKcRYC6wtgkiFGGF4CoalGkZwICTmgBzGHkNoTcAe4PnI+C5x7ISMa4LqBWTYUHaORTegBJNJg1IhkAFmZYFgBHiFAC6S2BmyCApUGPIHBW4gYY3mxwjeaCHGJpKAsGSWawhxghChtgg6QanSSLYjTQtCBvwMiURmgOAlh7MitNco0BQS4CnTRMBrYNQGVjGJBKAiVC6RImVHAqqBECAgdRHVDBRRYM9EyBjRBM4AziANODgAU+agAY+RKgboIoEkR74HagKoriMUg4AzhANQsTNCKgMqBXjKTAqwpGAUDAVEjRwY0CzFMAsIxASLgRQVTBJJkLFvzKIMMMFKGumqp1FdCIDAYJQCDZKhDO84hqQVADwH0HFCxDYILhEZzGlIcwiYIWnApXhRoVImQ/a7V7g8EEKDoC0fy+bNwYYHIaFAiQhcxSC6C66AdmSmJZ8EhDFlky/hgoABAUpwMkYZCIAEN17v+nVSg04BKYToTAQQdgRJR7Y8o8ICKIGd4G+lRALcBpD/NwRoQSIoo0oul21riNJIsMequpaqgKELKOcvAugn8ggWiu8v/OywfUwlPd/QsQmSiKjQCkAATUUwCFZlmg+hdCzgwx3L5rHMQGzM5BT3uTjKCL1LRy5MZkheAzWSRL7GRh0krC1gcONHSiAwDC0GhhEtgskwekJinF5OkRAYgiihegcuIQCkKZa7AuoiSIkNmYyjmFSpIJGsiDboCRwBSwwMYCouWwAUjAII0WZDxt/F80X///+q9KI9ECUqLTvm1aL48Nwxlo0c1hCwBEQwIQkGAq10AgEI8SEap1G4EWMvQI+2NYRCYnQgovQKlBx3NRnUvRPCDsvL+FyFkp2L8WUNEXYgDBqV9ooIBxk5zaXzLQGICIiHFK8ACR4LcAFZlOIEkQ2ELMeFRtoQCIpRSJ0Q2XrQMUBWeBTlwi/aAYxAL0CBhCBdKZSqRCUwtQBq5RwWOlKX3VSQkGA0gfsTYX8ftM5DmEPIvkKFgX1L/oXGSxgE+CAVdZtOALF6G6nE6s3o+MkTxR+fYtouhCSuNY4FO3YvCa7nt6ez0oCk8EaTWk0IU6YE6ijwIObyhgwAoFhln3DKwUNCI1XIFNU5aEleFjx5cVBcB9mgjASFaWy+QjBCcMglFxgnq3LaLTgJEwQQh0skGSNmvYas1uxjmEwwsysObh8OQ5FUJRaPy8QUAbEQXigLB6sDYtFEQwBRtEWQKhyXTAci0JRLf5xpU7cMtVgHj4O4FDj11bC2i33YCtQaEtAw1Jtn/++JkJo/4WGeygZh+YvSM5mAJmF4gKZ7UBL3gC7IxGQAEYbCMCJfgkLJlMwREiu09GJQRCWXnRMLmJhKEXkCSI6OaAMqETdYI0qw76Y72M0dCUIvrDza90m1kKklKd8ge9lbSWNqAOmtKH2IJiOKHjaRIEvC7CJNRPUFDZWXIhb9pvLEIhO+nmzdt2Il2FuLKepCFx4upeqtHodhLPndL1tWQFq8bpgyp6C/EGKbKqF/2YkBx47aMsXMOg5i3kWJmFuvh1DSEMLyIOJ+N8XKK4uM5xGktHKqydaiPX6fYTLnz/zIYOckkkmQlCMWTgclZRXHtT1eYkkmrWgJDs2uJQlGTZiek1YJIkk1ISgbH3lMEoLZe7C4FD36lz/RhI0MG0MIe7iAuAZKyJzVyu3Wa+hMlzM12KqOI39M+TR4io+Xdak1GEtszxECTQan8wR+Uf3pgVhj7v2X8FiKYNYTjcdNNeb8O0wwWQyV35sRCVmWyrhMCFKxvwWQWFiEFMwHiOK1xAG2yHzXE/VhG3cd31eN63cgAsyGE8W3T7YAuu0h+XvIisvLjpyw/DbjO+1qkfZ3lbIFZnDrSZRVeF2bDH2XtPf9456/Tbd1+ZBPTT60meX6i8mBBlMg2xSwYBJSuLgmBJAwCEIatMDUywxhmXFR5MBcGR4ZwhjQuFYUYm6PfoePWm0IVYZhJFEmgwEanFQc5Lxbz2JoXwMMNiUCXQof4gAO0KwfImpiGWCbPMJAGDYBbUxhI9AF6F4PlC6CwiWEEHpAVwqClBaBxsZpHMry+i2HQuDAeSnWLOPcXBC1ccCFm4jRLKxTH4O4vJoJ9kYRgAoi8EgO8vAMQnKKPedQCoF2V4QIQJTvi8A0Qthzl+X1AdY/gziQmArGVzIQCMq4uEcwj1FlMYjRvBFngP2isbzSKBvZoUVCz0HrOw9Fk5Zc6iN3V8MkYOcca6jLEra5DkJRkAWvYpwAG1wqqqqKmqzMzMzCyqSqqKjXBU7ydQJwABgLplkrGEXBLywBOM3uGTpLoEQDkY0BpqLi3gsoisDllkEJglIesrtrLTU4wwaJyhSsa6m+EgrURTSkWktEvJDIyYvUmugKBIhJK8gIZ42kChW5vjitwMEW7WQTHVWSLNOA4AZ2YErAbgCcWVMYQuIvgFooihxWtJ4nggZccCArr/Mq3ZNBRoqXxiMHJYwg5DaQcpUvUWYOgkbMom3yqqGwt5b4ASWqUDX8I0ioRo7gIzMBYS7xExXpAOIEpGGyhlEWTcRWde9zn5ZUx4FcFVQaUAmeXoboHMYs/QjWqYv+kWzpJ9IYEBDpCSFfBwEkHjf5Od0nzrJgLQQBKYqKMVlzDYCl7oKqJIMIZ/Im2Q7tsquoGsIppOLpX0qBQJgLM//viZCgACe5oOZVjQACsy/aAoDwALKnVHbndAABTqYADAWAARCFIRgjGloDEhS/iCAzAwzaEzJkmLMgMggMsSNAgM0sDohi1JlzJQmMcqO9yO9INcCMSLjhi0pp0JlRZgQIGHg0WheTDi3oMArDMAbRri5GcQi3FWtsvaQooni8UUeuGUbHxZEgNQqHgo8CBxBtUr6R+5XnPyuI9YaPA2aORE1zsTj+C1GdtYWmgwnglGjSX9Ltl84mpfBzpLCNquwvBJYOQrTlRKYgsRh6daN6A8wIUChzGhS7aIBjRIGDhUGgPRTfiRJlpduQ19YlebVO3JtIw+zqO3L5W3BdBbSVt1ehR91npdq1FZZmbQchjr/xl7r/////////////+sJsJ0nycshbkKb0QENDBFtJqPoXIW4vQ5R6jqQ4lQuRlO06kC4rpTk5QmAro8WEhyijMKhiSkpOqMnlUpVSwnSZxLWxyorlywDeFyUKlElJLGDNBirynVTDI3ltOlcE6V6iUpoi2iGkJVh1N6iay2j0ktXkcT0TVpNFwZrJ45lFDjH6TlQ0fPnyuiHMtVYUNZU6TlzULc7TqGmiywouKBEPBENRqPDmKRCGBCDFESzEMKQMR5gUOx5S95n+siwCs5jcGxj+TZsUUxnIPxiCLZi2EZiqTZj6CJjyVJgSMCIkFmYJGIEHxZHGDPeqcwY8KIDVCSIIaNSQlzDDAwmYsaY0O0MQMDPBTGmACAFhBEQRHWCAx+Cn9LUGKFJzDBBVMBGzIiy4SKrTS56SSKBeQcHBAA15VEZCaYIEJS1rBzJaSRioEKlcBwJby7EZocl67gAAT4VvIATFVbB0BK1wOTQtAQNUyjCsDM0w2XmQDJIXVcUXwhgq54GMAFUzhuccZsojALsgZS3NprNmDWqsvUEe2H5h+HbeSY4/LyPHIZXDC74omO71SAleqUrWL8qOpyOimO1xyDMj1A2DGCCIqK46jes8EADCAGKSGfW0h0bg5Zed6GCwYOAVXqzJoqRpqyCV/IPd9SxTZuygUGJmrAtrIcu/n3////////////////5Vz////////////////////////hHTiMtKT8yjCbTLrFqOIbLg97KcDZaEoCgUJjVgpGIeIYYrZapljj6gUnozTDrjJYGgMCgC8wXwdzCnFzMIUM0xUOMkQzYec9ehDBc2KCEuhVAwMMMIEzdV8y8tImYiZQKag4QByc4Y6CggiMhEjDCItsBkow4GGoNWYdGDNB1YYFDBdcKhxhoIhPJjBHICBBlhKJIQYAKjCgPAJAMIdDBxsIHR4VEBCYOICgUFwMAi4jHgCIoIhIUMIDC3YJE27hBCqZLcVGgsPlAEBBYx4cM/AwuJl1jCxQEE7JSgWLP/74mRuD+zaY0IHe2ACAAANIOAAATs9jQAP71TLqUFNRAE+ARKBQQwASMHGgaKMMSdMYKhJkTpaiz0IDAcSmLgCIoOE19iESlBa92R4EBwqZCKBhGBAQwo2igQJoirva2kygIQFmNAqtiVY0XAQDMmBASIpNkQICQkwILDkcxwAMECAAMgkJBwEFgJWgxAPARKUAo0JNqPHiUUFhQjIj8wsuRJFgVYcxYAJBkzcXQ2Ig58zIRIME2XDAW4rLwwLl6BpMJiMYJmxa4KRQIDKoAUGLRA0CIgMRg6w9OjQrlrLQPCqTHax/YxPYNMMb2PlDshVGozWBUFMUoCajAFQ0wzdQmeMQQBTTCkUkUxuUNuMMnBlTSEyCIxAQDuMAkADzAKQN4xEwLfMG/BaDAsgAowKkCfME8EijEhQI4wMcAwMMbBkzAvAAEwLUAOMAPAWTAxAL8LAd5gNILUYAQAEGPBZiYyZcPGXA4IEA61ZABYQBJoCGwAVGGj58KURVRgjgZwhmYB4KbTNDswolCDMSLS1gCjQIGGOkAWBgUGigIZeUGGEZAUAAXT1ERmaDCHRDCQExQAxSkyJUSlCpIQBjGrzSOBRgYk2b50WEZhiQy0N+jNqvMKwA3UxxI3B42pkyJwGZTtBQhCAsQ82MQEMyxLTBBEwlgHMTNiDELQYGYIWBoMQjoQKGQEyEpoAZmPSmgKGCJGihGcHAYWZAOaheYYUeAsCJAFFiRcwBAyRAHGDCEjWKzIiBZcUPDb1zWyxVkZB+Y4ObwWaEwagkagUa5MJRAKMM2TLYAEcYJyJDzPmBq8CCQNEGYVmpImbPmMghU2f0aTPSsAYNWYhQZROZImLFiSyZ8WMkQKCBEU7YIdVmfDm0NISTRDTOETInQj+LCwzCIDSESF4cYQkGBBGIJjxYwzExQcw4womzPOSB0Bz9oaTEfqR6wLD5KtM0dkXzFypvLEltBVTzD9kY4FepESTksRiGWch/qS7aXEmxaGWdCrPR/EcJ3ksj9957rzHI9Vyym04plROqGmS9cLSNVaoZ3C9ISuVMdgfyahPVhpUCfPhSuSMPNcwoM71ncd6rPndNzerQq1An1JKzrKPc4jS8fyQG9uJcXk2y0OtCEPRiqOIxSKMQsaGIe2Md1Y3tytUTQl1QsKtQK9cNrtOHqPSL4pCxlwOdgsnS4lMUhYy4HOpJauLtkY2yC+cXbtwZ2BvhRXNghOmdgb4UVzYITpnYG+FFdvCNYAMfwX8AmCGPp4iZq2Fh7jn5mOCIMYDoZZpWpPmHgHKYUrcYCU3MBQEc2TExTCeBZMDQAUwAgojH5KMMD0BowJQIDBABmABEBhAg8Gdq5rLYAQ8FDoBBTcSFYgPTB4QMHEwFFGDgwsJCwUZKDD/++JkNo3quGLEi9vEQJULVdEEXfQrvYsSL28wgnos2EARe9BgQoAqxOcBC4oKmZAjCRg0DikSCjAAEtSXShooI1Z2stYQXVA744RQ5URiIChyFeD3q5TDUqEhMidN+Y+ITooTy8RQIdRKZu7SnfjrFEiIgtYvspqwBsC0IeQmIQOFKguAHHQeD5w+rqdEgOg3rytOUoXW2RZpa5QODMlKkqBLqK77KpqBwMsZDAkE0BrKManAVEgLaQWyLsIHOUhUrlIKMjgYCXfmFBrgCBlqE+1tIB2lkAU31CJbD0NtVSTWCRnCw2ZPGsGWqUrSgRAHgrDJ0umEGLVLyTyekGDFzuIhJTAaVYSlVMTJjN4DPIDs/LL//////vfn/jyN3//1o+r1dDMfQosj8+hEnfU5HZyB3IBgGbkKBlwDAUDzBYQDBclzA9GjPI8zj4oDb9wzJEOzP0rzTyGjSJPTdU4zEYWzUlBzM+ITldNTdTkD2RYDV9yTQcnTRdLzB5rDbgVDXZRAKWZiWExgwAJdJXLlRm1seyBHyir9BRoWJ1wiU0fmqhGLuJ2YFoeZqt/zHvhUefWpfgCRnMPAW80YkmDEQAVBrE5lvhpmBUAeb7aeBh9AHGCGCAEB0mAMZuYKwUBgZAhmCSAcYCJERhlA4GTD55xQMB5ExgUvNPBTDyo1Y1MUHhgBVcEAZfoKgQgRBd4MKU1FAQwwCmhNNCFcgoKYxSfiXwOwAJ5aIUHEAiNANFQQJeED4kUlQXhLuGCChq0JOpZC02nCRRZxMtL5QMhGVTKg8HLlQnKaqKrrGR0qBAA3Be0AF72XJ3uipyo4kYthbKgIMrAQZINDKfCP6XaRYhKp27hBI8AKAhQYUHVQVC9TFmms1Xyj4sVYCG2iqDqaMlYOqKKrLVeuYusWcEmFuFUJRp9G/UfcBfSlqNRME3dS1OlPdLxXDMkbWIlyVWtwUOVe+CrQ4NJiHwKELDhQpJIZEIgmZperWh6SIRqHA0cHKIJHRL7Qy++KuS7SqUd4wEEAyB///5lyJEEoP7+X7ly1/Vnb+jbP+/0bRtna+dXRrt6NdCiq0zHmwp2BcEMwQQTjEIDSHREzARViPwbSox5FgTERGHOLuO01X3UTRHFTNnmRE1UU/TnIOCMcSMA3fLXDnaXyPESkgxXE2TIPElNPEikxO01TPmB9MO8HUwNwLysAuG5qrWJmRgOUEC8epxrEL2PU4CIo3/NEeEkKgATIqmQ+EmYU4Yps/U6n1ffyYQKIBhKCgiMWIxnVlzBWAVMLNBk0rQSjA5DrNbREUwwgNwuEqYGQBhieFKAYHkwJwBDAgAtMDkOYxXAHjKAw84jMcGxYjMECAdiDgcTgye4iAh5xUGJgEGhJl52MiJgaGGEZ//vgZDqE6y5jRTPbzDCPq1ZBBD6uLwGLEA/rMQJArJkEEPq4kISuNBwmLEFRCsLUgwVOpS4JpLMM/HEjOBWamM4aRgKUGE3cLpAhsiICoJkDiMUtUoAFx1bRJMRgtHAIwMASFS5WBRBEYjll3U4042fsNCoAoAqdFZ3C7ENMVTOLgrpRWLzI+nGMrcFQmihYALrFlhAEw9TUaGboIxEx37GhxwIsg0p9nAa2VHEIS8yJy9E6xpNT0DIaFCceWETTQodIWagZf0eZpkpaGAGIGXrdFC121NIi59l4UpkVmJpgpDMQsvG7cYX+3oXGS0IGlpkw6QpCUtddMbhtxAc2qqiSOBIopCQ0XLBA6yAKRAToOTP4LAzl///////9T3///+f8d/mhn5jvIGNHkkY7fxz/HqvUibSAuAqAQEjDLFGMN0PcyKgYjRsb1NcSnYy30JjRAU5OiFYo15I1DK3kpM5AuIy+1Qjs/XeNQ9s829CXDmIgZM69DAztwfTZXGkND1QgybhADFWBcMCcFUGAHJ6tygGgp+hvT3B4myte63txr0/zRgagGgYCgApGWxlyRgshLsafsE5GDmAYZgfIIGYPiOZGAIAE5gBAY6Yu2AsGAYANhi1YrwYAIASGAygWJgEAASYS6EGmBvgRIiAVBYCKMA7AxTCBAJ8+eA9cMw6owAMDhwwWaEidlwCqQ8jMy/JuQVDA4abg0o6YpiYkYLDxICQhDGDkqgsQOccIjDto5pyAYOSHRCHSVAhCGxMMqqZo4OOEYoRilqyYaGU0QRoLiVIWGbQcHU3e5WxdqjDQDEBMsyUg0dYABVFyGBJ7Fl1kl+lrAqQRLrSTdQgKKjBZS2b8Bjt+aqrCUCRewIFUOFnYdKraXIsoBi19BUUwoBp0s+JCKroirhAwRbQywQUCJPGYGCqE2WfhBAoAAkxIYgBgMtUOPrlUykEhBgDjswLzrKUkxEa0N4tB9JdDGMs4ZuLOEIK3k0m7MOEYZQf1wmXu8ZpyXCgTKBBAg+19MNTAvqz5GovcieslbhZdZBAAkqYQRkBIrlxLEpz////7/vt/Mfsffeb9jHj08Y3djHti2M8tj+LmZtuznft+1utQyRu5VAeMDsC4wBABzAHGJMbsYkyTAWTJxIoNJM/Y2JGfTRDYSMZUnoy8yfjDLGaMbhPg2B1Ozt8SzNH8340YUejLqT/MztxIyxsTzfAHeMOwBIwTgZRoGFl9S7WFk+sH8D/6Uk9acD06+bowSADWMDVCSjQ2kXk3EYUkNhqGjzB8AGQwK8FgMbsJxzAfgB4wOIFNMoLAizAYAU8wzwhtMC/AjzAegFczAJU+KHUxCXoxNFEClmY23CCzBMQQbM8yVMKQUMDwkMEArMkRBIQdNOhM//viZDOPzKpiwwP9y2JOKybDADrmcxWLCg/vUIHes5KAAI2BMJAJGgTMZx8MJQdBIaiMFTE8PTB8KCEDxoVwqDRg0CZgcIAcXRhIAZgWCw0RI4BLVyYUDCUMhgAy04FAJaICRQVRVBKpFAYwYkKXSdBYgOBMcoegT5LAYoizVSky0GbFlC+xfsIAL9hwo0WQumYYcYZqArvJijXOMB8dFCoSLgFIY8KhjQ5gLhhicIiBMwIGlgi9EVBwAgFYbAxGKBizHGB4aCMyxG5KAtQMgEs4OvmWAiiIThEGIBwYSKjBExUcLJJ6GDChqEdmCQlkzVNkaROQMzgwQDBapRGgi2yowzANYIxFoF0g44VJVCkOnnDggABSoXCSHgUMTWcOGs7UrX+7qElHkWAUvICkOxhBCEkcKLmDQgiLQyJDX4UaTlQlsFDi0GREACEp8mJU4fCAAklAxE/8vyZeIX/3+T/kxfFF7EJk//DOpG21XsYgiMDUmDISToDzOkjLLxxIUIjKqDCrBRWSvjVkTcGVooDDBkTtcTMkwFRLjODQXdVGDEgtRgHoM2a1Gv+G3ziaBpU5S6YH0E7GAqgyBk9pIMYFmATioLQZdyAHGA8A2BiDBPYYNQA0GCEAc4OBmTD8RLgwNYHRMCSApjAyADMwCcS/DgxUze7N05DVBUBJplwkeIxGKxBifOcW0Cyue8RjycTLjtHQQACZDClf5lDRlRQBinVRmsJjjQ8g4tkBR6Jg9OCygDGyYcW3HBcKcU0gcHDRCLGkBlUpaoKkgqKMcXJjgk1EC0xKAxwRI8eMmcCAJCrpEgCllDDPEDGgAsRIU5NELtI6IHorreV2hMNGIFgg0PAw0eFGADGLDM9YwYs8AoZhi5kyhmB4OdJjPgKDgUqGh5kkhhAZMBawCj4XAmKHBgRIoMYIipjHDJAQUTCxJUi0mQFgIQLUYYgFxCga4mMMzApAIgBgkKDnDkQqBaqEBwUEHtiZAQjWug0HBkwC06QJEbS+C4MzQYeTpcgYQupwImhzGBojCgwIvBEJWYKCxISEA0EQCJmyHmOKrrS9ChIzAAxAcMBEotJVMtIs0KEyRliL9xSR2CpCUEhA5NdyMKzigaGrf2f/M/6TVCn/YbWf+QUE4lqR/8pMsljkKCgnFBUNWsUKhq1/9Y4woKEI+oax2pMsOkFBCxIEFlgYGh0gIKCBAwToasbVDVrFChBxIZyanq1QUFgVREsMqJJX6JJLSlUQIlk5UllKoiS1gAAAeomMDMTMwAwXjkCsNNid7A+FwwzGXC4MEwJk0qDzwoBcYLArgRPmYGIUJ9vqpjsJJiIHpgCEZiPVJiOSAsCxhGEJhQ2okERgMDBlAC6RI0AYwAZAJ6/jIkMiQJUA5CmyMf/74mQyBPqwYsZL3crCAAANIAAAAS8djw4P7zEAAAA0gAAABCNAwwe+GOP7DaiqMgEPUxB24h2NLExRl7A4oDRmW4WiSLZkKmsPUIBx6DSHFAyFNojKlCLQko79gpUEAmCYJVoTUrVhBgwZMLTkAy+gqCylV6maaYOEVkW+st9EaUkkUwsKXqBQjDmAvKzohBfMVcaW4rtSqIJQNwfh7ljtSru4u9+E+SwQgYsKCGEZkbXJbjA6mSb48Gw9slKzhBMsovIW40WybZxVss/dswBUKHpccLho6P8uigWIvFM924TLXKTILoU7/okMTgx+0N3xCoagYqswQiTU+m297iqUrML/IIkvUaHXZA6KCEWJV6pg+kyOMBdA0jA9QTU0TdBMNj4QSTMFR+Awf0HtMFIBIzJ9RCQwIsCuMEAEPjIiQSowKQFeMr6GFDAGwFARAVpgRQAoYTEHWGA8AiZgGgEyYCsA+gQM1MHFAlQtCHn55s4ugCMOBDhzwxdROWfBkWMEEDORAyMARABwuZosmDCBEMgZuMAC1jrvGoUxMIMOTEwSI1XsBiQMNTCwILgTTRkSBWJQkIhVSqPoypvAgMHEpNlQYIoeJ3GniURoCkzae6D66B1Yvkl2X/YgYZqKruVX4FhXSSaeS4hzAxrD07JcnstBsEPMBMEMBBgKRpi7mkzinAkEqsgODlxIKVISlmipK83bB0BhhAIgetJAACSveOrbYa3KHVqMmSEIgmNyoRuhDLDkqzVLBBCoy2CVJmBkIJmiFU1XClAc8ACFDBs4vhDjvQEvRc6+3aZlAYCLXMzoHXBA4iFEjioABAVQu4isLGJrNnUsSfZykcqi5ySiERfEtGECDxhjirVlFTZMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAACyCYToShgZA3mvQdGa9rG5sSFFGG4E+YBwTRmtB2iQH5gUDkGUqCkYAYBpnSiPmCYA2YA4CpnBIfKaDy8rGXKMcnRPCMHBTQx5kTN2KBi4MBQEEQgJfgDKDuKLQ+YCKBweoYyuBWgOKxl3gaDJNLMkClyRE3MwxF2cnSqHQNMOZdoSYwdSOJyrg1ZUk5Q0pxbDkH0nCRD2qfoDKTguxfzHScdDjQRRitpLhxBoPx1E9ji7/++JkWgb4/GJIM9t7YgAADSAAAAEwwY8OD/ctiAAANIAAAAThpn+CIFtIDOjlWcpICnelzJWj0aoHzCeQ8lc7sbcDwEeflGJoQhbYzLhH4dIuSJMojl6EhZd4TphRJ+j+wvqw9Pt+cr9YeqJZIepEW5kBZnJHk4MhYhqbR5HeZY8UPBdFCqyFmWXQuYkDIjMHzBczBWAOo1j0eqM0xSqjYmBwkwsQD5MERAzTJ3QLUwCkACMAYHejHZQd4wM4E1MyWA9zBkQD8wHgCIM0gnOUPZNTi8MWwHMWwtMfEfH5KMZhpNJgoMEA3AQjGBpGmJ5GmI4DGmpdCxGAEQDDUVREAbaEAHGFIUo7kgILBJWBcATC0GDE0BAYAQwBA0WYsAL5AwBDCQIgEGgWAZBwlAUywhCmjwCkklDFBB3pljmQaYQgRqm4imAFzZYYot8QIG2MY2AjBGoWkjhK73zQQDIaLqPq2S8JQGuRvV1AENt1chZ1r8GmiCY45M8tMKAHNOR0pEUBqIAKcpDQ8Eb72lnxURIqOhYEUkUDVvHBDETT8BoMRSYVX09rOE0kM4mDiBCI0kxgR4QhBCFjFCUHMgcwRQUKoQrMKklBqmqTrzLDgJZIZrBehR8wQkxWkjwhIMiMJGqzg4BxkaGCqamEGVA6haVZzAyg1+llAohVEIILjEAwiEFjXKc8ue0pMcVDBoLhOPM2/apMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqwABANSbkaShgEWZi6MB2w0J78zBkyEgkLEgROVEpohgdrG5xSYKCh1FiBwABoFZQBD0imnQ1ZZ5EyzBAQMrCELBIkAaWg4RJcuo/C4gU6B5Y9YRhYiMj+3WRggsKuoyDdkz2DthZQxRM5rairWnOYe1FQpm0SFh7pluJgJjuGqmzVMRoCAIu66ELjaLqlsbZgzGIzSvYAcaD6bTlCRksm7ODADCphxIhCkRmCsYdyDXeUVhgQESkW+0+MrXk7rv8/DMry7phsr0P016CX8dtxX+ZK4cocKPveTBabDb7tLZuyRirYnccf3iXdIIPhMOS//viZHgA+RljS+u8wPgAAA0gAAABN8GLDy/vUsgAADSAAAAEqZeRiDuvrQNtGWsyyCGTwlmCa60HYctry00fH1YS3FV0y7rAECcdomTvqsMjyhtWisuvoAAQtXVGBKBRRgFYQiayGf4GmQk/pt5YhOYWuBjGAbgohlIYt6YNSA7GBVEEhjCIA0YFMEbmOpEDZgYgFaYCmBwGAEgaZhO4eqYGABRGAhgAxgHYEgYDcC9DQuuKAPBgw4BWYASBFGAOAFgtBHxK5ggkcFPh0wYIgnSDRZQWCwujm6gJjKaYqTFZiuQtKDgI2YQMcCiZIPJBjTmQxYXM3PTIioxg/MbClNhJ5NKJBxERgzKQDRLiKQLKgQMMqDBKJX5iFpwwplypRSGBBxjyBp5wJoRqBIBFx6CESTdFyVAZ5maNEYkWah0NjQosL3iBWck0dACdUaAEwihIdDCmhGXNYxKOAkIEpZAKUaBUsGkYyUB1Cy4oIHCAeUIQUZNUvNGXEZIaPOqacYHPlMSQINKzTgVbTBFhEkJk4OwhA8qiQqCMUdGiIsdZkYQMDnAyOMmiZWYo0YIAAlxiSwouAwJghgEprgCFJhBAGTBcIpSYQkZEG2EaGI3FxCZGrIEQUeTQhh5WDkCq4YSMKBMqSFw5QqZUBAYYOC7kkDGPUqCoeBYFA0TJkxQ6AxElLFgGl6HVDPqB6uQAjICKYZhVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBAAYE4gBh7BpH5RKid85oB9yrhGJCCIYOwKRsvG6GHaAMYWzDhnsg9mACFYYN6mhghAzFkjAYfTi4pzLkoywIYsHRjpABxiFJgQJJjaIAcOYOAQGB6BivQOCETBIBlVg45xgEVBCoBqUhxgDORygJrLLgJC5gFDDOjdDZoYBKUpCQQnKAExCERbuG4cRWEBD9L6YypklFEFH10CRjdHHDil+tjASRQMX/Z215mbfsGXcW0gmFo6JqSwt214HAqHWWIpEvu095R0USzT8Eo5e3rfEQzVn+gsu2rU8iFauwYEoAvGOrFdovk7iRiwq8FBVIw3B7Mmdw0xhKsRDymAXvEhVEC7qPTYV2zqv0aUW5RXVTV+36JzQWhK//74mSNA/qPY0Ur3cswAAANIAAAATdFkwav71KQAAA0gAAABOSnUFeZG1xl9rNEITDHXcNUrExINZDWW9VUL+PY3YuOtdRVra4pOkctSBlE2nK2gQdHB22Yy+xfAAeAsDBQAC45qk5oPA6XCTbADtIwpIGLMF6AkDMuS/8w2MDnMICQfjIOQrwZCOTIwTIEwQ4ELMBeAWTAmQGswvcd+MG7BfDAogGoeBTDAZRRwxDUCIMA7ADzCGgE8wFgAjMAKAbzZTY276P0ozupAeDjUhk9fAMNMCUnK0M1+gFv0ztwMrEASEh0UFwcJZwUoDNUMfgZUpubgqadGaMIFxghpjRQxCY5B5G5wzMAzKhUYTLgx4QYZcX3RuMu5Bw4LRTCrgCeNOQN0BfwBZzAgxZIIUoXNsGFBBhkgjFiIoBmZhy4XPCQkKBTBCXANkJBi2ADDIBQmTHS2JgA5j3Jsi4IYGeVih4zlIlMgwKoyXrEB0ODmUAIhCMeDhKRANSjAcLEjLhDUAiaIouY02YIUYUkOiiggYcWHEzNkiJOW8MmdBpkvaIx8KHDws1A0QGgRIwyAxLIGmwSVEZQ5yRpoVKkAE0rYEDwEKXQHBTMlSwnZwCihhRwKRAwOBRSPgYKZAUWjKAjIDH6MSBMQGBTxOQsIxUGiCKpiokMMSBigmViECYgEGZDDCXBNyKCJQd5cYwQkzhRlNL/2ExBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAAAwGkBMRMMMwcBEzs0JqNpFyk+iALjHID7KoiZlvIBGJuDqYHyjQgDGHA3DSaMKMEkDAHAQgQB8lI7MRYANG4wMwNTBOIYMEsFI0poM0nTLgIkBxUFMcDTBj41ZbMPFRobM8AU8Ek1ABwhJkZYZNBfCakMkRE4IXNUCaVC0hwGStRLYFFA4CO5UiGbr3BIGfAJ0NJQoIAxLbJyhYi10hXIHxlZ1UUyxwIdU0ERsZwFwKmWCUgyhsqMiiEPypMpMKQJjrIWc6EkRWaggQe4HBWk/qmDdkTC/yIin1/q6hT8uGvktzRRxrhKFyVqr1cFsq4WI1golDNdCr2V1aOLMxbggBUzgGCX2lkadNkH/++Jkhon6dWLGS9vEQAAADSAAAAE2BY0KT/NQiAAANIAAAAQInmBqWLGQTuo/bWXgW9BMigBsTEVMUAj4Kq5JvSpRVrDVEd1YZJDamwsh/hkQtJAIELaM0dUChBeYeMpmSiQVq0iSYMGGAmAYgChvXZPea9S2eGZ+FcZhSgNYGBbRhABO2YVyAPGB4m4Bh1AJEYAABAGcQjjpgWQHGOARpgP4EoYScITGEBgl5aswHwA/MFRFBDCiAO4ycbSvRmHhEGEcBB026QwogjWZnCGUYTExlMnpmAoAiEVGL1cfEYfUAepOIBQiPm/fn9OBDYKWQwQGmDEFApUFA4RbVsMCCMMCMU/NiSMuqTDN+jJA41pMi8NYINetNiYkSuxwmZ84ZMaCmwKhIEh5uZAOYkiJMjLNTNCzcGm/BIwAogyyBBIWMgViIh40ASyMgKMcRMK7RyOWTIggIEGSJCI2LBVjGEaGVLiwsWbAQ0GAjPATFojBEGbkwkygAGBBEEEiaIrEgUNDCQEHCMso+IgqfCD5ix5eRCgGk18JQI5iE4YAinoFhA0SBJsUCBcmYYyWYU2RvMGPShMcAMSeT1VYigDEgkBR2W4WERE/AwUwCkQFDAgG7BUEMjC9jHR0GIBRoxptUIcESODggEEGsJjxYKDTLBjOnUvwoHL8AJwYAkgEAIIVBGJGkhADEjcCRU4bgIYUG3KHcV1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVwAAQFRpJMwwgTDEDDSOLwEY4MlEDYnJrMPUGgxyK81hrAx3B0w3zI4iCQwwCI/ybweFJK8DAsaEnGYICsAQIBgJGG4sBD0nnKd6ARCvEkIMJQRkmak3BiQKieSRNKBi5haDIc/A6+2VtKSABKIKjDCYWCW2WJysBd4vqrG8VM6KmReIWDEggdAsEhSq1jJel2XSZQmmlSFRVglhGdui0UOnjDTGIKfeSCEWkulcK3t2Vcj+je+iE5y1G2FJKF/n+ASA4JEmPtAV4zb3dYa6S634lsAaSLSsaHQIQPRJ3cYnHFzOItVd7B5CIxGnrOlSyk+EUi5DY2rtLf9l7/NNUxZ0tBPZW5vos//viZIQA+fxix9PdyVIAAA0gAAABN1GRBg/zUQAAADSAAAAEnsjji3J52fLFWsiQvSAlKxoB/E0Ze7L1Jo7Ysx9JllLoL4RkSIFolGAxFnC0FjPGnm4zBEcuyaMHpDWjAJAU05j0juMlDYKzqhRl4HEIRhJACwZT0SYmA8AzRgjJdwZIgDWmCcgnBpH5AqYFgDFg4AcMFnAADFmgeswngGtMCBANTAPgYUwScLPMPYBWQASzwh0MQlAxwIDCKyN+B0zQ4TuzMMMHsCCMwYKjI5tMHjEQg00WYjF5xAinMTg0wGFQYCULDFgBMQi0Gt8wCSCg/mCBuYiHZhIEhYIy1Jkw4FyLCbwALJiBMNDTUBiheZ4IIQ4GsG3HqDmoJAU4IhYNJhik15gOFgUEY1WZlWCkAEHAKQCERaEFDzNFk3zChiVmYl2HQgExD0osOATkDFSiiZZaYESJCQAFTPAkY1nUcylCg2hIwIcxTB/R5mNJgw0pWCSaXiZpqDhjwDITGCDAEhQOZtiCqTxmDNFpgaBTiLkBUWVTY1LMmRBwMxi4IACwYOKF1k0jEjAaKMsMR3WWCVQsWAJ9kZbEeUgYyacam+aMYJOBEGMIWNWFMOARUW2XtFRJhUAcYAwgEhAa/MYfKF5gQKFryJdgbepVLTBDDAAiUSZIaTSQicKizIOygSOCTCFwgKBjya6qhhAambePvbvdTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBAyARjjgZGDUFSekCqh6upnm72jUYHgHpgwgBGv2V4YRIPZh2juGj8DAYIYepruFrGCSB+AACjBWAhMlsXoFD5pfEIExggknmCUBya0jHoApigojWnqBSMaFDqgdL0Rh5mg8omYCCo8mrBI86J7l+kUEJQCFzHAChMSTAcBJcsSBwdWVgUFoUAiI4KaFCGOREUDbMIxAAegHGUyFxumFxuqTCR4SlCuRmZiOBRpEwpKREt511KlHAKvSDZeoGqq/hZwhK9Jcsu4TFJkiCTE0JjM0txCVAak4ulwUUJI7ij8abCqut9VJRktQ6COZIFK1TCnKk21GSOijAoKvJF8vmu9P54k6moLnXExFraQUAJ7pFMMWe0h44zcWiShQPTzSNZA27sP2slrpUGW5Xgqv/74mSXiPrRY0Uz28RCAAANIAAAATjRkQQP81EIAAA0gAAABChNTEnhohmHBRZ5cPYOZQz03RFYqHjB3CZYtFe6xFkhQK+RqathfG1EIwsYbKI8mH5hLxwMbCqcUIT8nFNFLhhmQD+YBmBRmjFA/hhBQCqYTiGUmdqBaZgLgVMZW+OOmCdAaw0BKGBMAqpjQgxOYB4BuGBLgARgQoIeYQIJNmGZgLpiHTGAUOZNIxiA2mkFCbtARkFkGjDaZuI5m5cA7iiIbIDhQgHGS4Y9MIkHTCgWMIgRQcwCEzWBzMThcwE4DKYRAIwMMEYxGU0JJicOGJwIHAcCik3zURDis2F1YIGmhOAxCTGS6QkuNG+MiSMkWDKSJJrxhUAMwNxkMokLrGKNG4JmBdGIJGEHGgDlAJEYVAm+AmLAGXVEU9f5iAggOAQKYcCYpMas6a4CBAZk5QQkNUfNgVPcVN6sMspBBs0w4wbc0I2oOBQ40ZMWHjBQARFZealiZkgZUuztBCSBzbtgEBSBABszAFEwyQQxhAMYG7xGSIA5KCxxhhhbwy8EI9GeNpOGOpFVcTGgIdEJUyAcSUAAK15EERHwMNA5I0zIjSCJGDhoNboJSZgZUCaUcCjCeA64MYEKBBjVCaJtV5kwYkOBJIww0QABUeXjM8NTIhQZZAqAwRdCaYAEGAwcDCwRBMZcOoqXFCBwKntmbLe6skxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAQrMsYTYMph2lNncxXEbTz6J9+EHmNAAaYJoVBq6jnmBODwYfaKJo4BJmBiFge/HsZtiiYGgmYEikbnzcZDBCUDiYWAsYxGgahhEYWBEZcgaHBYYIBCFgSbhgiwT2BIsxbYzIUmblEcQMAYkEQE0ogaEjhNhwwlMMkHQxmqxiyAGPAgKZQeW3AgwDD1BEDg4agPQngYkITLKkzEtzBkGQsUABhIc3oFAcKgSoVL5hmMHCjHAREEBQQaMv8TCV2Cwgsw8KlRgAyEtViPpiRhlxgYBYEFxaARLaECIORBx1iYswd3ia4wgLBwQQDQFPMqbFhyrRUWiqstAAOB04TLhER6CLFnVhyA6jatVcDllnVZZCIg7amIFNaRTCwRpRiTS8igc5xaYGlU6HpfyGC36cwhDlz6oXAGBHGHBKXwcHAzAikgBAJQXMCjflMRK4SAuWFRqxQqLIh5eERDzIgjBl51EorCv/++Jksoj8LGPEs93SsgAADSAAAAE6KZEJL/dsyAAANIAAAAS49ANEBxcwQddTERkQGDxQOOiCImWAgyJAzAMAMYhy9BAhVkWMFZC7jBNAko0ns45NnnQdjFKCE0wDgHIMA5BfTGoBz4wIkD3MAVIjTHUgQ8wA8BJMb/C7jAEgNIwLsDXMew2NWOjMxTpMVArMpRAEXMA6DjPQ+TZ0QgcFhiIHxcgFESYMhiaGjUYJgeYagn4jQNCjISYwUeM+DxpGNRJzLksxcWMfOjcDABXBEnmfEpaFrA4cGAixkwOBmowIZUcDEAHdo6PkI2Z0jmHkpnJmAA0x0cCDQxknMgFjABgw4zMALwErgpUDGExkqNOEgYXp7lQXNDGghwMRThGPBwaQhgOJVBgUSmFCwGGzDEoRhpkAsCktBUWIxGlrPL4GUCURMIECADBSeZIKGxCBg4oAAQYCAUujA4mOLEbTSsPYkNAxgQuDgUxsSgVBYZBx4PCGoLiA0TAAFAzgEHBhQAYmCMjMKKhwiIR8xsVMXGDBRkIEjFgQ0YbQgBgAtgxEUM+HV2g4UL+kxWYUSGGg6PAGCwaGGZBhRGigAuVIowABBgCAQchOB0YW2ZWakIeEAxEUAgzU6AowYCTAAJMcNzeEUwYQOuLxACmBIy0ac00gMIETBCkLD6wIqIhYPCowZkJmGExpQ6YAGCIaMfF39fyctDZMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoASygEYKuGaGAeAiJmmRDYZEEidGlQhuJgeYL4YHoD3GG0jEZgxgFsYEwTcmGxAj5gUQDkZDcJKmAdgK5gMQBKYAgACGBohyhgNYKcYBwAAgoC0MB9C3DAwgAswAgGHMAwAnjAPQDMwCwAJMmPDbjkxhtRBaWQnZgh4bEFHZixxSCcGcmbiIUQTATIyZIYEYrSGQLg4cnbo5qg8YknGpO5mpMYEEgp+CJ8uWYeSHhrAEACgQ5AM3HFSooKMkPGBZiRCWJubY/MEIczecTCCwIwa8HUzDBkaAsJM6pMieLamQUCpMSIhVoZYSiAREiAkYsMJNAUOLEczAVYExpAxogaChw4woAGhguDAUIkdm/TgLGasobg4ZMkRWwYHM2GAwQABTFLTHhRGMHC4gFrCAJOAmaTZgCifYBFAEWX+EnpgAI6NEAg3AFYc47QLGAKEMCvSfMeSMujBjEWhg6+YAWZskYkyQjgKEMQaHgw87FjwOaAVUaYeDDLiBgImFr1MgGZSBkgWIGVBg7IYcYSCTcGhqaqYmJiM+HTQiYYFyaK4c1EYUeFHBWnAiQ1oMx4s2L1Sw1ZczSBYMENDz8zRKRY8ykE//vgZOGI/mNlQbP71LAAAA0gAAABPOmU/g/3bIAAADSAAAAECAwKX7jFJK7OBjsojmYrUDxGStoH5p2B0eay+XLGDwhAJggYL6Y0SQfGBfAuZh0hd6YFICdmC4hSRmLItUYKwEKGDYgnxv0axjP05vU3ZnYLBACBnjD5roRpnul5pUJpkcFZl0Mxki6ZpHGpjBmiQBC07pLO4ETWys1YCN2kDfJUDOYCIjE0AVJTMms380MYCjL4U36dWiYqhm7OxoheYqEmSsYyjmQJhqJcYgcGgGYhBwSUGzGwO9zLTYHQYXHjB0UygkMbSQhPBS0YClG6FJM1GMsRipEbINpTGJI4jLwIWhBKZ0nCUGYSQBYEMTJwAAEAOPJhmpqY6XGZDKWJpx2YuUg4aA1GZQVmKIJsbSNBJghuaipmwxxnCMZEHGDFpp1cYg1I8GDo4sQmHkACkDKxsAiAXOxyfNWIzJxgwcoNRRDWx0hCzJQQ0k6MCJzQggxwpMlACJuMZCTOy1Sox0rMZBwMFgYpN1IYSIlke3zBxExeCMgSQ4YAIIZlIlCqBCIar0ezRA4RgphY4vQwomNePgEYgUGFSs1cdMkZAMXGbCpiRUOlggLw5UBKEaiNGUghETCQCFg8iGTFnRYEywCMVHTJzk0MHCwEZAAGLUJmqUYgOmAgBZEGBoYHGOAxjIwIikypBBTWZgTNar9vbv1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMEMCzzBchXwxgQg8Mg1JIzPPUIUzbMeTMLzAkTAYwnsxEQQ+MUnFOzF3RRkwuUFNMfaIADHkBFYqAS4EJwzwZowNU83WZY0MAU0L5M7rxU2bDczLPMy7O0zlLUwOAkzdCswOGQ2kGQw4A80kfOyHDTBQSfzcUM0MmMrMjRhRCIxqRODcTAksQqhmCEbQTA7PVKUWBrYMMgQqJg5DDkYkIDGCo0sxNZCi2pADGdFjchAKo8GCnQ0wgahDEExxQCABTcmQjUVYyYDMBLAMSmFqZj4aBkgOhDDlUlFgsCDAOFjtAcJBoFGAEDgJDM6HTMzIDdAKGzBxU0AEHDEwErCBcwZIATQaANgVCOrXTYjEGD5jKuHC4GXzSRQxkSBRyJJhpKEFQMzA/M/BjImMDPoEGRYzNeIjByoVETATgaPDECIy4xMhHzEDEwMnDBshAzWQIwMkMLGRCdGVFpEbmEihh8uGWxlJARAhgAQAAtHACHxhwAJMRIbmdjhhpsYoRGUkpm4QDQEywtIAwv+W0MPCgV3AVLM5FzLBACG4QRhBWPGQYJmEBxiRUZ4SIimcHBiAGDQAwEDaSKBgoQhgCYUWEqCDjsyQ//viZOKP/ullQIP92zAAAA0gAAABOz2TBA/3UQAAADSAAAAEYQwMVImpK2GbjYkBCRmZmPCSe0GV7qVuGI1BHBiN4eeaP/X2mfRlUh/j0ysZxuL3GFlCmJoAY2KYE4CDGGTF95qj4bmMheJxfZkeZOML7mDkA5ZgZoOKZHKUImFvgYZhWwIoYB+A5mDeFfpj3oT8bsaMcmQGaVlGaoj0ZdPAYiJEZ9W4ZTz6YRIwYUpQZUFwYhEiYHHWY/FIaBIAY8gwYDDgYzAmJGGZdAwYDlgaABeY0jCYbAsY5gEFgYMAgBMWSRMUQ8BwRlqwgIzCkISYMCER1mAJPkWo1QIBZDVlQACBS8EhAKSMChDwSDZpRRhDhqBTBgcqAqo0B0BAzKp0GDlCE0CAQAQjDxZQTAQoPAUIOBmPbA5sZpeatubQkYA8BwAlMCy8kMAw2ZawIcZ3ww+kNofM3EDMBpxAYHBTECEUHjxCxAGAJsyJsWCGCOkRoIaiJoZ1CFSooFOOQXYYkiCBiMSNwaaIjAXGpOmGBi2QWKpImQVmrhnxNBy4yUUUCqkjAhDFrTJOjKswkIYpCISRnwhmGZlEZgpBqhRkkyD6L5lQQYdM4fQXMamEZExZUxRUWNCxcOQmiHCWAzQUIZj2MFQRCHC7YtkYQeOATcomDGDKGRFmGDjpMQKwSHBQExowxSk0AgWKtC5heM///T/pTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMI6DMDB8SBsyF6mmPrmJwz57jA0wj8J7MFUFHDT5BjowIkJ7MZMJzDSVwCswVoUDNZOHPjAwwCYwJ8CvAgP+YzoLcGB3gwZgxwA0YFkAIGEBArQcVTGBuAthhEIGsYAkA5mBdgF5gU4C4YHsAsmA8gphhZICwYBgAbnQPh+cibuBmnvYwSGJ35kBMZcJgpoMlQzI28rbzsA8y5EAOgYoSCJIQiMVTDBwcuOYCZAgoMHFjLDYBHIWEwhLAoeGJgKMgSNkIUOASHMvAWsMxDxITVTQNBBImMt0hDwKMmChoFQzACR0hwVFIS9XwX1GkjJpNRIEjl8zEQLZmHKRZpsmIGg8WVMAQDIAUVGcM9MomBS7KfZcoEEGieKFmKSXVbcVDMo4vOpcjqODeBQAIa6QsmIQTBICMVfiRai5nFqKDzw6Uu4aZHWAcUDNHxCAAS/DACLMMswny6CQo9SPKGQGZYi/xZBIoeBRZQDGsUhk1ImYWyTKDhggFdshCKISAE7jwS8DQBosSDAhB8MgIYaMMdUywFmCxKh4wP/74mTMjP18Y0KD+81AAAANIAAAATtxkwZP81MAAAA0gAAABIJVEQpaZp7qF3ajYUDB4XIWCvq///6QWEIxCYDYMMGCvDPdr8s74tCeNCOS5zAlARAwgENvNkvSrzF1QucxDBZeNOJEwDAnQf41B0VpMBKBTjCEQXQwJkFEMrFDbTCCwbEwZsCmMG7CNjBAiAoxGEC0MDXAMTFFQTAwhEA/MDzAAjfbxHj6caWZ5EcmQmIYWUhxlNA4WAlImtjCaNHRosXmEh+Z5GRnUHAoUqqGoCqYYDpodcGjmCZrGBgItGHSaZcDhgIcjALMfmABHEwmIg4rGUQwAh2Y6BZhQEmPQMGNYGAwyiJjDCKphBUOqfJQoZLM3YC7U2AJDc0lMAyjFwTiOzRIQF0VVUMDIwGdGLKOyAuAWBBC8xTMEtAAkDAwNIgk4agolqFnxhZJlQpiShkCJxW5ojR5pRfweJSwzI4zLM2q0KpCYGwBHQ0x41qZdCXYYnAQVsYMSmCFLBAwCYkwp0aAsWjNQ/MyJT8MWJZ8Igg8zAh4ChX4KChiSY86MyENUvM8SB0syRcwYIHFwUgA1AQoFMwQHCpUHHgSZSXLegogBRplhCUQOfDRcxBAHAjEDwhqahACPZhRygZxjK1DGjDBQQUTEkQYROizNAcFhQEZnXPGINnULGUPoaCJqUER4UZAEaA6pK/y5PIo0f9tDkxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVYBAygZg5ACeYNuCNmVMnDBoH6YEaZiNwmDLgLZgLQQ+Y0ENkGB0AZpgDpJYYi+AFDIA4YroClmBjgOxgSIDUYEyAGmH6AT5gfoC4YFoAVGAaAE4wGfGBZALgErTK74yRBM/XSYYNjGDIEE5A2MQQTH18zA6McITKkE0pFB4Aa/AaEYcFQatUY8QFERADMqENBBPJdDqNGBB5csFEQcWMWVBgYy7gKEB0UHKjIEDMmjGnUjxKEIgYEDEg9L5HEHOBhKZNWOj4bHAryjowIlVEYpAr1R4qFi9JhzYhIpKggaakgDjKYJjRhlUQoslbJwhCAlqHwyJNcSGnBhkxgS6rgoCFBYsgGkhg7iWyA1iUXCEYYSMWKVYu8MEqdswHgwFIzo6lRnA0gyIZCQOBU9AigaEOBQTK09SAUsoDEwUMM6aUbT1AAH/++JkooD9OWTFs/vUKgAADSAAAAEx6Y8GD/MwwAAANIAAAAQGjDHgBGzMmAWEARwxIZK52gYCGhqCJPRFdWUoKpZCgqA0iwYABQ0eKmKRO+r0IXp+BcwoIIgKMxjjwCBIyqoiAWboEY1gNck6i9ZgFBxEZiBBiCQcDMqXAyAxACWSuBLuhBjBwYiYPsLzHYeZ5p8aR26faaFGGTAgKJg3AucZIKxvmHEhWZg3DW0YQqHrGCBg3Zm3ZdIYOQApmBAg0xgSIQ4ZF+JXGM+BNhgVYHGYKICOGEhhwxiLAFQBvOdY0ppQqmxXUZZCxoVCGfR0aAT5goPmG0mcgKJKHDEYmAo3OI2Q0GFWEgIWGTz8GJcwATDHYMMckYW9M5FYoMZN48EhK+UcMS1D0IcMEs0kS4pyLp8HDIqc31i3xgUnUXcApxVNAEpIQn2mCaTZMAiCRCtxdl6mnpfDRRI4Dky6zERCcFi2tKSbkaMQZOYJkPkxIOKMQFbpuUgYolQKMxCaGOjKQIAdcLqBBY8K+hmgVCQlMMtLJGCl6RCULTAkyH1hzaNQnmMGtNEEgHB0JfgQjIXFyiIosEJ9RWBi8rFlbkKk0hh0WFS4Q3U4hhMGFGMSlwrYUFFU1A1J9bi+mTjo4QijeFgFBgICsxQ9Y9SMLKARUfZck4sZHmVigx1qMuLnN8ABWTopN4YRMCP9L6Ut9v///epMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqow9gKOMBND2DkYdmQ1Lf1tNIHUpjDYw5sOAQTMaWeYxukBRMOLZdDLigw4wPcQONVGQXzDOQCQEAsxgiYMKY6gQDmLigrZg/4G8IAWcwbsIzMR8ACDAGAgowOQA+QaMAIAmjAaALkMBUDAKQLkwWMANMA0AJzaLTOqTlbBhmY9gaJEc6YY8SIholKNSDHKQFgmKFGRsmfEgZEAAxjB4K1gkQWRMqZVYpiqoOMlykggYckxCzBXO0Nnz0p8tvhfZ2jnDyi49GhRAzuGYkZQkkcMGpmmCWWQQChIFBTCTcR9Bwb9qykAaVzzJAgahYAt8PAsXS7BwgJZDEmTMHMIwQBNlEhEc2RIpAYRjKApy03ThjSDIRTBCN822FSEgTTBXoFXzlDDl01C/5gmpXtfUse50FEhgAiQSipoAS5a0vozjgUvES/4FBLjMWawSntCTLRUVYtdi8BF/JUiODjEwEn1ZDOAbWJM//viZLMM/DxkwYP6zSAAAA0gAAABOgWTCk/3UUAAADSAAAAETApYYKgHfRkIYmWxTIMI4WJXKFwQydFBsZWDAD7ORlX6kD4BME8BsTBMwb43iCapOTBDQDniBqIx34MsMFBAsDN5DLUWGFTBGkWIyZQE5MBBBaDRo0C4wYkEbMDUCYjAhAbkwXEocMKQAtjBXgh4wCcHZMDDGqTCWgN81Db4zHGMxHPc0FMQ1mFswXFAwlQc4XJ4ycGcyRA8xNIIw1IswFBYyCIgwpC0wjDUKBOYDAmY4gMYaBYEC0aIicDjgChTkRTBgmGBQHmDoMmLwHgYSzF4LCwGoiF0yrCoxYBow9IMMKwxFCUmGowsDgVGUwaGcwlJgw0C8yHIE1QYxc8JnEcE7acSABiU4Ok+MY60Ax7MQJDc3zGpAzUnaF0pChCg0IPHgEDiUawmLOCYkBJDHDCAGZ0CcyIZMSBirXzGEDIjy9goDMWbNEDUFMcgUFIRRiAQOAAYUUZC75ZoQFzJAzMlTCPFB3cMIFVsQ0MyBAAMHPgSDARgOWiTIHCAjeWZMYCDB5gQZIKLmpcI2t8IQIiCpRDzEMDpiPLSBiMhEmEII8Bxt3C+QyCDAAUFkxMaNLAtYEAsMDl7DAAoPW2sI1BDiJCUNQwAreYkMLAQwaQHSa2QhBaqaMMYIaATjXSLOmqKgjCiASqJTxqCz+vfFKmFTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQEVcwkIEbMFBCmzhV13I60RjuOskKoTD3g5owCwCkM6pLSjCdQBgwRE1MM2qAGzB4QaU02BHPMD/AFTCegb4wc4F/MQ3IkzAIgKUwEQBLMGBBuTAnBvcwgsC6NeMw/GxznqBNJpkye1jh4lM6uk0xTjHCcMYLUyGLTVo6KBYZQSBkxPDRQM4DkRBMx+M0hwIXDZJAFl6YQYoNFIkbDEYVEAhJg4YCCpkwSl/hEJzIrxUocBIUZDAJTDlTFoDTCQ5WYAUSTAYjSoLPqNGEABgtElKQmWGJggqERDjKGDLkhqMYk+EXQM9JRZtGpo3pxWRqkIASByIzZIyigxBg0hM4JEiTGIRGOMlDc2bYOYmABmtAGgMGBODAxXaBy0ASZJiZhjxggLXjEGgIOM6RNWCGSEnFR5q05lSokVeYvOiIFohkhw4CCIhjnBrS5i6wCYo4AQ6aA6EADcgzCnQwGFSSmI8TFBRliQBEBAwOEmfQmBNpeA0IWeGCYKJAauBSwIWmUAiRYkHoTgoBBVgcJgIVDr6hUqXrMKKMNkNCtNsZNnBMa9NKRDRRlyRjAROPN4LQXNihPUXNW3Iv/74mTcjv5tZMKT/NRAAAANIAAAATuZlQQv91EAAAA0gAAABHQwFOGjC6kzyE1Pw5Fdv0MGS2XeREwE4K6MHUFzj2IFq0xPYM8MntUaTBmg0kwUYKnNi+GCTAFgMswdE3qNU+B2DA5QzA2/liCMAfBDhEAVGCBBbBlHBUQYgaB3mDVgdhggAZOYSoMimMZgc5ubGZxSshgOTZi6ZZhAJpuMD5kIWJ/QVBqcQBgkMxrQDBkQF5l4J5gsDxgyZ4EEwyADEIB0uWDBFMHjzAAOGCoGAlXTEEODBAaDB0FTCIfASMhhUBpgoLIKEQxdAkDujZZzY3ycunSaluYdyYlOTSjFCzOQTDnTNKTHtTKKTRgzqqi8phXRkyAHRG9GGWDmJuBdSTZzZDTVAxmCc84cDSYsQVmTGYTTMBUmKczNFwUlMFAHmQRYApMO5GOJiB2ZVYLCTFAACSNusV0JYxpUNEx0cgMKC46TM4WNGvMQVFvJgwhMkGCyQJpc5kigsAM6cNkbMQWGAgWNBUiYJEHOwqoQDrcNCFMcRMuYAIg14lUg1YZoIS4dOMNgNcJMk+IAoBDmUAihI2AIGAzJiYQKzzSEQIDMjOVWGBpZBmhjz5RsMKPLPBAwx5Ytmb5oZgoNJwChFWZVEmUUGfOgZEgqj0HLDTKkOJoUQEEG2MGdDDy0z5Awwo0oA268yBwMFsSllDYvu//9CkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMDxCLjCowvg8E9f8PuxbCj44yH0wsMF4MNgAEzYMQwEwE0GSMLJAHDUCgNUwTMFyNNoSqzCSwMEwM8INMGQBXDKPwc0xBQJoMCQAVDB5wb4wnYKAMZJAlAcFOmHOAWxgFgD6YAEAqA4HmoD2ZIrByjfnLjGYwLBhpPmWh+DgsZKBpohZGiT0YMQQWI5k0BGCSAYjK5iYUGKxEKJUIvZhoIgEKmBEoZUAwkbAdLDCRRCCCAkxmFBrSpjFxkBBiWgBcGhNGOZhUaKQTNIbRmAYhQg8mDkxAxFh5iRpiyQGbgZeDnwCBmFVGQckU0CnRogURRbMKhzdGRgCCp5mSZqBJQGC6oOVF5TMjA4gZEkDUIy6MOhNiJDJBky48DADhiQtLXyYEkn2DiRkBQ6HMQWAToWGGYFgw0aMAZFAk4YFdLTHFQwYRIUQDTGzckgabjIFOmPSJBpDhEkz8VCWLAA78Igxm0YkMMcUMyMIRBlDg9DBxc2AUHZjDBVKgwSYEOZA4b00HRDHhRCJCwaFGSJmFipmgZqEHyL/++Jky4T+eWPBg/zUsAAADSAAAAE3MY8Oz/NRCAAANIAAAARSDEIKgAEWW5CoMQiRYADUhgWxjxw0Ya0BgJnWZlSpKRQuS8EBc0zUeYKaDVRkagNHJq4Lf///90ACquYLqC2BwWEbxEo9m56BQxtGo2YYXmCamBwhFRmSQ3UYIgBkGDQCrJlygNKYE6DsGMalThgOoGoYCUBgmATAW5iXweKYMyC2kgAeYEmAPmBsiKxheIBwaIUBwB5hgvIiuZuLJNPwCSjubPAxKM2jgmJ4WKJhcOhUKGJS6ZaDRh0QFgRtCEYGFCCAmKYOAoWFpqcMBBEVIDQGPAwxGOggYspEAXRXM8TEIgyYkOBGFOkowsGAqlNCXEjRgSzalE4BXTAlQYAEaARiUABqTzemrDorgqNMmGHhUMFSpmmYiKAKWYMUCEhmlI8RRDDDZlxJfUwwg1o8ssAjQQlMMGEAwBQTb2SRqZMEZ4QgDcABR0mAcJMOKMWBGBAoKASxlQqHBSpI8Rii/TIBG9FgQ1ZMAIQhJhoVNAEMFxpiQquhETAXcoHlU6OAH8ChsxgsAhChwJHhksZQmYwWCj4NCmAVAYQAE6HcFBwMECoMLEASCGB6E0aSGHQiEYQDAgkPIHGMUUTBFVRkTzng1wIFtGGWDAsAIhCiZEUUAO0DyBmhwWgmkwAk8CiogHvQYxMYACMlAwYrcy+KKK1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxI8OEMCzDmTw74Cw2Q7htNv8VUCEN7MBXCUjR1zkMwGcGAMH/P0zSrgP4wSoVXMKpRcTBqAFkwMECJMBqBXDE4SOwwN0GiKwIIwOoDUMG0I/DApAHkwcsDcMMFAnTBEgNUwCMD8N3g41YvjV9DMInQwKYTi4vMni80AeTG5UMWkA3FGhYhmMg2ZWFgZSwASTIRONgDAw4IzA4/OWicxqDjGYaNOkErFpiAbg4bmBAUGI5PQdGhZ4TKjUrXbHQgROBTADnAdXBhVwkcjIunrNMxHmJd1r5iTYYWM+mMobGjQVDiEYClxhAo6fMwIMiTGFgQ3DIACdCxNnhrwojJmKCAIoDgYqgSvIUIMCCNQaAoNVDagDKuSqoVUNiICpUlEmiEmJXhRCXhMwDAzQ3w4vKYwcOizYhytgMggoQMMPZSX6MoSEpRpRBdEwQY0qkYHAgcWaKGAoFALkwZoxawDEx5uRAyIWLHAIODiqNASpFkyCYzgYqEAgUZMOpUYEcJDTXF0Bpqw5lAIAIGYCjoMQAChcAohUCiR4LiCAYMhwohIpoiFoDSUMCmbLz//viZNWM/mJjwYP81LAAAA0gAAABOf2RDE/zUUAAADSAAAAEAjBGVBB4ILCIqNFQgYYEYZogaooBnSGTqNmir2CY3//6wfpIwrMJ9MNUBWTf6B5s5UsJROWgB/jGDgYUwW8HbMeKNsjAyAGswW0x1MxUCHTATgmYyWIwQMGuA8DA6wGMwNIAjMC9HdzCXABAwIgBOMFtAujAoRKQwmwEoM6bc7HcDEbdMhqA1sYzMj1MtHI94hTCKQNPm068bDJIzNbFk0qGyMxmFjqZJJhqgomPR8h1AJOAglFSMYoOBuMzmWB+TE0IQAOTxgENhYZGKBEFgQY0KAkajXhNC4SNFJ0y+YjHrNMIkYxkrDERpDjCZfTJjuhmbpsASCMBkDuqDXmDCTTpljHgjTrQiqFX5uzIOGhcEac+YREDBpFQGQoZZNUiCogziYxqwBJ0hzejxQgLMjLE1xCwYFBzAKDQjQvGMHFMUUNaJBiQ3hEw5A2hEKAAs7NCMEBsgElUkOFASBMIENOIMgOMCKUwFkYEXGWIQhIIHEShOPExCPHiwNAAQYACAiLAAUAmQBMK9AwAx5gRDwhKmKIzZVJl+DNCSEKIQaOpCBRvVeKh12lUWpSUMwFADBYNDl0zPho8AAq9TWPiZmRHwAICGxkBAQUFRo8KIkZhygKRCQouabRyUfgseMGnBVIiMmJBGqFtJgZKh+k9IO6qTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMGSHITDxwmQ+U1APOmw4uju4kL8xiQOMMNTCwzD/VK0xKwH6MHVZhTL9g2swb0H/NUtUzzBXAlMwWsGaMDSCLjEoCTQxoENrMCSCATBkAFYwBkOYMZ6AVzGU1T9A/jABWzRU6gNvJlahhicJxgjJpgMaRpwKBnCeZj8eBnsKpm+gpi8P5nuVhlMiRgQjph6LxlYQRicHJnSMpiELBhgdAKO4xdG8yKDYwGDgGhqYmBeAARBADgACTVoAGYNnZORcN41MuBNzUDFYDGmHJGQYBUUZGWgeJiTMnTkhB60ZBADCxnWIVHnDNGdnmApA5ua5WSOwu8MQuDh6iJhEgCDmOVG1AFY4LLUfwcnMIhERoadGfIAQKr0gMoqm4Xg50PQTAEEmTLPzeAjNpRQYYE0aU+ZhMJVAENNOLNnYAwAzoAyKcOskVVLIDPDLDgwywMCvzRFxY+I2ZlRAcnIDKLxeMCkAYZasmGYwkGYjQpDStDYJBwQZoWa00aQOY8SbYQYEKBGQCJGNJAwwWtJAwf/74mTGj/7CY8ED/dRAAAANIAAAATTNkwQP9zFAAAA0gAAABJPMuLMQNCwoz3U8gcxKE1RNUj3BgAEtmQhFIeRlwgUNEha8IDaEg8MI0viz6FQLJmRdg6ebIwZEKBQQMDiRQBMwxYqeGLRYx93+6sw/cDeMHPF7T68lKQ7sYFXOhlSaTDKQtAwoYW/MqnYejE3AsQws1cBMLyHhzBJBNg25hYuIQA8wIUHzMCuAYzHVxVUwzQTSMB1BWTAOAJIwusT1MasAgTCwtgKBJiAFxkqK5lwWJjsM5hWZJ/SVpjQMZlSiRjuKpgESBlWEpj0J5hoOphGLBgsLZAKhhOPZkECZjGZgkjQNDowTE4xvBAmGwwRBgIGcuEsxdwOBtH4CBWYEAYAA1Aw+GKIZCEDQMDoUBEUAN1hQB1ADNUBw4pEebxvcpVipxynAQ8AHpdhCAjTAghYGCIzm/CPQqShqCTgqIAQFAEh7KYwVIWGBwRquF4kKVmFwS3BVRXcje0sWAVVGmSIs1B0PhQ8xDjnMARwAPL7BALB1gQAWDgUwzBiAyhxoIlGEKXdYI8iXapnAfVPpupniSlsYYE46xwKEIg1kl3AuGJAhSU+FRk0swYYzWAEMnOnAkClUlzFwUEhAIxU8WCsMYkIxouKAOsj+4yWRfl5GioJRESTKwtmbiJCAY4DAgVCCVslpTUZKBWnr1mpba///RUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMNfD/jB0BCM84kKDPsXOsT8TxVQxDUEaMK4APjQiEWcxdYNgMHiRRTL7xgQwlEMaNdrSCQMFJmACgYpgP4J6YuQIOGC0hVpgbIBAYJABpmBnD+JhPAJ2YAoCJGBjgrJKAImAWAKRgFYHuYLAAqGAtAm5hoIMIEAHpx9KMIwG1TCTIxZAMrGDUIoVeRAJAVkMWFlSmTsZj48asTGXsRjxkbEHGfFggCDBQkwIrMJFzfigygEbguSDfzpmHsTMOVKEKpEq7UAbgusMzLtpcCyYhHaG/ojhJzy4aab9moQMsk3xEQnQBmzvjYfDhqugUMTHRkC0gPwLqEMAtaa7LHwMuIhDCnLlMpT6WEUfHQzVHTtFki45gshxZMFIWPGGSreBAT1rUxTrIDBiIHammKkfFQaWKrkRZctMgpBMM8EohqYECJC1PjKBpqjWbFIjFzDjDA24FlyQMJPL9CxqFBndAJwWsbqBgQ6MsCqDMYYartRl1wUMPIAldI4BgF//++Jkvgz9D2RBg/vNIAAADSAAAAE5dY8KT/NRCAAANIAAAATEz2DOW5w0KthiAYg0pnRgAK2s1XfDD+AwZgrT43H43mEvX///0AOg5gUwHkYT0DCHIlADhn4QPQaRuWEGESguJgjYBuZ0eM0GCLAG5glRpaY66AVmEvANpm+hr8YNWBVmBbAUJgbwDkYkSImGCOgfBgEoGwYEAAcmBnCuJgwIH6MIA/yNzXI2MBm4zS2Tg75EiUbwDJkoBQcaiLhk0GGawMYtIZj0VmC0AYAABn86GTxwYTCY4ezKodABJMJsIDJIxKGAEIgw4mFASQGMFCEwIOTEAnM0nBo02QczBs0TUakGKIkoAzBEHgQFjBqozbMzVcA1jBdjkmw8cZwCYAsJLDUdQAINERNYCMWxIhAWQiEoYAqYR+DApnSpoRhjQ4IBGUYlZUkGFkjRAjNiTbCjLHVTFAgEEVwmXXGREFzRAHUqBosqGlBQMoMEZjYXBIkAw81UeOpbgqwZcwBCZmgYOZAUAZgRRmXFmADDBIxSNRQIXrREAQo5BiELrwEvTjFRCdBkygKAGZDlQSFQA4ZAQMFBFFAw+ZZyCRRgShoxC0iQYYVKWXIBohJGGEINoPxMIHlyTFBgFHOsbNUzNmmNWkBGEBbQhKYyMaFUHOhy6YoSB042UM4IOgbNWHLMiRU2yA06ECmTbpQdun2pNgYsOVVAADAFUYwdMKxMBfAQDlDyh06ep/LOOCMhjBqAOMwNQBWNF4DRzB2AMQwv4v3MwFBWTAxAEgzIUxJEgdUwZ0FnMBwBmzEABpkwV4CuMAkAsjBMQQ0wTAJ/MS1A4TAEApUwh0I4MEBASzBLQJwy4bTibKMmxw44uzG4dMAnIMSBhIJJhmGAoZpNBlE/mO1MYwA6vzCgYMcJsdDRhcXmKVkCkQYHDghExpMDiQ3CgfM0AoyQLS2Ry5ooTISpgpRgl5A7MahFgYPIAgaPTJEBKKLTJTSuDlBSQUJSSgsBiJm1YOyGhJpNGJTGzWGLVCAoYJ8bMAbUe2MxQMgQDR4xrgDDVNgC9Cikxgc2z9JAGkzDkS3A0RGRZjxRkhotAMUGNMiDpDhiAGSBTXEUEwKcGBGBQUAiLJUMgQIGigIMmLPJNmJFjS4aKhVONNWBBUeNFi5BhBhn1Rn1RiBK4iyRKTDDJYGG9MGZFGAKDwYy4sFGzXDgwsYVaaMeRCSRmcMIJajEkDCJS5pkhBhCcEmIAhC0xwYGpQaNV6zGICUQ3hMBqjGljDghATMAuMYlMqRIcps4hCLApA3yQ0cwvTJQKYAUACgDJwXvMMVZZFlH1P7zAF+////Tg+L56pHOON+9hsZ4u2o5dGcPGEaUIRR1DfCOqJtZiNSLcMnu+sRnGXsJ//vgZP+AznhkQkv81LLtMEUSJwb4epWPAg/zUsHFIVkAAPaonxQms5u288+1KTGnuWZyV2qS9nT3Iy9jl070LoZGsdDoW1COlcSZhQYSYJDVCTGB1DQAApJRIAUHi7IkoWqNjE1g7gKOX8bvEHbpIvA8sl8oxlElg+KXo3MTneZ17VPhutGKGR0n9xtxCilda9G5M4b3rkeSJs7eJ8mWNLg9wHEbm0+GH8lUIf96GmOnCpy/P2X/eBtHDh6Wydx4x4dpTa2zx+fRMyaQepWnB5iiZUk5JpmIHpmREpiED02IGKYgoxh4wyWeE5QYHmJqRp9zQQ2ZQEEhmGRhthsMpB+YNwCDmGcFh5qD4JwYHiAJGaeFlBhuoIsYUGCTGB8gVxhC5cQYacDRmAxAIJgJQFQYY8KrGLagFBgiQKOYW0CfGAWgLpgGoFcavQR0wsGLYYdpaZr0vGEzCV8kiVRg4NgYTmxleCCcZjLBkU1GKyWYNEQhfZkASDIXMdoAx4NwcIDAxSMaGExOGTHy0MnHoCCZCw154RihCNNAWGAhmWpjGYLFBAYS5GqMqCmaIgM8Y8+c94cpqcAeAmAJmAECVrzTCAdaM0NN+5LSoZmr4GQJlQ0AjJg5gKfEhYyasOFgQQIAJNQBochDrDAIUYcspFKcqmhkKa1KFKBASJoJmAw0oCLp1yY0lNEYM6cHC4cXMIBaaygwRElHjxEOrGgBKSIoBhxhiCACpBB0EEAoXNCJHB6CqHAqkRAXNuGAUU0AkBMRE0Mm4C4MEoAggaZmZAyYQUXCMAONCIMuhMPDNC9MWXDVANlmCBmcLBA0GlQu/GmAkNhgxywQlTBiTKxjlPTDtDHgw5mZBKZQeAoYAICNegPLThdsWEAFHmaHgqcPSAgGEPS4okqNoHEaiMs3feXNb7P/q86////l78vy//a+VarJILghI+QEQtGpUsH+OpnFaYmfJ+lCnmRyTG/1VHVkPG3jdGixam+xrGsbsmb5UGbgGmfp8mA57GqCXGdhlGTAKGPA8GDADoIlhW2is8EuLXamUd8WQyoXvvFaFimZUyZ/6xQWMLaBrjC5h2w5m+zfNBZ0pjRsEjswRoQAMHFFVzRcC3YwMAC0MP6F9DSMwkEwOoIhMxrBFzCjgL0wKYBHMEuAfzB+SHUwsMA4MEEA4zBUQZ4wDQlYMItA7DH4YzxwjwKHJg4PhhcQpv4MZjiWp1OhBgeT5jwXpl6KBiiFZgqDBiULJnijgOTMwJCsxeBQwXDcwTEMEmuBj4IQIMZQgDGUMQAGMAQmCAEMBxeMMQeMQAIVhARIIDQMCBXkIRgleJBkhBGFMkWFlwRXDiwhRGROAH0hUbQIZYmKNANqVMkkMljbxhMCYJ0YwWZRgZlU//viZHaI7oVjwQP91EJzSHaSAt3yNz2TCQ/zUQGEINpAAHo4CSI8wPCcNYlBQgyoQ2hEzjkxoIKHTPPUHAuOIBYQKDBgVGhY+c8WbwgArhgSpiSZhxhUFGIFBcybckYw+AthvVQMCGLWA4gKAkNjCBkSBieaIfdR5NWkRnMU3AzsVOv+XVCs0wrkomA4MVBZAXQHCMEZAIZ5aZkAJLQjkoITKDCmTAEBI8BippV49BKpglBgIqa5gDw5d0GIDfAzRjzGszGGgwGmWYVMCTBhC5MGNPPGDCBRb8t2FVJlzgQ5HiYGjoBAscC6YxJEBIxqspuZEUYMKYAGaoeVpTFKDFiAwo7TNcCQAIV//1qsmXCDi5AbfAXA2BgrAeBjgkYBy7LsBoUNgBhQToBxu6ABoWMYBr0sABtGlCBsTNyBocQGBpaPSBqOScZYqgY8QeZWrOfVhoYPMuZ6sMffLgYGEAYYjmYbgcGAStZ3YtZ6TG+LCzrP8I70qbs+LAYMJg64OoYIWDjmz2MCRy9xmsbiiO0mItgwpYBXDIJzIMwKUC8MLkKgjLkwhowAYHAMs8DoTA3QN8wMgB1MELAuDCOhQgwTYFmMCDAZzA8AFgwg8TEMLiAjj4aAN5HQFI42QcTLoPNApcyC7yBpGFxyYCJxtoqCMZGExCLJI5wRzVQiAA1HgCYXBxh8EggdmvjAYIEBg9SgYsmFQ+JEQdEhWDiYiI5BBNBSBM+hAKdOgwyY7CoolAkQYhUEKlYzRHwNFQ6gasJPDSCh4UalGBiRmCiYYUdG0CDS8CEzbjA4kqNKNaJgiZFQLjGLAICAxyDQRlBBlSoEXmDAkSAqniIsYcYlyTB1FgXtBSdjhfBFZ/ga5DARfkHCTQDFCjBnB4uYkCXXLYr8aOLFFNVKC/wKQA4KDRoQmQ7AxqWtMsLKiUvwFhhE8DihphMWFSKIIqHIDSAIvAksATZixoUDCEaCAaB5jS4VCixAwCMRAB5GYNSJMQAHMKMCKoKJImGCUhiQxAkHJm/bmYIsVjzCAAqCMCVM2eGmw0qAiMZAAkiLWzGkQyAKjEn2KCAUBUw9AXUDpIJA0baWN2/3rOktDIBBgAgLGAMB0YTZwBvVKpmRKa2a/4gxheksGEUqIZYyyBnYMAmZsWsbXBJpjbE/GIUWma1ZIJiVCamV8akYIAZBo4JRGO2wMazA0Jg4BcGBMAgCgEXvnQ5/v/+xMEVClTCPgVk0YE/pNUtRzzgQRvIw7EGfMCaBUzAFC1QwDsCxMD3LgDGBwGcwCwA3MxJEJjAYwFMwHkAjMJClPMe1MClHGhrMOReNG3dPggZMHC6NFx5MNQoEINgUKDM0fjAItwVBBiYE62TAgCQoJZgoGIMA4yjFUweEcwyAM//74mQ/iOzpZMKD/ctgXMhW8wA88C/xjRLPbzEJj6FYRADuOBLBYueVggYOhGYwB+YPAgYEFCYBhsDg6EAXmFobhgTiwFmAAFmBQLFQH0A5cwFOgYUy0EuAkEIVTtRhOlYwBZWnaMGgXFP4IIRcNIbYGZMINgi8jXBMkkUSMptQMAGk4SsEmBFqPwJRMEAwWm2BAagA8QnMDUhJ8rUNGA89TAEQBikZAEDVzPQGS4CMcJIhvAqGKGCuwsGHACNoEimQAMyJXF+TfpALiARKcxgFMEbwhQRnm4OASzG0AQKYy4woUYxZhniwIBBaOvUHdjSiHQWcA1hCGqiFziJwMqlydxNUuRPYCKrTAIwYm2JG4IOhkVOHBUKkLSKc0wnFWqIYCINHUeiVVMB1S8UJQTITAg51zEbNYEswSnmCxB0j5q8AAGBt//5/+GdJTwwSBExQDTFoFNtxAVZpoYQmoqed2QZ0vpHEwsZqiJtgIGHXUa1GYYiDQExOsNMqJ41yGDV0/DQSYqERjsMLqXtFaay/8UQKbFCuV1bEvaKbLNYgalYyVRuTDNBeN2Ciw7XRzzSTTAMI4KEwcgUjOyVTMLQCwwbXMjLnFkMFEHw4OibwEBSWuAIAxktCdGKGAKYCoFZgXAimF6VGYqALpgTod2uGOjhgQm0M0AOMOKjJDN3BAVBZBRaGktQwYPg4cMhHC1Zc4xYOEIiCmUiCRE1lw0EwKVQqNgYaGg8lCUyB4uLWg0sHEjiAQyYbUwapoCDBx5qumJAAQhMQYBBqRiAsYNN8w0VBgCEWeUCNQ4xdEBQ8uODGaFCW3LQrrHQhYQQzj4YjGDE6EOLL4tsXkUSAgYhbMkAIiEBhCeUVmAIcKaHJY4BDFAxgAtExMcK4QBAtIMZTxQDJAC2CjrCBlQ4BliBQc0Qgx8gHQJCooCBHn0JhCCZwLaloIeTblxIOrZGkExdEesTXU2C4iNYQsVAXxVGEAO+Omg4l6gK6uRylov0Cj0dBYYzWhcUwQQUQjQChwqObK5M8XFEbi4x08vEBkzGAUmm4NGKEE0SGLQaIksOL/////yF/////8TF9L2W0zgrBFQJMUAxUiMsIQKPCA3MWLDOx0OvDn5AzitMuZAs1GXq5swqYWADoIZeiBzWao2mXCA0QkACng/cIn6IHGZEqdBUFdhIsDP8RL/lgZ6v//+eVAEABhXIU4YPqGcGQyrTptcBzWaoYDfGEdAKpgxoCqZF2NpGCygZZg/JPIYj0BcGCIgrRmuYeAYC8ARGA1AMBjSaR5OvpmoaRhCJJgyUBpN0JiCC4BBoyKMUy6DEwdCMwuB0y0CEwjG4iBkiFsVhHvZnEThzY4IQy1UX9MrMQDGQR+XQyVEjpjipjUICDoJgUAMX/++JkSQj9PWPCK/3TMAAADSAAAAE34Y8Er/dNCAAANIAAAASFMAkMSEOMAIB4gRCUkMUiAoaZwasASADJERU+oyMBQFUECcDGAIKGQAKNgLWNCEBoaMMAJMIQGgJhywArAUeIlAGugo6DgIMCDwYaCDgYwYJD4CCihczsqFgMdLPEBZGchKBgARrAMsOcMXggkM41GhZMYKqgQhDZCFTmgElpBAKBTg0bMzKoyBIIDmQEGHLDh8Cj15jpgOQAgoFRIFABdKZYoX9egMCA52hxMUZBxAaQgBiASzcVsioUwBYzAUeCF+UxgMlNjBJgimZoSRYSITwwGTHFjEVYKjkoEOoQPNMEDGiQxd1QRbCLwoLQmGUFGFRmtBighKExYQWFLmWFEpqmC8U04KQSwItYAEQVCFgytM9W4SUDBURI4whAA/MLoVVjGuzHs1SoYNMIQAVDA8gbUyZgN7MCHAljB7Rhow+wDxMCbDKzKLAtMwNICBIAOIxxSM/kLkyKTkxPD8wbHw0uZwbTcwAE80eAYiFQxVDgwgCcxXAEKiiYmnoYciWYJAMZPgqGESYvDOYGgeYHhAYGmLLh1uGGjJGQMJKIJpgJhZBu2xlz4MQhVGcpKcJ4HkUxjokkvEzwQcDqpgRJgkBsxZqk5jzw+MMAKNeKNRxKHA04GFJ7oItCEmhiT5l3RouBKoMwtMHUcA2sUOPmWTmTLGEPA8uZMabhGBjYbLMWICF4BNmpKoEjsDjWGjGmDHv0qgKnNGvCkNbBmBBqHYMAiQQzrM2AMwQcWojRkIjmKimIAjiAyAUyokBeWGCjMChw4gOQTZqQF1Ag8yQAsL1IG6bmGUImiTofVGJEgkWb42hYYU4pkbc819CcIAIVHGkQmhNlZAipm5VGWamlPDjYtyzE3wMeTJfCxUmgj0kxKgMRAIKFAAYXBB4uQX4M2nChsRgjGEUqRxGWuMSOKzJvTBl1YlDNgDBiQVQmPMAo+W0BxsMKGKChyUwokoFP/TwJUggAAYFMA7GRsCdRjCiDuZeGfaGFniIZhvoSWFg7IyTEHKMEPBmTA/QR4wagGzMIrCYjE1RD4wNIIWMEcBnTFB3DfsujJNrzTxATMsPzBy4DX8izI8JjMYUghIDE0DyATxQqjPYaDN0bDWgCzYbsMjjHloxRGNzDBU9NhKjanA4FcPGBjPQ0HoZoQAZMOgwsBV2aqWGdLRlAUFCs2NAOgKjAwEeQyK5M7ZQc8mjrBhIYY82mAsIFQDPgQz4WEYIaMrGdDaGwlNmUGZgSGYKVmHDBn8GSHJsZAb+8mjk5uM0YujGNoxgAg7IEHhodEAyZgemdgRnRCZiHjCYc4SBdiJqkxYaMXGTKTcWLjEhQICzNyswZiH1oycEIgFCk//viZI4H/2pkv6v92zAAAA0gAAABO5WTAg/3bUAAADSAAAAERjhkYYZIKGNAQoEiwUYkDmHoZAiAEYMrCTBgo0QzNrAyU4NzQjJkswlMMANTDUEwyBMOITPhoHABmZYa0Pmqj5jQwI08zcQMWVTPmUxlwM9CxwxC4gIxwwlCBSWYCiGKthw4EEEhizYYiJm5kgBbQKHukKig4gCSCZKXGHAJhwcdWombFpp5eTTQOJzAi0GgIJWQSBAkRMiHzDiMAtBWfGNlRma4ZmPg4xMuTwsSGLmiMIFQgMvmqJbShJMAyOIykSURGbiE6AgGBAFbwkCOrunMZDYlzYuz2g+ZjvuM34T6TPLRoMwp0TxMjfUlzeLVQcwy0GcMLmDVzBdgqYweUkbMkxB7zD3gHEwXIBwMFU0M3g7NlMfPpofNVRWN5ySNtFjOAWmM7C6MPQMMMgsMyQsOFD+MAQoMbhnMFxSMI2BONx9MMhJMPgNM6g8MHzRA0VmSREmEY4GVILmbQCEx7JjAgdzexsyYcOPEgMDmYQAiKTDjIyQIM8FzQz9HcGCQVGBQiMfIzIEYlZjQkwAk4QDmVEhj5oY0jGUg5tQOZEGFBCLF5hwqnkDqMFO5hpqnuQpwQNECEPFhkoyZ+GGEgZhAeDR8whDCDMLGJmw4IxEwlUMKDAxJHS0MOTDDIekiUrDBgxWtNSPhG0hh8IA9hIMDiJFCAJtRpVRmf4w0mGmUVDVMyUhBhcIyg0AgABYQE4cNs+FFUxQeIQUFBphSCZ8SGhB4oJM1DipPcCjBgbKYmFDQOFzo0EOGjsyMaMEAC15hguLKJjYMHCYIKywKjw2FjUzgdMvAkFlcGHiJkwKYkBmHgxgY0bQLCRKQgBQBgJVWeQlZMWAgAMHVnrAAkLGoOdDKBQzQGMKGzAwtpphYM2xhwYIxAxgECDAKhhh4AhoYWLBAAYyHTTBrGrExbSptN5JlWj/pcFsyOx4mMinD5DDHyC8yf8JLN9CPfjF2ARcwuAC2MGyDJTB+gi80WQLnMIwErTA1wD0wOgHAMP2ANjFXwsY9BXhkPHOBy14z9ATBASKFWYJHxuu7mo7CZ/E5g4AEofMsYk3k/gE0DFANMaF0wsfQ0JMsLAEdGgHwcPGflRiIGClcoUAosmDhwhPDD2VCeZymCgECgshAzFQUwAGUPM9OTFgEKkZj4OLCpkAsFBYmXgcdLxMnOAsXAIZMoGBgRMMGgx8FjIkAw4rMPEjEy8tAYwBo5iMKBIaFgEwMCHlozcBFg0x5PMPJgUJAEAQ+M+SgoEgZcaKYiHBCGAFEDYZ0ReZAIGgkIQ7mNjYkXP0MjZjRSZaJkyKCpIFDQ4BF8WwmNCpiRMIQIy4qMGAwMMgUfMTJBCYmWHJjxf/74mShj/6tZMED/NuwAAANIAAAATZJjwgP908AAAA0gAAABCgLX4LQkLX2GPQsViQULERkxGaodkAwBjEwAKMFAE1DISgyciNSJjIi8INDEjlAGYeciEgBQMhmYiaGFAqaKQJggKYIDAkLCGUwwdGA1WkqCiTwGLEkygKMICAAODxoMk44HmSDZlgoYOcGUGBMZGJh4ccAwCGis08nDEEwEDEYWBhhmwVDW0MAEbbWb3bf6/90qZc0ayn9XDoR2KlFAZlmW2GQ0ApxgsYr6Y/INVGiIolphSIfIYGOBKGG2gaxgp4IgZTGL4mB2hbQQC3BUG4MHaAMzFFAMA0NFcxNDwHBsYUBEVk+YEkCYOBYrwztDQ4VFoeGoqB0EAaYkDgbfEOYOBoYKhQYMgqFw4MtAPAQqhw3mCoALTAQsmC4DGBQJiUY4Z4i+EJIDFQVKMI0MwMFi5nAi7C5i2yRQDQIqVFRZjRylIFJAAcaIKYI6AZAfQLiAgEBupEINYhChwUEDhwEhwKGHUhphaHcwg1IRVcwIEClQYDZGZUws9YrDQMIMgEMaXMGpBhAhDFUCacOcRQPCgcKMMvVUVMwUOBCyAwKEQgzBqDJoGtpiNYS8MChBBsVRhgUHSDElwUYEA1Q4xKUIpAJGY9WIzo0eBApBkwQUaZg0mHCjQFBqKGCjNA0rjBpBY+FmoWYmQFFAgYDmSKBSYhSBQhd1IFYg8BIAA6XBAYxSIIRGBGouhERAKqii2WyRwBIUBETCAUdVKTOGiEaABxiHpYEF2SgGFAIGciCWZICFTrTEeRK2Miy1wYKaFErwe/WTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxC2BwOKOeuTo/+IsxXl+tMGqC7TBvhIw0hgUVM1cbtjCRw6MwfsIKMT0BXjBPg3Ex4wxQMJHA2zATgOMwAoGmMBKA6TChQz80QEzO4tMdFk0MNxEVjDTEMrIEEIoyaRjgzeMVBEx+KjB4pM6qI7TQwc+jIYwMJEcwQRDU5FNJl4QgMLA5IQWCwNAZjkJBcBmXigJD0kChlkABUgBgdNQhIxKNzDoOHUARIMSaMIgMgeBQwySMBYxKY6QcVNuDNOLAxAwwwEiARBMmTMKOMKJBZISRmDJuWaouYkEZNuAo5MuGA4hBmBCgYSYgqFhgGpGYAgIGHBUBIdHXckDIwoYLQmzDhZwaUgX+DqoKWEK4FVyUIYJ2ZMMYsCmuZpEZZAoYDA4NGCA0UEjGCizamxi2Q8qAQ5kxi3hnWBiDo9tAhQgXmNRjooxQIO1GQGmbAGFCGjQBw5bJjghoRAiDGOimnaAAQsIOBjPvRExJBxlxYcdGBYKlmYChcLGTHrD/++Jkvo/+F2PBA/zT0AAADSAAAAE1eY0ID/NOwAAANIAAAASQqZMaiIKiC0SzDUiTPjShYDowORKfKipbpmVxlSCXJtExojAoTKp0dAF+wSqNQcBoczohZZghQhBBzkdNhwWrX4C/6v/QZGGeyH3wl0JuI1skZmIJamVehoBhPA0EYD0ChmJhKdZhIwTuYD8B7GFsgppgN4UYYqQULmB+Av5gE4IGYBKDNGF3gypg74XQbJXwKTBnsbGOBeZWOJgBjkJxMIh46mKz4hVMwFwxoHgsHDAQ7Ogl4VAgXHRhIKjwpPy4M+cJmpihJjwgK2F8awJOkhAswBBRl5JNiKq874cDSQg0YIgaISRCDKnRpGieIgYKRGTQGSDCEialYKAAMTCDhglhMTCIRkSoNQmYPGICI/iREMVCgASJGEHAEIQOBgYJPAIJBCIRiB0eY8uCQjDGXBx0wIoBMUVXABywKJzMsDKikCBiyBCFGghhyxiQBEXBQRQoxA85JtCWMDgOVAhwmhgkKNHVKTOAVkGgBA4wChKIZE3AzIxIAsDkKwC2C5AQj03UAjmGNIBYKoGCQ4qIARMiEDhYcDl3hwEZQoYQ4ClJhw5pi5ixQjNrlDiZggQ0NMuNHQyAMgBtIUaKqsya4MBmCGs/Qml/jaj1FRAAKoIKiBGLDDqVLS5QpaEAFhW9SNMuLUWUICFaLAkideYIf2VMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEjIj07rV9kONt/UTIQYfwwzwVYMJDEPDPzRFc0KtoiMLZE3jCXwPQw6oFiMCDCQTN4Sg4wE4RsMBwAfDALwL8w6UEwMYICKTUGKREIJgAWxhQM5oyCZg2IhhuGhiiWZliTpyqfJgYGZkcBRgoCJigdZoMKhh8BpIMYFFUOGg4Dwlet3aeBgIYyCNBqJJqBBjzRqzafR08AWdGBAlMo3w42hU1tM1QIe8mDAmBMmuNl0x04bxuKthGNPchAKYtibcM4YUNw6AIYZpCEpnjYUIAsSZoWIwRMKNCeBXoTDgQgAFAk0NscNKAAgYyYAwsoy4kwRcIFhnQx4QOlK9BVYMHhk01JsxAwzp42SgwIcxawDLTCgBUe15mIGUqtQWAC0zbBN4yAduhhwJnhBARHnpmQxhnpuTBlRh0BBthYcyMWKCAYGBmkdhxcxIlNwLkAMhMYSMSLMcTL+jU01IpVEwpU3YgITmQBmDAErQzBw64wghmWVl1h5uYWIZ5e//viZL4P/i5jQQP907AAAA0gAAABNPGLCA/zTwAAADSAAAAEpIaCGZehhsQBCzhqg5hWBiigYvARAQIjHCSYuZVYXeMYyMbQOoUMSuAQsGJwELCBRlDA6HMYLNGOCExgCQoQM4RQTMbbWd/b/7jJIkXc+Hw5GNfQyjDLOTBEyooEUMMTFOTKHRj40QRAZMBFCgzATwegwpsH/MFRAtDMggw8wNUHZGgewwFMIxMI7AZjELQgE3ZQBGahpkhz5M0EgMERggSmT1aZKJxq18GEiEFgGY6CJh4pE79MEhgqlwwcGDHQkKOKYaFgGEYyFzEQBHAKJF0wILyZuYcAZsIZCAYA8Z4aAGZQET0NUVDnJklpsiwAEhUuZgYjkwNZoAUmgGhUkJZzMrgAlCh1LQqpTJiSaIu0IHgwmZkCY1QyULCRoiHhiAGxoiIs6Bw8xCBGExQwCDxQSBjwKQggIhKUgDhhgAxa4OtAZ+YE2YUkZEyW/MgVRFYUVBCRQqbaaTRzNDocGjwMAgga2ImBDQgyAEaPrQCC5ZwZamoAGRJjxRYMwj8zAszIsxIkzihDRlSdRUBpblxiQQKg5erY0EiKPqzkwokaEAUOY02IBZMPcRVcFQCJMY46hABGKVYMAGFBqlnhkUDR4kEM0NMgFBwIcDCxAQE0jTDmzNAxAObGYgICUKaIXKjIQxiFEwEBgEKUCcusa/rVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMW6b1DwkmNEyWv+rMleX5zFjQG0wBIdDMvOBojbgz9owU0VzMDwAXTDKAnowPsJgM8tGmzBgwgcwGoBRMBzCaTBqAW4wnIPSOagYDZkyscwMEzJQ/MZD0wMGTGQRMEQg0EgzI5MMJAcx4BTMcCOr2swCMDAIWIQCYZAxx0a1QwsZNabpIZNEENQEOCzAyiU2p0OyqomcEg0+aIa1wISmPTBfWWkMeOEYkdPAZEjyFRaVSNooCIY5EAaaKACAKY8IDRwkqMKCNWMC48yicDCRp6QLy6CElkZe1ipsxQqjMYNowUuKigQnUJooAAo18gKCKwhkZQseNIADB5gUiHIOJgQIYsoGLSEcECi4wcFTJKpAMDJhJGBYKCAAZmHCpgSEOgQqIwq6xGDGjBiCpiApEtIA6dRpnP/74mSbD/2AZkED/NOwAAANIAAAAS71mwQP9w8AAAA0gAAABBzzQVBg5saY8Z0mm0Bh5oBZgS1UWKpiMYe0ITggGDAJCINOeMuGMwXLYGLLiQU5JoEljCFiyQOnCIOJAKMGCzIAFYiEEZsWYYQzkKijGhUEBdkMKjIEcBjyICAkxzFlASAQvLPOQRExQeWxNGAlcxNTsoinI3KLv//uMX9Ykj+z0lExpn6wM8iWeDELxPIwl4J3NDKB9zg2hZ8xVYaUMC6AujBKwYkwPMOLMkaLrjArQb4wFYCQMAIBVTBNARow4IQDMOhrMJAwMIwHMLxRMEQrBAVBwMEQNGNoKkRAkw4GFQUgYFDAlKToFPjE0Ey2QOEIYD8wpCEiC52TAAGRkD0b0CYKApdgXsIDjgQqwLgIgEXUFQoIsMQTDIXLbm8osFYFE8CjQrV0WnQfdNTctUWvBoCYzdzcAm62FHAuwgLQ1bsyZriQ6h4oV4S84qFuyknmQ4CJBcwuolWqiFEGSiO6IKYDK3KQbbo35rCuZYicqFoG4A7jqjEhLMac3JUKfK1Qw6mZYK/5eZr0BLQtisAhRdsOaXcEjmsrTSKCOaPa71b1rsOatJJgRiRma8WqMYJQFVigV6DjzbNIQPggFpFmqCqrooNzVbKS36I8ufR0ASNw1OFBE64Dmn6VLpVcteZTpbjRGoVsrNF2vcmNer/ZSkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjCAVvs8HllMMSi6dzJd0ZQy4AHRMCMDnDDKhC82Qsj9MO/B1zCLQFwwFkGYMCjAajBsifswZMHfMEeAGzAhgQQwhgBMMSnBQDKA6jKIQDDAHTEMFTMQpjIIYzEUHzAQTTAQZjmcOAEPIQMJg6LBhGkJrwHQQFAiEAwiB4xDHMtwa0SZE2YkuOEAwiXzGiCjBAIM8qNcEM+0TFMW8FjDRyESBBwIMgEaZUEXLEIUAjTGiTLGkGRgA0YLDCYyISIUKmhLKMAkC1wRDTbuTCjjICjWgDFEDTABAAfUEiEHy+6QgqHQ6GiDhYkuZYMwggvyaEKFhhkxJmxAKAGhNGNZk4gCCDHEihCZAETBjHEjMNzDGCEoiuPDF3mxDBVUMEjBJRwKZkwABBhAoBBllk9mVggww0Ch1vtZWujrIC4DLF0JbjiUCmBwMTEBICgKIig0OYIFyioQwMyMYDAQCZYAlwywACjPCgSBAAo1JszSwxLQcQiR0teWzZ3/++JkvA/9e2XBg/3TsAAADSAAAAE3OY8ED/dOwAAANIAAAASjqCnNOFjSCE048kDCxyWiEQUGqR2wEPV8gEKgovwBiohBgEqKlAUpIhSE4OAw/GLWW7EuO//9Bi6jcGfdUvXGgM7oBj+8F2Y+YFTmFyhpBn0YmmbTge5GEpDHJg0gAAYVMEMmA4hyJlDZQwYPEDjmC3gCxgVgTIYTwDgmIjA/hoCKJkcHJgyJg6BJk0P4yRwOC8wvBMzGGo26XwzoJkoFQwPBQElGcFE+YfBkPCMLBAYbC6doOeU8/phRAWOmMUGFRpaAoaYkQZYEahGPAA4GVWhlGo8BIi4cOBxUwsJu4BGG9DGOEGRAmKXGENmaMp+GkBoigYWa46BcwPcmBQLNMiDC5wwBEeqmESmCDotGJmGAFt4KChk2XwBxkz5U2IwtuLCRbAEJzYFTREV/iyQxRwSkiAyYwkc2EHXUAJonZmgYjOmbBGcFJyoMGIIkkRU4CagAmZASVTRkqQQoMaNB0Ux6IEFgcTLmCAqOmAcQTDXKxQsDTAGTDMTOCTCjrgRUNEwHAaHB5Y6Z1WCtBhRQcuGmgKTjAgGmjJgCJmLJFWhZIFToCNBcGhqLAzXFTEl0Y12mBNjSBlZiUIOdGHRAUWPADGlC6BkWBkSBMZFiRmQCd4ObERUcVmAOjZ8tUXKAIoLg2MCRsOAvNBNwJfr/9NVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTK+ndo+WZcvNvC7yzUVkXk0MkQxMJ+JATIxyjA0e1UPMJpEbDCSgXUxL8J4MJ8DuDSuBQswhEIUMF7AHTOL3D0c2TVa3zD0kzA4NRwKwUBwwGJhqABjGEQ8CxiySpzMTZhCMwjEpAOCizMFxVC4XGBIAg0DIYGRw5UaSWKmeUFiSI8qm8WnWuwlmKh5hMizIYGWZMBFCxAWYAqfZpMjSBE+WgRteYyiSKFncOgooyCgFauYhFCi5tGrTWWoK5IySalKFqeS0gqCDExg1nhjBhYUwDTORICFGljKUkQqukcwqOqULggL1sSHMyBwaEYoCUYVBW2rYquHIFx08mhLPBIhihBQcHWO6lwjaoYJRFz0cUVWAysuMyxo6qphFqyuKARHpahDjkrCGKMgTBII//vgZJcP+/VjwIP9y0AAAA0gAAABNAGPBA/3TsAAADSAAAAE8aBABCApoAQAhaG1SBVg5ViIJZsyHGGDMDqhItfZgEhCrPW+aUOCBATHERkuS4RpkNNZ0yYRgmQurwRlDooGJmEuGcwhqSmqmkNyClNf/9tBkQLb4eZ+0SnKN89hkm0YMY1aL9GG7DjpkyQ64Z1gpjGNHg7hhJYCqYeUAlGDQg+xoFYs6YXuE7mALgGhgPIT0YjaCcmIahCRimZwOeAxsBoOFYxmDYyaHIw6GYwVGEwUGk4nKMGg4YkCSIQCBCHm14tg4q3EJgMMEgqN2nSRSPGRpYGAyQZIkTJGdBcicUmNQzTDGhhYYxswgoQhSoMcwGiAQNDnYcWNgCAAI2Lk0hKVmRNmPWqibqOMA6AFwQOaFDwHJwgAIgQXKA0iCCQFEsSJRDGShcDQKT4OPG4MJOFYUBAFZQIiC7VQsAFCJADRJkR4kbaaa0eXXa1JyUyZIgYAYIV4KTlY1OMtsEGBowbwgZgI7xgiQVCgBYDBIWEBg1F1HoS2DxNGsFBEcAMEfRrZUBF8Bw+ZManSBBhQ8ByczIlK96gaFUgo4YKwZoCh8CQS/UxSYUigTIUA6PTT2jhckYoCjOARIcvBwImCI52kww428QNIgwkMlwSFLjNeSWHlIkbLoJiGXJxkxgRlEjUFWup9DkTHWwSHEd+r/0pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoyRldzPgxVEjiFMXky08FDMomAPDBtw+Ay7IHEMTuTGzAIhLUwLADEMLfAdDBBQjUyLomcMHOCEjAZQKgwIsALMKRAexoiFMxVEwUkzFBIMZi41sBTXafERAMYi82pFDodCNgiQz2EA4firZNdQQhCowODGAQMjho9pMDZBZicM6aRweQyGJSsmatGOMTbnBkAZsCKoTTjjalw7AEJxaEIm6pUMSgIskEBgzGZgua4kZFCZAMMqDLIDFD1blmA4Gbk4Y5AYMyYcMYcsackDQ7wtPEiIKQmYJgIwY4KDtRtTBhwYUeAcGWtSbhoCBhqUkW3IziozxYbVAkwpeDQ4iQA4eQPXMMoTFgCQYlAL+gg0FFZnEQdJCpcxIAqgQ4kFAxlySUZmx401NCOCLRZAmAgpGialYAlIsUMOCMEDUpIVBn5xjgpc0iRo2KKLse4wSGGwuaBgpAaFRYiBDoh3UjyZyaI4AkQCBmOHmxUGBMgUmYcOZIIIDLNlNDLhQNAIpaFwwBKo9diXwKYISERQMORvMiGCo0AGAFABCEBIRWI//viZM+P/W9jwYP807AAAA0gAAABPFGPAg/3bQAAADSAAAAEjOKDQaAAAVGTCM9If//QZMFKRnyBQ3x7tOrQYdo++mDohR5gmZRAYdyRPmm4sbBgdgUUYBCBmmICAyRgKwgIYXYY3mCYg5xgkwOWYxw+fLv8em2uZFK8YyhiYajuZDGEZ0huabG8Y2CeYPiYaqHweHGgZ2CegPMMgpMRg+ODClMUBEMEgNMKh8MHy3P5QjbWkmOTESIZCzTkdQMxoRBJYYM4miEIsUDgEZMIgoyM/UAqGGIspkYwPJTDzDCMx0IMNRzFRUwQHMfETFj4y8HMoJDBWQzsMGg0yBXMtGQgDMTAgwmFEwdSSEqHlM1URMrYwaHGNGwqVmImJKEGZhxlYeYwENBC40AgcxcBMaJTIxZd4dKGQjBkpiVEsxcnMhATg58zolNBAxQTCAgyJwMWODOR8DDYkrGEBJEZgUeNTIzJkwiXAuFprmEgZkQcYiCGLARlwMLMgEADCAkAqwAFhGQmChQKEHEMCXiZLQHAYbL+AYVMHOEe2eAYNL0mJlIUOjFgQtWa4ZjTmYUUl2DBRxaBgRSSpJjygGJhj48GF5jISYeHByiFT0RjI8NKWGCBJihKYSXEJyFQYHCZgoGAgcZGgMWEw4CUAvAZeMAwsEgsDG6GyhoOuDKysxcdMLEEQEzTSAAZEUc0BrBp4Kfr/2U1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTGBkaY+ww+DPJupKTLED0wx4EKGMDBB/DK5Q/A1uQ19MF7CnDBHQegwnsHFMCBAsTJGx6QwPIORMEWAtDAcglEwScA3MKxC1B0EXMBkAKTAIgB8wAIA3MA8AjDALwG8CgCJgQIEMYEwCGhYEDMAvAIBoA+KwE82YuMzvRCTGNEhhh8a+nmWqBkhEJCaEs2FWMAAl7mGHxggSY0mjTsPDpcAvCCjI00nMJGRESGADAcAGFAhgguBhMoDzORsw4yEhssAokOGYnpkpgICIWARAOGXFoAFC4BkIANIpjJMLGpmQCYSlAAJDjEw00Cw0ZwHqnEIcSCSXANGBobKwIYEDDAkrBysOMDDxpvARqIgMIFDCgs8cnMsPAcWBQTZIEDQsXCwkFBEwYMMGGAAEBYPMTBhGfhDaQgJe4wARzIZZBKIKhMswxEQSQoR4wUb8gk6kMDZocOAk1FRtYFBCOQsqLBwkpcNE0xXQeYYwoOZMdgAuhdEmSAhgMGTrFegx0eTImy3ZsAgJEwjiqgjkY4emwoDz//74mTJD/4HY0GD+81gAAANIAAAAThRjwQP908AAAA0gAAABGyJpDSSAgppgkwqxAa+AThAeWkNIdL9nZcA0kVemsGLFmVKIgCyZXGdpRMLcYjQZOy/tHOrt25+LdiIZhWu1GOVCBxgnY7KZNWJgG5wjVxg/IjqYFcCUmABBORgSwLgaAoGFmEQCLRgagFoYCUEUmDHAbxiugBGYmA0Y6hKYUBCYJC2ZXBC2MwlCQRFabdD+cFhkYUg4FAeMPg7AQQnBIaBcSzIAJiYLjCkHzSQNhgPTCMHjDMOTEQNTCoHBoLgCBoIBmRangTIgGrBBzAFawhsY5cZNMTKwUpCAoiHgJFZEJI3g9MUx9w3YAVChY+FQppAJiyBiRpkEjgAr6YJAIxBjohjxAXTnQimjFmtqFJ0yqYoEgkkBsIUDj4J+wqPLpluDBDTAIDYnRHFMiINgXBhAwCUEsgHoEcsFIk6laTMiRa+MkwzsjwaYEZ0UYB6Z84MJiQCZo0YQUAFQd7V0a84HEUyhGOXmWoMclMIBNYaRJMApM9NAz0lTgaeSgzFGAaDW+YtOyAKykAJpipqQjXRZqLBDIhi0YsWNgBZsDF5iVBkipIBfszIgwIE0zYzh4soIyCBwhHmFVmkHIVlEsxggoYSIHJgQEFARikAMMDpxYgKCoWGNCIRjxgBFzdsw5aAr4jCmOMiwGWQ1eAj/q/9akxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoyQ0sNPpPNZDv2IcUxWtXDMXuBeTBvhCcyVIOUNcWFKjEag1owP4CsMG6B/zABQYQzAkTtMHvBNTA1AKUwAwBCMG6AujDZQfU0iiCY9AolgUmGGRGbLIQVG5mYam4FIaXhRpcIhQbGThyZQWZslTGEgaZLChiMpmYzkakE5ZwGj9K8wGEhIGBgIQHFaAzyMqgUxjOAhbeBWJvSYAegYMLuAcVc8xBU1QUVKBy4zR0eCmsAigsxAYCnzABzCCQ5AZUEYoeAhIESmEGhGFPUDCzTOzUDh8wCTxnQQwdBzBQ0LIjJmCsaroIcGDJhwoBLxADMQONaJIAZuwjbiIEBEZz5JgjK8jXrgx2ZEwZYUEMC+ooLKGJf8zyMethdEalOZsYMAiYa7xtxhpTA8MMYIIlSAYHCBCUAQ0FRRrEGEBQ+tQCiTJkTNAkOwRiZWY5CZYUaEGrOSGTGjTQii3REyB0EWOhZSYYQF0xhi6PRuwhh0QAJAEsDDBMTMuYLJkQpwAUAQ8JnxEoeQVcjg0xY8eCGYDpnAIsa8MBQJa9CAQhBhQYs2nu/Rg3/++Jk04/9sGRBg/zTwgAADSAAAAE8SZMCD/dtAAAANIAAAASIMEiAal6Z1EGPVvUlvOQwIGPXORqgrD/O25wywpBNMopDITCfg7gz04FgNhdRiTEYwR4wbsAuMKJB6jCLwlsxsgpeMMEBuzBUQHkyqSA3kfs2F9Q1aYkxgGUxvB0w/BEydDQBMKKhGYPDwZYAUctBQZmBiYwgGYfguYpF2aHAyYRB4YRDuY8hMYekAcWUGBspkpQZeJGLng6KGDggENghkMXcTQCQ2weMpNyIUVWNDRDKBASjjHwUwYeEKQYyHGGDxkpOFWIyE8M7ETMzc0FBMZGDITkoeDDW0KhIKO34HhQyclM5DgcOAZhAgymmHEBiAQYYzmqlRqJsBBkKAgOVCagJTMYNzYANlYEKjCwgw4GMfdDDiEw4OUYFSIxUNMkDzk2QwcdCoeagsmSJph6WlcGMAiBmDJpmPAYWLDGQAhLysnMrPlFAsGJOmAE5lYWDEMyEWMABk3kaTKQIOQBwXGF4FOhfMgCgihM5CjNUoKhbBA5OMLSzNAJz7AXHTfAAHG5hysIxwxcKMPNUigyNMHHzG0Ex8gMWFihdBwYYCTAAMMaD0Eo6AGCBZgYyYEAmXgYY2wI7pjx6ZAmGKAQQDlBqIwUzkxMBBDCTwGjQVCyoZGEjzPU9RGOCQ4DA0xsYKgOZQLhB4IARldSxKP1/+upMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjCxhZQ+fgxBPIoP2zDomcAw0sJ4MANF4DAPBIUzTZGCMEQFDTBhAJswyIGbMEUBjjFrCDswW0KcMCjACTAFwPwwb4AZMSUCBTpMgMnBUxyIAIQTUxcNBmQxGJQsQjVCZNDG8zqDhYimkh6YqFh3gnGaBYVBCa9GRhsKnJDIumrLHMHmSmmZEGlMmTWGHnGaUHIDFnCI4UGzHPTTHTEpjFJzIBjAiAAqBp4m1nleA4uBkZpS5nBpEUNCRFEphRZiBJrSKIisxrjxlTIoMHC5KBV8ZUsJQULDRgTSpBR+BkBshxKUEQIv0Zd0YcoMNDQuTNGUUhEuAyYrFmSAD2QFKTFLwxkBjoXFAAaDR4AHFUALFjFFDIigAsMMCMOSMcKZORPCsCCgYs6MkzIChrz5oCwkDIvZQEAIcwytD4dSmhsm2BGaLMpUiZ0uGPH/OGxMOCGXpgwaXzJjBKzRJQgiIUJggZcoGBiYSYkGoJH0wxZiKn00DBiF9EJ0y68oSGfFAQmqA0js3woxQVgxihRlEhigRKBHooOXEQUaFGeIiwgeXpcNzFgJjQDGDEJ0q3zW//viZNeP/dRkQYP807AAAA0gAAABPLmRAg/3bMAAADSAAAAEkZIqZY6YEmpRC6yTJr5HY1iVzrP1BQMjTRQVsytgEaMMZEJjNNRCwxp1c7MN0EJDCsgGkxAkAYMBTA9zN5Rtww1EMPGgQYyFhozeaw+7Pc0XdMiVoLCeNAIYhEuZwBCYsgOYoDIaUAWcgmiYwkeQhKYeBiIMINczYhQw94OlQTFwYyMSFpMxxgMQBjsVc0xGCoUYGCmjp4XXEUTEwMwcKNSHEDjEh4x8HNDHCwciAyMAAQwBAyuLaIYcgQAMlOjIAsy05EnszdMMbEAMZGjpZdUZCghxC6YHEAY5AokKBkElplhcZmLGLmCB4qMgLHMcHzNQ0wUuMUJDMgQzkENzDguMFUJEgkyoEcMyELLaGKvpgJyATs4YgNYSDNAcGnBIkmHA4JHTCyMw4HBoqYqMGFhZIVGvB5UJQKEmBF4c6hxEY8OiBRM7HjVn0y8IMKJTBBAoajBB0w8vMMQjIC1apsZeNCYJITSy8SHDAwcDIpoR0YgaGTlw0MS5BkoPhJiMlNQCAGQhAXHjDRIIlysCCgMUFJkYQYOOmLhRiBMZgQA03MaazBw8xYXAxkDQIy8mAAkZInGIChg4uMi6YIcNGMpQZImHnoQppMGDjgNETARgsAwwQGKCgIGTITwKAIsMEoGY0MFuyYEJQFq8Ohv9n/tqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjMsxnI/X8nePhoBhzHWGtswscTVMCYC4zLqwK0yh1SkMPrCTjCMQPsw1QB/ME0ADTMvgPAwrQHoMF3AfjAxQLgwa0FFMDFDXDi/aGhIYvHKgBq0TmPRwa0SRh9PGdoQZRthhcGGIiGZZC5kM8nBwoYJHxs8+GQEOXCMzCgqvhQSMWDzKFkwomBIqVQsyApMsYDXAQUIDPDUz0CJgg1dRMmGDAAgyEJLsGIgRjY6RB5m5oWvSVC5eYYCmPGIWPjQi8x8KNEOTWy0eaioMGPgBji+ZSdihQZSFhUDScQDGOAAkNjB4ZUKmeFIAFzQxMGJ5qaADhkyUKMQMAEzjwsYgdGbEBhB0Y+JgkSGAkysJMkBjckoaWTLyAxIZKoUCCIURzFiExEdEB2LKAEJjAJhpxg4UYcMkBmkMZYQGjEpkIaQrJmDI4YMcAuVGAjoIBhAAm3hggGQuGGJnhiqePCQCJTEBcwlCMtFjEUMLABi4UGI5EAGLj4ktgZSLfLAI5mIhZkQEBGcx0bLB4mu3EGlggEjFycdKy55vhWZCUiQKZKcAkvMAQzPSwveAASaNsCiYBDh8EC4WFTGlcwAqP/74mTeBP8YZECD/NuwAAANIAAAATlJkwSv80+AAAA0gAAABM4Oyg7NOKjEkBJAAhBgBaEDZh5omiAkEwceAo8ZeDtOg577Y7//7AZhMB1XQTIcl0Q7DUxnMnoHcjHvQLwwY4RZMb4EIDPwjzcwrwNZMB9ABDBqQVEwPsEeMg5GpzCvQlgwN4BsMA/A1TBTwQswyAGJO0wcxmNTDhmMcIMwEgTCQwCFmYcGRmEnH6h2YyGYhFJnIZmSYOZ2aAwQjDoGMbjIwsQDXCSGSI+ph8XhcfGQh+NC4wKBDFA/MQBBEMBDcwyIBAJBCPwCIQYEjEBaMXCEMBxg8NAVEA0Bl2DFAhMVhsFBYUDZiUeGRBOaaWYIQE8ytWcISrGZUUaxAFRpiiAlBBB00ggzw4QCiZcAlyZqHxmDxgC5F8GYZk0QdzDEQiAGKcGjBmUPigUxlYxbMLNg5MdKkTiDUNzKox4qCmw0ZBAc1iJnBKjHAK5g6UEgYIB0MHBTJlxh8baSRGwSqNiXMMEERBF8yrAxMkFDgTHKGpEyLSszN6fM0VMAlIgxkyCpgAlCBBo1JmRoo1AJExRsskBBQUDGZSuEGJRlEFQgG9mHPmhPiIAgkDkLtmdKCx8wYVVcElisaAGBoAhhxIE2AwaY6mgoMEyz4ipCpkBRTGmzOCxCPNObBXYGoQEfMCWATABMxEkGJoCJI1Knh6noqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxXIgrPEYKzToHCwgyRFDkMBmBtjBNghQyjYHZND5MBjA+gh4wRABDMEwByAoD5mCDEDxg6QW6YEYCDGBwgHZgeYBmYceA7nRkiafEhmFRmDAKZ8Qpi4dHFUyCnAcZZ5wlXmTxYKCkz2JTAACOCAozKRxGTzOYzMkDgcMYqVwSEDDRDNCh0zIATCgYIRIYs+dUwbmOI6R0T5zxBmAq9xY0BnwAFh5I5LIBURqITaTlqzWJzeHTKDVKTKJjSzimqdMWHMwY0CpwGPgFkMyeNEEEjBg1IQXMU6OsMSGNqOMULhglTFuRgEOKyqsHBKhoYrMnEOHKJoRm0KOIFIgVIZ9wMwhAgJoQYxMelCoI5SU0BgSAGTMDWU0bAsCTaFzIgAUuGUgCFBc+cMWXlGUBlBphFxuQYVKghKDgRhTZHoHKSUJrw5jzJliRojoJPGHNoAzHoThCjODjXNTOnjkFUsTDjB4aDDxmDBogBqnAOGBSMYMIEcrwG+GnMHeQGIIGUHgkaFSJowrQ0JYsTMw8NESGgQOPAp+bVcF6svFEjOjekBpQkcZFGLrjDhyxAa+AiqlQOUn/++Jk2Yf+FWRAg/zTwgAADSAAAAE8MZUBD/NswAAANIAAAASTAGHBmgXHTQiRF035v1CYBJjKKIoY3qhsm0xjFZgn45GYycDUmEhiMBgOYrKaMAP8mDrAuRg4oEgYLiEdmB8BIhi8w/aYK8BwGBWgIZrS3m1W6fU4hlmcFEFNwDQ1GYjH4KMchssCI1suDDTjOfugeGRhAVGUACcQdGfO5sbcY8BGgqgtxmJkZVJjOiI7NhMcNjrDsMQTeTo18cHqQwAjDt04laCjmMkRhQCbYRgQWMuBxGemFCghBTMCkOKU8BU9NxMAoWBF4YGeGkCJjJGZerF4kBplIsYUjGUjySJhwIZKSnBiRlKqY2TCAsGEgxkRGQA3cuDEsFRJccyUjICk1M2CFoyEOMTKyzxnoeZQKmGgZhYgRC5kicY6OndgJYQAaKmbkhj46ZKBGvt7ogBUMYBDQzMCmQ0NmHD4wAmBB5kgYMhQtRGICI01gxfM7CDjTYGGpg4sKi4CFDaCpFcoUQVImaHhmZmZgVAUvMINjHDkqCKN4XCzOQ4qlpsYsKhxgAcDhMqGJi5aZGDmHvIYKN4ZKJgqICEQwM+MPHjK0ozo0AyulsHeocMDgkHSgQdmBjBkgQZommMg7yhwyDlEQEBhxEYYFmLgQVIzBwsKizZzDT8ykVMvFFBjFBkxsFCAg0QPDigxEoMjB0mVPX71vlVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMMaTbjaqSboyx4D/MNUKuTCRgbAwAkHUMYlEsjJ/Q6AwO4O3MFbBVjAVQiAwWEIsMa9EfjDTQDswGYCZNIsM/d4jhzDNlkowsJTTiuMqHU5w4jHAMMIEswwzjVL8NWgsxEQDPgtMjBcBL84yTzQhZMWlUMCBkkMgZHNIvjG5w5E+NaeTGiI1cWNVJDOU8UcTVRYEIIk8iQiaOMmDoQcXCA1GqcyEYMTNTPw85kOM6WjImEw05MVGjIHQZIxGdm0gRkIcZOxlBObAPE1KakeGmHwGVDYzo3cXMJEDUKwIqzPlkxRBNEFjCQkGCxhASDU4wQ7GQoxRBIjsmQjP0IkFjFRcIIjGiARB5k1GIyo2dcNGHTiEQxQmFqkz4CGUsxozM/mDb202wrM/GRk9ASuBlYxQ+BQiIyIxYtMEVzEFEIpjJUYyYBMdRxoQMwOTGQ4HPDDzLSwx8HM3UwUomfM4hJzX8Y0MmNhWSj0NsQwsxmdIRqB+ZamkA6YgvmShBkSOUQZpSQY4lnIF5NdRI0gsMpSjERQ0JdM0LzCTo0IPMZFCQGMeKwKTGQAoGjAINDqSY8emRbAyHGzlBiwoZumHLpBkAUYIPCMIBokYyAmDmhgIKYix//viZOoF/4llPwP820AAAA0gAAABOomRBM/zUsAAADSAAAAEjJqBmc3B7M2QzIgMwsgMyAyQEBQOHJyYbi3Keb6CEpiUgFqYeoOcGF6FIJqnKYeZgOF+mHiBDJh6YBsYEkIjmHiglRjmJQqZbiP3mBgjmRl9RfMZLMKECwk4YQMIpGMOC0hiAQTIYG+B7GA8BH5ie4ySYw2IemDtgohhQAR0YJEASmBQgJJg8EGsTqZEVRvSqGjgAZtRJkk8mUQuZGTRiYJmCx0VowwaLTEyQNKJgwAHDDCQM4JYyAIjDJJNZk80AkhCRzL4mNRE40kWzAo7NYjcCBcx9kRGTVvDnPQsbErzkg02aEaYtMWFxj3p+EJvHQUvipww5ACwzdszFDiLgZr4bNsZIUbM5RmBCDhk2IAwpwawgVqJJwCFA2xEIyg4ECxqmZM2YJ+YgazRaJtRZEYNIVRZUpMwFLvmfUNzDlhmCY1DXsAq5WTMqMIWJCCMiMMEHMsnGFRZETBgr4YwWZYMEkiyorXFkhMtBCAVVmJRmuCmZAG1BhBwsoCYJ3CQK5BRWBkJk4iSBRFBDAoNmHaAKKYYIPOmKm3DAI4ZNeBDRIKGopyXZpEiewgGGimnCchzUwAASLiNKDAJo2Jw4KqZiwYWJCJCYQeXDEBGQAISAspxmoqIGRgOSBcEaWIQJiJoYckCg4iQFVcWaLf0f10KTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxQQPJMIvBtTXx6dkzvWf6P31FvzJ/REowWcZgMbkHojBvgP0wAUj/NChDCTCVw0QwxJRHMMuEKzE9go4wuoKBMaVFfzAywhcwCsApMEpArjDqBs8xo8DTMFeDxjAJwDAaDFDBIgHcwO4FYEIEgYCSBzGGQgSgEAgTTx4MwCIwSoDYRSNfR0zSsDUR7MSkY1GGjBIrBAXNVHYy5DDCZmNDtcxQKTLw5MPGUyGCAdDjHRFMDCgwQKDE45MWg0Mi5lsqmICOCksZXIwsHhwPigNMBikyWETAgHDBEHEkwaD0QDC4pMNAIxiGDD4FChPMAikRhgMFyAkLAEfJLDIDJM0xX5pNm1kaShUFCwLTzGTCJByJgYXWE3DLMMeF6TRUHRgg0I0BVUVUXBXxyukY5ftQAtOsGYl7BhCUH3mKgWRMg1G9rxosrVF6CKYwQyhtQEAEmAkaogjBWmBNACEzEiRMqwxEUbB7NI0zQjPUGiREKMhkwaVwYoHWi4RhhggwDZoSAsQCsxAIRPBB48kYKgsSKCgJ5TQcLHAQACYo4YaAA05zAAX4RP/74mTTD/46Y0KD/M1AAAANIAAAAToNjQgP91FAAAA0gAAABNAdIzCBE2DqiIpFoMAcNAKIjBI0hWIC0cQQm0Be1GSOesxOANPMIfEyzivKoI/zyebOh3XXgciFmEHhIhg6aTeYLIGKGEzkPhqPIhkYT+DDGSrIvRh4YcgYOgCuGFlBRRjIAJsYRuIcGDKAj5gVgCIYhcAjGNSgYRrzYJ+/CRskR5gcSRt2UJnUT5k46pvTQRwUL5mmLZuitpkEOBVHA0UDAxQH0zbNUxgCkeZ0w0IkHMqYzi2YuDeY3A6Yjn6Yhl6YuDoAkZMkgYMlwrMcAzMCASMGDTKgDGCYamO4lmRQLEQ9jpNpomIwPmLQFGAIrDQgBAlGDodAo6ZkSaVmJXzTHAkUKDQ2sZZgZkcZguYQwZEQDlYCMBwowBkKkDITBMad+SIAIVBhDoCDAqDOiPBRAwwM3AcSbGIIg02peZMWdQIa9uaAISrQcdGBQoiCqQWhxFEKPhcOUAGnB0JF4wg4FH0WUaQVcMGRNUDAygNPiIWBkAGPIhMPMqRFQwQrMMjFQIIEhxcKiDTEB0OVCwciLshCIaFltmyjzhGctMAgJMmMWXamZgSmnKQSOMGPEn7pmIAVy+4NCiTFMUShCpOKhxYDMQcHIAYQjEYBKNJYSdiTohCjwweSCIKsAFBoYCLlCAwMjHskSCVtKclf////TYAAAAJRSMMPqCEDDYhLk0pNbjN13gMzWeDUQwOoBhMLcEAzGiS6IwNADmMLGHKjJdwXgwqYAQM1PKSTBPAIEwFAI2MCqBxjFHQo4xFQFrBwTMYJYC9GFECUxheoD4bgWxs3ZFiPGNREbqcJ21HGsU+eaXRzxAGtB+cCKBgROGGWMaeNRilQGvRgRNsysCzBQhMdF0wYbjZYeMWHAyAsTIQCM8ipeZmUFmFA4ZiAxiwpF4TIwQFRBnxJhCYoMAxRGwohHJGGyPCNQZEobIKY+uGaCwxMaDLAQzjYqkgKqMKoHEpjAYQJFoZjRFYDLC3QkDMYuUwMM1NQQLxmYQpal+AygKjQcZMWWeI1y4ApYaAzA5LEygMdLg5YEFyQkaQiKEzSoEwzHIRkeaEaUFzBgjEkxFBNgUHvQJABQqYJCTJjGCwsQLpmKEmNEmHHgkIYMWIw5jgwEHGEFKkBBIgCGWMuuZ4UHQy/BMWKyoQKBQAw4wrNOmTF1VS54yRQ2BodS9iCqqFafBAYNeLJQkEmABA0oIwZgAJq2JhVQELGBMGLNGjUmMSsrIhIYAMsNCh4HhgqYMIwH5JwI6RzNVHDKgDL2DPRTiJkAiHNKOuESmDaAV5hJgZcaTdJaGz1v7R+YQHUYq8E+mA6hKxoYyCWYT+FfmGlIeRoIYrCYImGUGz/++Bk/4T+b2PD0/zUQgAADSAAAAE50Y8ID/dRBF3BUYGGPnnQHJxgaQMCYMuFaGDNgpJjbQ8aYvaBHGBmA9BgTIESYZgQgGGXguxiSLJ8saBnTRRkKNhiZChtwdpmEKRmAppo42JheNJkojYcKhmyXxlWaZgchZvEJJpQMplkJZj8SZgkEBgODBpmPRjgXxjaipg+HxWLJiQChhCMRhoSJhQKJi6DgcWZhuFphX4EIJIHoMj6I1JMwbUy94I6HlEmuHg1wdUwaI+YGQYcKIlZoAwqwNwyMuKN8iMm6Ni0NSPNOuNoNNCyOmPBU40IVgZjR5q1zKxwWZ0uZEkFhaDtURPTTKguBBRlr5jR4dra2PQVDQSZHhS/jTCygKYk+JNDGBEEAIKhQKMJjKiEQzTkEMmXmPVFB4MQGSSoKDQUuiCBZKEM8WMCHAocUQNOVXLdJkBgYypA0qsiAmWFqvMURMcFGj6HQxARD8UGJGmEDgQEUOhCdBxmcM4FLugwEZlqZoQIAoYWMSTAxEUDAI6g+oMOigCMCo0SGDhzF6xkABhhYKIsp/goeEJjOmgUZAwxRtK0cBkgsyAsiEtFV9bGfY4o6Ur774q+WAKySV8v4WCyRkbdlGy9bT4r8WjsWiNo9knnhfxAskRn+xojMuRIPO3PF+Jy4cmw/kw7aibaZXIIkJ1ZwtVuPGxojJgdlYfDteUy0Og5pkpCEkMw/Eh9wQxoHUfyxVUDQFx2DwzcX4XzIWATGgsm7pqO5yLtmcXzK0pdUKtQF/PZCTjOR2fiUIOYRaEvTkRqUqiOAlaKRj9jYUehiLYmE/jJKcm5kKNWIedh+o5CGR+nEmokYo4j5HLKuUKDaFcXkdZY1hiTpxHCXIYoewmw0B/mQTsniJaXjt4rEWoko7cULc4rtQKdumtK0IeiGFmZVcjUGeaEM8zOnF2xOlhPohOptUR5nOPFfOKrTje+iCEw7YNZMTtBVDKqcuE/t6E2OMePxzAgBIUw1kU/NQfJijHxwUEwrND8MpNC4DASxT828E3bMEtBBzAvAywwfAKlMGnKWjFJgUIwbgCjMBWAjTCfCOQw0ABMMCUCLDAjgX8wNEJ6MDXBOTAMwBMwDoEkBwBOYTSBfmDjAhZERjPQQN1okzmxDZirBmGNEooz4TTBBJOFEkEkIxo2TWJYEAFNANUxmVDJayM6m8w8WTI5dEQsMJiQymoDMYjMfks0OZDIgmMthsmcoFEoENhg4BmJh6YPFBhYEGYRYY0BAKKBhIWkwnEJbMNEgCkoZGph8GGCwyYtF5hoeGEhSDgEGC4wkKTDoEMcAMAiAyMIQAFwYFCZLjAnEgsXrFQkFBAARyliYSBTdiLScFGRM9Qoz4AIiDOTRLTENjcMBBL/++JknYTOwmRCA/zNUF7tJrMEOr511aESz/dOwci02kgQ9vg5n9GWovIsoMinW4ZgItYVi23SFA0wxk0GilgkSTIiwAMGdGPmYYowEgHCopep8BspJIWmOQ8e6N0FGwGkpGqUE0TKzYGMFczAwgw3B0tUK0zThcMscHUhWY0ugacniZzCEI8QZAINAHizADMR84nw5ERCr9UxaqKCAWEQrmAMEIH4gZwhFUWfMUVy1g2HqDGQwownQym9eY7//3f6QE3HGPX///////10f/I34DL/m0AqH/yPXH/amwAJR575BKBwDLmvMkAlHy///////+t69wEyTSwT5YDiFjFzTyzQxmYEKAHx4KximZ/LACMq+aK0923DQlsCBQN/qUZAATLmApg6hgrQlOYUo+dGnqi1ZscI4iYPiCAGCwhL5mEwZGYDoEKGC+GKRiKYFIYIUAxGZvDUxgUYEyIgRIwXQDLML9FkTAkgY8x3BM1ZFQyYzY7iCkwJBg03CcyNIwxQCcweI8xlFsxZNsxlD0wdGwxfAExNCUwmCUw6DIwZBAwYLU54w4qwqggVNBSozdU8zI0kkewGAmmaWm5FGSWBRoZUaYQOZREYoKAhBhCIiNhQmZoeYk0LW1cpMI0jIQklgVAYlAPGQwmIRhtyQNMlhIAphApAzcKtwp3DJRUCUg4tMEYEYEFDTHBAcfAoZTEKDgsQEjgUDDycBKDGlDFCVKS74JelDsIar+GQangh01gWFgo2WfQwBz1XIwiLxGcQgQYnuqd+iQqFxY8Ye1PUFBigSBQLDumNCFvAINXvCIEFBjyDQkGAE617I5yMVGDQgOFL6ZqXXDhwQOFRDZXwRGBgUKBkR1Pu+MilUWtAZekWmov4hDpcGMWEyhY5fQIRxkKAgECVCGBgqjMAGMWGMqwMiXC5UvMBoJaVpzirMT6MGJQCJ8Opc13PDGf3eBFlOX/////g/ruv/+OvP/3nP9F/0D5Q9+e/8DqE+r17NGH///////+OVmVOSQA0YpCkYOvqfHZgdSMoY6IGaMU4ZyDEY0AycLpiYcvQfbCicRE4YrCgYgCwYhB8YUA8NAaYWgmDAZKyNAwjJ3tnsv//0DAiwCIwJ4V0MSs2cTpYUnY+DccqMXpF7DCFg0Y0uMa3MC9BHDBb1CAw7MJCMBzE6DU+SIswNICzCoDGYI8FKGMUCbhhuYQwYKOCOGAMAp5gYoH6YrACaGcJfm2KSmHoOmjxkGGa4GPrLGIK7nQBsmP6BmMBXmYCiGMwPGVwFGEpomEZxCgvmFIbmJZngwNDAIFDKQUTJoIgwWjJY/TGwWDF0KzDQJDBA6jHIPDAoUDAoSzCIADAkJTmhzGGwvEOUdNNHA0coegKEGLTDnRx0CCIBDGR//viZGoP7jdmwoP91EBprTaiAD3Md2GhCg/zMwF9tRpEAPfYPBcYlqaBWKBjDlAUTES4vgZ5gFmA8hHqwXHA1OYosZMwBCg4eER0wowzYQ54YQj1vGiBmGMGBFiSg1ZdC10xo4YNQDhJq0BjFhjRIGChCgOlDSdUhqBjEgSGbwLMzUi0OLNHBVCu4vwnCGD1okoEOWDBgMJhDlqKcZEVS0BIJI9jwwFLqkTNIcOWgagMEybAOhWshnMwIYdHLvEAlcoGGmBEKLEQcw5dOMsAYGQFl7ViioYQCxIOAkAhEEIILkAokSuTjEAMhGFBcuoFhgQAhcYDCCeSsY06GkJYEJeQSPI9F8EXmov66sVprNq1lLQSd//QCzUc//zP6q2Av8/6+H5adfPj3yTJF5/4Ibme6/c///////nhbpI27haswBDwzfqU7spo9kys3qAEwM+82/G4xUh84DoY40nw5GLA3+EQWbYxKIkBAMYeDuYkgeYUEEZFiYZECq6jXb9lYwGgDkMJTC2zKR7TY+XZ2JMdRSQDESQPcwkoEMNFKJjjCqQIowfpPaMZSBwzCuhQU0NwBIMKfAaTB+gRUwPQDRMYVCVDDMgIwwa4AFMGwBTDA4xbkxFAALME4AfzCZgJQwI4C1MCYAmDFAhMoM09yLjXE7OXo0wARDD19BRvCguMhlc1yqTC6qEaWICyAnKYVEpssImOgAKC0le5msOq7M4F8UMRhoVmYwsYfBxhIdmFyAYPGJkYJGLiuBAmY8FQcGjGw8MOA8wIGTDIRMLigw8DjzVIQjIFNsQhIOAIC0gCYWBNHciABHx5iL/EKQNRNs8MMDKSbMObGgwA+Z4o1cZCBvCBUk2SxIBHJ3jKHIAQcCb48APul4VAiJJV5iKIgDA4XBUdQ5AAgQDiIM39DUJUrL8rsMEJnYVBQLBj6ITZ0cgCIJNhB4hEFoLgnGBqgzYwjERgeMZxo4SYyoZHHEtWkFsyoKimkYNUBjz/l9g4hicqA40hY2CiS/wkeZZQECXY4RhAFkgOuBlwQOLYlYAEUMUspLL1KMAU1tmUGkMASUMGiJFGEEjzEC1gIDcFY0m/X44/qtz///6ZZ7yNvKv/P8v/v/J/nqRlN9/Ptf//1/6/HLHKIyRnojDAxKqs8rfwwMJ40TIoynSgyWYMyyMg0dWQ2FHo2HyQ2gDsyLIoDC+YKDKZTEiRC6SAcPA+MAklw31S/w16v9UweUIEMIKBmDOel9szP+LNOUeI0DCwguEwNQKuMwNKrzEIwI4wdA9AMhmA5jBWgPIyWEdyMJ0AjDBNABEwOAGXMS6ErzCMwWEwKkDfMEDANjBcBZEwC0C1MBbAfDCLgI8wAsCGMBaAPAAgzUgaMkvI7yZjG4GMboQek//74mQ9BPy3Y0OD/MyyWW0mUgA6zDQRiwyv8zEIAAA0gAAABAVHhn9ZGVzMaKMBiQnmRgoZQMpnYLmIheVCUBkiPBwxqcSJpmCQUKDIwOFHNMCgYx2NAgAAYeDJgoqkQgDJiR5U0kzUFMdQxWBrcOfIJi/ws2LFCRYWdM4QsyRRGwEIFTPDMMVmCCZKwUaU2MkN5RZwIXGCE1ChlI9AAJOmIKAE0MSYdOMCghoUGhxg0Y6EAL+HBw20SJUOe0DBw0osADjCIC4hOQyVChlihKYKa79h3D7EIAySqmtUvioWiIkIBEVbHuLRAElH5S9UiJYKGU4d+jMJpA1GVnJIGls+wWLCxQCIBQb+AYh3k/Eqy7iUaKaJxZEWPSPIhxoxjSfwFJQHpdSdcSRgYW09NZ5zPDT6bdpQqAX6dtlrySOEqAxXH8U1+Rh//+fxCXkJzCuiFL8M0JyEIPiEKFQ8QuIXL+L8ohf////rfLcsh9lia5WKNaYOBjMVvOIUMulBWw4ahYA3sIYlnIDmIJmSBsybjeUxfiNyyW0uoBwMOhBBjA5weY2F1+COUfclDmiCmExPICdMNXC+THEEEYwHIAWMElMijPVgXUwVEDXMd6MtzCaQGkwXgB1MEKCIjDlx/gwOkJ6MBGBDjA1QTowFUY3MJDBdzfWkM8iU2ihjGaPMSQ8Hz8xVTzLL0NSisy6GzPo2MGjEFDQyGXDUrrMVF0WHpVF5hAUmFC2YeMgKCIcSDBh7DpkYNAazDDhJASQMUj5J0wmFUrxIoxiTYMEaB2jp1my2nyatA1GOGgcpFUWlMIw3BTdDQtT7L3h5QmOCFn/DHgUYCVgCUBiQxwSKbkdahhKqPAAc0CxCaW5EZ7fkUbjK3GG2tMQjAQAPRHFgFKGVmMESJrZDnkVy3pjhjzRKUPDryLJmgFBkoAqD6lq2niJUBEDUhhmK+EAREEPKlm1WLFRTKhRWAkwlwm4jOy0gFiAWCNQNSg15BQcVNBohrABYpksMBVNEYwAguKaY5hnGQuCQEEIyWEFigxfwDXjqJiBq1I8CIZFBkI9oBTAyAQrEKIoWBw0UkCKjaUDbCJQUXHj0QzFDohEdMLsApjCLQz45VLwHP3EzUDIblR0xCUL8MBqCdzBwE2EwSwJBMLLK5DSJgAcwrsFOMqBXZjBUQkgwKMDRMBcBqjBYy2ExPQJ1MDQB7TB1wdYwaoPpMZZAvTkGFjyc1TL5zDO1qTWAajZBVDDsvTtBKzQI5jEUtTbwmDFstDIoezDgqjMZMjNkSjBEbzAgahwoVGQuWwCL8wmEYxADMOdIxWAMRhMYkh+Sg+ZBiEYmC2OhsYCCgfFaPYDAujAITLAgWaAIMHCjGCDAlQADMGYBAAya5LQChAQIMUL/++JkbQz+wmTBg/3UQAAADSAAAAE5NZMMT/NSiAAANIAAAASOSRM8hDHQwHJixkR5shYCsBc4CRIiCjV5Y4QBIWYY4NaPEBYRKR68asaCnJiwbMhIOGozEhUtl5Fa0zy82QYybUOFm3SGjLCqMwAAHQgEJAVgStGWTDkgxZQx1c1Q00x0zDIywM1CQtmPNQoCNKZMoBHgYIDmgBKwkQRCkw5s5QEYGDzQMMmRDhCFBCm+Z8IFggKIAgmaYYZo+mOZAYaMkaYOasuHGQsGMYaMhEK0Rm3wCWohGCEGPFMzCyQxyMGiioSM6AQ3EakyIIxpUGDDEB2PJ0GXSooAQ8Yoka0gIApfgRDRYSISZnHQGaBUww0UFK/BUJXfOZ1TH///+8BVHMEECDDApA2s2TOYIMb6PRzoERWsxkUEuMJeAdTLKTu4wwkA0MN5CrTQ4geowCgCSMm0RSzBBAcowT8DJBwMYYbQOIGGKgUpg1oBSYH4CSGBjCERiC4LIYEYCFmEGgPJgCQIUYDaBTmnwYbyT5qpbHOJaY1exowXGrzeaoZBklemWxcF1mYMLBh8+mJioYiGJmsNGSDwa1Ipg4UBa0B6YLTAwG6RENNJHNqBNUMEAYDLzbpjHkwF3NY6NGtLBo6h8SSEQIAEi+pk0RlCCeIWXGCFj00IXG+BGHfl8WJKqqLF/zIjwQeVlFlbNEzQ5GJOx0ynMKCDJGSqQCwk2IhTcwsM3Z4WNK1mEVhFM1ptINCgiNGUJiR80C8wwwDbR4uZ0QYUQIyY1ACxIwxluxgBZQDIg40STkBwUxpUyYMBIAuFBglWMiEpxl9zNjANPQ2MWBMCiMEBMsTDiylCAcZMESkxAYKIjYHToDBIKYAw36h4cBTXMElMoGS1MkhIARYHizALA03WIigQzYYWYAQsYgkYA0XVDCQqPMQBMkKMERM8FN0MBJkIkmZInPOmAIFYIKgDEuTHEDchBYSYYa7hWNHCzout9iysMGhBkzDpgu45IiYDPlXOTzyIyp4xkUBXMCVCgDSsi6kw0IJyMTtOzzRQBF8wWED5NE9WEDCIQXMwSEGbMBoAJTGSSAckBSjAEQPAwCwIwMBxIEDAAgEA2DUznygNpS4wCljCW/GTmYQzxzmWmoYaaJMRtU4Gek8MC0zGcTJ58M8IIxyQTGhFMHgIx4IjFIQOHicWCRmZ5GG02ZWEhjw0GRkCY2DJiUEAEDGJiUYaBRyFRojAwNAQ4Gpi9gwkNCDMcSEIQCFwCfMSqAAYBEAE7MiNM+UCptaQQkMyQM2cQHFnxY0DBxkT6gxiDpoUEAhgcEgzDESYUzEiSCMiKFBUE3QBPTAFR4ELJDOizxhTHGkBIKOBwUwgchEodTKFgKOHAJmxAcbec0CI//viZJSG/e5kwgP81EAAAA0gAAABPGWRBq/3cQAAADSAAAAEMDGaImSTCRsexlsjOHAM7QCmqfGZEiMkJVzEyl5s1LIJmGOUG7QDAUBOgosBxNYcza6ADHjQcaZIw4yZAxJQygURkmiqNlv52fMkEBB4ehFg9XbsFRIGTmXCsNRFYCutYIxBlNJIoOClsTKr1IAQKVQYAJl8UaBQ0BnzJEUFoCotF4aIJKIGsFERYEgarUP5f////7oIGF3gXhguAFEd+O4VHWLHYJn6SJEYCYF1mDlBJJtmJQIYHCCsGAaKcpnlgBAYKYA8GorKLZgtIPgYF2EBmDpAXpkSQ9MYZACpgYLxMIMAzDCbRkQxO4FgMYSZOth1NMg5MVSAM1R/OKwwMWy2O2QvCEjMwg/NLwbMLxaMQSqMEQeMtiOMRjjMAhABogmFQigopjI0uzTsIDCMGzDFGDIwWwcThiCGRhkSQsBxckOF4wVAdKMxYeMBDjEQwwERJlMaKTNxIEAzTgYOGBmIhDzHiQmEgMADReYwKDStGzAg0xUkMALQMflUNMcGjMQ8QgAYWhAUCh8DBJjoiIwAKkqEorBQMKF7RUaBhIWkKAIVJBI+MKGgEgNKEYUBwEDJhsYKYmHmGiIyVGFgYJBneMKDTDAIFEqiBhBiNE5h4IZaaMGirXzCA8YTDKgwx4NFAAoIjHToLB4UDxIFMWMDGAcwwcAA6FgUoLASBltUtRYVASYMEAcTGGiowAIrmIFK1TCxJmqpTJCQwYqMABjBQkwEEIRgwwPfKJIug4IJhAyIDKgYYCZhxG6yfQOZwwBCwCYuFmMCIXFGTKcEQ4YaRGOAQ8NBYWTvCoCFQFkxZ8LCYIBjGgsFAKHVAE375VKcMP9//ycwkcIxMHjFPTwtEss6TijJP0GKdjEFBRcwHEGUNj2EgDFygPAw1tYtMkAD3TAsgDU08dCOMB5ArjBUAY0wdIA1MkDBwzB2wZEwDQAYGQYIwa0OnMU+AbTAaweAwjYCDMCwAUTA3AREwNYB0MCEBAjAAQTUwg0FeMBYALCU/Mk8AEKmHr5oxqfqwGoNJkYEBBAyENN3GTfCE020MzGjOXo8hbMuAUlDDkADHYYMGfh5hooOlrWyYSneDD4ZnFupnI6CUEjAVJBhVEMIHAKiYRAFcIKAmvbDx4ygoxp0x6Iy6hCAEChJliMvBlMFQgNNARobV6PDCIeCLZlWaeRj3YiCmHJFxAiuwIu0QvB4+YCINlChsAmxsTSq5nwgYCtmILg5CIAYAKpdA6QVEBKwGBb1gAYYoMZMgYo6Zc+Z9oaEONAAaUQpIARc8qBCEMHSDpzwIcTBKq4dQoauGbcaZV6KaCqXMA1EZ4GowVNCgAwIdCw2CgxdUQLgov/74mS8j/42Y0GD+9UgAAANIAAAATnFiwYP91EAAAA0gAAABAMEAMWiMMXM+IHCpkgyF4QrOKSMQVBJ4FDhoMZM6CmyPoOqGnNLDG9NDT4ZNCoEzJQ25AADQUBKL6wjdUwbktBxBBETFzNwwcMY9nE/qMKgB7TDRwCA9Z9iwPllR4Dsti/kyIoLoMV1DojV+zDEwnICkMFFY3zEFQZEwYQP7M4yQrzBkAUswPUEnBQQ6ZIMKVmByhGxEDHmAGg05g4pAKYPgCcmbcZHDKNmKojGWAjmWpsHGhXmQy9nHBIGHBHmN4IG4gJAYoCQGg4YTTwXjEMADGMeWYmEwDmI4HmCA7mS4gGAYSGGI3mVg9mLwIGGQSGAYbmAAZGGQvixHmEwImAAEFx1DDADDIGStIHPQIkGjiQwGBolizYeCG6MA5OgiW4ZluFiRiyhn1QoVXDGV9mhHkhkzYUWsgZ4OCzCizRACKGZwADSgyWGAho1BpVBc8yQU1gooTGRRCgg1BQyRMz60zlxTUwr8oKGBDkRgBEVhw6yZYUZgeBn6CAyKczrEDNjFAC65sDRRAMgEK3BkzrNTBphZEHCTBKwsMC5cxCMhLmCFGFGDTMYCG0KlpBETNsCHnRVFDQ4xzYyoYVOgbyY0eXJYEPGzEEEAo1ZMghAz8xYoxI1r46BEgpmHhizQcXMcPCgowgwxCALrRUIaQikrFTOK1V2ZlgEY1OXpEkReSCigcYgoj6p0wAILFmVLhYmHM3iB8Bo////3ExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjBgQqwwuwPcP2gjZTP9vk4y4FUnMR7EhjEZBgU0LRFoMLAB5jA1FnMzCEO3MATEWDH50W4wWID2MDoA4zAhQHQyAkaqMQSAMQMDLmC0AKpgjBDSYfuC0mZQJHgpfGH4VICTFJMTJE4TEZdD5pQwsMhiwQhkEAZkAAhgaB5ieNoKJEwtBYwtCAhCEwfAJ3TAkBTLkKTBgMjF1WTIAJwM1BgsE5iiMRheCQyAYCBwQAEYFgsawkaRkZUMLNEly+YOkJCoOkj42oUWCggmNJ0zgsAAo97DXIDBtwCdMCaFDgjBiogyY02w40KIoImADgpmCqRihYclQTGTChkYEnDUDRwAZsuYAWJDC0ZgxgGaGeqnBOGGKHCfgkqCCZnxgcjNuVMujEakoRAgmckuBhAIZiIiYR0Yk4j2BpxENNsDMKaDagYhMMWMUHA2RQceAAAUY0YBYo6QNgCHhJhikuNMLGlhAENM3BI9WRiQcAHR4MHhg00Qsqi0GzAjjE1Aw6BXJlySLYVBAESpWQDDMnQhSPTHRIQoGIgpQkiSmzfjR0WARSJwISAo+ZEeJLDSjjlrQhL/++Jk2I/+emTBA/3UQAAADSAAAAE6eYsED/dRAAAANIAAAAQCFxlyS6jCQiJ6JGTKiBg0BSyMpckt1GcMO2TH//qMArCazC1Abo9etT8PUcJ8z92xlsyGMLIMVcE8jGCVrExOgHaMRUQrTVlQQowAMCoMN9UTTApwNYwSoDuMAnDEzGTCNMw40F9MB/AlTBrwPEwfgD8MWVBQzE9xTTkljEgRzDUFDDgbDg8HjI9ahZTjEwCDDInDQkPSY0DEEVjMouDI8GDLsaiqAZhSBRgwGhhEBhgqYpkGDTRTGAyTDoRAMJBgKHxioA0GAAQAuEZUGAxKAoLOAicdMkFGJ2woc3OSiM2jN6HMFSMcIM2AMsqN6WpDDNhxCY0gZx6ZJYFCBwxoqUNiOMeLMMHC5UO1F+zBmi4Q8DMmQMcPMeaDAxngosGNqHC5QsATLjAQXNuiLcgiWZpEeoado6YVea1KikRazNkTECzoOjamxGcEBsxwoYSEJ45wg5ZQMeB0YzQQkKgZeFR5ojpkjoC5GhQGILgYEmAXLNIEHqYiFCNKNDwrAtkCwuqaNsIRxiigiEA0cIwSm4ZgBSszQoxYQ1A9YxqTowAMMTMGOXQbMWWaYyNSGhgAAEGyAEZMOY8uWQSDCAgOukockKGAVgQCY0gb5QOCRgGchiYsULdSgKNCCYWFDAYhYaFwCKbNDHoxwDZq+3/6/+hMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjGZQ6kwmAM7PVwNYD4LagU+A9I+MNjGDTBWwLAye9EGMGTAzzCFB3U1GsHEMJ4BBjGhlm4wboDhMFZAezAzwiMxGkiAMDUCsjAhAE4wSQDkMISIYDDMQUAznO86AKIxCNkLg+YXE0Y9FAYEpMc+jKYikQY9heNOMyMxOGcwhLgzeR0yaCEx2BwSNwwcGAxTAUwJJsEgWwMwuAsytDQwcEQxWC4wMB0GgkYAAAYdAiYWgQYTiMaduEJhUQyY1QQv4UmQOINXtNSLM28NkFCy8HDAIKEnQIDCxc0RQtuZRQIDQOWBZwCSwKmHJHEAMy4sSAiFcb8qQEFSKXmFGg48a4QaxUaIkao4aggYRUYsOEZyzpqxQUqmWAgk0ZxwbIccwcDmZiFwZxFfhgDxCNBL1KwzoAezmVNiIeITgs3WwI0JASMcdGQ5j0IhQiSNqxdAMLmTNCxMxYMwq04osyG8z7iTgkeNAwYlNcCSbMgxEKglBrEVhERYQlBlWWVARMw5FBYFBiSEYYIDglMYMEYIwZIAZcAVRJpAhEbMSONkeCgoVICEOAmw//viZNMP/mdiwQP91EAAAA0gAAABOWGNBg/zUsAAADSAAAAE45LyiAWFwZEsCw8zC4zbUuIWCySaYSEgDLU+AdASYMOGU1VLR1/aYMoGcmA2h+x2vagyZVGK4mmYIQRh4AGOYDWDBGaFH2ZgDIVwYU0KlGilg9ZgywMsYU6q/mF0gY5gwoIsYDWCVmGCEKphTAM6YBqAlmBqgBJgxI7kYO0BrGB2APhhiQB6nIYAmASABjHwBeZ0hp6dJA0XmiDyYuUC6zFQgMbDo6WqjUhOBgwMEEIxsADEwoMBHMywODDIpGh0azCxi0ImUiuYVHRjECGNAYYsBpkIFmGAydBCYlKQwgzebNSh4OETNTDUGh4ybkObWWZhMZ9KaQ0DRIdqdkLmjCiQFQM6tEQBTIULhBwuIYpEb4mhULXiJWZYIZlKGRTDI0lwSGAysyYYwxUyYkcDmGImWGDpkAwjU3j4swUTMVDGDJmAYCqk2osBjUASUEPSHdEYseIGVKh28QxB64RPgSFMkVWOCBYWSA1WZsmIgAWIkphCcaoMvQwxA3iU2gosMgiEJCRU6xcQUwwKZ8IIyBjzI9yEBAy5kwDwygM5M8CMxwsXgKxYBEJimNBiJWTQSYGheBiI9eIBwGSGLGg42YIBFgE7LcmuGhdc0lCSY4ICjZUECE6YhWFTKDpMEEkUMoKGEGmYUkRkxTEGAi5EAYoRTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMH1AFDD1QSM8LpO2Pq4TLT6QA2wxlQBDMI5BYzUAyPAw2UILMBTM1jPWQvwwMwGyMKCYejBtQVQwbQDPMCLAnjEWCHwxAUBlMDuAUTBbgFkwT0SaMQOAhDes8MXQUxAPDMwYMRxk1WjzHMnPoDQrIRlgrAMQmPgEYJJQFKx2wzmZhePBMwcHjKAoMNDcwWtQdaDGY4M6QYQhgySVyEJBCOMFA0EDsxkPwcODCIYDk6YFC4JBwkxh0BiR7WCLLCILiRJEALMeJtHo0JYwt8G8zPizGIjSDDdLDCUTbsiBuDkRlZIKHAMWbMMUFzNwzFCAYIZOCmp2BAMAAUnGh4eIgwRLBrAwS8w3ozhslRGkPEA87g81oEx7g2YMYHDwUHNTeD00DBmTNAggWRDDNnDPnDAKwZAKwhQrCok5OQxa4cQgY+hLMCQMwoeQxDE9YkxhoypkHCDKFzVAFMTSRx0sZYomYZLMGJjLSANkM/aM+tGs5gAxhGRjCIQYWSdMMIhCCcGtwUkErYYGAokKCSoSUAMkKIir3mCYJnl2xUGHIjOpzYogc9VrMqINujHASMympv/74mTYjP6dY0ED/NRQAAANIAAAATnhjQYv81LAAAA0gAAABCzwCEhZgVQhQQMQDNOZMCPMqfMgKLAsTqDRSKUQoz1f//9I4mI7iMRhUYWqczaREm6qiv5usRd+YVcBBGBiAQpogQnWYP6CPmEWnWBllIDIYLQFuGGbKZJhQQGwAAEAwJQEfMTtElTDJAa4wKECaMAVARDBxQkkxBQBVMCXAGDCQwBgwEsADMAQAMTGhBNlpYwwlD4STMrDcy8sAsXRgeCEMGJBaatORoseGBQ8IhSYlBQkWB00mrhCYIBZmOAGFhGYAABgcGBQPgkJAIpGBiEGD8xEGDNjl8GMOjVoyKcziI37csJ0xzBix0UYO6apCEdTwJDApSU2Y8IDCp+UoVMmXZnOVGDAiE0IWQ4lFXJilwTIAmMUkHOAgJsbliQozCDDShSoLBA01BszgkzmEOHFUAAThiE4hZgpWARgZTNMuMkyFlCK5CaCLANLqNgYAQADVmgcGNmBWIgHLrgY0axwYKEYAEZEiCBxjQ4dtEIc0TUywFR8FZgceAx8wpAMNpFBgMyZEBOACXMokNCUHthkGRAWesIWBKcHOQaSYfGErCBkZk4Yg8KgC5xqDgksFGpMaMTDMivBoMCozMHDQmigKb4UMKwUzMOoNSPMSVHxBgwAZBaeNGwUtHHwVEGwQmjSA4sBrwoyi6aJNKSjWrOKSkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqkAAJAZATBIARwxBUOYNXULuDVa4EI1fckFMKJCBgSBFmVWg35hfYCGYGgYlGLsgKRgo4KsYaaaPGDJgDRggQBIYFCAPmIcAUAJBkQaAfmAQAfoFDuTB4AIM86wzxp0MeBc0YNzP4rMfAgweqjr7dMUBYwuTjLoEDhWYAFY8MDWQbMSnEw2CTBQZERJMIjAxUGDTAvMDg8w2jErTGgZLzA4CgkJmMwiAAYx4SBKV6vjIpTfDhKqYVeekgAjYs5N2cUHNSYN2uMYIEKYzpYS8GjsGf3Du8QKDHvgoSMyKJgYOYlVORoi0BrTCmoGYCxstyCgBgFIIQmhkP2LkwQiDDSLam5gigKsEJQRPyKqa8qYiWVThKAZ+WABj0AqZZkrGYlQYA8HNyb4BmAhFSUKgwqZHH4ERGSTgAECAoJZkzUSDMGMYsAQQaBCyIAgzABk6DLKzJnDbDS2wUYGHEjkQzqAexg4Yh0Bq0eQs2CyEvOIgwgHr1M0PBoI3Zs1QkUGJMsrKx4jTLaImxYL/++BkxQD99mNCS/zUQgAADSAAAAE3fY0ED/NQiAAANIAAAARjAsrUmGDpyjpF0FKDJtlWGACmLDGfBjygSSmZHiJGX+A08yCUGmDRtgMyCwxAMZEVB7y7YMW3FHTBmRJA06lYfN/0GQji9x9Aw/0CIMGwCizHyh74wZMElMJhMSDCyQDQwS4HHMDMJ/TDIgDMwIsBkMDNAezD0w5wwS8HkMDVAhzAMgCcwLYS5MBIARTUDpPNDgILxggbGESGasI5hw7GmzuZYGYQKTHYPFkkTAkwcJTbIPM9CNYFIh6gpho5kyhr2gYrOyyM+IELcwT0CHjBbzggQeoPGtBscyI52zWqDHhjDqhBfOYbESIhKmB+HXMBgsGkCIqYlkHg0FzMgjZHjBkzPkTIiw8OjyYsoZIMTZjDnDa8BoSZIKKDEFxGLEQExycRg0zAoIVADgQwPCEwCQGNfHjIGDOAHcZN4BRojek2ovI8BgDZgihqQAKIGgLsNMYcMUJM8MFixhzhiR4McndMA6uCWhMHAI8tOBAZgQi8wgyZucQgx0sXBEJBjJkSZWKQyMOdLnB18yjox6Y1ZAxoMSVlAksgIGRWYQVDCYKXiwkwkYAGkAAXSrbCiQVMhcqiolcRMAEZFCoWSAIZLCQS26xQaAcsEHgqIFVARLM4HHUoXDGDAAYcZouZNyMAiyBuA5lTBphA8DfOQw5nJUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxtIJLMR9FqTQKkf4yplHJMzdN3jBLQpEwQ8OQMVzEqzBEQb4wp0iyMQJAGzAfwF4w7IQgMAoBCjAmAL00zGM4S/kxmUExoBMxKFYx6p029OwyMHowBM0xXLYWcEzUHkz9HQ0DNczUBNFMzE1M0YTJC81MYMOTjlEc1BEMVjDPD0zkQNCOzWHQM4DLzEzY7BoeZItmHqBpBEYG9mLlA4ymBAQKIAyZGmEyIkGmQzwkNGSg6xMNcjMCYygPMdDjEwoKg4QmGfC5CYmkB6MpnQOIgMyEfM0QAWIhQnCiMZcmmKt5rDcYGMhlOJGRppqZW7G+DZnICY8eg68M1XTAVQ09hJi4oihEFEBWDA4yE6MKMDaRI3xpNzAyhPbomWYsCGHCpcc1UkMkDAshmPrJjaia8AmCCIBNDHWsxUDMhBhCAhUHIg8wEDM2I0xkhjLC4Ci981wtOJATQCAyAuMLFAFFhhIIQkLl5gEeaAEGEmAIDzeAsADYCSTQjkiDDKwUwZGMhIjESozweCC01MiMqbB4XMOCDImYxgIMDEAKSmcjprQwZSSmnjJjacIjQFIBhggGEhgY0YuVBxQZ+XD/++Jk3g//V2M/g/3bMgAADSAAAAE4YZMCD29SgAAANIAAAATg0aYEhjyYWBApjMEQhlAMlEhkcMWBCQxMqUjSD0DgAyGiNlBJwDR0OWSECbGGTmx4boY9BOJmprBGhYywZJ2QZ1uwemfqMiY/IdhiwirmcwpoaQSLhkCD/mze7ebAJN5ibAvGIIGEYwx1hiVA0GDAE4YLIrZlojCmGyS4YyApRhfAwGIUGIYWQHhyAIbaQh7ud8GG2IJgi8aspmbIRsjEZ4ImjrZt7eZYJGHCwWHREHGRMZltAYIGG0nGHDG/SHgDHVchBc3RIyQw5hQ7cE2I4v0WcFCIXBBzg3RQFGgLHNqKMSHI2Zjkq5gctMq6BQ4kDmmEGBdFS6ZMoawYApBiEYSWMpBMKMMoHMBXOEeMITB3Q2eYrBgGMOBjPqTKjzIEjOmCbwIEpgG4y3B0s18MyAATTk8Uzrxm5gGhiUBoVRhTZlUYQjEjhgiASACwEvMZgwFXJGxNOiCzk0Icwow1RUSImTAiQJlhgwRAXPQkFrBs1wAFJihhhSpG4wDs16w4KMzxIz8c4j4p1AFIZw0apIFhRn3osVMVSOqCBowzYcz5BJAyJURMQaiMqAOhRDGwBECNSDDggMEBMjKlZwI1iyIcXGgWhUGJETjHDUuzZFABGU2RTL6A5QAnYISmoDJJCEAgycY0SkwMCNGBdNj2NvpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMHKAtTE1xJo1cSHUOro2Pj+wCnQxnkL0MIZCsjAvB0UwMICmMEuSmDTFgSAwzkBpNj0KdDKFQzAwRwKJMDsCPzGqyaswGcDgMJdBlTBuQwUxDQKGMdNDGzHSZTzc5TJg3zCgrjLIsDM2JzQs5zz+hTJUMTIMnRZQjCVMACXhl4UBiOZpmSFpiWJYGFEw8Fow0DYwJBUx/HIw8AwxlJgzqJgyEGQyQGYwkCERkQYHDEAAoBASGFI4HOVHEaGcUHQsHCRGqUwIBgIcgOI8NAqB7UHCwE7BzIxJkyKkzY4cBmaVhc+b+Od1eYc+XfNKxNErNkJMOkNzVNanOG7Ni/lgXHBhMwL84L0CJTeCiqOMNSNSIXYkoZAmKqzQtjDmS1QQUEJQwwoWLgkEGPh1IOHGQGSyGFDCw0WFGBDESYm2CzwWAiRYLlgYZMINgEEDDIpwUmNADS0MHLBRdK4lLmsPM4EkoYHBJcUfgZOvYBEDApziITYkF1AV2DjhkgBg1ZhxpIUaAIh5gx7fmOSCwAHQ0bkn0tUKDFkAchhIJTGZQm5AgRqsUwJg2xUEgDXH//viZNaP/pdkQYP91EAAAA0gAAABOW2PCA/3UQgAADSAAAAEDSiBAYJQQXGF4h4MIiwtzFTpIJAgIwRQyRFQxDkUB0lEKnW+v9RhvwKgYU6Bum1YuMpgp4hGaS4pomGthg5hWJCGZFKdpGGBCJpiepz4ahcFfmGwBM5svIzsYqQDCmEDBIJgWANaZJUKqGDQBLpgfYFOYQyDXmCijnhib4KGYfSGd5BIbrNGaWLKaTN+bLpoZsFicSnQZNPKZGLKaOBmaJCmZUACZiECJROAk0McAdMtBlMOiRMUi3Ap0jo4AwSAKHRmUTJjGKpgoDZiAHhhoChjGHAcWZiaLhikOJzHpliIWUmDTA18MLDRqjZqgMQA3kZXGH0GlDmlOi5c/JsLyi9406FmwYCCg41oE5A40a0ENzTqgKAOO8BRNUQ+dN4hIBJmBaPBl3plR5aI1BMwCIx4QLJRIEYoaY1WOozhLBAkGBQQ0DiwNKCEUZIqFx6MwJHgkUZxGFyDYQ5yhCYwWWoC6MxoQEBRKEXCLzIYmXAmRHFrSAMUKwEvB093DAJiyxkgA8DMKUCoocUA4CZ5KIlAUBmNWM2RdCw4wx8iCI4AZMPElhkCABGMmAwoBKUjIdARcLgjCBAUWLNzRZgzicDgQYIIC6jxKQIQxiw4VBLuIkhfIaLAZgIAgFHKKNeIBSywEkEBIWQiAgYoYm9JtK6qTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoABWMIuD9jCgwhQ0oyNaO+jbHDrvToMwiMHhMJeCQjNGiyUw4EEcMOfFnjQGgvQwaEJANXWIEzAFQkUwdwJhMBpBUTHORDQw4MHgMMYAgjAagHwwRMewMLjCcDBFwUwwsYCDMGyBOTBUAYEwD0EqMD2AxTAyAXcwo4BiMBuAujRfAVfzq0wDfBnFGIbI8wQMSZzXjkyNrB2gZMhm4DRqqYZ0xGVPByIwbCTGExhoDGIYsxonETIZhBmoYhIwHRjfrAFKBJU1RsyidNICrDDJR46ZJSLBxAONeGNyQMoHMOUIAwKvC2sFJDfFzMFxqkZoCTCSA4IShm2CpjEgk61FQaACgZMUyi0w5Y0xAIVjCYt2dJmY00YsgPazkKTBCCaQAF5WKNEUFRgYWHhoOlmNPgQSWC4tXFnZlXYQXCiUiFF/gCaDF5kT4thMiMMyDEhBkSqNgEOg40WgEjhnpZzgxkQSqgFToBTEiwxKGRRGAMAnNWPAIJjRl0BizpmqhmjI97HBg9KEIVmiQoOQhDAFBhgOpixEInGUMJCGNXgoMbBIiCCFZjz4XHhhQFGwuPDv/74mTXhv6jZMKT+9UiAAANIAAAATmRkwrP81LIAAA0gAAABFxqD49sUxNSjYm0xxwFXEgZjlpk2YwkEV4zRkMGDgxfbeSetaGQIsYT0GrGASgf5j1NWSciUOSHQ4jlBiU4UAYcCEXGhnk1Rg/IUcYceETGjnA95gfYBiaa2UmGCeg3BgIoJeCAOExEYfTMJ8BezAxQZ0wTYBEMIpGmjD9gAoKAyBhWYEuYGYC5mA5Abh6FsGzjsHF43cSTEBmMxx8zGfTZY+MFpsywQDXJaNJjwwqaTJxPMypAzeGjKg7M7CIwKQQCVjVQECg2NChowyRTHgEQAmHgETEEeMoXZGeFlIADAQGCNIZMaiDoRxxQKUhHAJXmwHrtM6SOEbOQCM+nL6AgmPHBpYhLW2KPQSUQQmaElkzWhzCfQoaMMaIQQ0JAVAGojOiyqjDMgUFG0Kg6OHFDFigupMAiTOB2syw4eNIakw1iZlgACJGFAS10TZDiseJMi67ADIoDLkDKEQuDSZLNGURGKbBhIypUDNDBDEexGNC58SFhAkyT0MmBCtV6T5gjZmDgwYMcMlZa8dEIPA0AMhkWAQhFDAcPMOONKEJjIYhEYMAFRYAjolQYska4eJCSoMMCdMHHInxjRZwHpnC5kSqMq2wSgAL8xAx6gEFAyEKAzBHTFiw7MNQU9QpDO6iEAswyUwCcvKRFi2C1HmvZK0xBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwfwCAMbeD/TE+PcI2n7l3MPGSujAHQEcwOQHgNhWBATDMhDwwVcfpNKiDITAFAls07g6ZMDjAuDBRgQQwkkASMLUL8DB9wMUwW0CWMEUAZTAywjYxUAJEMASCJTEBweYwX4IVMExArjANgNMwRUAzMA5AhzCYQHYwIcE7NhKY1yOQMyTC5cMtlk1RBTCQgN+jM3wKTOIbMZg8woZDDImHoaYcG5vAgAgRmMSmYXHpk4RmbDEYbGpgoRGHBkb4+Z0qdQwdkeaJ4d0mLBDIsTKXRHaONNM7gNwHEjCIhvmZhiAYUBUodFgLeBRA4AEDQ5FszYoWeqgMinBgNX5hyDEFTGCDCQUkBG+XGhDFQ2VT67kr1DSEQAmxU2HGcGqZLZDBaY5wwICXmXNBwAGq1AQQBMYjDggGDUxMMHEp2VZmSpWrViMKkNKtNm4NYUSpDCIdzNaSIrBjSJkhBlwoXImSDGzAA7CvMwAAzogeSgKoCjRfAicoNhc2YQyCpYMIlBoQjwIHFiwGIA0CIRRCFQGmKAJomfAAkeFkxcT/++JkzYz+v2RBg/zVIAAADSAAAAE2jY8OT/MxiAAANIAAAAQrajlEw4xTQwAszYEcFgoU10wKEtoZAYZcehJM0FFQsiM0KNwKKxbslU4ZUhPCppNILkyIi2NK2LX7///eAUpGCMBYpgvIR8YPa9ynGxj8ZxCAc4YkYByGCcgUBm14LqYFSA7GBlE8Jk4wJqYLWFdGPSkSxgroH4YOkBjGBrgtJho4qCYA8B3GBNAAhgW4CuYJ+EsmGoAkptMgnXIMaMQpVExj4SgAZHJbSbVZBiAMmSiua+JBrcwmIkgaGHoVEJkEiGNkMYDI5hUHBzQKEmY/HRhgMmGBOZSExnoDGIwWGBAKigwMJlZQw3mHyOYHCZgwLGFAQLCkwWBzBAiEipAZfQoEIiCoQCzHwnFBMYMCQcBTDg8RrM1BAyaKSEEQ8KCIdCBgYLFxjPiM9I0SDheBZZnhGOYbrYaGJuHOUYJT7kyZlll0gdY6AgCIThDwNFPWYxwqKBmwI4kuo6paZYQNEA3CiJtHIgrCDwRKKHJEJoNeVtMEg4ozIZFYjeLZ+GiA4NCcFEx4NAWbBpjBsuDAQ58kkNQFMBBCRCCIBmCi9OArSgwuMDW1N1Ky05jjp0LrCoyUABCggvoXXAQDTCQAINBAi/VWmK0igXYQ+FGxG2M4ms8ZZJorIyMeBSpy4EISBaQQyOpqpEqMmmilJfieZZVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVANQjDcg4cwYMQRMubjGjeWJaY6MY23MQwC+DAQQjs0vgtOMBSA5TBezvky6YG9MIRDBzDNjWkwJUM6MJqBnjA1QCQxa4UIMC6AyDALQTMwG0GFMCZF7zDNgRwwY4DHMMAAbxoEDMBaA+jAdgSAwKEAtMAtA1TC7gSgUAAjYQ0E+Jig4fMsGkLx5gQYoWGPMZp7CaSTmHnBiLsf2dmUopCCi5yRewcTI/GKgJnI6aaCg4mDBs1ho2FI2IwonmpHmKMGtjRc0C43hYxAwChTikzjVD/FjKTTTkyNCYB2YguYMoYcYYMkZEOYpEgUBHxnzRf0RBgK0Ag0wzA2SseMGXEFCIChwEbUAAwAIIlrzJlTVFjCkxaOAA5nDgGKmPDggMugDe2GgmSBQ5gTIsiAoUDXi55kBjBmfkKRjKrTJETDogIBMokXgEDC1RCUEIAssYUswUyhFNAwgAtIADxmRZiQgCCGJFGYDIZmSDIjCod3n/MuBAQMzIQSTF3jDjB0AIQRmRZIOEmCAZWMtINBkLiBMieECihMAyiiKsQQc0QhRl4ZAkkgIxhnBZlXhhiIqwMQqEmSmwGCGJJFlg//viZN4A/lZjwpP71SIAAA0gAAABPFWTCM/3UUgAADSAAAAEU9ACg1oMYOhjRdy46tAoEQAyuYR0FtGCODOxqaky2cocTvGijn2pgfAECYYIEhGiYns5giwH+YeqrTmGMBmRg6If4Y6UkJGCphJhgNoXAYGeGeGPCgJ5g8gG6YJuAkmAIA2pgphBSYPqElmYcsHXiXmLjJmSDamEKTmmwYmkhKHLx9mXh9GNxJGT5HmZxFmPAuhxBBC1mOQCBUwDBYIh4DTBYCQgezQUOTC4BASPphkBxjSLBgYDBggQhjADhgAMBicF4AC8FB0YFhkYDgoZGioDgyMCwFKAiMXwKMSQiMBwLMCQXKgJLoNgtMEMGr50ZAGZOIEjTdCASBITohSBhJF0aCgNOdwaYJYaoedoUNQzGlUOoK7AYKZIYatQP9TTFRqqahGYVMYhuNIBAYMC+OemApExok6w8CrjIKQdmXUTGzOvhQEssxgUYDo4AaKUTzHIVsJuhY00o3cUypcAvDSJgqoEwJ2RZkw4JECGaYYmZ9SIwZiDZiShkDRr4C+guBMgOHkotJNWFT2FmRoxY6ZN4WCgMmdAoE4Jhyo9rMQfMOFAS4HQyQqCgalBEXBxkxA4BQGhA4mKHw58pqZNcBcoNHErQ3E0DTDCSB24NWxJifBOZdsa4SQDzKIjEgQWBDSZzuhvTgNgmIDreSSz5fHKTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoITB5BWgwv8OBNn5uZD4Exlw94MXTMCkA0jAZAtEyW5JkMQkC7TA/1S8wgMI7MDXA2jK91ZkwsUJkMJ1CQjBawMQx/IT5MILANDA6ANMwPAHtMHQDuzFpQEUwGEJCMFBBEzAYwQMwDYBjMBDA5jQTSyeO4skxsOzITDMfrU3UHwCghEUDSiqNvmA1yfDHIkMhDgwyUjAhRNbpwQB8zy7zGQkMnCoxQGjOQ9C4iMyCwzqZw5rgqCAJwaNgY0cFRpiUYjWmzkG/NGUMmgHGJEAwuILaKgtGNqWM4fMmWFXQO3jQpRkzIkaQnCiGeRAKOIA4USGGHpCGOOB4kADCI4CAxjQwXLGvRgg0aBUYswkcW0FgoMJjkEz6cKiCp+NYqBAoOExpW8EgjMkgEZJg5IkIhbjo8NwK35nhpgy4KhoFghaCU4GAB1xI53BwUMJDJki9yHclJhgUxgsx4QFCXJEIkgIkh8woIMPqCCyAUUkx0KhxR6BpQYlBgYLhAYBFjYO4wMYUUVhkrjKmwMQEaRNpOMFOwsILUD0YOAqaAkkStn7AxcRByYkYIsadgb8ul8f/74mTXjP5JY0IL/NSwAAANIAAAATrljwhP91EIAAA0gAAABJE4Y9GIHAKypYA0iagiFzKh8EI3JFs3pR/1gEgJgOAJaYbACKG2jXxJmwhUEc+KVgGGvgPhhNwXEYKglImG4A3pgyyb+ZZyFBmChAUxkjC7UYKIAWGD4giRgOwKKYpuQXGGsAVxgeQFWBgkEwdwO8MUJAhjSJGzsczDBgDDChEgQXhhUUpg+pJxOLhhqF5gORBmMdxgkE5jKYACMcwxMcwVB80TDQx5FIwUAcw7CYx+LcWGcwmHUyJL8wJAQFBMKiKZFBSZslCY+CyYeggYYgyYjhObKGhaaBCaw6Y92awGS4gheX2MwrCLJgB4qaP6IJhRyqR21T2G9BBoY1MIwps1as0mgwKc2DUKqEfDjnyuWpeZNmARZChAxEzIYxRo0D4yy4EmDpAjQjAARMIJNCKSEBBI0S45SQ1hwwA8ZBmaOApGgNAxMxBEHLDGJw4GAU8QDggMTCRkMoGCImkEhioaNDIAREkIxYWTBzCqiF0YFOYMEOIwajKiIzwIOFOhCgqIYgSGEpDYkx6UDngWKmeDEwgwiYHIEuDCpQxsY8gMADVAjDvjBCzFCACYXwZBQFxZoCABZhYgZwQYYKad6WWMwlDM4NFmANiE+a4iYtGKnzCmw4QKATBkAN7ATQ06I0YAmQgUGKkE5nUQlIns6sW8akxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMDWDQTAqQYc30HCePVuu4ze3EvYwZUQNMKRDUzOY0WIwBwHJMDEQ2TNMQLMwNUIIMWvZ9TA5wa4wZcDoMCWBGzFCCkEwvEMtMC2BQTBMwGQwOMiGMM5A3DadzMDt4GKQx2XDGwlPwAowjdzKxVLBYDD8TPAzIThGEDFQxFFwYzUAKo5jEOGPxmYIP5nNamOjMYSDph4wmSwwHFgDF8yYqDB5WGiMEDIkD4YTj3NzCHleiGKX4AVoCkjkNjUOwEZKJRm3xhy5QTATIrRGeBERsRkDEmDSyzFqRkiNchELMkzJoJkiSdANJiMfDRe4zAkLGzFdThjzFkjAGQNIIT8ROAnAowwxAQh0lSwhBqsqSQAXUwQQhnAyaQGHiNYPAR0KaVAbJSYUMZRWVpTEhjMHQMWHBhiSppECbJg1SCUcRhjkuAZ4WZtUHHnpJuiJJhTAJdggYrSDQipQuLAUgCAwcXEZ4a+pVGVAhREksKsSyoyuFBZgjZkR5Z4wR8BKBp+ZEaHBjQkEZBUCRVDXDwAWMuujxgzgBKBiMWLAkW77hCD/++Jk0Az+M2NBg/zUQAAADSAAAAE5WY8GL+9UgAAANIAAAAQqAh4CFhceIR4KJmQLsHMeZNq4AwROUOImTFppqXuIscNpf////SEJgLAc+YTACSHJWQRZ4brMWe74KmGRJBJZgjYYEab8gSmCvAn5gShH+afiCxmBsgs5hWLZUYTMCPGBvgW5gPANkYLyWrGBXhdRgNoIAYPQCYGB8kORhaQOYYDcCdmFmAGBgMoD2RAdgiAwx4ACMAlAjzCQALMwAkCVAxSZr/mFoJiAoY6lmoZJnS8CBEzo+SEMdIzJp03QTCC4rCg+XMEXzMVMAXJqxSPUJqo+YKRDzEWdMuNNIcRaMqpNSFHhKAUxhMwIYyQUYHmq+DCAwoAwgYNIBE4BCQYSIGxz1JqUgKvDpMwwZSZmA4UGGdMGKIGXIFUOY4IRNjBgAKxBgQGphwEYlso6GKzMrgNVHiRi1ZjyR/W5t0YqZMsiDuZepVExoxA8HJhIcYEMY8oZsqtoBMhU0jgJBw4cW3AgsFM0A4iCg5+RGhwCQqB0aOBAcKNuHMEZFqRvqpkCpKJaIY1ILAwuWMWTAwMcCmhKmBLRcyloaHoTDSlQcGNqRKpVL0yyEKjCggtoLNVVDQHAyqYQwLHhAUQ0Bw520fwdcZuNKAjuRKgw6Yo0F04EimHBGpGscMfQMsYZIY8A9QhdFrAjuIXSV7MmHTor9lVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUCAAB/mjCzwecwTkDlNt5KwjFFXxw18AlzMNGBsDBhwUkzP0O4MHtByzAFgpUy0cFYMAaAYTBTDdkwgIDfMB/APzAHwFUwsUYpMKsAgTANgKMwI0DUMFVBuDDkAB4wYFjlBfDn+XSMuAonIxg1bG8jYERcwmETa4YFi8os1kzykgNbEUDI4ETxHhSYmE5j4GIZmLCkbLEBgwKhQRGMhaFwWPAIwAJAhPIxDQ3MGCwkC4GAQ8XTHwcGAgYBAZoIWmIR8WWEIRM2kAJ0wiUxZsy49C8x48z4Y4EAWZGIDiwwmHhcyJUg5K08IOm+JDQESfmnOA0y0ExJQQFDbGTbJQYNMeACrEAnTCsGtg7SbCKfOcZ9ADjIMbGKBmJKiyMOlgQ8AgsyX/IiegxMTdw4cmqNKyVIJDi7Rhxb5JejokIPGHKmIJGmGwAYMeBrAyGRzAxJQELAwaXNGnU7HhxlxA02NMaMmWNypEjAiLlq2uAQuDlZoVwkpFh5NAEBY16MLEEzHhAQIwQgaYgAEDEKdgOnFuDImRGMLSR9HB4jHizNHx1IYYgZc//viZNME/gpjQ8v81FAAAA0gAAABOs2TBi/zcQAAADSAAAAEeNAjUhDCjQCBJBhqCYNAGeRoAFCktks4vSF7gBMCwERjBdwtI8uxipPgcbaDbpUDcxIEJgMIiAxDYBgTUwJQDdMRqLpjSbQKMwY8JgMRWSVjDIwQgwOgDiMA8BCDG/CS4xHUGtIgOAwVwENMI9GwTFZgTszvcDcrxNOmIlH5mWHHBEgZGiB5s+m4iSYdS5kU8GHROkIYhABpxUmIBuY0AZEq00gICTLY3A4hJAoZDkBiUmBggGhOYAMg0jzDYQMag4xEIRZJGNipgIeEB4YvFUDFR8wUXEZEYIIIJzRRgKg5gxGDmwwgTGg8xM6MFCQx2QeMVCxhBBRaYOFA4bkRhQyNFggC2aGKAIIJElwAUESAAhECCJj4+Z0LKPGFmBgYMxMuUYIbsLAQmF5EwYMEIQCQQZFAMYGEDREImpkxeIcG1KzJwsDCCnClKVA4UmWCAMDxZABS2raYSQhgoYERGHgpggwJEoADBoiGAQaBjFiYoGTExwZFjDxMw4VGQgt8GDzdy0wJAhgdEYuaIHmFDpk4ODmFKMwBUGRAHKQhMQMjhACMBZkoskCDRMxMGMQHCwRoaM6MDEyJJaITABq4Mk8gkGhowgrAgeMAocaGShBQ7CxAnGBhkGApiYWCEIsjHRIEATKGAIIGDKhKAIYg/t5CTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjDBQ24RiEp4ecMQddq4/n1UjbRiLoCKYMwMTGrJm+5ht4A2YK0mFGhXgx5gowhaZeeYsmDcAvZgYYEaYAEBaGQcjPJgMQSMYBABmGArgERgCxPeYD6EpmBOgcBhH4I2YC4AwGAoACACNZ8pLmW1aftQRnIHGHE+bSOJkkAmDRSYRGpwk7A66mNg0MActi14qo44YEjQZ0MpSwwKLRa2GCCEaDJJgMiEwDMOBAwiQASJDFCTJETCrTNlgqaM2cBB054YYHgYKbpgSkjWGjINgCqNCUMQEM2hNEQMgmMAUAiIWtBZkAaJo2Bkw6AURghIYoIFSJYVl2zDBzGC0nCi2aF4MiktzKJTWogUGMGBRMHRJ5XppTplxaHpihYVFiEyCXQUSBx8IEjpUIZphFtzRgUrwCKTEAQ4yy0BKCoEApoaUDT0FPDBkgFLZGdNezAFEwhMXaEhpimRqi5i04GWiREz50ZKhUIxpW1kANLg4mX1MWaX8StxgEFgiS5jTohJAKyIDQVBGBBFrDTjTGEyYsPHh9WYcqBlwwWLCcxxUw4A1YowqP/74mTSDP5nZEGD/NSwAAANIAAAATkZjQhP81EIAAA0gAAABElUEA0yhtp4ChA4CYEwJSXjR/AQRXwQfNQVMOGDkZhSACAxBmc/kHfWAyAmIGhXJhAwFudUwyJnEEihpvCZl4YI2D/mB5AgRm3RtQYO+CfmDVJmRjHYIwYAoDVGivEdxgpAOAYEGAeGBHAL5jXwUgYOwCdmAhgP5gEgLuYQYLdmIzgKZkyOnvWMZKQ5gc7mt1KcJPJo5ZmqB2amBgBJQ12AEMjB4bAwNAU8Ndl8wSATB4aLKmBiAYCLQRiDDxXM6sYacoKdgGMZg4akQXMCg0wCEBCEAENXrMyiIEAMODIYKhDMITCwTdEAocCrtqRzEwENiP2Y2ubtSYF2aAGak2IXZrIAjWmVNG4XCxkw5sz6sMygKgJECUQZoMNCgEbEtxgk4JGoHhkUQLh6gscyyAyyAIgCRMwi82C8BqC6xuABgQCRgYrcEQwjKBDBN1PGLBlwwMuMC0GoJniocGERMyIRC2TuaYMcY5MZ02YsAQkjXD2RCIUYgaWbBSUwIo2wwLiDEITGizaGiYSmsYUOJGhI+DgQKCLtEAkmBmbHiVUFBxUMgnSFS0MmNM2VSbMkHIQ5kDYqTMCRXki2ZckAohdUYQGLUmXNAKiZ56ZEOYEUIhq3jFCACNBkkCnIwaYSFBRRnMgZMSiIkAWIGNEqBTxUtUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTC9QX8wuMJXPB3KaD76Gcc6tA8iMSCCOTAwAoYyXtC/MNRBAzAuWLQwSgJqMKxBcTYGSyswgYCnJQHowMUEoMb/DTjA2wFwwN4CmMA4BBjBwAAUxokCCMC0AZzCeATwwFwBMMA/AD1ATBXQEwwIwAjMKCBQTAwAI0zUUPrPisAMsFhAZnhj5gCEKP5hpSYiSmPOZjMEakCgodGi0DsAADwaBBS8CgCZMbg5ZCgqMA4KFmdVrYXeJOiI4mSFSYQJERIwgU3pgoOGheA4+DkJkDbNRQIDl5jihdszQs1IEyBkAEgIZABQSUmKMmHAAoYZxEm9FxCgAqEKmwqaMCNNKINONMKxGRBMGCEQNQGrnHSrmzLGIXA4gCmaC5jBJKGHCpjQgNPgY2DgJkRg02MSCBRUwIAwA4ERSQEv8VIMqJjxgDIJKGLNmtSChwHM2JmVEmYHGEMIOGTFjJAOzCSEI5GWBiwpEAwctFFeAKPoKoMJBpxGGEEoZqoEAhzscXAIYFEhLDEQkxIESdL2KwhjBwEGAA6NPEr/++Bkyw/+SGPBg/vVIAAADSAAAAE3pYsGD/NSwAAANIAAAATjBATdEg6iLJjOkTUkwNMXIBhJmhZnyAJGoJzCIy1hhzQ0FGSJlyAUEgIqis7djQe//+swscM0ME6EuTwKET400F7TPiGDdTFWAecwlULrMLzRejFTQeUwbdWqMnCAGzBMgl02eAtYMFpAUQcDWGABg6ZiXxB+YRYDzGBvgKpgkYGuYOEPVGJwgLJgJAHgYWICnmA4gTAkBdAQ8HFk8YtYRkNrmOyQY5JJoEOBidATBBgiNkGAsFAw0dzFY/MFgEBKoQmYSeQUE40PzZgyZeYEJ5icEGYx4YFIphwKkoNQzDihjXwtJZSZEOGLwUSMWBEKVBAY4uIDoKYGZIiogqADBhgStMWNC5dAcY0OZtSDsYUHAZkoAAVZtzYKBm5UGFNhjxFRQAAoQMpNoMMSdNYUNEMEcMIEHWKtSdgCEDVyzlLQWBV6YACyIoCp0GHHCocWGggiVEJkgwCNNXRmgQLjjACh1UABQoDMjXM8ITpIDo4sMgCHgpIJIkg4HM4tMIONrDMk1NCBDDKTyQxnhBnDVwwo8aoBZHLgoUngsHFXAQJBKkKDVxiR5JMwro0gRG80rEwqI2BEONjD9ItdBhS5WCARUyKUUBioIQywafLymWvAUqAWiFBtSxRDToMuILuoJS3BbQDBUyXAKBq9L9H2KkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjEbw84wtADQPutXfzzB8to1JBUBMQ2FFjBIQhoz+g6rMIDD0DBDlIQzNYAhMELBszbmTGkw+IItMELArTBQgHAwWUp8MLcCWTAMwLYwggFCMBoIiDBFQPwz2dY0hUEyhHAxsC8yhCs4KRMMMg7bCsxXEowHHke4wxyG4iBQoJIHKWYAgUkaYcCWCBIMBwTMOScMowhMRxYMGSlMOB7MlRXLpGEY9mEYUGJgmmAwUjAKl7BEcWcaUMZQcPHFNQuzOHANIyCJkCnAFg0iaQqcACSpwgad0gLKzTijZmgsCBqM2ygzpUzxwHCR12ADZk/JqRxErMOSNITFlRs0IcsM+VMeXMEKDIJm4Rmk4EEkAU2ARWg9k4MtGSCkhtNUzRNFgUHjRcGuTiIRQgYIkbIUYsCYBWaUsYQcRHRgcCoQNAodB9CYMaYAcmqvQDUjzGQq+ARF2jOlAhUZACYWyDnoVCA5Y1YyoUC1ijI002KwDPBpckwHUCak0oCgxQ0Y0CXBKCfQPACxgCCzPCTIDzYUDSKgsPAKYaHiEmRcAwmAS5hSJkhpmCzLTKMTAiy5oZHMQgBggFEjRlj/++Jk24/+lmNBA/3UQAAADSAAAAE6rY8ED/dRAAAANIAAAAQUiEjRMXEAMBFAh8AlQXJgpmjy/VgQgw7///+gxZkI9MBECnz4khqA9g6XKOs1JhzIAw0Ywb4ClNI9PODDiQJkw+czsNMMAODBGwr82ewnSMIVAoTBuQNAwIwBvMLvKWzDgwFcwGIBIMIBBMjAvRt4w8gGKNCCGOuTnFhMMcA4MAirOCRTMa15MylIEAQmDwVGbgRqrmCgYmH4BGTyoJAEA6GAJLGUxCmDgHjItGkYJGEwOGGJrmDwCmU4kGCABGEAjgIQzEoSAgRQoDI0HgQvKAxlZpgA5sDocCMONA6wlKGVCGAVkpE17QzIYWggE0NOgEcNmZNIwGQqAkw6IxyUy4AdOABARghYqbA6Yp4BmQXBhhELADFBjAszVAjEFTdGTJZTkNyEcvw0T4KiiqgPK5KTwqNTFCpkGDB50zMyZtR0RFQaMMejHEJIBMAQEt4wQMSDpCSaYayHGTDEUgwjyBRJhGACAmpBGZSGFKGyCCT8YZC20KNTCF1ZjUEzTh2ljY03TAWpGQOmJEmjBmGEGAHhQABnwivGrjGrFGOciAUX3NgnFVIBBm5eBjwwA4VXoADLFSy5mwgRhDEZjh6liwYcpBAAw41bxgyQFGGZEGbHCRRlZCRMMqM6BBgMeWAlMAkxpSYInlmliLcyMI//9VUwgcaVMEkCOjzFQz4wSyupP3FNSDIhQgExNAJaNeqHazAXgN4wikkQNP0AozAjw7407kW5MKeCejAtwI4RgsBjBg7UYg4HXGClgAxhBASKYYSDXGLvAT5uSvpqDCQCOoxoAgwOFYzHNozULE62O8w0CwxvSYz1KsxdFoRD8RF8Z2k+aZhGYgmUZKAsZFisCh4MDAVNBxsMJwTMO1VMqhVMJwFDBKMAhUMIwRMFBYMIgtGgZIh7M/EM0MGwBoRBtCBijBlGYMNmcCiQU2q81owQDQ4kctSFgIXZmdMGkLnaKmiJkxcxh44qgWQggGAQgCYlR8YqMZ3EGVUDnGO6+MYGN2sU1Bic3BNcpmAJQBUwA5wBizHqTgnjcsjGFDKqyU2WJZgR0XMkMMUXJTwsCNCcEKFgBboRAQjYZ5MZoYHGSZoaM+WEBiwAGamFCF2gKOChV/DQtA06b2QgJNIMMRcMA6MYEMNMN6dIAQjCq/Agk0JIZLm1LDKMeAGMJptGEbhWJLVnAYoIDQXHG4BmILAJMYdWaMKclESvzDGTSihrGisDnwG+A6iUbwyaahAZgcY5OZkcSJAMwByMUaGaBGQAhiJJoCDAU4BgYAoEjzPm2AJmxHKmD3r//amHZX5jWQKUwIAAR7KIAAAIZett60NDpwQIREGIOCAAIIECGWTI//viZP+P/stkQIP91ED58FUgG2n0e2GLAg/3UUIEoZlAAPqoGECCEREJtHgxDIJk7u73mS/tenp+7z1G4fl/4yuVz0IZ+wJKVBEOCJhIkEJoCZwEiAolMdAjGhczcONiHDaX8ARRshib2dmdsZiJkDmUOSjPAg11zMWrjbJUF2Z8bacI/GNqIhIBgPGQBKVwqdY8NyPcrl+fagJgmCYbfa7agJhsVk5GTo21AuGxWTo0bfUFZGK21266QrRkZPNHKCAVoyNGjRt7AVisVitGjnOkbaNGjeQMeGEYrbpAgxSC6NHsIZDF0c/CEJrkaNG9Ax/i5PPYIMkMFpApDAAAvU6XhToPX3WgzOv1FowNwIJMDICcDXQxgowJsFOMLdCrzTWgW8wMoEvMy4FJTBCwWkwYMDAMESAwjHbQfkweYMNMHVBGjArgLYwZsXtMRsAfTHkwTyg0jPYdDEIDw48zjYVTAk4jKd7TS4ZTFY3zUMmDHsozHAmDAUBDMwiDD4BzM0RzJIDzAEGzB0LTEslzAMLDCoNSqjZlUIA8GgOC8DCsRBoOC8Yih2AhTAoKhAMq2mQgXmCAOGFwCGIIngABkB5gWDgWD4xsAoiCwaKiAKCHQuEAT8FjTSggNeXUa6KDmYlGGnBnk5tnS8DAJzPfBAUUxNJeMAVMy9GihlYxaAt0IAAYIAqUAjR0KIxowMBAYy24NbmpJjVEwbMBSxqeKmAKcM8wRlBzwCjzbEDaCR0iYEUTJzNLTHiUJztA2Uh6YMADi5hRhiVAyTNaPMgtNcZMQXLRm3BmKNGPHGwaqxmGJFvgoIJiwGTGLJAIoY4waVQZ4gBhxihoCMGGkBSQhcMgBGMZOPAjKPDnqTWUmSGjAmQAmEEmuVpXDAABBTHkzLsSVYZoKaQgZ4GBQAhYmFVCAUMvjQITMHiJaiouMyJlzljmAXEKiHgQNDA8LPBQz//6qrr+fX/n3/Jfc3L/zLOxD7XFjl4C4xgqApGDKHOYJRCBprqFmc6GWYnAhJn1psmWGWIaviuxnkDRGMSZeY95MRsmrYmY2CuYYwrBlvI5GnggEZGwDxiFibmMyQSYnIfBkhipmBMEAOghmAWAcXJVM5MaEwbpZ//6d2/1fpdd//pzKjB4x84wlMCeOMjgETq9AkE8uwNcMM8BeDCTQfk0lQasMG8BSDBVyIE0SwFPMAkB2jHtyhgwxIESMCBBJTBNwLkyFoS3MQpBeiAAfMBgBITBMxukwkIBfAgIQYDwC4mCGAKAVALTAdgQ0wM8B9AwBMYT+AAiwKMcPXn/D5uwKcSMGApArciqAUAxgw8Y5BgQCZSZ8TDhIZJWky4ZOJg4VNFfQEwmLgYDBzTwUCCQZamHQJjRqaGhGgmhnhEFgECBxf/74mRgD/6EYsCD+9UyZeh2YAA+8HQxiQgP7zLJnqGZwAD7wYCwKSjJMY2BiTIePEUk6pADFjlBQhwcFcFnIMTsLMkjOWZRRMyQFshpQpk3BxioUKmsCGcAIICg8CdwZNOsNMSDNinMOjMGFM6pBK07rozKgXGj680xErTGpMFcMzZ41boFEzKVxpKcUwZomSqBEHDhwgBGAGDyY0A0MWET1YQGGzEjhhGHFjNBg7EYmCY0aVBxlQgwXNyhNICMmsM+aN3XFmAkmUxVVDnAOTg1GBAZgThwS5glptgw0fAgAxTQMaGrUgoi+4MRGRHG6DG/NIZGorBkEwZFE4anFuC/o0iDrJoloCXG8HGgAgE+bQKDAJuwoWWBysLRwuNASAwR0xCKXhDQZMmJdBCkKLwUNY+/H//3+6krhhgYcACYAoEIsAKYTBUBpLEzHLWcuahQRBvLPfmsq10YP1E5jy4xmUK/WYazsRlSPWGmeTuZu6LhoVqeGVKdOZxA4Jook0GBc6SZQqbhqphPmA2DECg+CYBtbrnQdR2CJh24OUYLUGEmoqKGBmGRNebDYOHmE4A4RgBYOIZBOJNmFhAUBgCo8uZBoCRmBkglBhxxQmYBmAUmArAO5gPQC2YSCH9GCkAbwGBeTAYwJYwEMOZMC5AjzAZQIIwYMBvMAFAKDAhwDI2B5N3TjhYU4KmMpAShuDEQMEzM0syAlCgWYKfmNiQcNlC4YWOBBsdoqgIVCqeY2PmXAwAFAqOmAgY0KmBmphooGbQjGIcTqMEtRAAHSoZGDKHBCVZmRJHFXEIpNcsDeq8JQDRAHg31dsc1LSs/BJxgRmmewNBKFBi01owQhs8ZdHDiEwKZDj5kkmrGAADPEJtVKAAsDTB9AieTqJiDNPA2Y8sQtmEADiHZKoIdYJYKZmiW8YMaMUQDKmI0kSaohhiBjKtgOHUxYsgOImGOi15OaPRmuCDKgNsEAisVkOFgQuSYhYjVKEDBBGUzEXYeWca0BQQEWpeFTR7swAjOdU1B6hprA0smvEQxfs9UQUhDqZEWFTSZweCMpgcYFlQoIAlSAUwsis02wg49CSYhhnCA5wxRAMI0MtOFs//8j12WQ+1xMcwAgBgcD0YSwNYACeMK8cE1OlbjFCA4JjHjRQUxMOIkQzygkjULAKM9wpA1ZB+TR9ApNJUMYzoieTRnUaMe0xg0DiDzcOL8NL1EM0jwbTCAB/MCEBQBAOopM5f6WnDKkAzpS9TECJEOsFf0+J80DaXSnMBUfAwCBRTMgQwMKcHgwqWDzR+EJMKcD8ySWMDFPAeMFoJIwXAXzB1LDMBQJwwWQHQMGmYFAqoKL3MAIIswYwcggAMwOQAwc1JsISwORnA0s8BE9Kc4KMBTTemhmyD/++JkOIDsHGNDC9rE8F7odpMAPPA1kZMHL3NMwZahlkgQ6jgjBgh4KMtdM6HMQANQAMCMAKsZJGNXF6jFIgugMSUCoEzyM0ZwpCAocgJQRBiRdxULGaJiNAIhoChGiEqxpCLKFChCYBRwyhdzwUUBw1JdB1BAoMjOGAJpLwQiUPQKIQdRUEQoSShcQITZhgAOVAZUXETHDhycoEJGHcmPHkKEvMWA6SxhhaahihocNMufBR8AixGaAV0u+hLEziBQ8BK4Mu1t6hF9OpoYNCl6owNvL5I5KQB/iqWIkAjGYaIj8bEMEkMElrhyYcItAw5CxdYkRprFjSssyvomtKjOMdGRkBCV5ioxwBOsBICpUv1xvgsKm4KiExAB49UvKg2DBwMhJRSYvZNQFcDB0ri7SmKKDwSy4AAMC3//1+s6krfRSsEBwzCVgaGDSUbOeOkOUgFLxtVVGGD2aOepy5Dm/8sZihBy0iGLC4aXKp1rMnTIiauVh7G2GauOc9UBikcAYvNQb6Ez17NvWOToutHfsvr7raVgAgEAIBGhgmKYyYK5rRDCmZiHscsLEBh3D0mF6JKYb4l5lcC1GKUuOaBw1o0deZxh/JjLAcmAkBIaYpJ1XVGldgfTH5hYDmXH4avEhi8TGSk+RGAVD4JQBlEMDVNMQD4oSAC6iYc0MAzgc0CM2S4BHjchDkGRl2MOAVdOyGMKIMuRNyLPAENW+DtDwkgY1roMtmCAoiGECgIwMGjPxDLjhZ4aoCCopqxwGWmIdmWDmYIHDGlQ0YEoPXAQgO+NVSNGaBoweqlozPGwg8LA8ganBQQwBp2UEJckzg8CmS8wCQmXZRA1hQGmSjqMiGamFCHfMGkIiAgBhRjiJigQkCKhQHGhgSIwoGSEz8xpQCqjZEzFowAHQEhzUy5dXJiwqDxdIw5dfiW5sQQKKGVBhwJqJiTZpFwcWJRRwGpn2pmA4VCCqUzREZEoSA4gQkQceC40GjG2MaCFowsuWuZRSXSMiTTAUm04itjBAw5w4FFRM0IIHLghicE6AB6ZAIGgUTHhEPBN0hNmLOG1Mm9pmUKgZwjiZ4Eg2ao6CrBqxxN/M4DOMiCiIeiqKq/o7WQDT/////////+FtNPiaZH+E5181Fv7VW5KWfLHDApgxQqOAosyAADUjYNTByjUozmFzWwhhIPQiyKWBjQRii4BQDCUYTDiIw48SMDwZasWltoZO5UtyPf5EWh1bgVBVwd2PTfDuRowkIY0M6qRSjMrjk4265sgMsmBDjCAAokwBYEoMHlByzEmQVkwUkbkMwyGwjCVQy0wacFhMEPAXzAuQRUwRAD5MFnEMzDmQd0zWiTZ6rJp2Zl6prNoHc7SahLpmMphxTMABgz+LTBI/NCpE0mu//viZDaM7Bdiw4P8y8Ju5UZhBB1OMbGNEk/zMMHCFRnAEXrITG4/MumEymZzG6gMig0CgkwGHRUTihLZcCgUJG0EjdAYIPjlpBSBlWMFAxRGgPQq7HTQNmyAygAAYRcovCVBzmhh5gjjgBdZQdIYwokKFJgZImSRTSkeNFkGFoSkrEby7pSQJciEgWNJQEXKRrjDwwA0EgVIChUJAhCMEQhREBI7wMQroGBwuYNACEQKhl02ulwEuxAYjgQFmsKalRashCFiAsCmmNDmKatZEJThXtx91Pqhegw1FBXuFAy0BZEDGtVIRQUsXyTVWUOnprF00gy2CfSBo4Ow9MYWGQmjCK0FKR4IueYgb9IpLiTpcEeSTzBoLR38kCRhIEvNgC8FUXYQFqbq2wIqCAEciAUzCloKrOy8x84D/896//7zt6lmoNbosGCASMOT/NlWbNTTzMK3nOZVrMZjaMZCUNSkmMvZVO3bXPGeDPA0zNcWvJWiOCmyM7gYMKwDBwGIprEZ2/8YpwiQKflyH33MKbuXIFAOoBrPqMsvU7lxAUwGt9IICDWt9KABEIwagHkNbHPITL+BkozkZRFMMgLkDFbwO8woQLxMBrBkTEPBFQwFoV1MwIDBzCRA0owLkBxME6ArDAIgPUwOcEWMCyGJjAlwD0wnkBdMBmAIjBfQAwwSIGONFjc7K0jGNFAyxMVO0weZze5iMCBMWZRowwGEhCZKAwhMo0fDSgUMBhQw6MAwLGGQEYTBpIahkrkQAF3jFIMuw1ADlxFmADmFEiUksHizSKaEo5jRWUACxAoMAJiTyEICaAzJnHmkCQPi3qboQygsOlm+agJYeDTDDLSbVwEEIcmAggEqAIxDqZjAr6BQ6iwCgWw14zwTaEN5IWBBhpqJrSTNScBpKbTimAEBjETi0Cw5lgPhDwiPEIpQeIglVQaINUo6sBmgKaHBMJIjnYtIS3ALmhB7gDorQAcI+D6MzeeLNLd5LVYZerKmhKfWUQhK4VILHQDUX4HEKaoXroERCmrAGeioY92LREhoAJCwxaJurtJvDBoQwjW0BjxiOIKJgtUN0UvODQzHWBYJmHpBt91aai/X75//qun/UEDDCoEZOnwNAFiwEIJN/M09401HwdzMpjbBrwBlPp/mIuCsaH4eByCFXnJbPydX/G54ml0mTkpYZwzrRidnFmGgAYRBHDwHpQAskwwd245d0/6XNYizT3a0bf0+p/tYj6P/+2v+lKIwPgUZNRgfYTKQQ+85tcSsMYDLsDCxQeQwOkKmMFID9jHUhCMwiskvMp0A7jDDQEAwD4BeMIMA4wMCYGBygGphw4leYIYBUGAWgdhgMoNcYJmAmmDzgapgMwHGYREA/GBDAsJgMID6Z3cGFuJuyf/74mQ3DPxUYsQD+8ywayVGgQC+wC99jRJP9yuJwpUZwBB5OAZE/HHjx0qOJGIO7DNm8ISzowUwsJMkEzFBsiCwCAmOvB2IEYidmKigcVJpmTCxikKY6Aio8FR4xsDBRCLKBaNCsowAxYNvJREG0jVMTJEnQEkLRAYolXCBRlhR4SLQnlgaCwMMPSqkE0wYon4uBEcSEQoTMASAsINGhhYcOzNCWaAICJHjiyamaHExA2VhAqOsUV4vwMfRuUoJAi+KMwJGfBpRmDAa9TKHFWoWiWhfhHpCAsDDBCeCZq02RtbIIgYc1oOJaSwotspcKFFoS36c6wjBUBRf1KFpiSTMxGUtgZDHqFFy9tIjq97G0kiQEWTTvcoyAUETlKXEg6dLaJNxwv6OGhgokOvZjQ06HFrZQ+T0cZVq6UunHjFisB/u7OEo+6C0y9hgHgCGKIN4ZustRr1jwGSq5SZ8gQJtrBeGp6WgYg4JRxGPYGv8k0eHYzRoMUoH8EUyYAM/xtbhkhA64OBQDgC1LGXuRGKfC/r7aNe1r70L+vRxr9C+u+q6LL5RdWzRX+pYCAsYAsI4GMSSfhgnY0WavoeqGCeE4BhpIDqYKuExmBLByBisYM+YEiUpmQHBBpgqgQ6Z8mQamgUY1AwaYiQfhKsZfkcbnBSYrJcZXgIbNIeYAjwa9C2ZGEOZsgoYLGaFRmNJBDMbjaMDAIM8CQAQ4GFgJmDwgmJYkGTQlAIMAsA5gYECxgSCRgsHRi6JAIBEzxgAaoII2xowPuChZkOHDAgYU3G52aCIWAADBslAosYCEjESwAU9zS0FYoAhAEsHDN2KorslwV4GCYXtL0rJVSRNcx9E5YJSuS4nX4XQ1tTcuqFQFE2Sp0iRZjJm8y3zKa6BRESl6p1IkpHxHCwYGHKwdKU6knWBU4ROpqkaYw6+HiGCV+LAzSGLdiqCCUk42dw4vISFbiiNAawjzI1wMywwRGlprJUNNawJIqNqXPMqs3EvM7gKCh5bYXEEj4gtswgEuXBMgcWXMIcDYNRR7TmCyqpYTDY6AYIr7O2WqLuwcvpBwRgpxNyr9lm/v//v9bqVaKB2CJ9jQBBgKgGGJucQafZvhg0j2GgMnCZPBGJkpAPmCeSObsks5odBXGZQpebaiUpk2vxGvEC+Y4YdhmLl/CRF5QEiRAfEwCKTbBH0j9z/V/38UsFLSarZDucwIau761nTt2q3X/d21TK1Dac+r2v3OCKVhj0epjUzgRfsMphD0jGcAg8xKsBmMVsLPjCo3/M0RYEfML9H7DBjAB4wIMEiMDLBkjATAhoyTsLGGgmgw8oEKMAtEgDCVANQwzMEGMu2YPd3xM3j8A3bGMBPFSBjbAmzPltDdwkje+MzKwKDBAKDC4z/++JkPg/8dGNBA/3MMGPlNlIHfNAyaY0KD/dOwAAANIAAAASDAgejcc7TDoMQ4agaEZguBYCC4w1GQwhCAaFw+XQa6ayp1BgW43VC7pqMhGhVrMZ0xkpehaOrBCAUOJCjBbMu0x21Y3fLksCBWQOHQ8WIAFzAVHAS8RgmF+BI1D4FGgRNkagQGGhw0hRYF93YQuDG010xwFEYIj7mGQRTmqmZCIkCwNw0LEhBkACkNXEICSSODekSsNpiS13lMl1IJEzS4BglNTbcvMosoYqdVJEAFDDIgQkoBIFoFtkj35fpYCAaGROaCnUkS3KNq7FlEATEGSTjdlTA4KWKfTOd0vciEKgCE4RES9ygCIGBMyVoZ4joGMDwahySDuKGhYVDvIEUAKKtd0kUkATrSClnAdZ+///+kACayfT////8v8+yGFyh22IISwglMXBjNmUHMpjpkY1GnQK5ls8HTc2A2zKREMyoI3XHDLRoNUkYxkXxo0EwSTNeaQUd3At+VQwrWMfEuJXSzyy0ZGrK4lBXlgK+t3iXKhriIqYDMN4nGFTH5pEYxGfFyLymRgpABi5AP4YWSJYGERCHRmVwIYYLSpFmK7BwphjIgqYJsBAGClAPRgWQKQYCcABGInCspgnIH+clsCaSmcb/GuaRMyY+pieEpsYSO8ZRiMZ1qmYCIga8jiCSdNSgZB04GO4kmW4pmLZ4BDymdhHm8dBLMgggsmZRwYt+YoSTlhVeZEIBQ5CFBzdQQwAgClTJhwoVNyWMs8QCKVCzYxRo0CJSBpjwOmnBImVVGQXCQCPo3g4clWmPBpiRYQfYEhmHFxJwQnjADwsYYgCiaTZCQYWDhChgiDgG6CjxcAxpkeztEaY7hM9NSXHmbRjCApOYYUGDK5Z9dj+pfISC+gcPS5LoM0hajjOQEiEgCaDDwwYzJpCDa01YBQcZYGXPZI45EKWYsR3R4Yq5maSL1uO04lEF+ZO1tOkIsrYYyDg6SREIFCipVvsbQPR+BKUuHBKbIWGCwVojKwg2j+FwSCMICJ2GSICSZNMtu1lLoUGvPDqI5gQ4GBQhYSOOpIX8mVf///9CMIpIQDFwfdAxJlR1M+acQDAH0HQxjwECME3DsTAdhQIwFUODMHATzzE+QAsw5IL0MCrBYDBFgEswGgKoMCMA1DDhSTAwWoDiMCPBHjBBAOgwdgB/MHjCUiDJmVRAYk5xn49HFKgZbWp7cvGBdiGPE3quDF6jMtlgxSwTURGMticxOYDLYbAgzMrhAxSiRwymfgUaWIJljIUChc8ZgaZKWbEwOjzHAzHjFRBkoOAgVUNah6yYE4bQKnQRLTBrGhmwFGBSDy0YZGbJgpaYUQnYZ8WWgM6bZUYwUCAKrRpsZQyOCCgWysWK//viZHOP/ZRlQoP81DIAAA0gAAABMkmZBg/3MoAAADSAAAAElngUOBqFQwwx4DChUUYEKZQsBmQYfSOEhIJCGkWmREARcZwGXUBIEwJsz4NcAsWDhDjlpAECIAhUDFBMKk0fwxUKpRI4sxAUAgICMmREqEigBCcDgI+LMcQAxh9ENC+I0CXwFzJiABESaqmUOER4+LFiAuIQRkgQGFsqAJIxoZ0y2xhxjOQSPBgkBAjHAnrTVMcXWUNTQULIRz9NuBCRgiamZICGAgBOmGDuULEgsGAIOIziq4OEiAGX9JDw0KRGMCDiE7JZTFsN0/pDJohTU5nvZ7NhMHhD6xF1UxvxdEMysCGjDaAOMwTUKxMiPEajB8ms00BcC0MZbCnjBngKYxIsGhMErDvDCmAO0wCYsVMFiBPDBmgI8wpsL7MGMAswuHQgAErMQcBAjAdQjgwVYBBN7S5Mp33M+QkMynPNgwNMYBVMaifMnBBMU4nDk0EAEotCMGhEDxhiGBiWMRgYN5lMOJg6JhGKIg01CNYknLXISHYC4JhmIRl3jFSGlzZEMN48RlJsSXMnAYCJAyah4ORCBgQIBA4uZgregqVgDMU5AsCNLxxpCDy5gaQ2JhpZFcyOdIom/Yc6QgEhZuMmeQY5Q1uPCm+Mvda6pFjGWA0gdHHjVnAoYWGBIQVAbNVS+S+QRCIFThkRouMwMCkIhbkSAJOroTnL+tzUdSmXs5gwWtRisRYc+Sdi7lVBgkSYLJPmuRCclcnStxY8p3RgQF0U8HdMg8w3AgdFZnSpUKmSMeUdW6BQICAALcwSMNFpqzc1I38fYRAoJjDMBSTtMq32N5Se5auS4Ms///+mTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjBzyD88CRztNnpK1D9c2FcyBFSINF8C8TCqQlwwlQX9Mo6HDjDkFLk0cECjMaEFOTAswU8wH8JiMEZADTDkgMwxjgoWMAvCDTtojzjb5zCMyjSzJjJtcju52zRd1zaoAjmYujI95zYA6jFQphLtzRs/TAEVAg3TPg0zGkLjJ0KzAULTAIOAcBxjgHxgUG48P5jsCAVAYeDMxiEoQCqLDUYYA4SgYNAw0h0kzzB3Is1nIqJbHccNAIbFZadQlCnGZDCVw4IFDkMB79xC3zGBCKWeB2ggkDuANWIHiIUhBTcRrC6qaUjTTLdJWM0YyjWsYuICpAVgmGX7DIAcGKgMmVtCAyQItSbYYBlIj30Mq4SALIF9HNIQAaKisxyAWdDwIzSCmyJ8KHF+Aam1pPkLoILMzAw5AEGKLFISHEM4wGpB1B6zhd4mxRTHHP/74mSlD/zQZsGD/cvQAAANIAAAATQ1iwoP8zEAAAA0gAAABD+CJAwEKBrwYUYQK3mfpFA4CHn0LaGTOWaA2CMhjAg54UEQ3QfXOtUGGLwaygeqdNlMBwJAnY/jFVRSnhgFLQagXPuSLPCatZd1PXv//d/uMGRHxDLoe44xQA/VMa1eLDCKzEQzLYAjMJSCtTBBgUYx/oTDMJIIRzP3wLMwQ0VeMGDAyTCWAMcwLIAIMC6AzTGLRdswNQJJMKfAAAsAEGAxgLxgMoQuYK8h4kXmpvqZOHBulPmFQ6cGZJi2IGwxwbOPRitGGgAMY1cBospBU9GOT2MBsxGnTBwdM1hgy4BjRh9MqjUBBQzoADCxUComGRyYeAYgDBjYIGBgQhKMn8eJOs8U1CDgSIaWpplmoUdbgIcAoIIHPw0qYNqhiFbjSEOJFHoBNJahkpYiBC7QxCSHEpig10QmgoFeQQjZOogFDjpZlkocWDAsYeIMpUOUMiwyKzoEOEYLIJABWksFkRSfKmCpR4ozzzSBEmwcKRNBQwBFA6VxzEMMoAS5UXNFRlxUMGHQUiwhuQu0kwaRilhAolSpQVyDApbNYE0ggVMaKIOBT8gYzSQAOrQo8hoNZoJlrgLxkaD4ACLWCM4wSS+a1BCMdIBZN5lF2jFsgj8xiGmgoAJDNxQdRDlzCCjYsUZBT+EQyWwOPTIAgJeNr0p1XUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxHgaROKx0dTSmB0I+hgy5MjqK/DNyAOgwrIB4MDnCPzK4xBEw5gVKNOJBIDCGBB0wFQCkMBOBbTAVgA0wIgA3MfWC7DBpQFM7jD01SRU0HFc14ZgyHCo71FgyCMkylGEyyNQwWGgxwCMxKLgFCAZknyDSeMXABMeTIMlgqMABDEZQmCANGKAyjRzmRwlGCgmLQMZAhNMQH85xaRkTByGByaYmWMiGMUJIhRnSJRgXoBByAQdFl7BVaa8sulghmJxoiJiTQVOGvNJcGiPIimnJmqIgxKQIgubMCqQFIfjJERDhQcKnUFDIrS5hqlJgwRkzpfgvgJUiyYCXmgVCp4IbjV1IYSLEd1YEzYE1iQUQESoAMRauATZ91JighnBJCUVjLgL1MCBNIDJgzjmBMg4iYFKCQQCRKpBcaHFDIBSE6YkwbQYZwCooACpmHwtMcMAEDSgiIAJIV4BQ2BlC6DGkxAeBSoRhJQNDxUeZAOBhpCFMMfAgEx4RiKb5jAQUHmoFNMZsBkxogKD/++BkxIj92mNCA/3TwAAADSAAAAE3vZUKz/NPAAAANIAAAAQkqEV4jyQvq8YY4BI8yw8KAwMuQmhAISYiAOLdC/LVQEYSAAwISEjxkwg5JyDuf///+mAEgGYsKCInOnJC5pDZ0Ac6Cv7mJakGhopQB6YMyA3GBqCupihon8YdwXOGfFgEhhsQR8YKOD3GFQgCZgH4F+YF4ASmOqg/hgBYKMZ7hRp+MGhxedtpJjzMn8xIDRQLSs0GjzEpODI+YpJJvApmXoAYlQhlcMg1KmDhCOnYygQzYBYCp4MkhowKRzLCsMOCExacC8prexnVwCfCGAShTkng6CAhwXNGGNG6GmBbjTsSJGefmFQnHRmFMrYDgYkqOcFBwcaimDSgZGDnRiFI08Co4xzoRFjTNwgMYcaKARLAOlBCFgcS5MkBSoelLHM2EASEt+Y1mYx6Y8gZA0sOaYSLFCtEFAASUDDZgAwBMoKQIEAR0qZwLBJgw68U8lbjHghQEYYixdSQKEipM0ZIGAA46LAAKKMoAAxIAn1MgEGNa6JCKIJijJmiAVBhwFGJExRxcIJIGpErEJpYgAt3MiORbUvHSAXGIdlgF8K2ERka6OoTGS7gBkGTDMjBwIx5VIQ1oYyb8yrsxi0YKGJFBBIA5QwidIyZM4AMBawyI0wUsx5UwAw1hA0LIxQFrRmSoNUGAYixtS1r8CXK19ClKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqow+8ZGNJT/VDEMEUE4TN66MR/CijTJgVAwcoGBMEkBhzLEgTYwOdLsMz3BAggUrIAKEwIsCUMAIAXDA9wdMxrgZxMJfAqDCTgAMwJ0C5GAREwV4DWMAsBVzCFAPAwDYEaMC3AIDVMY4ZZPhLTIC8x9QNX2QooC4kYh3mYhR4VGDjYa/DF0owYHMhVCFeNxKjCyZTEzw/MLRDVR0CL5gICaFRmwkBKvGKmICNHhGAjWbsyDzJmCqAcAAQi4VEQOMCVkMcmeGAAKbQCDnpvUpkRKXJKEDqRgiA8kCIY4CMYCBTc0IQaLiwwBETBEgQIFAqZrETFjzGHTEEgagGVwZVDqBmBIcDNuuQTGAXmojCEkYQ0FBpYGggaOFhIUYQcVtWXhm8eYF+S8QKpoJisAuEygcxQBUBlE5VHjgcKqxI4JJTPgGaFQ2QrVellTHPzMjlgh4YEL15Kri0gO1mKFmcFwecQtArSyhCRIjQhS/kUAohMQeOhCwBBAcHaAhkZ1ZEHUMgH/++JkwY/9uWNCA/vUsgAADSAAAAE3qY8ID+8zwAAANIAAAAQHV5eks6ROQEkGCgVAl0wie3MKSAcaC4sxg0wIUDOYMGkIQ+gYAD0DFUzGgjKih4o+7DDdGKoEbZt0O5aaLMObn3XCmhjuwPuaLQBjGAGglhgBQYwYn+QOmENK7hk64TwYekFpmBFgIBgYADuYFOChGCug6RiL5V0YGEAqmD2Ar5gdgEUCAPcwd8DZMDIAYjDfACYwAYHUMA0AaDJz80NHNsejXM0MJzjG41d1MLBjuEMwGFPBcDMFA1g3MxPzXEYwpHMOZjYxQ1NXMmKQymMMDDmR03gaJmYzkjNSFAcLmAKpQRoNhysYYQgQARQIkkKoJkQCZ6VNMEIIZWJJ3kI8YwKmZKRmIcTAIGDkBSCYt8YaPiQ0X3MyHQ4EMIP0lgYDl/TAQowYFGmwGiRMCqyJkFkDJSpLdOMxMAMDDiEYFkswscNBCTChEyACjRlIWpeDAQEig4CEAcrekimqKkxgYACSwxtw4wEmL0WSBIIFCUEnC+bYWsERxrhAYEZOLYnAgarYjOMcQDUBh4aMVQhYA6kTFmMAIKCArU7Z05xxlB4xQRAMwIZDTyBjwO7EZgR8S4mQyADweeXpZaYoTXWqoAzJJAAS0xpwziDFBvECZa9ShuQQEaa7ISIg5nQ4QIuLBpUNElgEI3d1pm+C3////fVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxJ0OmPPaJjzXu2L44V2bNMlVH6zV3gu8wnMBQMJFD0TS8RAwwgJ4GMAtE3DAQRUAwLgFKMASAkTASAH4wTsEXMBPN+zANgHE6tb025EgxMHc10HgyurI16acxmNozqEoIQYoNAxMMQCBEYblSZuj6YKgoYEBUYkGwYWgiJNwgeZSiYYNgWgHMSREMXQVNURMAoYHFCpkiOYYzmpmxmH4YuSmMGYGLDChAwBAMmCQYAiT+FC0yACDjBgpgqGPAoY9GYCpjgAYUIAUTLmJWjgUYGaGEhRgBuZGDERkMEhopiAgw0EVKhWYuMrDmMkgQVGHhgwZmfi5QRGfLJQKhAaIyUaJR6MFBQw0yAywMDhkAYYGJgrRMIFzjyQKhJgYoBAMy4JZgVRFNUFDZecAjYUE0hEejAQUHEBhBOYUUGEkhjxCICowIcMeIAgsAQ8YMHKygJHEYsYOSDggpuFxcxkeMTA1wBQaM7CzbCswINAwyCj0RjpjQYJCxg5WBAwrAiYFIEcOKy5xioqYoFCwmYoflUFHRckDDIBUIFRYCMPCh//viZM+P/wJiQQP928AAAA0gAAABNgWLCA/zT0AAADSAAAAE4DAoSowZkCywmIDBiAwQzMaGAaCGchyXq1igUMECgwcMTHy95j4kQABhoAHHIQ4BAkXPCxOY4IDxmoAATxn93/oMMbHqjXfeUIx2AszO7ZYxDGRTLk0ogGMMF5A4TCCgncxXgP8ME5UaDJYAM0wCsVpMD2AWx4BxMDwBMjAHQWYwqYoUME4AGDeYDNCJcCosXPRmWUH3TuBq2bSBRgcqAwIBi7MUBQzCVDKSiMfBwFAgwOgjLwBONiQy+XzKYhMDAkOAJhQNGKxWbbLZiUYGMwaYCGxiZDmLw8IiCWlMXhMqgoMGhjgBCQUHOjBlAQTAREKml1voRAlMmLhQOVhgE0BQBKUxpkwZpgpQOCycaWhwcgYERcsGgKLB0MZDihswhIygkyZ4xJIRtxp2FjaFYWCgkSJcASGNEbWFDkBZYwgY31EJhGMBm1IGuCFAEW0l7SICBlYUEmIBDAsSDkyRJpgZR4CgsAK0fzPgnEUFMmDEmhhgZgC4BKhCMBGQwIHM0ZUPAIBMqHAVUwYQEBTKBQcWNk2EtQOCiIEPRzEAjPCi/JoDAYhC4JY5ghZjixKBMOqVGUASqXbMGAxYOBQoFCCIKyQxwtCNgwgEiiAeICRRjz6pumOAsHL/iwxYBLQukY8pD4IBorIugYILB081p4UqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxW4r/NYV55zQLDcU9bBBaMkOQszQLAIcwQ4IhMIKFWDHYhLEwF1LuM5iBzjCeg6AwJ8DGMB0AJDBMQSAwPAE8MT5HyTBmgSAz+HYx7PgwiI01IHsyVN07RIIyDQkxnE0wIDdbAOGIwEL4wDAgwJM8yiEAw2CAKBcYSAyaaBcYggIYOgkIgDZMYWBUYek+ZggCYWgMY9UNGTIpDtpABdEAUQqjCGDNlAUiHhIhAGlNpdBUSIgZpTIVEmFHo1DhgqgxRSYIWYkgYx4adGGJRYaBjJigqvhaSEDQFMLaGhNi44BDhY2ZAyFgYJZICjCoi0LJDGBA4+YFcYhW2dLwuzKhEXZmOIDqAE6SA8WpCgQMYJXmLJmKSJimEFCAgShQIKBJcHE0zHgCoIBMwYVMmMByADKzWDAEcNcJMEJeQy6UyQcwK8QATKBmwgkmFyRhRA6CKJJphSDyKpcoOXpKGhCGJMCgYaBEoUvAY5IZIiEHU5F6BYmLAwAGLkzSJZcUHCTAAy6xmS48DSZBQEiOGBAmBJA5+WrrmlMoHl7lRv/74mTOj/2gYkID/dPCAAANIAAAATtJjQQP81OAAAA0gAAABCyVPsKqyAQY8ITO0dUOYoPSBYmsNgRUMfrBcTwbkBw0/VWmMXeptTC90AM0SYRJMFlCBzAZxoozPsSFMWZSnDXHA6ww80F9MJOAVDABAGUwQADEMDAC4jKoBWgwcEEVMHwAxTACAOswFQALMFjB5DACAhMwogESMAQBlRIHDAzbIReDQeY8RRmEljrWMEEkCiMUQpm4DHUzKY7E5nwRGIwcYNCMBmH4qZINRgEGDQ0MEkAyUTzCQfMoC4AiMx4ITCgEEimFxaYhGZjAHGQgo7RjQDGOAAPCMxSPgCoDHRgQsHiiCQ8m6YDEQoIR4SBwsXKBgYASiY0DwhFoKD5ASSYJGOUEY/CIjAQyATIABbGYkF4yATB5EBgAdAw4KSUNA4DBAzFDIYSD5pW5hExpVJ0T5jvZtqIOhBBYApTgjSzZgxxoRxjARlSpjAxkhIwHRsMqjcgwyBphnxJhVxANLYgJEYsgZsMb9CMuS3Zth5hTIICgqOYRIa0WLTjID1hVukrA4go1asHMRIACQBjzIiDAoWa0AYEOOAk5UAZmwxoB4CHmHAGYDlmEkwAkMcFMyQMwFMUdCxQ1JQuuYMybUgYGeYQqGIgSFYQYw0lYYh8ZIi0wVCtjIq4yFQnGBVjQwzpFAWt4IODo6uPKIg0BX//6KjB2CZA3GvdWMiuG1T7u0ZoyAtI9M44BQjAQAW4wMsDNMZpGKjA2RIQ1gQFPMLKCKzAlwMUwJ0BHAQLcYSsCEGSzhgxgxwHKaQluYrMYYWhuaBPqZWACA8EMVBYMWx8Gg0MQBDMCAxCwIGKANGTI3mFQEGDoCg0DzDwHzSAiDAMEzFYATDIIwaEZhYHRikNpnUNBhIA48NQJEYveVAIMHSWMUQPMPwxMBwfBQ6hwGlEsRuzlg0+ENgqZMUAMujFn40PBow0KUQIQuTMCDNYiKGQgQhg4SADXMYQCiwxoozqUQFhwgj2aQABUgOIGICDZM0YclVp0mAIJGgEkIhIYXMNoXKaZAIlwsHNQOO2DM4yNCHApyMGHMDwQ0JtJg0LEcGGVHmMGGGRGGAGUcgYsBpBjmRg7Yo5FC4ojNQzL1mYZmcBgUCbBQIBppyBoBzFga+MsVFqgyPW8CQYUDGOPF6C3gCEmOSrQIVhhB5sCJh1LDi4phmBIbGVRjkQMKmGDgJ0WSNSrDLBbI1pQxYRYyRIBDE3ktcZVKbEyATxpg6YQJeF6BhKHXjGkS2RkgQCBGSTGaGmCKAQGMFEjwKCMAKJBZhwqgDSX/Sz////QYkAMOmj3/LZoCCKeeRI0MGS8KiJkVgDeYA+C7mAlgZZmpgMeYgaIimoIBPJhNoi8YHL/++Jk/49OZ2NBg/3T0AAADSAAAAE3TY8GD/NQyss0Vxxcp4gA0GAsgNgQBemAGAA5jjRJWYQSBJmE3gKhgLID2CQG8wJUGYM56I5tGTGrgHicDhyZsAAwXjIwrNPBM3kwjGgvEIATqMhiY7aOSoKDEAJMNggxYIDJYWEhscYG4YUjIqzamy8JpBRrWp1ohljZjA4IHJXARSVoTMqQ5GhyISBpyBgVhhS5qUJggpgCJhh5lHJhSgKJDRIwsEAkg6GHNgdFASgy4UrEmXKpBmrdGCSmtOTJAZDlRkmJnhQWGIGhF4GKAMwMmZMiHJnIMPmPHGTSiDYFgZya6cgYLMcmS7WqW7Az00K8CiDNhEfhmENHS4hnixkSQNTnQIGLYIOJoCiA1Y8BUTChA5ySnRpKNKxs0BDZg3hw1YJCmKJGkjG6HBB4dNorv2qRGkS2mFDMxCPZmTxiURryYKPmYCGHXGTLmLPlwTCAjEEzZJSs8ZIIRAFV0fiI2IFwcdEIImrGTXOwXiBRAqjAaWXsBRimCFZbcCCBYYBiYQ/S3ICxE3FgkMq1FQm1aYfrYkQFIBuR40aQggIDCtyEI1XyEI2n7fIRtT8QJO6EDgcIVjKFTMDIqCopbomrOSoV/D+j6mBpoIYFew3s+dR48YQAZBsvgS4znwXWbBj8JBlvFM3gjsxiKGG1GE0c5/+lEEUcstG//wQMTnJAgY6mMLvxG+HoNtICAEDBG1jBG35z1A5heSBASJrMedQ/6jHn1BQ4jfFhd+TXR1aCM6UYmUZJC5oTreEQsAyByf/Tat6w+CAYMRVDhjZlDcAy5U26M5EVlzDdC90xDwFlMEcACDAQQ7IwDYIHMERIlTLQAO8wMUJBMABAvzAmQDAwCYCLMAwBHDCixk4wGcEUMnC424aDC4DMVOs0+Dj8YvMpqAwUOzA4fMnhkZHJiwomLRMFkqY0BAKSzNjEAqNDFgwKMgMHW/C42BQUAhkMpBswqGAoaAqh4JEA0LzgpTKKKRQY3BCqOaQ4WMCCiyBjsLGGkAiwGnpjT6yhQskCXCbrzJy64OhLUqlAwxNWArU3nkEYxalE9C1PRmKgBliG/C0oIHDGFgklwE2JIDABigiEoUEBTogcIkBBIEKGQIDjAMYhiMCLHTMBqBhMAoQmUCDQcVDJZAZXMVRQgtsF0XhS4IQQecTFCBcDGg8IDDgmAUgARKOI8iFkCwIFgnAYEWfCC6UUEMsowgiyIXHQCkUyDymzWDRBBg4UDGqBY0wzEw5ljTrgaIkGVXaMaLLjA0tACxFiSK6/EaEaDrLUvFDFnlZ6VAENMsQmATpRnQSCwcoFZgH/0ME2vhCaYJgOxgv2YvJMavD4Y7lKaYtybtuqbjtub/1udNpGZ3P8//viZNsP7GdiwwP8y8JnJjZxAD3QMq2PCg/zL0ktF5wMAHG4cfC4aoj0c/VsbaAGbt5GfY4ebKoib8wmbwGcYLB6BhGJgQaFCZ69mLf//j6KGNf2Xb/7d/VaPQPooY0f/+gw4UCrNPthljC4BAA6Osa6MSZM4zDkAWMwHIA6MBBAzDGvQsgwJgsNMo8CCzAHApYwB8B2MAZAbzASwCgwEIA9ME3GpzAKAG824izgqFMLEUYchwmemmXwZHCxnYHmHUOYzDhjAnmTD2YHEhlgRrPSbMTCAwWCDQI/FgKBQIVgcxIKDKIYAJ8BoVBgBaCHEloJiIMmDRoY/JAQITBwCFBYgsvI4Gyy4NADjgKkliMPGqUjiNMxIFJmCUqA44RocHos0NIUmJQHkAoWFKEBIhBEuQhIbEAjVwjQBhClzAMIHJG0uLam4eYO4UNVUSybqvgFrJwDZhtKgxs7HzIJCgoGuBCpoHp4DEBjnmqwTJFDAZGzMxhFjgQBQUmNCGUQS/oJDVYiSCkgs6CQjfPZ+NaAURAkvgDMggFCAQAhjKwZINLDSZRoAwIiYTNaCMJMGdprQCJLKGcsARAMaCigKWYapogrQMBsFOJ7IfhclPhrRYHd1sZdNoT3NaL6G3ELEBwQoKbxxlhpiIJRUtgi9QMgnMu+UYVgXX6ylENYzhgEPHQeib5HJnwygIWijRNSyMzRjDqaENQ3U25lDdIZOOLQ5UmTVgvOukU9E3DIwhWWsV+AW//X/r7gs/XdcLPxXq9dMGHMjzJq+Y8y0ZPtOC0abDERkeMOEiTA7ATkwQgHpMsSDFjCL0h8y64IJMKxACjCnABswEgDvMBaAXzAmQBsxcYYiMGbADzBRQOMwLgFXMBpAUjBjwIAAgKRhPADeYEcBKGASgK5nzYa7UmxLRiuWYqHGsA5lh2YuMmyJ4KAj2oMwUQM+DjER82l/M9VDK1U7NNJiI9gAdDmvYG1gGsxAjEZ1iatgaA8FRKD5n1Bg+IWCGXDmBIIJzRjzOgDNBQhkpUZ9GBnpnCILeEtk6pNPQWEFlQoSZIZAkRJRAUHQIkJHSycRUBjpd9AuliAhIASACiw0VNTANElMYvBIcACy4phEJui5mQAS3AZowqg3gAqo0lSIiACwWtrNCgozbozRswSA06k0wAyE4iyhY6JS1AzUsyYIFwLFC6hhTBkFhlipaw4hUEozDOyAeZ8oYYfaMYcTrcY1SwHERqoTKAsJNyVMAnJhxhSoMKgEaZIgIAhiRqH4CEBcqLOjBFlKzRBgUHBgMyAkVGEAMwAcOZgEmDYgenAMIA1RGPGiyLg0YAAs1NAKMVXGsVDQsyZwzLAsKlLzDETJiAscKHhhB5gQFK2uIAAt68///////6leUCoC//74mTpC+4ZY0ED+9SifMY2UgQeXjPFjQqv707ZEhecDA3rgJghAhmA8AgqmHAIGD2MuZMBDZn+KSG0GswbCYxxitAjmQSbSYtpn5oejvmXYxabpjFZjqG7GjONca+i4phiExGI6DgZiolhjLgiEAIoYEQHALMVe6TUdgIs/2UT8tsoa3q9rNTHLS+15RjUXycpAxOMXaNFSPSDKuRzw05RBJMJ8IATBgAK0wOwAFMBVBoDENAxcwWor7MTyBPzB0As8wOADvMC8AgjA7QDsgAlTEQwPgwXAASNpIDhTI04IOkADoWI9oDBj8ZQWmdh5jRyagMGIIBEfA0OBpAZadjysFyEPJjv1xqAoabZaDpBmYIfrOCyB1UaDm6JiyEzLY1yQqDIQYImYUo/TCzbgS5Ze4UEGIXgasJABUusMgENkbFrAyWMOQVKYdKhUIg4oTLPgUmRDDJGiqIAglJcUFMYQRmHFBwsRhkfVgDAohZEucAnxpqsEPNFDh0SmYBBIjGQ8YwCagOQqDJiywKHgTHAsBSJMOIUFaCYtaLLTCgDBsgs2R7WsYISZUyY8ABgQsElQkdM+zMaTNQAHiKVpighhR6dYUOpXFqiI+ZRYX1EAwGlRCEJmYMBBhR7iZKyh9QdZTDLnJxGEAlUeYIYz8EAC3ZVDE04AlAgI7igxljwcUBpkwAwx1NL4CizOEmkEQVeJiAoKWgECokQh1cgkENLEXEWRCMCCZiAq+VBIraqGG/1p+M6tgQZJjwztYM9AleGLmBj4ebBDnHDGiYmKFGnKBZWcaWbYmFgJqH4kqc2RWQ5ex9O3//7SX/VHpTtaq9viVT1MIJIvjUMWNIwMIrmOAPHCDDUSi8wuIFVMBYB3jBlQIwxbMEqMJ8M/zDuAUswJAHsMFRALDAtAMkeBhjAngEAxPQUHMAZAhDMhOFTWApsbZYRlmWA+TmFS4YOLRkhFmGSiZ4JRjYlmexwYqIIyVDL4bNEEcxIGjLhrN8wMGlIZQOUgqGckuaJqRoDVoTh1C0hECDn5k2QiCg4OLBgMMBLYyrMWEhV+a8IQEDRNTrpkVImbZQZgAdIKZgmnyR0wNlA1kKuAkyZIkYdYKGjKDyogJFJiSZh3LJQuFGQQcJCLxn6IEIgxsAJpIlGRxnIYsLEqhIPMEoMCBMAEQ4mchHcDiTMZHhcKxc1BsMCmimu2bgCZYQZsMDpxgAhzUx0DJvIY1BMAdHgxKOAxoeaEz0WHmuPGXIgZ4IEgOWjQEECjTPDaqgsETFJn4kEBKQRhgXaMMWNO0QOEJMO2kRZAaPLhWYDiwEFAKGq8MXGALgwGXDJiRmVoUVA0CbtACmRnBLujAoEsgVvBUMzaI5KNMQMBGYHgQSHBEnC16tohDF/gSP/++Jk0Ab9xmPBA/zTsmrGFYEEL253pZkEr+9PQAAANIAAAAQMkBNSxMy7AZQKqDFBjXHgFZbKl6wNq9vIAf/fL//J1/uv+bIT/IwR3E5jtTlHEuRBSRGCXYP0F0DuC/FIF8LiSIv5ilyN5FpxbdRtDuDfNyeFHTcO+bgUFf///8Cgr/+E/UYKG/+QU8FBgoKOBQoKeCg0IK/+BR0U3IK/Hwr//xv/wKFCYZAEnmRJIOpk4g5aYncLQGGPCw5gKYCAYEeDBmCFAdphJAJQYOIKumDCAWRgboG+YEUBZGCjgrpMCLGB/gKhhIoZ0YJmAvnVI5tIqdeDGxA5rb4fynGGGZmKgZOpgZANONxEmmeRJMSBBiYcZgIOAMacKTGIhAKNDATpRcyQYNnOjIhUabTEQ05I6cYtiaCTERiYaCGfEJqYOaiCA4UY7eXFITxlgoqMOCPMojCxQiTDGUyKEx5AQkzAhzNUTKMQdGLuGdVGQEmGXAo8CVohnm2BgwAHIDAQTeimRtLJiZsF5jUJkWJgFx4iKcZMAETZsIMLJfALEbVgbbUd4ofiAI0piSIDmobGeBjJIiMGaejJcEihY6C0hxgUPDxs3oYGCQqnMopMiIMaVHSxgBxCSMwIREBpgS4mgDJ1A5KQiDYKjTsk4FZDHsjBo0iCqeBRUCAV3BAsFBDDgwECbwhcCBQsAEKhUCAk4JQlZUeCjRMCiyqiEAwBJx4QaNXDgwoMqpATM37wwwgQRDJCCUwFzhoipMheYkPiNrbdAwaczYoGEzTjDeBTJnwU6NOEMM9BokwgRTzh24pM2rGaTEFNRTMuMTAwqqqqqgBMNGCezCdQsUxCsx3NPRe1Tgl2bczTEJPMGgBvzFrxPswkUAjMNbD8zCoQVMwYsU5Md3HfzF+wlswTYEAMHZDkTEVxCswscHLMD4AnTAPweAw+AQ2MP6CwD5FSPJV42UeTYYDNFIgmxxmCNHanUaINRgobmWiUY4IRiQeGBDQZvU4RHNkyUUMs8NomABU4mQfCmMRhlAzqwy1gwhIzzYBUSQiaOeTcVKDkBzNPkfmAM9Eb8aFhD4MBGUamMFGZUj0U0RtAGYkOYkAZ+wbIAAhAkSMWcGh4XYmJPmgPGFDFg2BqqF5YACx0wYgWBmIAIkAaqYQCrICmyihmhQWKBQYHBQaJPiQOSMMKIJSgOZFoTKhlnjhQ3i9GYxhgwxARIA4QWfKBBgzhdEHFTIpCgSCoQjJIsmbNmgMBwE0QoxaUHeBgYCRxizgkWQEA6QFg7aBRmleuQSFEgAsgFAC0QsjM6hBhcwJgGlwEvQTohiSsOOmJBF62wqZqtInZmxIJOmEGAImoqXfIAJgAgVekxxVUxME1RQEmQICeoMKmOaCIMDgB//viZNGO/hxmQgv81CIAAA0gAAABOjGZCg/zUwAAADSAAAAEQ0RpDqqTJig5vEhnVRiQDigqMIia6k4lKmew6xZuLT5TDHAGgwZAc2OEgbFj49JRsyItmuMXLAoDCHAU8xK8m8ME6AujHLjYAzU8PpMIEBhTZBDdcxQ0HGMDEAsjA6gbAxOQoEMChCyDB5wI8wPIE4MNBDeTGvgUIwCoIyMHXA0TBPgQAwMEDjNlvg5KhDB/CP+8MxHLDOCpPRrM3U3jCRtM3gsxaCzbCKM9tEwanjUhhBUnMZFUMjJhcbG3UycKSQUI5VNhgYPkwzNNBkwYgTAAoBVfFkiCQ+XdAgnAQGNHAAxMGQUIAgdmAAewUIDKt4wFMSRMgMBgNCeDBxjBJiTqSANTmTIlQ0ZZuAYpsxwYwLdmCRBUEYdCaIwaE6JCAEAMgYAA9RwHDzIkyhYCRrXlImgOkIo38YACxQOnMRNFipeK3GDKmBNAJGKlVLhJCgnBRox5BdgATmEKggyDRpZUFAjSFwaICBIXBGtJAoKZMOMDioAGSKXQGHFguRHXbftRZJQyg9YYcCES8QADChQaTMoeGRY9HJQIBBFAcWEiQogMgJuhY/4FaKomoUGfDGILkQNXAyGBB5ORWxdAIMgwiTCAcXBgoRCi06lQQAARlSReYOBGAFmSImIBOYGDQuKLcJSNLeZwViNflEW////pTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqArmzBYAtowD8WnNhZAbjR/U/82coWEMPwBxwYBuGPjEBZhLoOSYCmWtGPPgexgQIKSZYiOUGCeg7RgPoBiZTF6d13mcIDIFh4MeSeMa/VOsCbMXyiN9QLMBxfMZgfDiSM9BVGgPNFRIMMg5NQxNI0ThEZgzkMfFGUgI8DsACiTGnwhAboQULzJ3TSEjnDzIEQgmYEqY4qY0YYNIFCQVFGDYhcuJEgqgMynIqoICmLGloQ4UniQFR44ISxoSBmxJlywNAtNAJh8QAZMABAoktwcB4DrBngaSIcLAyUWQCMQYsg7JMjHiwiAGfRmpUBUwgMCgMREVZgUGMeYNGbHAoXAGAGgguHGIMLA8w4gAjSEJFnKQloOAwCw1PABMC/RIgUBFQ7+uShOFRoFOszVqaWYYQTDRAKLPA0ITHrbWQMLliTAWPKEAokFEYBLGGDmCKgwQY6OEElGkABgSRghDAC4JiBRdV8iAiz0LAmku4g2QqSJ6ECgElTTLLAp2v0IJgYP/74mTAjP0oZkUT/dMwAAANIAAAATnBkwYP81LAAAA0gAAABGp5coQNMElL/GzRy5T5lAzExKWNAkKoFTAU3EhkVyqTLosRnTCTgXQxsgDhPnsCJjmVdug/Qo/HMhmCEjCaQvI2hU46MfZB7zFAXxIx28Q6MAMDVzUoD/cwQAGXMBsBRSsE2Mj4BUjFbwXMwNQDzMDHBETAWyu0wKwCBMEYBXzD+QNwwDoEXMAdAajREHM3rc2HIzXxTMTMYxkMDnRDMYBUwo+DRRRM5DA1ofzTrcMOCwxsPzAxeDisc8Q5lkvGNl+ZDLhlEgg4eGRw8ZTGJlgfmNhMYnFJgUEB2URJDgtDLmwiIW/DmwOXEg41AgwCoxhVRQDEBoCCQQCIEAhaxmXRiQaxAEDAQwmBGwJGTXGgfhAA0ghVcRGQKMR5QEkIQzQgz5wxCkyRg2JgGHQMNTcNaSBIQ4YOSmZBnAKoks+BTRK8aFmfPlAMZPnEICSMiDGaDKGN4BCgZfVsSGBgxLsHSA5mYsUSkzBFzIEx4aIwRjEJgwRijRIWNWKHQyKpZQtQI048bMWtLel2wxEW2ACUQhx0uLF0uCYsGJzGKjDnwExTgM4sNIqCChhSAILGKdmfJIlqVlDMCnQEVDBZpyxEICw0xgcLliwWT+B1ZQhS5WA05MADoMDiYEGg0eYMUiyLPzCCjEHEfy8Mg1TcMez/6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxOQPVMVnIkjrgYEU/KycqMFFSKzBRQRgwNoICNd2G7TChweAwhdkyJANwwC4MmMp7ONjA+QUgwSQCZMDWAxDHUwlowZIK4MF1BKjBRALgwaYZ5MTbBaTBbwVMwqgCuKwCEOCGTAkQAAmEAjAdgDswkICbMBeARjFw40LgArCb7aGZvJwPGaXnCNCMcHjpAkSVjKLQxgLNUZjFHM40QKw40kXMLWDKy8AKBqzOYgAGYJwjAjKSIAAwMDYGBJsUBYMATBhEFKYhFTBwkHHIFBRUQBAmKETWjEh0iSAKDmGDgBHCoFGGBhECKhAwMPAxioiyQz4WFAswYSMhFU6QCEMpLIFA0gCHhYlAAIHKZGDAjIjEjc1wNMiE29S0MABQqFiRiBTsZJBCDgQVBpANCRhIQAlMwIANlEQRNWMMRkAIDAIg6cDRTgDpwNuSJvudLBixAIUhcI6xGKJlIDAw4LpGWgaKIjONyoEokorESzBIOBRwwg3cxr4mSB24ywwE+hTPoCX/++BkwYj+IGTCA/vNYAAADSAAAAE16ZUU7/dNAAAANIAAAATh78auNhcaGJQSQIdOFoWAQSwxO0eCfY2CQeGoaIw1Ay85awOAK1B4AgFKIgamZwIZWocgGLvCAN/bOt20f///7zAEptKmDCAQpgkIcqafsm0GUEkFpssYK6YNSD5mBLggJleIUOYKGB7GBxFYRikgL4YFeB9mBgDvJgCYASYC0B7mYomnzGImTCqgJLDHkszG5ujykTDNQMDPAmTAkODCwrjD4EjQwajAgQFBjAoZDBYCxZLzCcKDD4GQKDxhwAh4zZmX4GIgACMmzDQiiAjeBKJow5oz0PhdeYQ8mCBopnDSB5bwtaDCYKLGADCMKJDjMFigel4QBTLgRggQijEhzOkxACNmQHRhbIQAhYCBopfYoMgFg2UvkFxBtgxhQgCDLycIyKIxQQgTmLoBwkIVLyMUEAxQwZUoEjJI0EMzJQdomoDJKJ+mFFk01OleSpzBAAAHM2KMAHbAZMIDBdIOAW9aQEDwsVJQjAUzwKIMCVTCGjc8kw1ooRCAo+oWDIPpiDxIFci8LIAgMgRZoEFVUkN1+JjsFC5MCqA4EYcsnCUBEf0+AuCDmQKeNMJgiKydoslMUpDrgq8M2fC6EaOBREZ8EcR+YNSBCAkgCjEKDjahg5ecESYYKIjBiEZlRxoyxuxBgjQMEG7TLjfd5OWcqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAADAmo0kzB/AdIwPgJCNL3R/TXSwMs1fEakMGVA6jAewdcyRAZgMGXASRgh2MgAAxTATgLUwT4naKoDCYIiBhmBLgL5hX4esYHyBeGBBAJRgKYDMYA2FsGDKgOBgI4JQYDsArmBWAVhgVgF4YRKGU1JtJ0eOemTCgECQu+CTyZkEGJhRibWYtUGwDZhBsZMNDQAZ4LAAcBRWbQImyuJlYqAAsLFphBuZgHmmA51yGIl0yMnAIoDR4yQIMYCETAgpAQegFKgEaQZF3TDBMqnAZRGJEJlIuYYbmagolTBi+AQswEHMGBgIDmGAhc0ynTKKXkRTGmkLgiVCfKHgOQNgc3ESI9wkiAGWYbJVPRFEYoVcCUyICSIemQekfTnQYrcFnThKKBVL2cCyIMKHp1/EVocIlwBXxKQtcWzQSF5x4otu2iTIw8ZUpapG0cBMKBexcY0yAxZYFAeZgyiQNJdcLmt6SHkS7KkogqEYgBmuKKmUWF0lV10kh4sMCDwAZCQYWZogCIQxMEqHAqWicwIz/++Jkx4j9l2PFU/vM0gAADSAAAAE5qZEGD/NRAAAANIAAAAQwgikv2DhStgyKgEAtkNQEZqUoo+IQDJbCDhGoWwUDguSRV6phGg2EYNmH9HXQTDx8vCqeawAoOGA4BQxgmYrsZvSgGmG8hAxh0pL8akgKnGDlC5QNbJzAcwYwwKsIhMCDBYzDDjJ0xSoEVMFvA1TChwHowi8ikMP6AVjtQNOEpg5wdzJGBMxnE0IOjdkDPwtQzXgzMh/OICszqSDHLKMlsQId5jgnGwgeYLGhjg0GDkYZLeho81hYdmYI4PQ8FChBOZHJBhgbhw+MbDYxyDDE5FNUXJjpiVwGcGuwA2UCVBlyxrFxgGJESMSBMuMHVBseAhFG4EG5LiCCbFoZAMMhjICgsCSsDl4FFE20yRl9AwIMiDVhDDMDTCDJiCi05gKGBQsI2RkAYYeCoMRKDNmjDFzhejXJQMWUpL2ArYFBxlwRgjIABFYsxbAz0xAg0QAIk0DCZhUEXGNizM6QLjrAlr3KNfSHsCAwzRI2pwCwi5YWeGbNiE4LZRQ4YESBRZEYU+Dm5pzgySMIRMiAMSXGiIqDYrDRmCgOJCNMaIIJQzWDTFAgVPS8CwAFAzFGDCBBUQZ5qjIgYZIYZkchMUSCjRcwcMARVEMxoY1IoDFQMHNAWMU1McIXaODgELEKsiQkTNtiEmCA48OZlf3f//6f9NVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQgAvKxgTAF0YVoFYmfCoSplmSTubYoKjGIBAEpgf4SSYHsRuGE+BIZhxYVqZRoBUmBvgK5h8plkYEIBnmBnAH5gT4IUYFIKcGArgOZgC4A2HAWJg4IJUYU0BVGrQ4crMRkwhmolOZuDZmUqmZGWcAKJmwxhdAGKAEZDEQkXwMXzAAIAoYMaiIw6HAcWTDAhMPEAWBYXDxglRGCgYGEUqAUwuAzAoSJQMwcwyHTBYCMBiYAAwsARTQMDJIJQ4qkQEJhAOAMw0EzBQBFBIYMKxncbGHQKVk8RggVErPgEZzBILMZAEAhMAgMKA8ZZB0jlhyJNgWzA4QJwNhgLFi0BgkGbgbeSE80UQ6QwgiEswQzAAOA8TXDDmnoXMlTQTQGXDUMLyAo9XQ86mwh8ZpodEACkNU9B0EHPBFANFBwK3xskYEQIIuixbvgkFOVB8iANg0WFVcy0SPU2ImVMUUxbAMDLgFzEEiew4KleikIgHlMIcSeIkzPAQEP+tYIUgZEQCBjo//viZMEE/YFkxLP8zGAAAA0gAAABOGGTDk/vNYAAADSAAAAEzcDFBhCpw5EABhBjiv4IklMwQAspqAKKLIgkcSdLD6tSAMMCKwEvkK0w2l27uYXVMYLiDwmFjA0RmZjeIcIanjGxmEQZhswDgOAqxjcBF+YACAtmF/kypkWwPmYF0DCGQPHcZgL4HOYIYBsGAhgbRhv41OYTGApGAiAOpgMIE4YMOH5mGVAbpgSQG+YFWBPGAdAX5gKwDwYEKAZGAKAigOAAAMIUA0AUM1OjSHcxNAMfAQUsm3i5hoEZusGKk48kommOnBr6SGMwJQjNCo0QTSoMwTTQSI2Q0BTcPOZkak1s5A5METgILmgHZgZIoqI200AXGhgw4cMxKQVCggwCouYKLkwAQhwVHy5wkSjgaHBg8Mg5+FTAxA0BRWYEWmKAwMCDEEMMAwERGIE4AAwiUBwsXPSJC4IZOFo2BgGYIBqamTpwCDjRSQHBxblHUAgA4HCggYsMkAQygqD4YeGFhBj4yooZECi0xSQWAUfRIIqKCrYMLRNBwyBxRAat4+YA3wEeGbgYIDKGSUbSZZ4UNCoA4CZb5jHGMIy8xD27I/l0wOWUNptKoI4rUMsAwqyAcIXRuS8MEcEnmGKJNAwQyx3ZMiI5C0cAqQKfLbLfgwRJISuGDWqJKxI97zVAZwPFJEhnyjYIWIByFoRSSxTnPG8qTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowbYUBMNrJdDPi+4U4rzXmNSfSbTDZxO4w5ELpNFDP3jCRAOAwoNXpM2GBATCDRVYzdVdCMLJBGDAHQY4wJ8GvMe6JJDBvATYwJsCzMFgBIzAOSUkwZcFXMBxBZzDYgCQwBYBkMBSAVDUB/PcEkyZEj2VPAonMVho+uUhIVmLQsCgIcuLho8lgJPGExCGARuAFRRwcsGFiAZdPYaEDFoPMwIczMIDDoMCgwMDAUw6CTCQ0ARkxCczsoyoAKDQxCLMiIKZMSa0ukMYpgCoxh1Q4HXCaAuNFTEhmHGZJgQmWqWEUxAgYwqobjmaJGQEGAEGBRmTiq1OEJCRCRMwIWCNMzAydQ8yIkHZjCrTHriq7Pg1OAtNYIGh5a4yQQRszIMY4YoSZkmkEXoDogAFGKJGDZBgEKnDMnCoKMEeMmYBQAQBELCqBNMzASUtgELis8a66YcgKABb2bUuaZGZI6CkYEEvUh0AxQ06stwZ4iWyUUEAcxicCBAaHdVpIEHGSGhB835EwgF5xZMFBRkySYxjxSZyt44EMCAJRY//74mTND/5TZMGD/NSwAAANIAAAATgdjQYP81LAAAA0gAAABKDegCImKJzrJWynsSDAaIGQAwZAh0DeWGpAEBY0AAwyIKEyyBnkBggNM/28LTv//QYEqCTGIJiupmMnN8ccgtlnxwgipj34D4YkEC/mu0EipjQgUIYFaymmKoBkZgawDaY1onFmB0AXJgiYRQYK0DjmSlhpphBASaYDeBDGBMgRBhMgvWYp2BFmBJg7BhGQKyYGEALGBHgGpjo4ny3Ca1TB/FeGAiWZZT5h85CNSmJCYYEG5xk6nTT4YAH5jMRmJSEZMEAVMJq8eGAhmZtdpjgEmHhKYAF5jkVNoYLHhmwXGLR+BB2Zdca46YVUdoUaPCmSBnImnLnjWU6c8MDhwQAlzFHl6AJmHDzAHx4GLETEDxGYNQIAwdTYlBFAo44kkjhx5YAITLpFAwVLprqYs0AKY0oJH0MQl7QqJS8MklNPGKqkwJwwAZO1P1J40pUzZNCEOLIxoIgSVC6QBBBYiI0hCCBwgsDjUgHYJZIqBVWdFDmHIzPjgCvNKPCqMeqCImCSwRzMAlRyS1A1BoQ0XBQl+jJnSUuoFEQg2HOBkWYQwXfDG00QHhALY0XaNAoLA0wplbYGEEQEHEILFR1CLSlzmOMmYIF84ia4UZEuicYMgBkoQERtHoIEQA0eBTAKNgaGKjTDBTDmyIoCjEZirwz66kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjDVQGMwXQNXMq5uNT7x4oc62dEyMS3DizCbwhI2HcK7MMOBMDCQV6cwnMILMDnEYjArEUwwlcAuMBqBAjAcAH4x7gPjMXNA5TA+gJEwaMJlMHKDbjF5wIgweAHgMIpBTzAaQOkwGMB5NnOY/yeg5tnTx0aiFhiAanWBCYsTxpAKBYbGJCkZvLpkIinARKaBDhg4nGIjqZ1LJhcSiJ4mQyaKlgaLJipRmXwCRGoDNMwEUTPYgMg2LJmacGiHIBoAMWjEDEKAwa+MwkMYWMEAFR5m0ACCB2A0gIARx8UZ2GiGYJgYoMENwMTCxAwogldhVQClJsSpnZJlBRwGRtrBl3qAISFERl3QUwMsnAjAKljHPA4iApQ1GDkIEJjJ0URmaCmGMAkoZNeFwA8PMsgTqCw0Cmw60QIx5OYBUROQcaAA0wY0M1oChlAIFJfAACgY3JTxo2TQgoPLCAwIdDAwgsyDQxYMHKBUki8DRBOABy4tAMizQJiyAibmYTiAaZMozkvGOhTFEmxmOGipNgDXzBv/++JkyAT+fWTBg/zUsAAADSAAAAE2PZMQz/dNiAAANIAAAAQCJYh0MQKLB8ADTLggENBXtC8xAgEhwwuY1GY4MYYu+ycphxSeCNAKWAZumIASZe1h40QZSY8K8+8Pvm////90APsuYOyDmmBng/JiQ6moZHsCqmeRDbBgD4JCYI4ArGUhBkBggQDWYE4XMmKshHpgIwO6Y4eTHmCLgMpgDIAAYpoked9UcCJIYWkCYxEkYz9McNqWZCjabfhUZhhMYVFKYnDEGTqY3FKZJB8MBsYPjIZWCGEBYYgCsLGGYcByYGBQYii8RFERBqYBgIYLh6YPhYDAFMICrGg6bUMAEwcDgmEYBCKh0MCQYMIgdHrgltMyGMcjN4qMafDCpiEZe86SkcTG3Dg5aMBzLIxIaRSxUuY4wD5SU8FGGRmjHA4CYoO2EGoCgymsYUMkSl8JGVB1dhB1zQwMkMaFAZsEMgRRsZwaHDkUDGoAGeAwYOJCohh4lOIQi8y/LWQoGZ2bEMYVcZ8MMESYCEAy2JkxyR4UBhjBcJfFEprwYVRRBxELIGtmMGoUlByZL+ubOBzUQiTFDWqM3Fg4kVbopsYc8EIhwCBgSP5gApWBZaYYWOAUiUgiUPKi/zOYda8TCQSLM6eLIGVcCS0YLFlQcsTjMIDAQozpgmxBQOiwiCuYxy4wowwYsxxhVy9QCOGoQjAO9hZ3ZVpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjIvwZkwVkf5NQit3z6aFeE+fQR+MG8BDTBuxXo0vU9/MOjAkzEbklE1S0K8MGKByDS9FEAwSYGuVjMBDAkzD0hvEwA8QDEQDkYH+BVGBHishhvQXwZoyWcSngYQC2BQ/MGyyMMR3GBMOjhDMUgFMHQMOnxFMRQgMDxYMDxSEISLUMHgvMGAXEQOoSDBgNzEAUzCQIzEiCDAaydYRDgYCgMQR8IoCquaZYOeBSSAJDsBRi7wECJVRw8kLMYtDEwUwEG1sYDQaMtAxxIYUGViVtdpZSuQcYMFO+oKz8aBL0JdjSIkqXleROUSFEAxboEkAQMEAgQNcqCSH26sPaCvd2mfsZkiwSTbdQsAQDggMmJT4RBHBVgWLlzmRopNwYyw1zlawqAVCkOLEVNldMCZUDAoMVvAQQJCXCBBRpFw5GBBRKVK9WiWo/Lndhc0//viZKYM/CZjQYP9zDAAAA0gAAABNyWXCk/vUoAAADSAAAAEByN3Hll6XREGqdSgusDQAoGvV0YjNNPURSocRYZJBYjS1B1PsRg2C1AURXNfV/WaOLQYGi////+kG5GMLhDkjCxhp00NefWONXIrjYaC68whoIEMC3A/zEujhAwMAM1MGaGSzNvQMcBBDhnZZ/GYBYAHmC1AZxgZwEcYIWLOGBAA+RgcAAGYJcBBGCSh0RhMgLwYDWCZmFDARRgBYEmYBUAXGJxRwpEYznCiCTThi0qcTZGGlRo5aYWAAlGMZGTBCYwBRBA0CQ4wYxMMFjiA07GU3qs3xsXxHJjmFDGufmLHspMBnMDCEihnUxjABjiRQFABA9qkzoExEIGARp+KpT7KDGxzEnDDAjLEjVNlgwjOFyjWzJlzE4jJqTATDbBjMo2zGCzBzkH9jCKTGFjTlAhyYoUAgA0gApkzIY0l4FOB4iXjSHNQiEritAqBQPWsJGGioAAYFDHTBDSEAhSIRYcwLlSAFEwYFMCNV4imsMBhiA5eYoAItrcy8CdQoPEhEBNcFAR2BAwVM6hQOEAkBGASGMQTh5CBR18wYQMkOGg6faCQxQpWAEICIipmmuylWEqDSwKXaimAR4GHt3MEaTPHgL7qkLhgEQAl76DBgxJUapywxwwWDw+h6ds+aoUzQMTkI8wYEGAigg5EMRmxctdRTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwOcBGMIWFMDjjuhc0nPtaOc1SWTFMRCIwQMI0MKQUjzAmgWUwXAEoNXvCuTA2gWM1JpjYMEmAxjAqQDcwnIAXMKpLizD0gikwYMDrMBYAJDCZQ2cxxYDVMDGePDmHM0jEM9yeMUh1MtiSMLjuPay8MxAjMTw9NpD1MhhaMvwqM0B9MszfMmQ4MiStM1hPMXRgMMgTMbg6MDibKFdMwAlMZxaMuSjBRiGKoMGD4sjpWBhvGOwGGQxHmzNAG2HHAiWQwwhedGSGNDlIwCgA0hZRgyJnVJr2QhADq8+Rg15oyr08ghg5gkxxBpqT4shM+jMINlxgDYJXCrMyxYODAJSFJoKzBYqYoeBAJjC5lRqjZ0DpnlpjViwoceE/QmRITgwJMmgQrDrSO4axTSReNiMBgY25uHCiwDSqAghNGmShCZAAXHMwZNcYZ8b8IaVQIgxCYQ8HoY4SUzM2xOk4BgEQGQFgN2CDgxUgo7A4iSDAMZMMHECZuCTxkU5QANCkOIfGh5iGIjKg4cEEI+lWOAUEzMjGoE2jCpjHozhAVeGHDtoY4wSC0e2RCP/74mTUj/5kZMED/dRAAAANIAAAATm9kQQP81LAAAA0gAAABMPIwwGZA+rGFQo8vAIAKizJjzPnCZaZ4+WQX2gqhJZ3Kr1rIwQIGJMCRAozhgb7w+0I69Pr5E5jKZQEAxGQKDM39Q8jBdwkUxLIlYNIBANDAnAcQ0yldfMPIAxDA5AVowPUIgMcOIrDD6QTcwBAFBMBEBuzAYCEcxDIBzMCZCkDCJwHUwKkBIMCOAHQgXhu0Mx18xXUjU5hV2dcCgIHZgkLmWiabYipABRV1mGBcNCMw0PDLhUN7Ccw6BgStjQZdM1ig0ODDQJqMWg4mUZgo7gBEGEkMWoepSodXGVXl5DmRCIOCSQHLCSkMaGlVmwMAJcAGRiyoOTi5wxQsmZA4Uu4tGmGJSAwCJgzWAg5absCYpsYkoBZAKLAaELMxZoIA4YnAgAw8EyBsefGQRGOAhE4zRgxQExBAzx0RDxq655pjg4aJpZfMOoGRBGkFCAeaogoAYUMbiAEPgE1MoJDCINImDSA0awtSsEkyUQAUYlcAhoCJDQmWCmLlGoBFAMUJBycw5UiXgI4Fh5nVACmApePWCUKCjBMDMuBNGcH0QCaLlCEwNFhg4w4cwAcCgGgBAYwSww5EoQJGCSUwIwFEAATQbBQNloOLocjKCjGDDZmTVIlNDPCEoxCRTFFVw4kISQlAJQoKSKlTOt2KpD1///9KjA9Q3swfUMzOSubqTrf9GM3yFTCMNXFoTA7BaQ0s5EHMBaAejArESA0f0EMMFFAyzQTki4wqUD3MAvAmjBaAQ0yEsNTMIiCPjAVQLAwF8HsMCcJPTA8wR0xXAMJSYyAAwBBYYlkmaVoWYcEEcIGkYxDwYIgKZdgiYTg4YFBsXDMmRcKCXMMhRDhgGQVC4WGHKRGWAJGDoEA02jG0ETFkKACD5hOBZjQAxgkE5haAwODAAgMaAZBwMEi5cOeo7GaSGfCm7AgpOZ9maUYDpRKVMElB71FgwQoMMiEgYCGbmaQkk6DKGHgEk5mMTSzHzjXpjJwzEDihyNIldEKs5xknBgIapaw8e3hlMyzwwSsANg5AZAkLNiq8MGSNcdIjA4WM/FCgIwJkZJAgyZUkZemNEDKSj2OSyhhyoYbS4RnMAFYEbwobYUiapwoYRhwgqIhgGBmHAiQoAszQEwSPQ+L0GEFnHCBgYQoDHezWtS1afJtRQsHNQVJnQXFAwYFxJhRAktMWNCy0xy1NUcAg0IFgKVZgRY8kAR0u4EFwKSITBgDoEOJ+mAKiEMTDyKgLZTKkUJgQWNgCNOXAAkxw8ABy2SE2dMXFKgKw1zeK+AACAUgRhcQeSYdeB6m2lo7BqbI48be4RLGGcAjphroMeZqaOUGFVgKRgTJh4ZB+DqGCXD/++Jk/4DOWWPBA/3UQgAADSAAAAE2tY0LL+9SzAtBTMgCvkEG5kTIoyYJwArmAogFwCAsDFgAskwNQE5MCYA2TAtQTMwEIRxBwwEYAiDUgkCVMB6AOzAhQJk2WBOxfDGKArAhAxmBgZz6oNPxhxMJIww4mmLphZOXLMbHCJTHDo3c9BS+YBOA0mDkUKi5BZgAXgtIEBBgNAgSZAqgx9Exg8YBmsOyw64g06oDVDYTTCQTGCjOljEEgEVFDBoVJkFBdEaIH4KGnGkxwDEU1jBETIBXGMGaM6nMKMChg0LAaJBCMxQE3AsuKFBYcvGR6J4gDjAIIdFpBq6aUWZocIjhiRaOgciVCaUUoEFwA1ADCxnkpi2ZiR4KVrbQHAAi78TGgBABc8KmzBgBIaSjlrM5dlPFuyWReNabt2SAMWBJj0idbPzEDAUzBJICoxwaCkgJFg1A97+rXRkKyixzKBHIgVBIBRLpqXBA8CpwhA0c0i04RkQMjFhzgjBGCByMwyIuODlhgzA8zDHac5VcmWAgAyaUoZ0Ik8WfM8ECgwEAzPhXtXu0OAEl+FhqaBHhcg3zcTRHzy+WfrzT5ZnbVNIyqDTV3zpNuLUbZqps+ixlgIOcBY0OXzeQ0eoWka4dAtaPaELaE21TJlwcGlqX25WqpCC9E/LchKYGCMYtBWj8DJA/EcFeJIJmaCaGEf6aV7AYbUsrbQlDLeKc2EytKlNpY+kesHWnD300FhVRBDHMhTn1Kv7387ztfcrak18zqleDtAwlqAshlhbB1i0G2c5aKpZQaaVZBCfl9IUKEZxaGOhiFslJGtTJ1CjxL0TUUkQJKpdGKtULbQhKFISeSBNcxDjOBGJdUKNWN8ld7eQ2ptZnSrUi6VrMstKwttDSjkqm0oq1Ar3j8Mowg8S0MLhCMDnJIaM+jgbaPfeIazE8AJgwUsG1NTyFLzCawSEw2RSSMj7A+DCTwHsy0oNPMIfA/CwA9mARADpiX5O0YVuA6GBDADZgBgCkYMQFnmMDgK5gC4CYYRQAHhwOiYBMAUGTwONUkxstD95fMTjwy4CTfgKMRi0yGJDIAANnvwyiHwoXgqAgUJDMYYMungxiVzJYTMmxQ0GCTHAHMaicywcDHoQMECQLAwKhREEFMwElLomnZmWJGzZuIHAgssMcEBIpDiyASAiVw1EAHQC+ZoZhccCAjHgAVJDkIqJHiSA0StmCPBjEwoAySMaKizwICGuplkUxQIrNOfFWJj1TOhCBEIYxg8SOAowFUZn3hjRBa4QLAMTC5sHmihwDnwOWgBEDFTGhEoMqBLko7hY4QBhCBC4VHhAIFCidJl1xbo0DchCoIgMLMOTBxERmkRDDjTGABrebJgcuuYgQIApmWqIRtipzgoCL//viZLYI/kJjQQP81LByC/YgBDyuOYWPBw/vUsmVLtnAAHq4BEc0hExgMyocDFDPJQUwNqUC6ALKhKgIhgYYX+IiYUThYeZ4yIij/MqM8CGCwiBGuMBEcdFQ4MkxgIZMICaAkrMYkTqJhLRQxWOixIscMkbNiDiRZxVCnawfDXq5L//////////B4Fxv///+X/////////8+/zdSVxBkaHgiBZEMzCwMMGiEwyIDPCeNGEoLiswyJzTcTOMoMyogAKtjjEkNjAQ067TYI0OmZY2soTb48N1EA3EpDI5hMLEYEBMLgBPVkUM1LFoNo9Rz9YfAgsTDmxUowmgK1OI3c+jX/xjgwtAyBMHeCjjCGwQ80KMH3MPbBAzCp0WwxHcB+MEMCFzJhyfYwlgAzMCGAYhAChmArkEphogKAYBMANmAHgihg9Qm8YfaASGB6BFxgoQJ+YJcAJGBEgQpuhub2cgCVHsoRCwhVA0tEaea+liMPNgiziwwBHoGhjFxkwIuNSETZxBLUxToMNITkRsxI/MECyA9MvGDBAsx8TBo+ZgqYw0YJ8ZQeZ1C4ij5qV5qC4GFr1N2KNlMNTYOYFNaEMSMOhEN1kR5NCiEhIkeMILNlmGhoFAAUaY44YgObRqNlCB2JYDcBRY6HIDMVDkjTCqD3LjGtVpmIBmDGko8wowvyYhkBE4sJBBERigMbAB0awBhwxJQOHrHAQQLAjOHxCbCwwIaGgMAbsASplwZqDwK1gwcaNCYwoFlBphgGTgQEVpWHysuQIhBhAwBFChgwrYxJoWKA4IADRkExfwy6wxZADAzDJgMcVMSjTKoQ5GIhZcQOardLLGEBAAEnQQGh7iFhQiHmCCAFkZAOZZYZ4IYsOFwjBTHuTFlzNCDAEjHnB6CYdOL1DEGDRjEMgsXMOdM01CqeNBUyHM6Z27+X//////7uUMGMBMBECUDAdmBQFkYn4GRlkHvGIsU6ZEYD5gJmCmIKogbnBeRlOh7lgB4xfSHTUhULMf8Tcwig5DLiVeMw4Y4yPiCjWmbUMjY50y9gLzApA4BQQAYAfDFPYBwM/9lQCAQnqnMJXC4zAwgBE1MhBlNJ/RADURxLkwIUCcMD8ByzIlBJ4QAZZghJFIYgkBHmBbgaJjKxE6YCyAVGA3AEZiSQhtN8Ro0XphWMJioIxjbyxnCNQ4ahruHhg0GJhUFJioDQKgow5D8zOB8wFAFO086ElKmfDMmNPaNREMyXNcIBAseUmFSg1UFkBz/x2WocKElcRTkCBLRzTADpp0RjMwTlnlfGSZAgiZJ+CCQ6vNWKCCoGfVzJnjAiTFPEtzNEwiqFAhg5ACdkCYEhjXmyESYwgY42ascnoHKAS3MEROkHCJAYuR2UkIT5p2xCRMSFP/74GR4gO1+ZUPL/dMwa0vmgAAerniJlwEP81EJvy7aTAD70WR4cxRujYgUmhCk6YipGZEByEBUgdiMIXGTLAWCmkLNgAy0RiCIUZYOgJVAHB0qDajgADMOFFDAZQDKo8RMKHACAABxwqXuHnyWoJBoWDT5rBjyRpw5iQYCGBccsKQFRQCmGqEcBChNkZMdIBgVFDBNM5BchBAwSYoiYYKBQJELSIR2MMAMIDRbMCfKioQHkd1FyY+DkZomgkOMqYKgdhpOZQBBQgDAY6eRTFj4CDkS4a4mXJkIsKAkxGuS/Kzz////eG8Kd/GdpiGAWAyYHARBgHglmEKJoYf4whjeFcGD+0gaaw5BpdHZmHEBSZh7lhplohmIobIZ6BsBlREOGsiYMDTwTdDR+MyZcQwKyhzYYXgMP9Q4x2ASzDNBOMH0EkBALNFfaIzV3NUAACQAMLIDmTD3RHo7AFFgO+uDpTnzyigxTEJVMOgDADOqzVMwK8FEMLnOwDHwgeYwRwLWNBRYmjBYAPAwSEA2MB3A1DFfRicwbcF2MAlAbAoCWGD3ipRhSQKkc5ph69tDT2MOJg0rvjdlANQJcwiOQIdDFYfNOGwMDRhIyGdRAWFaZqBRicbGUyGTEUAk0xQbSZ2gEvmDSkYpLpmo0BhSZ+KiUHBBIccGRjBGGXKmOHmOyCz4G2zNKDKwhkeI1BARXAvkAC2VBVQOMzBQRSG2Ix1kkgGXVGFBGLJFhGjcF1RhTJkajhmASoPGWWjxxIQxaoChDe8CYmYlgKCzKjgARXaicYwaaS+DlZ++xlRwKSmEJmmOojteNCEAwFaAk9MCKBwlB0yAE9E9BGyIyIQ2ycHFVmgpadIqb42LFDSjkV1gAqGZUBsQ0LV4HKm+XEsAZ8MNJQgWPRkRAwGdAeOkTtExEPA2EACg566QsiSHLYkUQFM0dTMBgUYT0HghnyxiSoGYKnAa4LKjWKBbMBiI1CES4CBV7o7ApOBV5nCJjA4MAFA9BMFRJkgYETmPGGLAmGDkNE3kU4QQVAtQZ25bvb+oftOAfr//66fv+umuI9lgr//////et3JKKgFGAmAQCQMDBTEsMNw4Q1FzmzcyIBNEE9I0FTyjUEaHMcgBYwdBrTCaKaMTQXwyhRgDGNCKMbITcxYwmDNfTkNGNn4yeQbDGhAqMHgDYwnwSkH1OofpMwM4DAkg4Iw1ADpO3WDtzIJcnEzypC0MLOCZzA5wDEwz428MRfBATEtyDAy+IO3MCGEmjTlFXkxE4B5MDpATjAwwP0wwALYMQ6BmTAWgFkwJAETMFXGDjEcgJ0wCMC+MBcAskiR4AAMDXARjClAQ0wAcAfBgAq5pEfgwGojOVDXSDj7TFIyKOPBzEjxARKiUCpRIOf/74mRJDO03Zr+L+s0wYaumQgA89DPhkwpPc0zJwjQTRACaOaEiDSxtkYcrZSY44EIQuFG9YHOGcGGkJmIMDhoy49D8dUGOoGRDixseWFVCaJKWoGAEYQEDOM072ybYmlBoZAIsRJUwXTGEaqTMmqiEhrkpzDQERw6uCWyQ0MEBSpiwmuihOMpQ9bzzDIwy6p4Gi0jDgqAqsnuSCmSiOALFXun8GAIAgEcZ7QdGEDlmx64OPNlUJWMQwCLCRjqoNtNIgCAkLhhh5lliwS/FggoUMHhJSbgGJMgQ4AkCDLhUU3Y0EQWATKNJJUqSIGAAg0Jd8xFo0uQSDSuFQy/xewLggoAdBDKjEOABRjACYZ3kCoxunjVoYKSDgVM7zQSUJOMjQ/LaNDLuGYGYUYADBzaxYnHnylOed/oAEh///L9V/L//5f1////hnq/DjX1BC14YNDJ4qM3I0yefjULwNNcE64LTLGDPhHc7bsjXKxN/KUxsJTG5YDE0YoBRqlzGbWeek4JvBrH3/wdVRRhYkmKBAZFETA5JQgm6gWpRMNwgIw6D7D2ZUsPGM/w8RDJzKiAhMEEDgxIC1zC5DgMRsNoy7AgTC7J+Nsty4wkQbDBqBFFTCe/vxiVEmgxSYcEhsMLnwDqZPOBoQWmBxAYdGZiIHGsxAYAF6PiaAKGK6ggyttHABrRo0IVwMOGyFGJLm7XiJSWCAJMGgomnQoNGEDGJYGXCokGvFnBECxQKDjiITOkRCBAUcypYa1jRMw4cpJiQgEhDIlhoEpiFRJaE2goukY4uYomDl6GKSQyjASUy5kxAI1AEAnDCDgMeM0uNAAAqM3igzRwwR0wZIwyk0Y4EDRCwS6AKA4KAhAJGopmHDhwdTIoBggK+pjRZALsrIMYEASZjSBKcNcGRhBogQiAxCrIQuyQoMgU1wE7MoAQBGKHEgRAICggcORkg4AiQuYB1AveWlFihnw6J5bsDMRYoZsehuwEzJNBwuIICS/DDFmQKDtsBAjDmmIoQeoEBABgjCfJnDwkFFnBjyIKKGVDtYMATNQKDlBCVMKLMOICDIOHxJVEyZgaGA4WAhIkRAIUMNvNVtSmlxyOilMqYSNIjTQjQb80vJhQQCNEwgCQjRMJBvzQSf8ltn+nhFtz5UxLb3ijYIlbP9G4Rgk6JywUgATBxqJyyJiNbnyjYIlbnyjYRbZ+UagEnJq3KNiW3/1MS2v/r4RldKCEkvpYNv2KJLf3VMqKISmWpMFYT0w4SezQkKFOUp3Q8zo0jaKE4MBsDsyQivDDhGJMpAN4y0hTTQNVLMf0nczIiwgMcYYDgWphSBNmDoDwYU4XBiFCFGIsK+YrI6p7LgZtmHmD5uZWCi8wBUOCfDeCoDRpkJuOKZlYiYu3/++JkNY38cGLCg9vMYgAADSAAAAE5XZMGL/dRAAAANIAAAASmWjZhZsRPxUEjDgg0wsMjHjQmQKMQAbTVkQDCRErIdDBRMMIE+oFIhgFKxi5KkWXOhtM1McuKAlkgEkIQEMFqg4jMKLAgEVUMUExCBiQUMAwyAgaHlEpqhAiCxAYGDWAqEGFGIK3dHwiDMcU4FQIKkghgYc5waCJhMEGnlyjaKDgTAWCIREQChyLZWtp5IWYpwnAJDCwppQGKok2royAEqQcSjkr1C5YoqKAnhEckisGHGKrlpIPLviEwMBCh4BeM9ESMEQgc2bbZsiKSMcdWIXAhRkLl1E3zUQEBZpCGAevUxxnpBKIyKOqFUUBfiUjB0z1jlUgxoTUZBoBsDjphEQQgOHMmuKJAtmMtwTdYwYxbMnAMIFYocamOVRmHg0RfjgEhiMgUQYXQTrm9UjphpbDnQaqXU8mWcAlJgbwfIZAwJqmBwA8xlDI3SZw4LAGLJEeJhtrEQZCAAbmCuASRgZ4HqYNAUCGJIBaxgmoFuYFyCcmDBmCpjioUQYkhIdzwKYKv2Y/lqaYkOZ+JwYnSIcnFKCgKMXiiMVUIMKTQABUAUvjIQMTGASzEkRjBQLwMFZlWGxjahxjgM5iYNpkqY5hgJBhyJZj+HosRxi0FhieABhOJpEhAICQwpIKhk8zYSzfnDOSjEvjbLhEkAwk5gIeEirYMlEPc3IEIQl2zFDzLkAoSBXAUcGoDKMmgMEEE54E6rkQi1XFnzKGCwJI2w64HRYQBN8SMwwMUFMQzEkhAFVnEEIAmjQszXBxbCNGAaKFioYbM2CSWBggahFAdOgyZYxTwBDxEXFg5NiFQCA5HJNcwrsusgDfAaFmKGoDWvAUKXNMACCz8wUEzIUzYJciO4KCEUoyQ1HxgIMTBQ2MpQMuMWLBQ4ZRLUScFQQRLL3kQ82RASQmOCsJMmKSFb1GkcKpVjKUIdCIuZwsGAgciCGBjihgwydxnhRlF5E7ISxpiCGIcOBSYwZ9DYKDB5GDhqEA4HMijar3eVtAxLAMhMOwGJDi7FfQ+bdFCPx3BtzI1QuUwTwfvM+zD9DCegb4xJs/NCF/UwQ0QvMNWSZTBzQEAwn0BiMDXCVDCax+Uw80HRMIKAizAQAccw4gRJBxTUfMZaYOrqYnlqZJEWZXNqYWAAZuuYcOpgacqgYhmqYVFoZFjkYuEcZJjAZyIiYjASY2hgY/AuCBNHBNKD4MzBnMYwjMMC3MEwlCoUGGpBGG4EFA3mBAvF1RodzCoiyHGcw4a4iAGpgi5plpwm5iH4BJGhbBVoYw8YlWaoqYBQdF8KiTCFTUnSZi3IxiE2CEwAIBCzGigEFM+UQlBcmZsWWfIjZKJDhhdMIfAgchk//viZIGM/h5kQoP91EAAAA0gAAABNj2PEk/3UMgAADSAAAAEJATHhTUESqFAAEYFGDQGcQg4gF5IJVF0iwBMmOM6ISyYGgqIgqSEMiJk7aNRd19AQgHjLtgwAjQNLwqSCApkwyJyOoJGgQQY4UMATOCDGD3xAhsxZciGIJAaLEYFigsSTUHBoKpAJoCpQGBqfMkNBhFOoRHSUeNB3tQABQxJ1ysvHiDiEIIoNshMWNX2CjgiAwO2UoFAZmZAKwcsIRAORaRAa2FioKBAgCY0gYoUW7McjXeniiAjWjFU1dO+v///oAKJzDsAREwxcNgNiRWlzMiBEg2CUZsMRhB2TCtAAEyz4BaMHmCbjA0itMwzAN7MIqBbjFXCcowFMAEMJZB9zB2wLgwPgN6MBHCVDACwD8wJAF7MAjERDCwQG42/A82aFkymOA0QBgGGEaHgeYBkQccigZ+AaYQDQbHAsYBiQYDAIYRkuYLjQZlBmYFAOBj9JgYV4YeAsPCWYJgCaQWDk5kkgBTm5VGgYmLOGFDmHWJwkgkKohYyARxjh5AKBxsxoUxqIyB0suDjBvVRhzRlephDoNGgFGah6FV4sfEvTAhsMAspjTyHMQIQuYMktITAEZmbRAomY4MEHhJ6Y8kKCTRgAgMCrxVVpqIcyQCkOPLioaEYZaRdQWBg4E5aQTQlBpeYoAlGLBUeF/ggUY1GlZoqmEG0pxosglWECGIcvFtBhwpUDjz4SIoYKhGSBdxLRSCoxGPLuRYRhhQeIhgYFCxFfYjDKvZAozAJdqHmUF8UmFzN6Sn1GYWX8UGhtrKDw4DKDxQ7DEDbgYwAQwAGAVUb9GX/GR4ACmOfgpMCkZAHNINMw1BxBrYQoVIWiV0v3sytAARjBohKIwYwarOkgqDjp7qms1xRKcMNtBfTD7xeY0SknzMJwCrjASkr8xOcA0MP7DuDLW1aswVYBtMGzCvzC6wvEw6cc5MTyCozArAJMwKEHFMLLIDjA2ANwwhADPMLEBIzA+gVYwYIC8NNKc28fDJzlOpmo0wxCJDmi4+bJfxh42GQKQbkMRrVlmqTuaIbRECDKIjNVo41kaBkumWHICQCVQsYeAxjYamLTqYLBpigBmQRqYbCBQXMgdNWGJDYyOKgYBECVwYsEZ7IDXh2VAVBgwmDHqiATIDJZgdxMDM+3NCqAc0zDcFYwYIMKGLIEXUQg1omGIGdTmHSAYgYcQFFRkB6Ugs9DFAZtMgLMCVHGJEdMIeMo8K3gEHskBTItnOhY6hMCo4LFzMljFUgMBJlySplS5YlIOPMDQpIaIiaa7C1wF8wQPBh8CDACFEIQ0RsDMx4cDBYocGgpCAMEEgZRgUJg7WYMQaNcaAINCC86ax1BpagwYYKgDBiBP/74mS/Dv5qY0KT/NSwAAANIAAAATpJjQYP91EAAAA0gAAABJoHEEHoSMEBpEGBDFCWBGBBjBAzIEUBGoAryMOGEZgGHjchjBKjYkTGiTAAA8ATSWYiVElBmzMGjDPMYkgShQUqABgHGzALyYKX5a484dvMDlBxTFtAmE8FGuDP6natz/jh4ow2Aa0MH/FjzNNEqAxIYQvMJITmzO2wtIw+4edMnSefDDGgmEwMkDnMOHA2zHfCR4x30EYMFgBCzBLwWsxEsVCMWCAzDfOVjSaITNlYTWhlTZRbjV0ADFZOzpSUTB2AzKEeDaMqBAaRjghxkmHg1S5p+bJmmLBhqQxlUQhmQB5oIXhhwDJhsSxkmXRgqZBk4Rxm0OxkkJgENgxEE4wJGIxhCowkBg4xAGPDQ3jGHCiyc2CIkIjemkwA46bYmbS+YCma5QBTxZI5IAKNzOMAueMY2M0nMSjM6eLbHINLAku42RQRrU9DADDDvzxozshycSYp2AUwyGKFq2Qws9AVNAhU20LMFCATAwBVHI0oQodmiLjwUsiBBZqRwFAAESERAQtMKUElJmBRuSJQcSGAVAwoIkCNDGmABFlrFdm3FmvLApAZNOATYZlC4sxgUgEGyJmBRqVDhBHcqBGwrxbsZ4ekYBDxKYNiiUrfUlcGUXAbyCjpgDxAPQ4GeNCBmIyJYEpjA5YYMqFCqhxmC5bMLCTMgDAiDMLQcfCBQAAFxTBIjDgKQsJlAX7L2qYgAEOBCAcYEEg+vK9fFk+r/93+hUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQCiilDBZgyMwQACWM2CQCDDjmEg1aAZ/MESAaDBAgEcwLIgBMClAPDBThUkyFsAbMFYCrjCUDAUwTUAvMDqAYTQs4D/vQzFAYjAoUTIs3DeO9zkg1zEgbDTUgzFZFTOwdTHMbzJATjB4WjbwfTAEMhCbAl81jIxQY4BUBKSumMCDAKTaUWUmbqEb4SXG+LnIKAAYaZSBFJl2REwMagM3kDh5iSoASmRGJdAoyaVQddMmiDgw8tNKUM2WSQMORMiSeWqYRWHL1jT77mbDNRMCNMaLBrkzYgzwEhBGbWCw0sEjQvi2xnSCCUFBjOlEUA4ujcyERjSAgCSBQfAIBFlerBQgygovIihNhRRXGimCA6eigKOQECGQCmIBAQKyABFjBCBZa34FHDAODkRgMGa8LAUtgYFQEMwFD5iSa8V0ong4+pMyZddrQwUYAhEzRNNAOHA4zbUFISJAJDlaO6TAUPqbJeGcIgaGXxJDCZIcFT/++Jkt4z9MWTFG/3TMgAADSAAAAE3XY8ID+81AAAANIAAAATrNaoGjRnCJABY6YdiYcEIR4mdHQRUELpLC0EIEUAETMAgDpY6naOCQpgiY0FCHwhAsMfyB/rzGDiBAZiDoewa7jV1nwvLlxo/aL+Y++FHmDzBT5mf6FkYdyCXmE5BA5oXYWuYH+AUGYHtNBgfIE4YJwA8mFBgNBkOwcMYVQB9mDAgZpgRQFCYH+UqmADgT5gH4DCYW6CfAgDvMDjA9DAmAXMwFQGFMAtB6DBzALowG0AlMZpzagQyOWMQMTbzw4vZNWvTW3E1wpKpOaAfGechywmaMugRmPOoocMkXipCGFlY8pC4ua2JGLgRnwmaSUmgCpgA6FicCB5sRQb4KAIiMPOAcmGNMBgZ2YePDU6Y+NInKAgQNMGEQxbdUWFCQMFgQSQTjWRTKhIG8MBZK0tuZLIGkIEhoELCg4sgiEc7rjAZNE5JFAh+dCpqFhgECmS8AXQUyYyZMgahyEwyTDAAVwFWSJFboWPAJRlpsyBy5rFAgGGzVTMg0zgkPjPJT7DARcVsJiDlugwwINXcqM6HDhbMN8xxzJRKxzHGQIyplwycglJAEdTgLTyOGQvgelJkcm26IGyY0IjLjgYtCUDTS9QjIJkiIkiDKg4GxPIJNwwTExEGnDMGtnAcsRDHagLTixJYECLigYQlHa0NjOs49MtMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUw/cQQMEMHgTS0ONY8elVXP8FCGTGgxJcwQUJaNZgNlTFJAeYxMoxgNHJCFAQIomXqLAJhDQKCYGWAekAK6ZFaDlGFjgVBgQYEcYGmC6GEyC5ZiyoJ+aKwScajsdDHoZoiuHHMbJocaYoIcigqZ0CYY4qGaXGYYhhOIweNfB1NAE2MnyjNBDvMrg/MaxiMfhGMfRBMJwQMCgbMBlFMliZGTQMAQyMLRkMZATMIwlGBCLzp8nFKGNOGcQmQGGWwmLRFYkLDxUKYE8ZYmIR5hxRxUAXFGFagJKDE5kGIQiU2NvBMUVDkplAZjERaQyIAoFApqYYEZo0Do44EHSZh5IcFM8cNSdEIN3jMAC4I0fMgBBwsMBQ4DA7RGRGSAjIc1JkQgmSELEmJIA17Bz8Rq0bzIhQsbAAhbYyGIlpkhZjiCaYBfhxBHcygAwQgACy/xhSBgkoBYGeDFpiqFJnCAwVPCEiOBwIIEhiOhMnVoFjKujClgcoMOoaauVE8eTL3CbRlQ6TAOHIziAWZ0W1piIEMhgxPkGCFfKZN//viZMyP/jpjwgP91EAAAA0gAAABOHmPCA/3UQgAADSAAAAE3C4IDCEJgUBgkerAUFwMBC4UZVBUgREh4GLmhg4YYyOAzKCDUgmLt6umEI//+kw28CyMIiGKDIjejc4NsWAO+BNgjEcREIwaUN+NlfDNDAAAFkwbtMCMy/DnDAcQ+oyBNMWMA6A/jASAfYwcoF+MhyGsTBIwFAwPYBnMBLAhzDLBRQxf8FwMSSZNli8MvDTM/y7MywFMgRWMwS/OKwEOSD+MZjMMjEJMoyvMQgIMOh+CoPmhwkmOg8mJYmmDYVmEgAmARLGdImmCACiBBwcjxiWDIJCYwlIsFByvQwEDIwmBgwfBg1gc8gtKkNDmNaGaiG0OjMke6hisuUYNCa5YBRzFwoAEgJiQQwlAx5ASgGIEJuGxmCyUZiwqhbzGHUmCJJwGDVhE9SICkIiET8YHiTUueTEDWOgIDBQgLLx0ebWucE+UYwdJMeIBwE04YEkgKIMKYM7DMiKMiWXCCSg9BEspKcC68RiA4oCioEQhiRW4xYUWIlzm5jwwyS8mPLFTDAQYITNhRAEY4wocajDkd7QgUisBRCZQFHmGLo3EpEhBBxEEAyQGIRIKjmHMAEGUaxwKCC4qeMMSBIdDkXUBQwQmFJAYEwwtw5b+GSDBCUUHKOK2p8phmFCBgsIFOMMBkoC3RlFJyjY4SJlRfhcK+JNDTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTC6Q9kwUkGuMLyyaD9+IE83tBDUMGlCFTACQh0184UcMN5AwTD3l7gxS8M2MBzDTTEsUk0wfAGvMQmBijAfQKIxZsoOMRqB3A4KWMDHBkDCCSQoSBsjApAuMw7ICBMCTAHzAWwOsxNdz5DWOva05IAjYi6M/Sg2iExwHGOh8ZWABvEciAiGJyIZnOxhAlmLC+YaMRp0lGHBMOmk0SETBIDMBkgwYIxJhGJCmYzIJhQTGKQwbwqYZ4BXA0KCpEz4tYxQPNWEMieWqOMxZUHR3iByUGmzVH0TjHFhk2NFwKhNERGBKEKDwNGiSAzAcAlpNJWSA6AmMYBGJOAcPBgYkEGKSmjLBVGVhDAiUEBiigBJgkybE0GPhkGWjHCZiw4ZRLaFUEmGqI1Y4Kigu1CA4JGQ+w8mPFZUCjDJhlC0REgjGhQErMWPR3YSZQ2Y4EuwtQX+L3gwANJ0ORjQICFgAaJEDBACE4YkCLERIyHASwBRzEI4yp0FBzR0gEDBRpHMykVuYQGBwcIChYcLQ//74mTGD/4dY8ID/NSwAAANIAAAATdBjwgP7zVAAAA0gAAABFpmfFF3hUeRDRUeAhhlAIONGvDIqu4oYF2gMAGGDMtSXGg5RNRoboVtBgMk0ECm8kU4KE////95hmIAcYJGEqGZ/T9pp4MrqfB4K1GGeBjJg84YkaYScFmPTgshhdDHkYicEgGANgd5nXSYcYB0A+mEaAMBgdANqYhkUJmEYheJgNwGkYRqBRGEEj+BiCwJIYDWFFGFXASBgFICWYKSBTmBMgJBgkYLeYCCAqGGCADBgjAE4BNk9VzOrNTLlYzpsPWBTQD062ONaCzU5U0RfMsDT00s0ERMQeDzTkUQBCZBneYcJCEWNlJgcCGECBCAEosZ4nioCGCIqWOSChcwwAEAGYGQusnqBAIVHBULGRkHIwCNgsDMTTKHVYxMyBxUYaHkTyYcFA0/RavCMRASkwpBEYuemiAQKATFhhzQ4nMbKxkvPk5QZG8yvg8U5LTBOGnjPWMBBM48CsSLELDhQpIc3ojdACpICgQgMI0GRmmCZromEIiGqhQkuAKhqqBghRUZIAULFUyI4KNB4IKNWggZDKWQVJZ4PXpJBcMVXCDwCmAm2lGzClajiBlwsWIzzVXDCHiCqbOzDLACg4CbCYRCjlKDRIfZa6ICCUe1cozmDCYU8S0EKAKIQHBApcwGyL4ByKCLrLFAhpF12OyZn2f/QkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAYRMBqEGDA+wxQ29Gc8O1RrxjmQjsMxMAW+MOzC+TNYEkgwjkL1MIpWFDPHAkgwQkDCNFFTxzCgwZwwIMAqMBvAgTAuCAIwOMNAMHkA/TCTgGEwykJuMUqBADS9IPRwMQFE1CwjW98NosI4vBjxSPMeKs0lVTVSSMIgoz6sDH61N5i43eJCwNTTArMEgcyoFTNKkOhiAyQGDHDkNypMw+JTBQRAyXFiQYSJZEejAJvMPjAIImsdhUJLwC8MAFMoDMsDLlmyKgUmSBmAmXTGuKnMQnBFGPbmQEIIiQiIFJgSgVOmTLG1MBYieImflwEQhhSBrpgzgEEhQCbJSY5QPPjajBQeTCzbIjMkGsL3Im5iJ5xBBrBgIHpuGiABxtOoGF3QAoI1B5CYmQXYJqzODFqh6WaAkYGUOCgMlNQAUkBAxAzHhxggpi3QcaApMiRCIODlZMxMaoCss1ZAEkSRAYwQFwIKSki4RmR5EkGXXNIQf8ODEqNlYGABywyR4BOS/RVBAxEFAphRZKNYGlyClghBmTEixwwDElFhykYemFdrn/++Jk0Iz+UWPCE/zUQgAADSAAAAE5FY8ID/dRCAAANIAAAAQElQ8SMIWNQ7CAwKAgAiWkC64aeIyDJIzKAwgsKG5GVQgseWgkisrpbRg6Ao8YJQABG+sajJ69kyQbkOmDmIkhphgbwV+YCyiNmIZhIZgNCDUaDUCWGAnAyRpDSigYIkCOGETgHZg4wQ6Yh+QwmGmBdZg64F2YDgAamA3ioJixAPWYoAkfuhoZzFmYDoIYYHqTOwZUDgcmkMYrFWZLEcFixNOBVMaRWMbkBM/hBDC8EjiMdhdMbDCMGRbMKgxM8wUMQRXMFSiCCfMGAgMCgrGAXMFwfGQ9MZQSMGQZCwEEV02CgLHQcWHnxg25skhl2pgRhiD5nXAKKjVUzoAyBsziIyIQ34owaUwIAcZm+FHJLj4wiGA44ckYPEQCCFQTBQSKQPEhDCA5uZccAoBUBAkukMAgRpBZjTBiSRMKRkR+PpLFQBecGDQEfCyA26sobGBAiw4KHAhGXle4BGzChDLj4UChoCAjz8EBgUoBANpZd0YJAkAmQIGQGJlowM9Bwox4UtcGMxocBRgVAGLAgYDw1SEedGTCFqDEAX+T8Cwcs2WvMUGKoAZCkwovAqUgA3xYALIC5xIZOERA1sxBsww5bxkwRkwJhQSUQqDBwMwgQGAggukIlG44yqMoEAhtH8x4MDHzFGB0KYhsJRi7j4QHfA5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMKtANjDUg7s5CHkcMl1loz/2RIQxd0AeMLKB4TK/1towdED1MRhNQDWjAhUwesGZNUHYMzBIQNUwcsE2MC1A6DHmBxYxE0ADMDEA7DAcgX8wVsqHMM0AkzXt9TPI+DFAwzH0TTCAYDeICjJdDzrk/AU4gcxRlMCxg4P5kKRBlENhj2JZhIMphcEJk0DIGMYiBAwnQcwMCwwfAwwPKwxhAYwiD4xDEEgD4wMEAwfFMw1CowOB0wZAM0RhBUahmujG4Jo+iEUbhEYg6BjQhNGghCQgmamudlheYxMYMqIkhizRwA4sDO0iMRJIQQpiNc4Fs5QfMIDDlCjYBVhyYpVGRNBdMZs0UACh0CDhvWBVAGWXhcYZs0JVgQUHq40fIVSfwsqM2QOGCN2CBgctyAhBaVL0qEgskBpExQJMoSNAQsupEAOqmWgAYhBIdXUwQaFSwQSeJN1FM0pJLowYkiBlx0AgjBrCGAEF5hwcZwWa8OBSTCV5otnNRmfLrBhwEDCzPmzUkTLJTCDDOFB64IRBpXwVIAlIUPyVMRVH5TLASEdRJyg4Y1EH//viZNOP/lJjQYP91EAAAA0gAAABOdGPBg/3UQAAADSAAAAEOCIGDQAjDLMT4MCBCxEKlmnmdVGpNJCwoMSqUA0MTALYxnrMHvFczCbAFA5Nq6LP0DZ2znN0UAwDsUDMD/FKDPrk1Uw1ADGMQ5BejT2AhowPEFPNM8XFDDjQEswe0CcMB+BezJYwUcwrwKoMA+A6jAUwEIwZwjBMNlBgR6LAf9JkoExh4f4GO83TQEwQVs5aN4xgBcwiFk1hGcxXFgKgGYaCoZ0BUZCAwYnAgZKhoYUCOYDgcYAlCZSDcYUEEIS6EiAMOAAFRNMSRaCoIkwymDwKAoYDCQEzmGwUSNaTOCDGiwISmpCmRWFIAziEI5nCRBBYyxkCFjH2BpGDgZkBYcrKo0xCgwoEQCw5AYBQPfwsZWYISDQ3RHkBuAZgBJQoLdGGDmgKlnSzhGOBzE2iwtQKkxhkaiAf6kY9uqRS8yw03ggUNCAIiUrOIipoigFGhgUzAgWKGiGmyOChsGkEDQqRMUCHpZggqLCZZcCQLdbqYYoYQwPCQSZAhVuoWAmBKBdEZAUbQM6pjRwJcqKDyEwgEygAgEmOCBhoGAgEGIB6lAUemEdAVIDGJgQ4WFmNJmUEhYuk6FQoCtAA0Y4EHSkOywAGCgUqVBgGTLnMoHCo0xSAimqWmnHgkeWhZ2YcsBkEsMaGQbX28lWTB1P///+6TEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMJsC1zDnwXA5huDGPF2KHzyOEZgw6YJdMKlBzTVZ0TwwcIAVMJZHJTWigewwSwJuNBFRQzBowMswDMCTMAXBETHch4cwJUHzMEVAhzA+wVkwwwQPMZnAkzMUAMKpAzEFDX4MNYC4wtKDPQkPNPUx+wTMCfMCMowUAjCYkBRPNtks0CizKQWATiMIjYwaCBwjnmjeCSsYfSwRODDQOBJDMcEUKgYhPQOGhjgKiwaMAsFiBjEJwCiHYQnCZ3QHQQImqyGAYmaCgRmbM+AURkgahxqCpkxpINLxmkLBhYzAMwhIBXTNv0VBQQZsKCgxiyBZ0VDsPHD5qBoQXAIAOFgAyEhgqXEL1FsDKAq6DhBoEyZ6ZpjwRMsL4gYWREEBAAGA1YmUIzZiwBkx48UOAOAR4wIsaemNImPIGg+mkKAZ4HFwEFUbMWKA1c0xUW2N2LUiFg1ExJUcEjgkdJkJ0SaBBIApSAsGJAYZUtCodKRK9E8YKiwtoSKJpksNApuZRiZ0EheHDjbJEGBVEkQYBAYMsMh0FBANM6IMiP/74GTMj/4MZEGD/NRCAAANIAAAATj5kQYP91EAAAA0gAAABIMsTKBYFFG0IO+BsYAKDIADXTaDA4GZssBgQUPFVqELQYVW09USk3VDB5RTAwUYGtOmcV+Td/nkk/NAWjMTaAYDCqwTg1lYpdMPEAkzAWTQU1uQPVMHlAFDM0iDwxOEF+MDGAgxUEcMNDLnjC0wfYwAIDsMEWAazCBgjgx5UASMkR8Ad/mCYkGEI7GVozG8xrmGAwHPK2lZnmDJKBmqhh8GHwkmBoMmhQpGG5bGHojAYUTAUIVgzCYcjQwPTCUYiAwDDQODAkNTAgQTBYmQMT5hmAaEZgWBZg4JQqCByAGQgufASwqgmJAZwMEgdKMSDNSADiRkzQdANUQMIUXsPDQcrMEaMGJcFg0vM0LfswqIDMB4MLBhCJMMXDFMYMKtBodaI8yMECNQSMKmNCALbGaQmWKGDIGGDEJkBYQiQWeCj0DLzHLRY0BncSMjTMOENiNBRoEozYEzDFWWAJ0FxSFhCPMUHGj5lGJmgJKTBQUIKgogMDjBhG/T4B0UwYIDTF4jQEOFA0eaQgF2JgEAkzUXTvAQpnCR5b4xJc4h0gEjzwSBmJTExYvkY5QGPldmTHsXMG1AWI1gExAkevmvIGRJJqmEFEBkSjBwQiXERYz6ZfayxEfMmTEQVE8lEGgSo3CQIQjSRKYMeRDIZfq9pfqqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowX0KIMKqBbjtcXqQ+rmdcMfYUyTBIBMgwwEFlNZzGiDBmwCAwnlGZNOgAjzApgOIyjce+MIQAjDASAIcwOsF3MMtMCQMP0GAmAApg2IDwYGgKwGKbgQhrQk5iIUxi+S5CIRhec5wGMZj2Opp6mhqGLQkFpiGJ5gsBxiOLwJAcy9AEiSkKDIEGGRBGXVMBx2MWQTAQFGCZZGQQCGNIMMFMOCpMZwEBQtF/SEDDCYNwhIYksCUZgSQZLMSYArUGkTHv08jQAjgjSJyVQBdIzhcGIQuhM5BDkpmypRKOMAT8GRTPjGkjJHAQJGE6QjbAYqJBktgEeGSQJCrKMGIQ9NMYUsDgAteKzYo8HHJhJhx2KnAKUmJGmbEIDjKBBpgZkgNnTNjDNBQsnCggxCsqnQaAFShYFPSnyPHGmBmY2QwyAowjY1IYmdCw0tKAlxnFqnZIBMsDMkOKowWBm6LGNRg4GVToY2YKjIqVAkTDTCAgUmBSQyoZYyt5IDdQyoYyTczCIzhsMiF3gMST9M2rABdJhN5TVRsmIMtNSMEJFvi4IXKmeDICw5AGJv/74mTUjP40Y8GD/dRAAAANIAAAATqNkwZP91EIAAA0gAAABBhQLOzBlQUeMMDMATHiJp2AiBsvUzZfKRRH///+4BYBCwgCYDgHfHaySWZwp1fMeGiaYmMshTxg5AcOat8PaGLbAGBgl6e6Z5sFPmB2gwxmoCCyYV6DYGAdgMYgBXDG5heQxEkEtMEAAYTA/gKEwXYeeMKhA5DEYKT0hEDIwMzA0FjG4oDPdCjB8eTmAPzGACTFIfTTsFwEMhAApkQGZmUJ5kEPJgsE5h8JagxEGRgeIhmGHZiiC5g+RBiMAAiCYHBsYOj4AjzBAQhwRCQQmBATmtLh3gDRDeIzeKwcFKzwjPBT4UJzcmTUbjCAx4OYBqahYZSIZ5CZ6QZQKDVJnCIXFGsODSwxcEgcmmNnIWhQkPRwoBOX0NgWMuQNQRMNDIFxmCQEHm5TGAOlwxGGMQRSLDAAyvOOFMQcHi7FDHBSQmZBiDR4NMiRhWJpgBMGBBGdSg0oARZmBjMC3CvUejOkTKujDjBRqasYMATDFRkoBCYcyN7JMwWMyLSOC4QgKGRQl7TegzFjjCBi4wXGmRBAw0CjheURhwuLOSuNMCL/AEgW/IQJAiGAQGMGFCmcHmEKE1UEAVcmEWIkKBm4KqcAymGEDQJjEBBI8IjglkETsecjCECjjDARpwYUOZMSEATJFAEaLriBK1tFVu4Yioa/s0xBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTCuxNcwukWLPXVnZjmXsOU/SNYyMa7GETBWA/A1xNARMTYB1jBZmH0zt4GWMHaDyjPaWtwwrABbMAYAfDA2AGUydsGLMBoCOjAMgHQwQEJwMB/IxDEMAWQxtio4sRMx+BwwzAwxlL43YVcyVaAyqXc0ZDYxgCs5WGYx+CcueYOgMFheMSxAMdwUMGQKMGxCMEQATrMsxyMCwjN3RPcLC6ZeQCFG7JGOvmcFBwJ9TGTTKCy9IcpQbCjc7QFs4MIjIpM85idnjdGfFkEby9Bp1BhgoMMj1FBMYgAAgYkYNUPYYnMXaEhSSRd0xYB3XRaSNFRQESmSJbFzHKQAJEgSqqHYRmgcZMGKMI1BRFOlH4x5YQIAMTUJLmocQU1NgfFDIlFDiqCYRDXiNCWM9BMIkCABwzRn0xCJCFhnyBcUsBzWKzjnguCBpAalGDKNCX0ZAKIDcOKxrjL5ryX+aM4YNElKwsaGlwBIUZEAZkICTg0HFhz/++JkuQ/+BGfAg/3UMAAADSAAAAE0cZsCD/cxAAAANIAAAARgRQE2i3QGhBg0DQhbcwJAEqBEIIhS1TCKzDGANvA01AEQxCKqJEmMCMKZoKbReFSABGBA4eAkIIOPhx0yoKFMQLPNXjdW3/YAvXL23/6zIAQ/oxAIUrPTcAbD9pYxkzRI1yMdSFAzBpwzQzahHqMDSCYTDQVsUx04UxMFWCxDO5HcUwPcG1MDCBUCoFHmPkEX5gsIEwYIeB8mA2giJgQQu0YeoD1mkcFHz5ImEpIGLgfDgsGdYxmJY1nXbWGC4cGHSVGBjakQNiIDwcGZiARQwIpiWDYIAECgC0sqBgYRAqBgdMOBGMfAyCAhDgfDAeAwGGAwLGBwOpBhYFjEKSpCJCoeb56OogONoAvsZERKqV3iw5eNmwJSM5oGDIsR0wjjUGMAIwmjACZMKDIWWkqhQESLdRM1YQRhgoukBwCGbDEeHzwJSFqsvAgA0EtYqBzyECE2MCMFPJMJQBL9l4jOVXTAXmmk8xaRExLlMRlA4q5osLDTquWnISDoJQYsIBmrJxI4F1Fng48vAgELVroMYISANQ4HgK2BY4AGIyGVgagwGEByi/TBHMQYA2meSnaYSBgCOymYVRVUTTfN9tJIQol8wuOWnEIQBLMktPwIEWSl8nIyk1w0AoY2BjAEWzh/QIYEISi/G6enzlcXYZ///+5MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQZRIwc8KqMEdCQDggR300ig4EOeqBpDCQAGIwX0JMMc9K0zBigSEwTBADMOtATjAbwVgystGsML5AbjASQF8wBUB5MJLGpjCdwK0DBAZsEYasjQenEAaIjucdooAASMOAJIR0MGxKMKz5M7gVMVAHMVQHNNxiCooAwHTBMBjFsARfKBsRULgI0YoKa0ccxEaFiVXB0j5hA4yZN6bMfHN6DOoiQrMIEADs0YUw6NO8QygUZEtYGwgEEBZJwGhrQyU5FPS9BToyyMxqcaGjo4EszCxzHkRxCFAYoSMyrLgAYQCTZgmAFQAawahMZQqChxrxJjyIGArHMIJAJ0w6UzYs1CVJMaRGYSCMUNJzVki+TJRGQMcTDKbbosmLBGVAjIcRFzMGDHGiIOCkoBRmBEGjOm7XmBLDBYx68BCAqCMEBQ5mBNgwoEDzanzGtGHBdoAvg8upCyICMiwsUQFE2RotF2wECMuLQSAE4IiSc4NYBQ4rQFxakg46CQ4iUgkUNKQc7Vhh0cDBykxBsxB8oPiw8yA0MFDSFT//viZMuA/iRnQhP907IAAA0gAAABOHmVCM/vNUAAADSAAAAEEEFGSiIqPHzELDNAFKwCAAgUgWCJeFXQhGmwsDCc1ZsBSxJY0jVNTXu2pQ4wwEQVICYi6BdGEgAIxugAkObn4LVmzxE55QF6GApgvJhi5YIYWYAcGA+GtZiZoK6YAuF0mN0GzJWBhCoGSYA0BKmAkizpg+QGwYAmAIBAEWYJyIimGRAD5grYCIYH4BZmA9gS5EBGhUBUMCwACBGACmCHAM5MBkGr4JkrYZCFmJoxgI+cU1gVKEkcykMMDFpYZWDmsBYsMgVuOsUzUSYRFZrBsYWiCICBh+aIbBimacUmXhZjKmCR8FUJoBWZeUGFhJh4eBjsxVINLKzCQUMJiUrFQ8zMaBpSYGDG1EIlDgV5MnKDSR0wZWNxTzGQ0SVC+xnKOPHxo5UZcemOBJko8YeMGPHrLTPAwQhJlwUFR5iBsQiEge6V+VSAokDtS1ABDU0TCDGzRNBxJC0Imy4xo4toGZIHmESIhwQSwYxwysAMjM09K0MOIBAa0FSTUDBBI4iY6YhTME0ExnSWDoRKAIIChCWx5SCY6qamorAYaYgBEIwMLSmC0AGaEMI5IbpxgSmM6DDjOdEfpAazBEG2i0OiIBx1Uw/TVGg0w5DgJUuDLDZuATZiBE6QWpHkShuHr4AzMUc0cjDEE5zORawhA7d+as7VTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTEtRxkxDkV2OUxQqDnb1pw1P0rrMDfCGDBvwaQyJg+LMLaABDEXjGUy40FKBAJcY6ObjGGageRgVwLSYF+CkGGUCgBgUAH6YB2BGBYExMHeHJTBvgTcHOQ6dBzHZQEA0HRwYOU5wM1GXH2HSYyCazPwpBIoMKAIzKHjl4yNz1L+nLTmhUHpAGInnaBnLEnrknStG9BGMEOqMlDmazDBjzxjrTT0AzdFUAsPGuWAEAPLQpcKwYluNCYNORUDAtYogmCKRVCaTHwKhXKYEaPDjfKiIwL9zFSwqlN2dAQ0xoMyhgMbDREy30BMjItzJBTCEQ44TdTEEDAiCg2cdGHDkcQSRDjZvnJc4ShKXGxUmTCGVaBH0BuyRGbUMZgOYIgQhDDlDLEUQSEOZskeUmbosF65y1A8VABs00EKDwC7NCUPAfNOTC7IyJgQizjnTVOCiYWSAIkMrGfKDW9OcyJ0wfUhfGxCAUGNKhrAIn4gXGSJGUGmZFGQMmEDmrAhWMcNSBHZFNMUoBQM04wBYzQoDRrzGSCh6IDRjgLBBZyMnDCFzRAEjgxkBwo8jN+UCoYeEP/74mTYD/4jZUCD/NQgAAANIAAAATudlQIP92zAAAA0gAAABI2oSjTmiUQXUOSABCoKrVIv1/afph4wZyYXqLemvfFnJh3KYEbVWNdGH6gAZgJIASZIOPuGCdAXRg+AceY3uBxGBhAfphjhBOYTgATmATAAQC3E83Ukw8XIxMFgxcQI1I4s4ZLEgNIGBcZTmEAmgMDgOMJSPMsB6AUdmIwxGpsgPaTaXIKohjGgZIXmQnwWNDBS01UPLbghoM0JzKj4tEbYDmSFBjAkEIw6jnEFhnB8CicQDY6bmCBJjqGVEcHGyX5a8gAhRELwiFlM5JzGCs0EBMTUhw0MlAjChELowYSGMGxhRyYWcAhBMCBzLGUOVDG0kGBQjOiYcMCNDFwAKjQlaiyaZA3GBGJioMYwQGDk6NwBKC1JjQqIgAx83NLZjVBMmBAUnjzSYKJmGGxiosJEAqEAUtMOHh0CLwiMAMTHBxHBpKKkYkxAIJAA6pcWTAAiIgIBDxAKmPhhgQOZAfmlgZioMYKEpiIfGLCplgqmcYoXiR6Y3HmDFwQHjJAZ8TGwGxYHjAyViwBIxpPMNGho/NLFzFyp+DCQ01JMBy2DkEaFzAAUoNiCWM9CCg9M9LjHBAkBTBBMy4HMKFQEIDQWYCHgQXNDGjMxQxcJAIAAk8wchMMFUVUejGx0zERC4OHGQCMTGGIGnxkIYptLMMbOlUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUASAGzIzgawbhR6Qj0H/Z+2aYMNhksh1mOgZGaiji5ipg+mGiI2aBJExhhicnEkQHooqmlBTmmYLmsmCgwuDAltzUgDDRodjeMxDCtEDFAZjEcsjAgRTOC4xazNQRgxtOPHzsmY4qkJj8gFDO5sTjgOInJlRhhMcOEgklMLKDPGM1EWMWHTADcxpXNNJCsaN6CxUXMyPQEQmilhi8MnaNoZmS0Y8xGwDQlMGnj5ghyYqMiCABz+ZZEigIAg4OZTEhYxwKNNBBEpmDn5lSIYERkgGYcCmIhptgmawWAgwMQUzMQYykjMNHQE1mUjppgUaC3AcnNbASjsAzMZiLkAUZsOmkExn4cJRxkhcZIzmjEpAtmYJpj4WacYEpgbGajgSCkEyZDMFQTFhYxx9M4KzWgIFCJr0sYMLmmKZlrYFF1I8xY2M2DhJnMISGYGSk5ElGriRIBgwnBS2YSDGNmxiJWYAZmHjYcnmBOptJ6DTgw8rCjiaYEmEjoWAxLwNeCDLgwwUHNAQxwlEj4zIdMRMwpAGMCRigGDgkDBIIUzKyA0EcMfZzEyEHOIOQQhAIgwz0YNAHDFil/0pxhdGT/++Jk3gn/E2M/q93asgAADSAAAAE5YZECD/NQwAAANIAAAATghCjQx4wE5NjCDAGYDHAoAk18ZgEmhiAMJAwzMMDDQgJM9BuzC4ZicuZGriHlZ7Je2GZ3SqnGXDBPRgfAhOYjeZeG1DKzRhjgh2YPUE4GA+h95g9JBMZc0GuGGbg5xhMQKqYLMFiGDSBwphEIhYYXeFeGBqAhJgYwU+YKCCxGX86cHPhmomGcAAY9HR7+ImlQKVTiZ2K4Mgx/RUDQJMgqUkNhp+XHQAOpWYZVBhUrmHk8YVK5EJzKwwLhhRUJhDWoDGnTRIj9/SAGd4SaIQaAcbIwYgABEB18IOomtJAo+3MwhEwzMwAYoPHcNIUG1IABUYwOd8ENUB1CDlwogMcRAq8M9gkcLahKGIyBvJpvWJgEhjEgBHgh2aoknWaAqaYePfzhmTGkTQlhUoFU4GMGCbmWTmFOG5IjI44hIoQGXCmNViQY4KcCjxJ+AvZjZZk3pmVo9gC5NO4zS81ssyR0C+C9Y8zA34w5RuIk4IQpggoVHgL6ZFITQQF2MuLNE2McJAY0xpY04o75EaFmB5AgyIEYEqkRgIPGxIIBxpsBog0BMIfBrAyhwyaZ5pIBhYEEGpIHLFmJADpkw4QqqgS/B1swqACJRQoWkEIMElzPUBGFMQYU8Hg05DsKzGCjbozUXDTDgaOMuDAhAmCwxBM9uupMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgwIMIRiBC6IZOm6nnQkRJxlOoyYZCEHyGDEAPBlkIRwah6XdmCLAtBgOYZMYPCAnGAFBEhl0YIUYSCCJmDYAvpgRoC0YN2AzGIKBHZwF4mJF2AlMbnGpockGRxCYvPQCNpiQZCq8MQp4yiVDCBfMEpYyGTTFARMdDsxUYjHpMP+xMMzVeaCIdg2JiDHiT0qyY0EFDUokJpkGqyDOsRowAqpAcOTNM2uESEzCU0RQ3Zo5Q8WRgY6AFRkxRnBwyZMWADmAcsN2yMmeNJEM/tNePGZxgAJsCZuBIy1MqSAUAFRDMFAqQMiNHgYscCBhEBEQcLIggkOpwEgBIcaekzUKDwcGXyCTBvlABjmzYFzgoMLUjBYM1BBAMyBk8QLzMl0Dkgh0sYQUZQIqFHmyl2CkSZYGFkBExotmaHxiyaZasI0CMWGRIT2QvCAxgR5ITMoQHUcSMiLMaHJQZuRzVwUbQCI1GBFlmhAYCC5AChYEEAoO/o0ei88//viZLsE/aplQrP807AAAA0gAAABNlWRCA/zTwgAADSAAAAEKCUNDCD1bB4OLMTGlylKAoZxhpoVBKJMEqWCBQoCkwiACVxuzZxSYhAmlXiwswBlKsdAERpoih4kNLpSzvKnDHMQuo/j0ZaOfJnhTA1kzkwOkBmMMeEqzFAwVUz7RCqMFmBOjBOQTAw6wBhMJ4C2zJCh4Iw1oI1MBzArjAQwNswuEGiMN3AbzpDPMjj0QhU2yGxhgGOlsCDCagCxgQpHFiAY2ChjIKmkBGZYCBwEKmcSUYIGRlUFmIRcaVExj1GAkUCw2BoTAAlCgmEjuj2ZVMQrB74NEBgQY4uAgRswgwhMeFCpgwo0LpGZGPbmjBiQsSrIPg4kBDZkkJphQqqMsCNguEihpDxtToDHmYitIBzwoOEUtY4KcsbM2TAQYXMGDAlU2IERjnZIBGgRkiwcKLhjxIxCUygcwZFQcxIswooyYJBUwiEswsMjyNO0O7BTEhg7CBRia7KgCtTDMoVMIRXqzkw5gBPCwZB0ZfBccoXF/FpAwIlsYoSY0aBl6QgGAl0RYMJEx1KpwOvXcMYFMIZAxMZFkoMLjCECATIQQEiA0rBy0hPGZDGRYES5PgwwsCGCgiKDDAloYAyFs7lBZKAlo4ZBS8xpAxZ4QoxQKtEwp4yg9lQBFmlQk0QLBDAB0wkZB4GGFQAIAocFUFm1JPwfTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMl4oNTKlpZY7hTrUNAEM5DNQRBAx0gdbM0yIODDH3R0wD0PLMEgAsjEfQJIwKMQ6MQMOCzBWR6QwWwErMEtBsTDawLswP8LuNi0o8kJhCeDdqQNDH0zQezk6TMTOI3CZzeVbMVpUw4qzGiINMNEjrRl0tmfzQZBJRiRGnFR4bACxEwSgQBwKMeAIwQazC4vI1ZvVB61RvoRo8pn2hl1YOlmfBizgnFGIUrLMJIAJ01Zc1iYQAjNBSAscmqLhRIGb0wYVIY6cbySYkUACJt55nxh6TAzJMK6B2Y0ogFCDSCgq3NYkEeIKJxp+fxWHcjHIgMmJhwGCi2caDjogykIEljJhzZIDa0zFATdFTnOhCIMIOCH5MIDhBEUNICB1gRlVjmSLv8YsSBBxdU2ZYyrw4o4y/UAhUii0LCThWjKrQsYQ4GCXCqYxA4RCUxzKtTVChYuADoCnhBowRMQChUOYciagIYyOFQSCocmMYJNrFFoCTh0H53lxhDZmW4JjAoO/xlyZ0nIhPGWDi//74mTFD/55ZMCD/NPAAAANIAAAATWVkQgP807IAAA0gAAABE81gRRIxxwGLgCSMQ1MPNOjAM0uNUgBpIhBmLDGXhGLDiTAsKTAlwNEKHIYrMMARAMaJbmYoiLJzZpgh4wOFSi436/9lJkBQzSfmEM2Gpx2Kpjtas0YiwBaGEPBBxmJwkyZTmlLGDCgXxgcoPyYdADIGA+gKJk1Y18YMSHEmBdArhgSoKiYDGCVGG/A0ZmyTmGgKY6AhhQNGvSeYOaxiMdFyTDqrOZw8DPscFZjwTGIkWa6GBjkRioPMCBkAE84qgzlEwAMQiShGLCX/NcfMemNElOaCBQoHADFnguHNmDSjICwcJCxMzR8xTIyBQwyEMwhyISSGRTmSAmBCJtjR4oAIDTHhEiDSkDMIFFRCRBAM0hYzB4yJsEEDAEjPlhUuDm6yQE3UOLshUCIxI6EDECVxfwwQ5WJCSxo0JwGhxBNMQ8Az0IdgqgELXUTkL0JpGWGFxxEIMEtMMCRlIEixAKHLqmZBFheECVorgXIYoiGEFTGUJmDFAR8YAWSozFEhAEMeRSHEZZ1THByYgje3AQsSZKmKCgyxDMCkZQcBARMw4Ay5oUYmGIlhWCVxmQqGYqGMeKCiclQqdBcKooFFREcMgGAgAaImPVOsBixKBQ8Qrfhh5RSHigKBExsvgZAwQEzEgRYmgeDAj2Awel7DNimWUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMRfjajSXo381Zb/uM4XTWTInAlUxJ4iOMPcCvzYQkacwMwR2MEUARjDFwZ0wUECxKHgkw6QKYMF/BKjNatRGvh/m74jTownDQweCQx7A4CCYY8jeYsBgYZg2ZYA8cqo8PGOYXBQYABGDj5N3BOMmg0AwwmCAwmCATmgAiTw74EAHzQrgaHBUUyTQsJCFSdEoZ4Obs4cA2YoqdkGX8LcDJBCYcY4OWDBhzNBy5AWBmYSCVsAhTcgzBoQEqEB43CpHw2yQzBgIBAJgj+ZwwatGcQ4OEjNrzDADMtjDKxNnAqAIzIoqiBgcYNWb8wbAGeZQa54ZkWCAIXXmsHmSSDKgwxM9Kw1CI1xMFXQhEI5powoKEAQeW8KFwOdiI2YIKATQVGhioMYhUqYcwaoCBohgigJCHHJkwABAxGQNURASUZCgYAY+IEgkE5nChiR5mlIJHIkmQDmMVjoAwQldKsLJTjGgEIEh5kzIZBEJUxYhM4rLhUX/++JkuY/9/GPBA/3TQAAADSAAAAE0oY8ID/NPCAAANIAAAASbRhBxlwYELhQSIXr+jwcQDlPFUMIwQEXCEiMrDLljLoAy010HHAEkMKTMyXCDhiQCgYEOmjMF0THo4NIV4OcPWAgQyBXu1aEkv1f+kxoUdwPn1D7zPG7tUyoY8fMgpCpTDZAxYzCsF5NcJH7DCSREMKAdJggwCoYP2FAGSUjFJhyoI4YDAA6GAEg1pgywHqYIGFPGu3iYOAZj4gmECSagB5pwWhg1MDHYz7BDdg8MZmozUEBoJAFqGajuZjJfREOS3IlmQECzE42AAVMjhFHYRg0HBAMlVR9UAAgWmqUBYeBlZWkCwFQwwwpNQisDg4GKgAwYcCTpM+JlqIhe40Z01odCSGDwMfM2EJBwCKgkIHAwhOVBoOkmHJAkO6ZiwprhxEYMQDXwjsxsOAl5DJITVDxGGAoQKkTQTjPl2WFrQMtAJWVBgokKgQGTSmBBAMQByJgIyJlAQFEqDECQUHmUMgYcqdJwsBA4+Fhpgw5rASnawpiBJixCHUxAcsFQ4cAiJUNjREz4ZgyA5DiLCDHhA4caUaW/GkIEFESowYAhDAwGq4MLrCqHkgAAFCEYYMMPIFgXDBwAOUA4sCSpdMxY4xYUkEJ2k11R8MTyIGCwabMEFAAMFGwwgNBEwDMDgcyDC6VsbEREtmIQSYjKICcqzFVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwsuIzNyTdYjF8fMgyGZtaMX1BQTAkBr8yFUPWNvmFEjGFgXIwu4AtMIHC0TABQ2EwVQq8MFWDxzBSQCAwdQBDAQ0IYl4CUmcY+GFI+oKhYFDC8dzKUpSYnjAItDQ8XTgIAzIQTTFgFZAKFca9hGYigsYmhChPCpDJmF3zC8jHQjMIDANQdMBwwztEOek04xJUFdwKRALsQmAFFCCCHM4TMSTGUdlRgJHxAkGogCjmBKGJOEJlGkyKABJhAeMqDDJgXJnHMhC03w4zwMKs1bzBliUgI3ZlR5kQZnFgJBFzBAABAItmalQREHqDkBg3pgkwt2BAYzycxZI0EEPXhROZdYYlqYJ2HQRogo8YMEYBWaIaYkibgyZtiaoIFApa4CHBIoLLg5CYUEY42ahEZIuOk0LxbYoeWjBQdAwzyAwIIRlTJmwEuDpMOlnAQIJWwOomkBmUNAESCjhecyqkKhwVFMMRBRs3LGnQ8BUMaRosDS9FpXBg//viZLqP/cFiwQP907AAAA0gAAABNdWTBg/zTsAAADSAAAAEgAAVCwBgxit6Oimg08IpABLnDgmwRmFIg5oFA4gGo2iIKOm0vgEBMWoDn4sfbGATiAoxycx5FAGMhDMj06gfN/r/9JlRSASf8EdLGv/bUJl+Y+EZAYCzmCwDY5jkgqgaueadmGfiHxgGIG4YbKB1GBjA/xlJg8GYM4IwGBYgLBgPAGMYTgB3GIghHJj8Wv6YfGJiEbmqUoZ4JRosZBRBGhWqbte5nMQGDRfIjMo1ONlKdMECAtiFC4be+aNUoYYyIBExkwBtaJjiwWFAJiHMjLHkJIOpmQMmbcmjDrSTSMEJEgBRiMGIMWwKMsMBih1TNmA6OOjmPGNFqPDoABMzJCRKcYUIJGzAFjBvwMjItoBDjooIwmLDlROnMYkuW6pzDogKAAigPGBjsRFww0JDzmBwsHEAolcohg6oBmQZABpQGImAiREaUFkTAnSgyF8o8jMMYdQQhwwGYEYREwUeISbYgj6voobKGptBiYoGmcGGILBA8IrpWhcsYuAYQKCjQALgxKZdUaIoYNIyYzwkhUDAMKlgqET3NMHJDBkTA0fb8xYYsqaVAFmxqgJkyYs1M8ScwOjpAg52ZgUXhR0EmoVMg0CZlGXBQgEAky5otyYNGZkAGDRJCY0IgjgExhMFYS/ZIfBUsvWXennenuVf1/+hTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTBIoco5QiAnN4J7IjEG2tkwHMKlMH1DQjO2A600wpbiMAWD8zBSAdAw1ALVMGMCVTO8Qmww60NZMC0BfzHdUDbyMTCW/jRQrDAkFRoHjDgMTHAWjKEAzAMkQKKxjIVBxSRhjWC4cJZd4RLCZKGQYgiOYcCIYmAIYCCUZqgaYHjyYRBKYDj6YbBCYPguYDgQYTACaIiiuCv4drNKYMSpMm1NscYmTBwoOJHAEBKAAQMY8MZ0gTKzSrDEGBDHHqZiR5o85FWMASNWuCxM24ozZBSsxC00r4ECxZsCRoqiNwLM6AMIGMKtNCCM2WMKQGBDUTDBTHmDQBy4JpCBkhYAGSIxKUUSiP+CCxj7gVKGdDmnTmNYB1ceBmZKmAJJqBBYwQoVHGcDqLGLQJXmEQmjJl4QSBARkFHzOMB7GgONUnMiNHqBgVYCZAZIYw6CC5gKARtEZQxwUEDzAkUfU1AaRMsJMSmChkCozJGy35sWZEEBJ0wwiWDAQdKBFs1pBPQaShcmaWeFESboRKMEGHkYGLJeC//74GTJD/44Y8ED/dNQAAANIAAAATd1kwYP901AAAA0gAAABCQ164w5MBHTGAS+xVGNzNMJLeLDhDsiPAoOPYAcuEsCAAyikxxqG05RETOKPVTaXRh93//pMabPKD6ESvE21K4LMyyGDDIKwmUxS4UIMRSBLDD9V8kw8YE8MDEA6jEVQiowDgGVMwWEyjCOAOMwT8CmMGFAMvRCP5HnMixRGkRMUyBNGhoMxiBM5h3KgGmCo1GYZdHCAGGAQHBYCzAcBzAoFjbQZzIYBEazBgGjBAfxJGgCDhhIBphMDJhECZhGBYYFJgABowJArc1KYzAtZj5Cxc3rdBkw4owdMwD4zIYxxUAmlZUYkazLjDRvQNvDmyXQALnHEiIIpaTdwqAMUhMKTJAYQPMSEAjU0Y5BI/hoDC9zPvWZpUoUlpRwkIlZohBQUNObBwl1jKIBYoUD0bDIxxGMNzDLA82Joxp814MeYllC7hQmAyhAKKKAEyDBgJDCTACJTWmAQoKpEaHAxECRYKAhwgyQo4JAeuGKIjyUqHwEaLJl/AEZNWMKpEODmBOg5UISAcrCgE3pczzcwIcxgMvSBQ4oTByMKGxQCACAiQCAqYEGgJHkwCNB0c1xg2SdmCF40HGgAJCChJYo0EEh4cHBRYQBBo4CR5Z4wIEKGDFhjMURJkFQQRCMQXFhpE26ZQMYwqW3NEceiRd5Zd9STEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqow2d2BOz9bIDpd9LIxT1iKMRkDuTCTw6IzTcWNMgNZnDCaQywwYMB6MVoANzBewiQyI8jRMDJC2DCDALQwPUHgMKxAzDEdQSE8o2zY5pC5kMMGsBYsxQnhwpGDyoa1R56pQmsCKYvDCqpg5NCE6mdRWYEEZiwHGOl6aeOhkQEmBBEYNCxgoPGRQEEI8wYXzFgMC4HMUBxwTCwBEQkMCIEw4OhGCEgTdFRJ+ZLIRQzEPwAuNOPBSQDQwKGLsmlClzDVQjNoEMAC1McdMUQMWrMAhAQAEDTKsAjeVthJYyEAHg8iNGjBDC6AGYMJM6WLqmEKgFGcsAZY8Brw2IMGAMiADBpmIoYCMYZM2SAg0wiwzbYKnCISACxojJnx5wQAFWGPOgQcX6RqECkxygAjzAlDOEjClEczOAiaQaQsaw2Z0AY48VtDL0lyOuyUFUjVGxoEacObBuDnRgxgCORcDlyToYASlUELQSiAwECxDAFSwLMePQ3MCbDjhkiBfEzhZAIYhgYRYTPkNBxiZI2ZECSHiIakIZ5ILKDAlQwAZFqZsOFzbTDDigaaAoQGgACLEKwEmP/74mTZD/5BZMED/NPQAAANIAAAATttkwQP920AAAA0gAAABDMhAoJMkWESQKFTBh34QNdfOpTf//SZYwo/n6IKZR4M2PGZDyhvmSbBgpg645qZgiMPGnVKXpgowdaYIcEUGFIhDJhBofSYc+UbGFniMJgCgG4YzHGeRhcbpVkBWeMHQgMDyrMYApMBSiEQ+mK4EmIAfGN4qnCI9ma47AITi/JhOGJrSPYCIIwhBUxFDYwBAk+Y3MRZFCzOisYGxAHGPh4FDzZx8zBSMwADLQ4yMgNOJhGTmeByTIjHRlIBJeZmUESEYQdEQyPHJEMDxmYSDGjj5g4eFgwy4lMECQMlmOjxjAgYcCiIKMMLUtTARxPgKBxgBqYGFPoYUWA4YMCBIZEA8RDI0fGKioJNTGBAiNTIjMkEjCCMADhgoAY8ZhA2ZwUnNApgbASjgcekxeYqDEUUYuMjwcCB0lCgCEK2GBkAEBSQFJgkChJggWZWRpemIgpigeZaWGChIYMAJAMYNDHQsGBxhowY+MmThClSPaAEwkiMOLQsGISDCQ81oKZ2YSfmbhpgJcERgWEUrS6qj5hIOHDACVy3QcAmHARjRuaODAIUMPLjFhgGGRihMVAoxUKMtGjJREueYqihgixM0pBMaJBQEM1DTIAYKC6AIhHQoJGNgQ0LgoLa6DhseKAaTAYOHjVRoAgg8AlwVwSrOpn+ukxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMSfesD2zIFU9T/VuMf0ZOTIyQbcwdQjlMjCFUjaz0hgwXMILMCAA6zDNgSAwPgFMMxEJkTDTAFwwNsBeMEKBgTCKQiAwz4RLO37sqOMw24DMoCNRIM1g5jE7rMEHE9WUThswM6C8wMOTHA8MWq80Y4DDQLMfC8ymNTBpeFCKYALhhw1GkQwYRDAkHBGCzCxOMAh0yOBjChbM3loxkHjCQ6MMnQ14OzFoXMPhUy400UYjDmRCGlEmFIAkqZJWYY4tA3D44IsmzHFgCNCCVQiHrIMeJEDUoSggoZcIdYKagOYUsZ08qwBzRrwwMGiAcTYeaAoY4CbVQIm6Np0DBAKCARzChmixtzYCJAJ4Y+iZY+Z1iHdwBqNUoBTksKwjmHHDdLQaPBh8sDTSrBoaZgs4Jt6Ch0mMOKEIkw4Nfqd5kFJjmgbEMCaMg2MsONAaMhCa6EFR5mIg5g3ZhRhmhpWUMEpNTvAgwzVEzQaHAUwXiZxKZeGQo0QTFFDMCTECwqhMFmBwc28UMmhAIDRzHgjGgztTAslNgUNonMpEMUP/++JkzoT+d2PAg/zT0AAADSAAAAE3/ZMLL/NPQAAANIAAAAQGujczaCRLMaEOHNhJQKlQsqBpcYBDz0MOF4wVkAzsmAiScYemeJmDIGhBr5q9D///0gFTUyRiyJ7IckaX5nB7MOJjeBsUYdiCXGDZAi5kgACmaTAMDmBNCuhgNoKCYAQG0mARgMJkkoXsYPyDTGA1ABpgIQHWYKwBbGHWgShwwRmCyCBRwZrCAKwxodAmTCCMJ84qEQlMmOiEYqJBhEBGKF4fyMZhwTmUTwZrB5hghHAQ2ZrCzIyQLgkDpzBUCmMwgBREZXDocXzKAZMkksEEcYDZMMDAYkNIpFTcwZYWIBFsyCUx5E4QIFIikoYoIGIzmZjZJRyWtEEjAQXM0ZVrFphrwYNXGgdxEWAGlWm3JiwkBOF2FmxKIOgAuQUfJZY1qAIQFOzBB04waVMo4GJJoFJhx4MDmm/GrphwU250yI038UzYIMGlDMwxQH0zfjkmzEJw7YZQahWY0eZI+iqkONFFkpLg6KFgQAWm/dmfbmdTjogdMGgBl7wSLEQIywoxRBHogCIUGVKRgGikxgKeasPACgVAwGkmnDlxAAaMMCJAqnDdzICzGARIckWJATAgTMgyUWaIanWGEQoFTjBCAzpIgBmSDm0iEBIFGDErAKJMU1Awg0wU1I4xhI2gs3yUMEmJFlnzEMUeGRoBmZUf41ZMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoyAdx9PMtUYj5J5IQzAM84MewCwTBaxl4wWAHXNrZBfjELQw0wYsFhMD8CPDAkAGQzfYRIMCWCuTAewZ0wQAAmMOuBTzE/Aeg2vhDIiGElsBhGYiYRqgWAqHgJcBFSPCz80e7TNyjMkAMw4yDVbTMNhoy2Mx4WGICKy40RYtcZCiLUDUnxSGbU+ckeZQYbEEaMmcKAKPRWg0YzB88ic4YxVcwAZ4Q4IIrR2gQoFMaTEmRfYMvpeDjI7ocVlGxXgpgMLSqLZQTEAgqYg8YYonSFz5jWgKCBistKg2WZJrhgiYBuEWOAQMbBQITTCSMhbGvKEKgFTjChgEKMY/OCXThM8RGlCZijYGFAEWYg08yxTIpzjkQEmCypTcuYCToKmGUDmGIiNGDgBjxIiIIcDV0hLCGUjfGUEJmURj2IvFEdIRCGnmVmghkJqQIfDhQgDDAwRFAsACEQQCDCx1lZ//viZK6P/YhjQQP807AAAA0gAAABM7GLAg/3TQAAADSAAAAEuCYwoMiVVXfyCwE7KhExRQCTHJBzI2x4xkk2pQvSY0CZcwDibBzWKDGAC6w4DMMKARceSpfDhYVYGcJjR5ogYCQjLpGvNocTEIihUtwSTwff///tMx0ZpT3mHcw/uKHRMDRWMzD7A38ws0LUM4JE6zZVDagw5IODMI8BCDCUgw8wKcGOMybJzTDDAw4HAEpj0bxkmSB8nxZi0LJjcFAOBswDA4DC0Yin0ZBgMYilEOo8ZvKIaRQIYaBuAjBAqCGwI+GAodBgbgwHQgUlAwKyMKBMclCBhs2DSQbHDC4ALgYKm4ZVIrCEPVVjZgExwaJHgpihdEKiiJ2cY3DKERMZArwWnGAVmKBhVUa0sOkjGqi4wwHFAJpjK4RGaKJSsA8JeIebBcIhcKjDLgGsGbAKOGXHPOYQmYYACSo8RXYqNYqP5jXwlmMzeDn4WKoqDoEyoZPZ03NHiKFTWgQMNuKSNJEQ1eHRg0GMQrCCohIDRdtWdkAg1YxhZj1QcLMwJYoYQ6HFTPE0zgUViI4rEypfESAtDTYKgkaOtCW2IAgkjQBhUYPBjFhIwCA4OOgocQAxAzBARl4cBHTZpJIsUVsW0BB4cREQEv2LEcxAbEjpi2gcBUWAIIdMHxlLeSdkBgA7ZgubElC7YWFxyfb5lAd/X/6qTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoz5iPkP1iagT8xXDYzXQ49MmRBBjBqCDczAMgON0JUuzChh5wwIAFrMQDC6DCYBREyOIy6MCHASDC5ABMwDoD4MB7ArzCQRMw4cQozeHkKgGYYlKZhi6ZKA2QjoYjDIZwgiflDeavrSZwB0YoDwChcMZj4M8C2MaAxHABMGRdMDiCDitUfFBeFjBMNw9JALDgXYAwEqpgchCr8BgwLHN6MHEJICABAwgYyhAoCGLJhQQZgcjMBGRrCgoEIBpmToiKmlQpiGMSGjThyNxwYCM5EDtBbcu0YMmEAFYzKIFLV+iIEZg4XfTTGDQxBAV9USSIkDaEnwhaagk7TsAGed1eDgYsOHjpoUY9EMCDM21MGGDgpKgNgGBhBOsxYczqUyoJYpeJHmBo8YBcCqYcLTFDH5lDBlAKxC8YUEEQ8MFlQIMk0jC/RhAhuCgQSAR9rACBl/TVrUFgcDQdMKTIiAYAMGpCEZjy6hRgCSAEUIA0eDXAZRNmTCpgFZACZMiLhswywiiFggnQpSbi0JP/74mTFjP2XY7+D/dPAAAANIAAAATkxkwQv808AAAA0gAAABNBGHN0+NSBdMwpcAkDDF0eUbjCEAYPLkLRLZp4oxt4X8hl+8Ax//9ZomTwtdx236pid3sfTmJEK9RgPongYU8KbmT3AgxnuiQIYF6F7mBWgihhOAT2YNeCXGLZFEpglAXaYIYBZmAGgbhg1IAoYh0DCnDVGYXV5gsLmVRWbAfRiknGeB6ZkBZg+kmn5abaQphgeGNEYWCscaO5i4eGDjiYUKBh4lGkxGFQ2MBoyeUTGAMM2BcwEBDEYVChkw7Q72cwY40zk4VM2d4JrGyTmeCmUdhYwYEmYsKakEJXzDGhRSaueqkPDTbmFTGrZmuIHATA0WICaIRZxN0w4w05YYJKfChsa6GYUGjCmMFmtUg5OIhAacMOJApM2EsvsAUZi24OHA46akGFWoICooL+MsNM0SC48tGnANbTZmDLgwcIEZAz4oVQGkCgEQxk1ZkyoEwzIajjz9DqZAklqbNSguFAIGOgKcDRBhQRpixoiSZRpCJvzZgSwcZDFhgwYGCCXMyYVDkChZUGgZYaEmEezPGTKixJuCSJhQBgzBE+ABsvcRhBGhNWqGERlz5pkwCsmQJmyMtXEJcABTDgCBSYSsskQjT9tjMEzLijHrR4UIARkKBgmRkGYjUJeiNgZJCjUkaQBhCABxA0yZiqabzQi/YR9VUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTJHUp070dT8PkbLVjM2SCMx1gA1MOJCljLxAGAyQVNhMJuDXzBGgS4w3MEGME5BKTJ+SGYwIYDMMA0AYDAnQB0wi0CuMMHAbTpyLM2towifzHBuMIKcxcOTJwdEBANnI4/6kjSI8C5aNGBUygQztJpKgFMeAYSOhjkJjDQ1CciKBHEziwCITVhBCAOGmMFSDRhrGpl7hhiJxrpkQx+SiMwYbESYx0ASAm/EmHDGKDmYPmHHgFCZs+NvTEjxAYHDgKhGzamgEgJCcQUawOaRmGPTAozNoyQU08AOTGjzUniACEEBE2HmJrRRgo5rlooIL/g4EAiabZqywCdmtJm3VoqGUCmlZG7voXGVHmYqAAWZyGF2BlwxgyhlkBvh4MIGWKGnxAQEIyRyUhli4hPG2kGDOGrHGAOosmmAGyPGIGBwM2KkaLq0CMUicJHR4eaUmZACnOacQYgoVpDXhzcoxEYAJQ5Agwr8QiDL1zhgwMUIq5izgKQoOmbAGQCGfNmEXGMGhG1FxyitAFRBlEZWYFno4RHDxshwY4NUvML/++Jkzg/+NmRBA/zTsgAADSAAAAE40Y8ED/NPAAAANIAAAASBWKk8FVRjRZo25iWAIdiI0IwZixpQ0NKEDhxkUwGFGVBGkHggq58EUV1cxWxUnOmsIsj6OCAsw5BMjMNvDUzAJhu4wksV3MVvT5jB6ArowSkIXML0AfDB4AbgzOYJrMCPBPjA9AQAwF0FhMH/AATCfgb4yO+DKQfMZBIw6ExgeGujsAkETBY100jwiMN1GUdShgc1GI26Y5XQWFwwNkmDCQPFogZNCRhMOGRxQYGAZi8XGDhiYWCRkyJtVBjXIEABWGTAGImEDGdRCASEcTQtjMNBCaN6GMgeX+ZUWGZgx4gNCBoQ5DOKfpoSBm3p2QZo2pqC4GCmpTFCEypkWgCVsyI5BhdJNJPYjJEZq3pzjxlBJqD4BEAFsYkSZQUZ4oaMyZh8bc4YgqcRyEOhgwZMec94JQhEONXCMkxMAdGBZkBSV4hTmAOGvAkxYzCQmUJiAkGUPTfhTWjzOghoal0ZYuCnJh3xhgxjzxrFRi04QEJHYBGmKbiwYUEo0Cyo3QE0CM0w84aULqjZLBCYMcyMwLTJBRcwDBW4wwsSVmCSETgrEjIAiBg7QNERY6csWMghgICgRgkxkixlQ6AlVc2gk3K0yREeLGYGiUE0KY26Y2xM0ho44gQDAw2ZoCsMbQ2Y0FAxgEpkg4sqFQzU7nBL+tVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTDOz8w+t5I1Pm7EPTKyk0YxzsIGMMNC6jKdwb4z3RUzMJ6BMDBMwIUwnUEVMBEDTDMExSswDYMDRlMBhCGTBUgTYwlQLjMm7k4anzURiMlFE3Y0jZZtBQgMPnE0MhT8x/MNGQxqXjL5pMRiE5cmDKwqHmEApWYGMBqoCGjBcZdFhks5AZBGEhmYADIkmDD5BMriQxeUgIIjKQwMkicxgGjKAFKCAYNNhlULreKgKMsBIwAXjNAWaGUAsBEVbAGCRjgBmHkCCmsFRyYpGpnBemFBkYmBoKRg8CTKQEM6FIxSBkEhgEfAkIbUOOBzGzAqfE0hjhxhsoCHnYFCEQbhkJITAlQ6satsY9MHQBOcctyeTaNrjiujftDHtAcOTCMQoBxg6TAxo8zqQ/Z8z7cZQmdKGMSg66ZNADAhhEZii5qGRnqwBFgkqZUAbtyjSYcqMIDm8DPhhAbNAcAS44RY18EcYgIwZzAbwKdtkJUxDTNuWElooWIAhgUw9VMAOPChNALNJJESqFIHAJ4YlkTfDajxZyIT6oDFAjFEAYNQJhQSImQ0uMIDEnZtipJAMCGMmZAIoyww4DA4jI32cEXDAigUKHKYCqDV//viZOOE/tZjwAP80/AAAA0gAAABO62NAw/zT8gAADSAAAAEIILgIKYJQZFWHGwcAjcD1xT//6wA9BMwJawDcWUvM6EolaMG/ROjByxLAwAYbHMYpEnjR5za4wKoT9MEWCFzDxBAgwJcSXMUwHhjBTgk4IAazAAgNMwXABFMLnA3jojMMkEMxcBDKAQMvIkoqJjELA5smSlmfTRpj8jmGRKASSaVJBxIsmBx0YgBBpFIGc0IZ/VZr8VCxqMokoaIIs0iwNzBqzMtDcxCAzBAFMDEQw0KgxuGGw4YBAIkcAgWmFR4YMDrcgSETPhLAAiMNn0zkKzJRKMDEUyGSRCQjEQMMIihlZgANgYWGJgwFgWFACBh2FEOYiAxlIBCRUMEhg06A16M3RwwA40SIwxEwQAz5oIehiwwg4OLjS82io7R4lTmSOgg8ZNEEPzGrAO/Nd5PkGDP5wBoYrgYwqI3L8z4wzNQw583S4exGMJmDBmjYjTox5soHoEjOpTByBQ8MAjQNAYLEn5nAoKNmJBGUHmpTL6NUlMfSNMvKFowIN29Bj8SdBxoykcyaIMSG+MmPFCMkQCjMhAhoY8YYAqZg2GMDgo2DGAmiRwzQctcAvIyNHoZojwIGlF00RJupjgBnRRp2JtYx0CYjgm8BGtjiFIZGEbAwahGZ5eddCbFAA0JDDKF5mDYk7MyMNwLB0ZTUvQ90weqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqACFQWQBMbHH7TePzhQ4CkpnMOnLEzFGAAEwGsU/MYsBoDPhhtkwYYPMMFCAjjBgQTMwEkMGMH8GPzAUwJcwHAB2MBIBHDBFgNkwqgFWPfogyAHxIRmFyWdBEJhE6GQB2Y3Jxn4QnJU4ZbGRoNOmVxEJEw3iCTCA1MhA0yqAwgDlJDMrmQtqEDAw8PzJQQMoAswaGzC4rBymAAFMXAwz+LRJZlkDNCYBWOC4EMWo8BAwcIhn0XmSwUkmAlYY0HBgAWmFh6YiGRkUKkJeFgmISIYoBKAM1OBSQ6AIZGbySZbGRl8MJUgoKiQ5NKMMKBM6DNMLNAee4SGDwQiDjC0IQm1UnLyhcuZcoJTjcmjJrBhCSqCgCGJzDIjNEzABwAwUrAykx8Q5MIigGVhgsQOMTxqTXqSzQCRmCBBQGAj4ADGLgIaAqYXgMAQlphQRlCYCKGhNJJjqUUegtsZs8DRKc5iTZliBimJmyRkBT6AIsY8MJdWcGdAAlcbFGFQQIOAJKEKzFKRQQjqiocwICXgAUoXmFAm1UGTMiqcIIiEQNFyEke4ocxwY50FhZhQppzJgi4l4GCgs4NonEF4zTwQlwKkAIMBEBADNFkN9HMaMNaf/74mTngP67ZMFL/NPwAAANIAAAAT0tkP8P820IAAA0gAAABOMqALkQ3AlTgQgAAAYzW47m0yFNBvzRr4YP4PcmDTBJ5hXYg+Y/kFwGh5hzQYVNGDbggZgNgAkYYSDfGTHiahgmQMqYIcAjAqpnmDMeK85kpRnOQYbKIBqZSmG0+AowZFapkdRmiA4ayLRgYkiqDMoMMCl4HkswIUg59hUJmHWCbGnn+BYOUjCwoy0zMRTDCEwwgcNgSzKksyMfBFMcJlAAvJgI2UJNCoAQRAIpMTRjJTgzk8CgcYePmTExnBGFSkwsGGAMqF5jJoYifG+KRqzMZtWGEVBmxIYSBApvNBKzVywuQwQQDhqZoYUUhAINTRnBmZqCGWnwiJzBDcwwrGgYFAxrQoYgFnCISAs0AjM8BxorM3AjMxcyleMNZzLx8xcrM4ThQuMALASoGNCJnQOOigc+mXCRg50cSEmSiIgMjgzUAjJiSqWGgcHRKENJFw4BMwCTRjYzg9V6HFQBSDBDEwkBDEUwAqMyAR0LMdeSAyMqFxGDL8GBIAPhnIGZCqmRjAoCmYKQYMmPshpwOJMxkBWTFRjIWBQRHcycDMIbTKR0EixiYOao1AEDMUDDEBYrVh1HB0uY6XGmhxiY6ZgYwMRBBnQsLF5syY3QOVzEBMwAbBxmBi5H8wcyFg4wQOcEIjjPDEzgSGRMeCX0b2muIkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxm4svNWGLjTMoRHww68aEMIIC/zAewpQwZ8KtMVSA9Df6azNo+zDAATSBjT8AOTKxMRIvDDQswUwJnakRnoXxjoRwgUMQCCaAAEQgEZCgqYGg6aAoGuJ5quQZMljo4As85cMNFATGhMBUpjS0awUGPQoYiGCCxgYQY6jmijgFGTYyssK5tZ+YdBGiDZjIwYYPF+zLAYaJRwNNaYzMh05UTHRgxU1BBgaaOKcmfnxsZMY0SGPFpoYeMNZl5yZUKH1tY0Pkw4a0amHEBVITCjh3zCisLEJsZcZSaEQCYyPG2GpriO1piwVEAuILBjIUZaAGAC5iIuQqhloqY6aGyGBkx6Y2bGhpAwgHEophIeJORgIkYWXmOFJlgcZ0UCT2ZCOGcDREoGUiChxlh8IhcUKkmhksNJBDDwRL0ykRM+DzJwowYIAwUZGbgYgMFGjQ1USIFQGTBI8PgItNUozI0AzgNJQsw8jMyAiEZEBCYMIGKiJiBEZocmxkppIoZOUAUKMKHrgyMEh+NRZiIiZGJkwMY0imEChlYeYcWGcLRoAuZOSmongEIDOjEyQ3MuFiYMP/++Jk2AD/BGbAA/3Z0AAADSAAAAE4JZsLL/dNCAAANIAAAAQSETBTMMJUEoEFxYmAIwu0IaUAxfgLiwQWGHoJh5+Y4mDp8YMDtNbEv1v4ch+nZXIwBAIAQVjEMAogxIcLKMf8MDDIoBxUz1NADMl7BDzDTg1owswNIMOGBLjCqA5QwD4BZMKyGzDJtib4xtgMgMAdBOzRctTEJNjbY7DE0LjGVrzrHzz1GQTZE4DTwKzT9FTSEdzHQ1jRMRRAEQcXhh2IpkuMJgoPhiwBpjePJiSMBk6RJ/aZhGgoRN3fBWM3jg2r87b86xAoUm8dDIESCmDHgYwrYDh5lHRdQaDKIGeSGHbg6uaM2aCsbpYiuDVIOPhhtWM0YcEjxsajuPHAKuS7MISAwZlxetJQKEwdABQ03okOlg2MFlURQWBANsSo06gCNMuDXw45qEBomAyRZEZd2UyTBgzWogg6BRhqjBqQRnVKfRki5p5RzQRhkQRJMCKL2gUa2QmgJ7pBhg9mJUAlQml8ZwC1kIFC24lIixUiWlA8dCgKcGPgzE0hMUKiy1ochGTYBLRAyIFc4ScDJZhQYlSDgxAIMARaeAAxjQwNGCRQKCg5OZ8YYAoRJC6hEaMUPMwMCfg8/ARE4IYwgY1osCEgqlUEM8ZMeIHkYsNLPATINLjXgxAkHNYCaijw1akxgwy4hYaB2ns3e5IdXcBqvE1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUw64TuMG+Lazb4Vag4KTjXOhsbkDBbhF8wVUHtMmvKtzA2wFgyPtDDMiQDcDEDwWA12tHFMRkDkzAowIswNkLbMdZDPjAAwLEwLAF4MAnA7jE/AV4xncAeNh4SOszdMtkvMFR2MxV4MmTaNI0YPYD9MlDzMaTENnQ7MxCDMyhBMq0wMay4MUy0MRQWMbgzMPBuMVR0MpSfMyArMIhOFSBMkAsMUQ4BRSGJQJGCQkIVgEYzGACTGoMR1yaJQOLAhCZw6FSgBBDiE0JoQSzIGTMhhMUbyWdxIYcUBhxmQQGGmKXg5OZdERcAIJMuEMYyNuMDnYIenMLGcGGBBlaoFKAWSBgkzwcoBGcDJHF7EVxCfNsDGRptkZmQYUJm+Am6dgIkNDmGmrBGOOmnVCNIaYUnyu1QZAEEUyASBhQOFmNENIQDoqF6hooDToYhKoJKww6BBGLJQSMGSYXEFp0kwclWkz8FOjWBioTMyNR/UpGAKlBe0yQNAoGFDCDTIKgoiGtEiMgwMCiWFHCIoKMQMUHKBJEYfyTjJ0xg0zKBiAhDCQpK//viZNEM/n5mwgP91EAAAA0gAAABOHGbEm/zUogAADSAAAAEVE1PsxqCbHQBmR5oFIWHAkIOHC+T+EQxuJihDIBGTj4yGGhlt/WiNBgRwUyG+ABJJUMALApTFdgfo1IggWNyJDLTcAgu0xqoOhMBqAnjC2yG4wVgEKMI3MXzDwAgkwOQBUMvwGvjCtAHQwTkFLMEIARjDlhGMwiYF0MEcATDBmQJAwYwS2MKbA0DAnAKkwlkEQMDGA3TAawQYyYezLRNMNQgwMQTPB8M/okwkZiZdGRBwaDLg88TMhlMmoQxAQQYLDFI3MhGFZ5lgJADOGOyLCCoSA0zYgxLkYgGPag0iaawa8yGNDfkjXEiLOagOIBQqoAqdqZh2JniRRDMKAAo4qDQCTC4RGUwaIRDTPhAMbMIoBKMiVgpKPhl4hCIRB11l+CgwAhBEaWQZseWdDibtKrqwtPAJAOJgaaY0CYQO+wsVByZN4FLQuGMCHFBxWOeFlpMBUqUwDBJYDOmWbMCHLZhYAY0ONGFyMNVRAgVA4siuciJmKEtaGiZUKMNMMDRXQzMkAXgYAUGNJSFRCqxmCRN/DC6AwRAwuHA1gwYYRi0+wKNAgpWsGDCEQZgahmEE16AEiYgQYleHWQYbNSZdhfwlJM0HSmC4UEsDXuTEIwocKFhfcaLNRbkYk4VgUZR0OFVYwBV4jymusdG9Dir+oOVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUEpSN0wSQLTMCtDnjTczAcxrpLeMxgGmzCwgR4wiUC6MXAFlzC0gQwwOIkRMIzCNTBYQJIyFEZRFgdgwAMA1MD0AN4+yNKlfMTSbDmiMZfWHqZMZyJM0TOEjZMfRbBgxCw2GCxVGhY0mKIGB3EwuM8acxlwxTczKYw0EHTzfBTLgUIjgKzCEzGFDU4R4+I0aAIywwya0kCDYUvuBgppxph0BlipKHMOwByAzYAwRQBAjBmgqxAUsQIA4sYQaGNEywIGMmFAwgQjwMnWgCR5EJCwg3pwzjw1KE56jwarHBgdAMIvMARGhSGA0FByI2AkAoTJADpPDI0gAALQiNmvs0hkaOIjvGYkuGEjeHzDEy3ZcUIGgUWaw4Z4uTDwUDWcShVFzADjCHTACh0Yt2XGFDlAxIIxgEeIIIjECmIAoyAgxQXAANCkGAwaWCGY6BGCgtDQvCoYQgDICS5YQKAAMzwswQYApmJl+AqDC4AIDpwgRAZMOmwDjqLYWGK4Bh5OgwKURpzGiACFMKJMC/Ipq0RGETiM2CMjf/74GTLjP3SZsWb/dMwAAANIAAAATmlmwYP81LAAAA0gAAABPAwsQnDhADAnQUuAgAIWjrJDoDl4iKgpszBM1U69BgGnA6/DFPB1sxL8OtPicgnj0jjxY4q04pMDyFyjClAb82MkkcMOIB7jC8li8zZkNuMIyDazSTFMYwD4ExMFjBNTCQwRUwqgwZMSBAsjDiwWEwpMGnMJbBYTFeAIAwHQIXML0B5DAsgRIwGkGjNX9sxMPTlDqPdtw0gVzfNVNMmcxEITTgXM4kYz8kDP6rKxwaOdRtg7FgOmLQecgShlE7m5DmbZQBj0ohUEF1AiNhwzNJDwz0FzJKqB6kgBhxN3TFQTSu08zsRDsuxYQYsCBsgijDDIqJBVAZMqZRAYJ8AAppCYkdFAhgT4sGCyoApzHrAs2AQ0HEhUWCBQGpA4W67sKomJCF6jMLDcLjMCRk6GXRUmYk8FBwJImPGrZCAprSCwpsB7ZkbhCHYUHSjJhzKhAsUBh8xIoVCM7EjgiBGOKJjmqWA5yyAzRcwYwyEVFABGlkCFKYsUDgIciMeHM4OVCZtI2woESpQbMkLCEBmgwVLAgAKpDPwTEqAaOJSEQFljNQMjBSJE8ywEwxUDJQcPLpGKFiAsh1A3w3RoqigadMWbKBoiAo0hhxczplQQulLwMPlsy2hYPmPSmZAmAFpEJHxgABB4ksI+jN1uthWlCuqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjElhFowMEC6PVPVfT4HWH8/2UZUMBlDxjCLhfg2qwNdMH8BXjHVDfs1DcPtMFkEuDN50skwsQCMMB9ASzBWQZQwbgs0MOACSDCIwAkwaAI/MDhJAzERghcwRoAjMTYAnjAtAe4wRkBcMCtAzjBAwegwMwBoMGCCOjBiAcgwJwECMEiAyTAvgTcwG0FBMCDBCTAfwDky4WNYIjaKI1wKEAebEMmtUwOlzisw7tkNPGDSCA1ApAQoaUjHMLCPY0mmEFBkAMYsgA6MAIkaEADImSFZko8ZQLmRAZihCZQBiACAIkZK5GmpSNgKJCgSJl4ws/Cw+ZKcmQgZgxYBi0CCBn4CZyQmUigIGQc3mRh4EDFNAg5S4MLBzEgcxEINLHjLQFWkIVMpJVpihn3IDjUuSKJp61ouYAIUVMM2sDhBGKLQqBg/4iLJFjAOF0AceQEAYs3MQFaBRyCAzyTQCe4IUJqjnXQIiMcBADpAKZEBRoNA6YqBsyVCBmQj0zB0eU5AdoYC5//74mTBiP60ZcGD+83AAAANIAAAATPRjxlPd0zIAAA0gAAABAMgVIwVhAEWzNWlEk7EUogjg1CwUqagQA4AyZ7CmuGdmAUgMYVEQBNCywA2IhigYsMtErQ0rWMghwIZaIAwosInTaLHJDFRKiTqJZNjrW8ZmWke0DAXbY3BAQwFB3j8kYiNlsbY5VVIDEkDHMPADE32zwzD7DaMXYEs1/wdjARDJM0pJ4wRwYTA9DGMc2EM963M2CXMwgRAxZGQVimvY5mpb/GagsGDwLgIpzFYRgoGBg4A5o8HBhcEYYQOufM6MNe+BOoFJzFKzMFDCKgaWNKkOqCBhQx4QAfjpIwdnMiGMi2HXQzKMfAM6XAUgDJzBEjY3jor2QCwI4yEyBIHWTYOD3JDcJQcVMIHMSmJrYJOAVKUvyaOq4gJGERDSMJJq4gMyYYxakdGmBCC5t+DXBzOHSqmOXCATAxKEEnzPAQYDEAJKNG0xgduSWxxwIBGhxdRVl6mymw9ATlMGJIRBMDAhQDE44qUSFhUODgZaQmIp7hcSUJy7EtSxKhMiApqBAAFISEuGDxQYPKA4gGBAuAXECiTfEQZFVmIOIAIUMgi8zvs9KpZVewXEBwMWCLcJAJdArDKDQ2X/JgaAkGGFMzLnBUcEMDBgGHF8jEnhASEYYKpE5HIXOxZASYMUYMEZ4EEGiIeMFwoKBxhNls7Wn2n1ExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjBdAKYwdQYfOl3kuz94oXM8LBF0MYGGoTC9AE01Dw6uMKSAoTFEiv40u0OVMG8DzzL9RgEwNIGgMLBDPDB1wY4x7oVqMQlBpDBpgHkBBN5gug36YwSDomv1uHzoRmuocBcZDP8KjHJMDbt1jpBVzX4YAogJmYCRgSTBsamBiqP5ksIhjCMJQVYwHxggLphMN5gkAxkAIQCCAwwJIycFcxdAsw5EIVF4wLAEyLB4w/GMw6CEwGC83SsyJEcWm4MmJjGXCGeXmDhAhUc9cZeiYgSaoIYEKBVhRLfowDM4NQ0rwupFTJjTKFTTAjQrkURIKZpyZICAmy8TLqVPFvzOpgdDMyLJp4VegZGHIACPWoaEgaUIhxNMLC5w3QsYIgq+NAkwjBkxESQsZWYhPwHDjMF27hD9EIQLjBCjKJgYCTxAqGXGBGAkMlEGNDamAYyBRh4AEKMijARsNfg4GXLMcnHtRQgEjAKRAknCB4mFWysJVAmVEhAwwg8LiSJ+kWZMwNKgscQTqmL1thMIrMGMQ0FRIJFmLSGSCAQQaUckiEJzDIz/++Jk0Qz+cGRBg/3UQAAADSAAAAE4tZMMT/dQgAAANIAAAAQ4OFQRj44sZKDAcdIGY1DAwQRN0tjMky9SJymagJdQwYodDsbf+RV3////6QBpYwNkJlMOWBdTZHIwA1y9AXOfoA3jG5Ab8wrMIYMjXNpTBkwdUwkQteMtpCvDA4wUQyuIMpAwJKYPSEXGAiBMJi1oOeYP0CKAgCGMEjBKjCGAiAxV8HWMAlJOwxoMWTgMkSrJpZMczDNWTYM5SDAR5mLwIGOAgmYwyGdodmRwQGC4nHKWFiYHSzHKDLqgU+F1ppjxkJgUrmqfGkSG5Jke4+SYW/GAKgE8rowyoxZ02Ag1LYgRmWImJ4A1EYtODh4oYX+apieMcGBQEYT4B2ICljKYTGuSJ4XtMsTNGqHhQkANpSCUwquNVHCEwXEGOVFDYwyEy9gzr8hZBEMiQCIEbWKLSzEJwhMbEeAN5mZxjl4DbmCoAUNSiQM8hcIPASePWFBTipWvmNcqNEBcwp0WsGVAjAYOHv+oUNEF7GdIJyAkePDCoHQCEBYDLjSiAU/AyUSAg6iAkRmSSIQhKmCLGgAGOEhAgyiYZHmDRmGGjJoSoDy80QECFQqKITAQpKDCewUPCIGagCoCYwGKpAIlDiiJxqBRkCRh1hWhBBQCFBg0WAIOTCTgSfiA8BkQFHJcGGUg4gawsSBUMzPmyEAX6XnYq4UwMoLDMMvJQDgTdME5mnigNQ0VGzGrBLIwi8X/MO4U3DEewzswOpRmMmjBUDAuweE1JEhyFASkwM0KEMB8BMTIvg0MwWIIlMLIAPzBkwMEwUAlgMN7ApDXa7Pd7gzWZjGxxNUzw1KtTUKtP9v42yBgEyTMI4M5A02KKTGgtKPYbEQ4wRjGTfMdk4KpcyAgjI4mMkJEzUNzUh4MwMEOEBrk1g46mJ04aCGJigwGQA8a0EagKCdBB/NWiNqLB5QBahZUa3eZ1EBJI6TMmtOgpS9IIIkxMYAMeKMMBMtCM0LLhMtMYXAq4MiGnBGdDDRszTUwodHQCzwKEGDZuZppCYssAVMrDGNNqAAReADRk3JdI7qg1pwxZwqliKMBQghGgxWZIAiWPFzYCQAkgA0Qs0hMrDKsMUXAU00hQYHCrIFEiYEh3MkWN6pSrNiAZIIzQ0SMAQKwIOpj2E0BRIQUGodCqPHhJhQ4RUGDJKhMaWNUTTNLdGyOgwgaNwpW3UzocZCmBMISTRDjOADBiQoILpzRixRaRg5CAIghqghhQoFFkz8GiS/ZgR5fpgyK5kC4yWAVsaAgIOY4GYEUGCwoJM2EMSlCAjM3KkJZQwv4H0MLfDfzgIqqw+vR3OPFxPlzGpxAwwxoHsMeEWVzEiwMQwxhakMpbDWjA0AYo2CwzBMD//viZP+P/kxjwYP81EIAAA0gAAABOz2RBg/3UUQXuVYB3Y+ZbByjANwHgwMIF2MfBIZjCbwVwwdQDRMCuBcDAPyKAwZgE0NKgDPtEwM2AyMklOMYhPOGjiMRFHNaCJMOAvMNT4AQLGLZLGA41AklzR8UAMiRmMTwYQQNBowKCgQloYmj4IhRMkCuNPhnMRAmMNgpMBhYMCg2MAw9MQwcGQDDhRMSQpIkBEYjGAoKlgATA8AjBEQTB4MREHACBJHMvGYayVowSlMeSNAiM0QAqc0ZgwRw0JsobMMSDAUox600pEyFMWPlAsxpwzCxI4ATSQKYwKDhIdhBAELgzMMg4814vuYM2ZAEb6iGgQYODm5gSZgwAkMC6VIwxwFc5hhIcSMiHMQIFCJQ7QEFxQIdMSPFTg8AABUGsC5671qlRWKDACFMQIBKoSrmeCGfHKdGODBD8RkAIYMWbU6NMTA08IEgpaZYyBpCkRUOFApjAJelNcyBshAgEMZU2l6ieSpwIAHpRlAIOCGONA6CWBghiBzaHQuVBAUyZsxY0yKQwxJCeAUACAJ+ggsjgYceQFUnzLmDAjBGTBxMxbIxIcOWKGPtZsEP///9OHYNfi5nnMWPvc3hj3W+7r559//7z9Yb//zzz1h/77n++/uaf1hyKxckAgIYHAaYVg8ZDBkZnpmYItQJcgcIMYZBrKaFgiZjIAa5gnxgR3BIcyZnGJhqwoauBmrGBkJiShxAAp3Oy4GrUofiJF8DCScwscByiHNpq6SYYvD0wZeSo9NxMRPRC/HYox8Dka+umMAxubiaheGYW526gfAqHCJxMxmXFJrJodQXHW3oUoDbCE1UPMrITDCgCA6MUVo72vqUnNbz1hhb19SxvXM0SnXiI7/XP9NCeCChaAAAAIgG/1zRHd39EKIEEFEAE3AwN/QkJERNzdw7h7/4RHxwBgAAAMPk+dUwI0ArMBUDfjXAZRE3vWuHPsFMhjFQwv0wQoIyM+/RfjF0wfEwrNdMMRECgDB9gGI28M1sDgj4wjwFQMClAjDDACtUwiQGmMHlBaTArwEgwLcXEMUcBCjEdgjjCFzJ4EzLEPDIELzNIyTNYczrQfTF4CzBEezJ8ODI0DjC4XjC0HjUoGjK0bgKDhjWFRiuHxjOJBgyAZnqFhi2LRhkC5icLhgkCIMAYw1JwwtDowaHYw9DcwZAkSIIwABQwdAIGBQSgqY2BEYFgUYYhSXhMEwVMOglMBQiMFAVHnQLgsODFxk0yFAMGcYJr9HDIaSYqeBQEZWmES7MDBPF3QZEAmTyqIjC0Bm5J/GPIAiiBIPKTyJLQyozBQoOaex/wA5I0wjYTlhb8SaGBjNVVyAhwcqGWrHUFMgRItXxmAHeSXYPkI5hA4hLoP/74mSjDP4qZMGD/cxQiueHMAA8wHnhjwhP71TKFbFfAA0fWVSlAxFqBRUIAWWa5QJxBSBgDmHCH5G9GoeqoEIqJmSUFpBVkI7YifQYiTGiG3Q2U2HlDUGGGQUSJOCgRSWHRA15yx7I7nAccMVgYo/DBWgYZPtkKEmmAZJhhwDyYCEABI2YSRm28ByShsQmFsDTUQEMDB25vNjRhWcrDINZXPt/54U8MNbEACMEnUMjZnQ0GMz4cWmRtIKGg1KaNNZhsDGAyKZnUZt1YmRCuZ1JIYCmgyKzf53/wzpInACE8wwZjWZRMQEYyAYAcxDKpjMXg8wqCjUkYOAGoxIJjHIlMbBIzapTOYrAIoMpBwwmFTEZLNDHY0UujXh+MkEIxwMDJBEMPBQOEDtJX3PIgyIRhEoOmYRgGPGQLTXB1R5+yZDef+GFICRJgUgR4aQwZzmEvhIhhVKeYYzkFImBwA2praxYGYIiAdGCPAOpgLYKQYRETiGErhH5gaAA4YI8ASmDzhZ5i0AGWYIWCbGE4gnZgPoAuYFwAPgkBMMGHAIjAcQHowJsDRMBxA3jBBM7iCMMDjMAUx4ZOrJDKjUKWRjA2NEo8nmbr526YIgQwJPMHOhVGMXNBCHgMsMalDWTYxdNM3AioHgYUMWGjXBk4sJFnQIAUhDEB1a5kYIZoPgUKnuYcUMoDPxEFBC6L4GHQN0MiIFR4KumRIAIK3EKCTBhwCWAQcQgQ46NKDDgRQyY4CABCoCoKMeCMeGMcOQRgZgZ8Uy4FMQABXOZcsh2JgRbVbgBKGAAIEy+QQGMGAN0XIAZrwhkxAGFSQDM0aBEGRJLSGRCmHMl/kKhkITGisQZRKTeAi+ZISRFTFHGDiEMY0ElOCqhhCg4DMOKUaR5EZcHIEgjNATEFiESo8CRZhQosUauYQ8NKDHRkazDjgxEDDAK5GPECQs4aB2jZiDGcTAhjHiDQqFCE5jHIzWLBG4NXXMcdNw8BkkdGmXFCJIBHhObR8NOhDQKzZL8Let3Jt6CwfOV6ObdOBKKdxnhJ2jQgQmjQGwPmpii2k9Q0cAJ9zmf//////0GRVZCJkAShyMhljYOaGXImFGnhWGePhDo6Cg69cyiEXHG0jAEybCoBtIXDmDbGKOiM0DmJtSJmEw0ZRkSDjhY7////////+inFixNSY0ZIiBONDBICMbCwbw1QBQjAOwa0wOEIHMK/fkzhRA7s4hoWKMLyAJjAOQdszv8WIMLJBHjB3ikwyO4IYMC3BjDNMR6owBoDyMCGAogCB3mH4i35gmYPUYE0ABGBegHRgJ4k6YaQAdmcJWepLBh8KjwgMTMg3Qlh4FnaSsEN8xYcDGxVAw8Mjk4xoKTJwKM5CgRhRG4wMBy5o6szJYGHQ//++JkSQz8smTDk/zMQHoseEADMdYzCY8MD/MxCcWyYMAHz1iYUJZigDBgmQvJSiYiA5h0ANGBIhMIg0ZCBByUQeOIAxYldSCctmmGlwREmCIYxosGTRQKRAFnAEaFoxoNdLFkHmFPABCQEEWvHTDWGQVAYSLTYi+ZEEEFuiXZMUUQiqucZGgm4ZAVRAsKGRjxRilFHSmLnUiSLFk1AKGFQU9AuCGGUyxwUgXYV8WtgBBOARy+LWFFFKV2ghAKik0JQ43cMJWKy9G4FeSm+icqmXYBh4KOVyXkN4MaCSMXeqNJcMaVcDCAQQvAs2i8CQ0UzMIGt1bzBNFRjxeDCTJSBIAwebzBEeBhF1hDKewcUVpky5jEFwERAg5FUWVMUAMBQlqnfp+7Fv//VdLc3AgMs5QXCEIYokJFpvo+hYsxzAJKiw9/f///////LJF4LFFBKT6JpgmJQNMMsoEpBhjBFNiYpB4yFUUQUCly+qZsPJENSbMw1Cak02fT/////////9RgJsADYs4MXiZiOxpizxxkmIQCuiD0AKsCfGuMmOgaZgUoMcYI8EymCr0PRigBXecVMOSmHOAqhgAIRMZ7cGSGCVAXpgfZKgZZQC6GDQhb5kiRHGYEUCxmBygYwcComLhBPhhKQLmYESBSmA9A5pgXAwqYHwCgmG0udGcxjACgweGLQMcsPphxGmdmIGDsyCgAEigQCDAYXCCAaDQBiA6mOQ+YGBy+QoCDARJMeBIDAIx2ezIgnC4OBAIMPCExiGzB4xMUggDAExGKgUcFmhAoYQCRTnEh5MgVBhogv2DnB4UvCBhQoGMhiTgwAXYL8gkBE4wAR0gvAGJBQFCeWZM4YDFIBx5WIlbhbt1GRip4GUSiEo1MxU4LmtMT4QvMY8KzGgaEEmIxAgjGXQj404swKCj04YcRAoboVigwkMjIjM3oVBME1MAiQeFQ0dfAzrtCIY0Vw56BUUhCCg+YjwHGMFkNrMRsAgNWYwnaFCU1E/wYq9iJ4ANEdY2SgjpQcqXcHtqBTZBK/J2LLOQHhBKlrdmag0MeLMNADRBiAWGVjbm+6IDAC5D9J1kgqPazYbeowTisSPPcp/nDeLaWFOvh9C5CTBzMcAzQMqFNzNv/////5ahvHCSIcRQgqTUIMaQcRYWJmRImpCTRWFdIrrt0bT5vIK0xf/////////NCHg0ABluBQ4WxAAiEaAjiC4wOkAbuA2yDbwFFgDjAcsA5opUMvhYeM0VGQ6UjAOwHIwAgJWMMyVezVvUg4x6UhPMBfCYDApwDgx4kOhMDBBKjA/Qcox2ID8HAMIwYkZsMEuAdA4CrTPPk40NYS7MdheIRKMWKxN8wXMNAuNMgtHiEJQPHBXMbwPMNAgAzcmGwcmAA//viZDSAy5dkxRP9y0BurQbAAL3oMgWREy/vMsmHM5nIAPOhQmJ4CLxMGgMBwWGQQLDzyY5aEKhiIYzBT+DLQCDMyBVN0PiAwQqG1GDRlYC5RgwmXIIzhq4SRGQyIAZfMxoz7TGiKIhQMI1H00BqD5hEltjIBVeVR4CAxbHUaTDFrIIyEwYBSDFBDNDNEZ2mzgoVh5ZcMCSbf9cCtDsxJMkLohYsAGprYPMMglmodaegnToGCRpFtnJWEW0wRymVrWJAJ+nmhkBBI7j6NlLnLzBxS5HVZKuNdxaVZjOlPrDqnvKkRQUxSha4lq8Ki75pgg4NO1ZSzV1CSzDGXg45otE3sfZQUFMaiqPgwUyYLnKCJpocBwlmRIAgw+0BoIiIgs+QAKhQDwYsKrbB9brsYRCQUJkdn//5HFQ8HQkFB8UHsYphqkfRW////////////uWuOBBBMLq0NcsWNxXsNbMFMJgeOmWqP1GtERnmIx5GvcqmwqsGsaOGlpBHFbsHQztmu5gGN5cmvUonTAamDIAg4UYczitI157pLfQAAgC+XMEhCQTCVwHQxi9JINP6OijZmwz8w1sBQMG2BOTGTBzgwVQAjMEVDLzJagM8wH0CDMNvI6zA0QGsEAMRgRIG+YWsHamBfA3RCAimBCgM5gXALuYVyAAGAOAgAhA5y3aRZigQbaUGENRtMCZSdmWDZswoCh4w8aQzOFFTZxYwIhCoBKxwEMIEDVAEOCAClixqtVm5hYOJOCICtAoHKGgUks22FOICwAoIiGBipkmD9Q1Mn7cNNEEDmjIaoZUKTJED4YM0EFGHMsJemWSb4qcpiIAKE6zzELBSwUGR9CrACRJhRi8syvQSHIlx0FiqQDwCoxWISyEoxiCrtLzIhGKSNVpCh2BmgmOIBoDFaLRltU/W3cRTTNDZO9pK/xwwMRdIrIRsGjEqB01lBVHQQoLOkypKYhaMYdzHKCCnRRfRTCoI1EX2TRLZtqXOEnUhmVLvUEWwokxxVrWltFrAcWTUqOG24BTRZ8GSjioEfBKZQ0bJ4FTVAgJNM43XXWpQMgWiIjx2MCREoMmpbXRgApJ/n5/r6////rqul+vr5f//kMGcsf9iCdZMBDAIDMLGQ5z3DpjBMpwA6LEDBs3PkW8yMwDYpiMfkIKHsy+PA4lmlI+c2TZol+GpQuaQWpt5/m3EaYrDCBFwINlkulV8lMoEDBgw90wt8NjNCgdAzM0p3E4TEz8MOvEwTB3g7Ax905HMD3BcDBrSJszMQHnMAmBJjL6kMwwGgGGAwOiYFCAjmGIkHBgvwT2YCWArGB0AHxgmQZIYgWBAGBFgU5hJYBeYCOAAmAjAOwENx6QuGDT+fRG5i0mAw1Gfh+LHkwYBSEOGoieZMf/74mRDDv0bY0KL/MyydM/VAAHjOHCNjw4v7zLIAAA0gAAABB5gcwmIwyYXBwVB5ioGmBhWYxIhKiTHA7BIonTJhlMCEcw8A1mLBmCQgApAaI04uonIDTjRMJDjxOIWA4UuABiRCO0swaUuwU2qUQFiTCRQGnGQDMNU2ShBIhiIgPIEHsXC4RfgGiGGSXSWqAXTAXhwsiBszBVUgiqgkLAJi1AwoAhF4x69+C2oJjMkEMHXIhLGIErQICYyoQGWoh9mxIPFAqAYgYBbTQR8MMEAKI9IxOobRIjNh4CAmGoSBAI9BwqImAG2MHAl7jQfTUMkIlHYuIRC7Asg7YcGXNJqTEsUBL4AU831BVI3WTLVGgzKBDjiJNV5Zkzzx4lYQQACRqV6kQ4lPAvQorDyuFcBh6bqKoOLYyHAD0I8g1Ofp3nX5ZJZhWFdBV1WV8Yn61JqR/+sNYZ6xgqATgQcSGNYfMp5NT/5c2pQ1h+1VjUurDUmO/rB1nVh1WNfy/ypNSbWQ1akZSGXzWf/Satf1ZQQJ0s9QQJybVrJ+1Jjak2UyWX/hs6xlRqeUNSZwKk1JgqCZTZiqwTB9wtowfEMhNDfZsDfezvkzeYlSMLaCxzA8QMUwZkt0MA3ARDBUyfkyMgGVMCvA1jInzp0wLwBvMD1AWDAeQMkwDcVfMEtARjATQBsoBdzA4hHowYcCSMAeBeTBAQJYwGUAVEIC2ZuWmfsZgeCYQ5GNjpia0dOECpoWnHg42FtMYDgcPmVggKFTDRcwg8MzCQAPhVpNfDzLAMcHzQjYz0YFg9EBuIYHJrL3SUXkj8X1McILCm8MKoxYFIJRhcZuYlWVmEIDsNJVphKTyCFh11/IDTgbiNJF9BCE6oqK2j+pwjjPR4VTNRJTciBLuCEAGBGHC2jgOooc66F6MKCcEiKZshXasQmRVqCg4NGR8MIAGBpwKXpPALglKAQwXIFCJot80MIRGhodfRoy1WAJeFCbpN+MgLPRURKGBkTWnqBKVrBS16FgGxo7qlLTpdjghdovkCDAMuIgVqv0ZzrgPUKjl1AsO77WhaNdQONW6wlMlJ4wSisNiqtIOOLpJGNmSCuyj6qMLjFyDEAhDo4tDOjOkYYXD+fA2kxZ4AmMHBCCjK6ESEw4wKKMCTXCzJaApcwWUAAM1ua8jBdQPEwakBJMDxAFzFSCIQwsQEMMDdANTBKgFkweUiSMM0BJjLaaz5BkhJNjBITTDwUzfcijAgdDq5IDCcHzFckzMEODC0JDEAOgcFBlovBjOD5hoHABC0wnAswCAUw3JoOL8wPAcyMGEzhCQxcBkwHDYw9IoxMDwaJIkAIwfFYwcAsefGUDGNJoPnBiCWconmHWnGSiASZECXdCBiYSsxnCCeBjkD/++JkbQz+bWNBA/3UQAAADSAAAAE4NZMMT/dNiAAANIAAAAQQgLAgMSLpMaOIQRjCpQ0MKJRDKDwjJiIUZlsbc0jEISxhDYNINFMsDC4wwREKHjIBhkArcYcgaAgb6Wb1QZR2CZIgGjJMUHFqi8JqEwsFCABjQRpDyEwyw8vYDixp0wRcM2iFgJKNS4BwQPEmOAB2swywBDhZcX0KxAUTCIYaceJFEBAOXIPmbECO2YcGglCg5QIGDRCBCKazQc/IgwwCMSIGAQFdgkoGER4kDU4YpMYjWBEio0sBUM0ZdlYthNmTToBhAQBS2JkxxkTykww0YsQHECga3NaIEBGSEBwAChCwKDCgkALSmqEByYHHE6m1YY9Q38uYXSEwGC+BSZqwrgQanMIjGrmERpgt4PcYIuCHmUkkgxgdgGiYGybcmGqAGpgQIK8YYOcHmB2AChgUIBaY/Cefr3iZEuSYhBUYqncalx8e1AcYTF4bjEGYTA0Yah0YLDAZFCsOkIYGCihOAoumOAjI6mKoFAwHDIkVzEQRwwKjDIACAHTBIDhkKh5cxCLZg+HxjiQhgsCpgOGxg8GYOPQwPAxJ9PtSk3AgBMBQmAlhk/ZiHAUJkhtLsITGGCiNITLSRYDFBjTIJIGLSGQDhAEafGTVJlGEEAIOasAZkwacGPBRUOZEmKByZ8NEwKNNWKBocdNJqEUE1okwaEEo5WZoAaMAEHgKcEBsLkDDozIFwSIMMgMmHECE0xUxJIxgoy5cw4dpqvyofIhJVMj3gwoKAwCXJC6dwwLEkwkTDixhQYhHgYoARAMCEgkwgsWMOoMgh4inuzJ4DRIAcNVkCxIwSwAAhJMIArVQUKShFjZowwWQyBQQBEzSl6BMMFARpEDhxggxhAQNAmIUm3ZlYU1ypEcG4zOCDOSxl0ZcmHfRpyvZhpim50xBjyyhJIUNYpDA4WDo2ARqBljZoDnLkomqMY3LATCXARM7A6HBPvhcrjn8Tt0wVMK+MJWAdTWojPUxE4L6MKyWfzIeRIkwXcG5MRWT2jC+QIEwLUBqMCoAOjH6gHAxGsJ0MBRAWzA9gbUwpkXlMU8BVTelrjYF2TDcYAwOjHEezgA7TMQRD0kOzGEUjDoPQE7BhAFJhsGBksGRnUPgKl8AFmYaAIYRg0YcA8Y/B6ajgQYBkSZNoQOhwYHhiYICUGCYYYAGTAqNAGYQAyiSFQh1dpnSIGUA7uZYQFDYYOJjQqcCg42JJXQk9NYZEoRgwBsRQAOGumE4QxgUyKMmDmcDEBkwY4woE0olSZhADJg6UW9TuAo8xqIxp4djmmGiVwiamIfmXZgtYRHCYcZikdR2BkxgSxigpAcdQ0VBDqPhjLoCauATBo0p2UxwgpnxhjjRbIww//viZJ2M/sllQIP91EAAAA0gAAABN42TCk/zUQAAADSAAAAE00gExgwGDzdYwjYpYhSTBgcjNhdBKsxQoygMu+Z0OlgX3FpIOHA8AYEkYVWRDTDDiLAKAjCUDGpWYA4iDp5jQRkAJjYxkQRrRBhBNgtwYkYcCqBDAWYGablQgCRZKYESEGizPCTLuiypkjAXKmUWgYYYkaGtwqfM4NHXoQIJlCTRhgBkSJQtTSNUFAw8lFiEkIjZrHduLQn5f3////QCyjGCMiWphWoYgbEGTVGJYJCRvMYGQHEi5gnwEELOGxgHQAOYHwSpkR+OYAiAvmGXkeZgUYKIYFCBGmBHAOxiw4PcYS0AzGAJABIsAImADigJgBAICbEXR5M+GQQgPCQEwkzWUDHb/ODj0y6DzGQaMvjkChww8SCqIzSCLMMCBYUCgcwGKDK4CMei8zmCAaGQIYDR4RDjeEEwysEDJ4YCBMYtEhcAEAcWNECcEsSZQDSIVlGJchCciQGBHFUEhoJWzXGAxqYwoKzQscIJxik52yIAIH7KGaNGdKGBHA0oYYoudrJhVINDmURGSdjDQxYwFRxoWI1hiBYOGJgEwYxR0mIDT0QBRSEaFOKBgMaMEKAhoDDjShygYTHl4AcWZ8auo1YoWFgZeIhQEDGVCpUou0IoWASBAcnWYYo8AKGgZSoK7CgCCQeKGGMKOhUSosvUhDPOHGwhu2xqRDJwsfLAselpoA1YQjWUgowZAqHAAwcRJi348ZMaQMEMMEsEjaHAYFAgqYAMcsSZV6Ajpih5o5xALM4CMAfUVNgDMWLBBw1Q9dootNMLM0FAqUQgxoUwtLACiDDvmOO1Ld2aTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqAZAzBlxMwwpUIHNjAL7zZDlNUzP8dAMHjBDTAWwm0yVwMWMBcAYjBxBlEyJEHhMCZAlDD1BbQDBYZgBAEqY8oOf2SOYcouDh0MbSZNQpfOGwSMhDJNcyEMVgNIQxGAjMxQfMECZMTAsMTw0LagJGzBEBTBMCjAAAjLkEhZGBnpjxoY+MKUICYbXFChueQACh1xAUQYzHCi4DJw0kj4BBgKriEgNFS6AYjMQyHRZlUSTRnRAtKRrJkBcte4FEmngD0EO3EgkwpICEjCkANRNGPTuNGSBSAqlDNECEWYpabE0lYYwEY8MIFJiw4cHEYRA0GDRoQCRA0YMgCMUGHhymg8dXuXSEAkEIQSBUixJxCgyX9Gl5ji5h0hehMJ1jDk2dDSM0ZErLKZmAAAwiYMGk0YIgYgeCAZlgxckADRoWKBVRqUAoCVhgKPMCcml3PcDRqFoWGlrwuLMUjGQZlhhFZVUb9lo8SLYLwUVAqcOABHsxAcWYmWFGPeAvcP/74GS9jP14ZMKT/dNCAAANIAAAATeFkwZP71CIAAA0gAAABIHbAzVPgarHDIqOMo5CKJtQAIGkTsIbIsGNBBYgBs5kjIBKo3Bls5wsyyAwJtTZLKlrSJUBECMS/HsjEtAU43XNYGNkXXnTVBBu4wpgGJMAmCTjGdxrkwPYE0MKmAFzLywTgwMQDrMibEyzCMAD4wR0B+MBoAwDDrRTQwTkBwMBgArhQBAMCmCBjC5wJY6+HNqoTVAwVGzEc41JABiGfQTmpI5m6OcDCCM7MbMzIQU34fMMbNqyVIYQoSBS/py35dsobnARHCYmeRiNmZtCa8GZ9Sa0gZUAYsyaAwaYQZsqELQYmOubM+jMIZMTGOJDFhgQULYDV8gMq6MaZNERBy8yh8wSRHQUNBC0xx0CH0AQJTAY2UCYgZpWDRI6wDAJMFB0EwiAxUQxYAONjh8OBFY8zJoGmBGYJUpgQhhCxMgVUJgAyGT4BRYMDq0AUeNHAAEFAAGOmsFixBTcwxkwJUUYi10tALCCAYRcx04ZYcoKYgqXOATU4YcFVCqEBQtnJlCIYFGoAxSDFQMJGNYhhEvmBTyCi+wUHAg1Eo1gc2JksBUoSzg89EiYZEhZgFRC1MqMZOlgicY0CGABJkHejurhpEPOQ/GDoRgCJuJ5AMETMyY82wg3qQFcDFkCgmdRUArhnBpgXgAFhQsyKVTte8vVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBICIRhh4YaY00JxmifGbJiIIqAaBQPFmF5AqhhE4ICYI0IhGBngR5gxAs0Y3uEdGBaBEZipAU0YKmBOmAnAHAGAVTBUg8kWDgTAHwBEEgHRgOIXIYKKBqGACgERgigDKnsOgIxmoIcoWmPgR4wCaApmJpJnACDncyIgMMJwMZGCCQAMDiBoyobDBsGnZgYCaEEA4cNUoNOjALsAkQZt4ZpOFBhnhQKfGqImgaGSPDIcEFQcmNSbMOfSRAMN1DPjTYrzIqzkTi+hpiBhlJjgplWwcEFRhkhiVYCXDIQLFxQMMojLPTRBx5OCmphgBhIJENCx9ZyQbhL3JhAGVGIBlnTJEx6kAlyHYmEmvCGHIBjwAGiJ8qMKBUNgaWHZJMPSoVgAgeNJJmBLjxIqhg4EEIzIClkGVQggeIDY4VN+vNELQTGCIAJcpSPDjFDwE2TsABcWPgQGAiQKAqqhRGBTZrQIcvMoNWECAAAACFkmaY0ioOEQQIJChAULGlQEA0/RQwSwGhzNkSjeY4gDiB10P/74mTHiP4BZUGz+9SgAAANIAAAATgRjwIvd00IAAA0gAAABJzAwxHNSuHFANIhDA1rwCnjDAiV0ZE4dMwZa6FERmQxa0x84pCmIBE58aSsMZd2pf4CBttJkmKYMUes8TpmoHpH0BW8bMQxZo9l5mVQdCYWAmBpUoyGFGzYZrCdJzxu4me+H0ZWw5hhmlxrhjRjsFpgwIRmQpxrBTRqEEplgVxw0Chh2XpkmDowIph2NZi2MBisNoOIow5BYyQAswgDoxmHowoEgwoDw+DQQYzJnzFvTMjgMVMYjLimAtlSCbRIcywYsOc5UBihhhQVekUYOlBGs1JBVYzpQLZTVIChkcUgKDziLDOADCFDNBTFqTPUyyZmQxhFQeXBTszyMkBDoAMogkYBJx+aowWNopBDkXPipMyLIKmSKOgJRHNiyKW5pRJcM2KAwb47+wzIkxcUzh8FEAo2BWEBBy2YGNDLozJESrK2AwKZR8OkAFsMU8MYUS0MwERLDjZmX4WDmhDhQKawWZMmNAzzrzJtzIIjhEAMAMsWb4sBzFCzDljCmDHlzfQgYaNsMMsnMCbTNMuKIpJlzIGXGVXggKKPTVIAAjMi0VeGWChgbskKCAxgDsxkhJ9JAw1MrKMcdM0gBhxMoKJjXEDKhjGCh00ZIeIBYOCiJGXQCoo0htsSFgQ/Ms8MGGM6NNDjOIVABwImKuYG0y1likxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqmRAAxjQJJMFHJtDdXEWI2O8RzO1HorzOJgegwFEm3Mi1FBjBnxC0y5pgyMt0B9DEog1M3x5yiMeXArTBywWswaEEQMaTMOQwhiMIzBWzA8Acgxd0BkMgeCFDBUQAcwB8H9MECBdzA3whMwCYEQMFdApTAMQhkxAMIBMCTAjjHk6ONSI2diDPpjN1+EyAizQ6SNva02HQzc8zOShE2lkR0znfhAYLV4mOzEwqChA4Z1HgcVDFZHMZkYzCETMLxgEaQoPFTSFxa+JhhAOM0dPyvOrdMKtGOR3JRpTBhwAL5mNcGuvGMNGznm/hmXKmVYjQkhKtuLGQYQAwg4ooBY1FzNBzMCSQmHdjPCjLEXmNsSDABjU5nRBoVqlYinoVg6UEFDVGQYHDiYIGmMbDzEVDGIEhUIJDBGUEBcWDgpAEBUkQYFBQYyxEIUmGkiEq0lQVyzEuAEvJQRFnAiYKPjEi1LkyAQKKpQEChtWakwasmNNxoAX6riIsaOSKIg7YFLIHFmQhAyIY0uCChsUwmJN3BMSkQDHGDGVdGJXLRNi5UH/++Jkz43+zWPBE/zVIAAADSAAAAE21Y8KD/NSwAAANIAAAATMaeM4/CCBVKjTkiCgpiMqFAkIQc0SIUzAgQSHA0GgyaIkaomYUsbdcZBSYwKYgLLl+NvDukI//+j/QYeoBXGFigTZzWcXmdp2znH5nj1Rh+4YAYUEI/GkWBt5h1YXiYOQyZGRhAqZgHoVsaQOgHmDkAexgZYI+YJoApGIkEgRhWgNEYEEBKmDBA05gmZEGYV8AAmDjgihhu4GGYHyAPGBnAGJnA1mhUoYDoph9iGnH+PHUyiWyAaGvwcZsEBlV3GTREYlDJoUTGCxKY6DJgdPmIR2YLLhl42GrzKYcEphsBmGT4ZeMCLY8YTBIYMQho0QgmomIGm2eDwUxx4zYoVSpUiRIRvTaFjDhjiFzOsAMzMOwIlJh2gWFnHhEX0HDS0AQMBpFNGEskLamiIGDCEQCqjgQGzCnlzBAVEBG8DFgAzZMWCSGZhC5xVBuF5hwwGlEppfQsTMCIQGK1I/orJZMTEhZggqLKoG5qHkR8BRxICwUBDkIBkOZEIZdMIgpAEcVURehIpDNR6OsMCpQDKSQgnoUBxIy/5gAYYSNITkbOkMwCUEgJgBiDz5mCEGQfuYRFRkEBS4MJg4asKDiBvA41AVQHAgqDC4ZDULA0MRGwAgEWIMtYaoSVA61UcwgwkArCRAgUCXepiWhXzNTdEZ+2pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMO0CvDEBwqI8T5wuPp2XPTdYz3AwjkMxMFICPzYqwrUxjkNWMMrR/jNqgtwwbMJRM+IR2DDTAfUweABnMFiBjTHeR7MwZsLLMEkBeTAoQbEwSwg3MORA7TAVQXMw9EEsMGDAgjA5QQQwFcCUBgBGYAwDhmC9AJxgOYAcFho69KNTFAqJGg7xo2WcMZGXmRp48b2ZDgICIUxowMFGTA7g98yEmN1TIiMxgIMBNiIyQHuQBiYy0qMrQEmBCXGEhKjpigqZSLGOhQsLCQiIkUGVep1lAi7SqEF0wIEYdo8yHLk2LUpAjKmKVARV8BskxJgGsURdCwYOFdlPFsJmKlgEGoJUFmx403iVsDwQIDXQOgABMBYh1qk+hYNKocQQHs7fUIVf9DmpUHAui8sFgplPshAC1ZhL//viZJqP/O1mQgP7zTIAAA0gAAABMRGdBg/zMsAAADSAAAAEBjbrrwYqy1aKHFXAXDIlDpQXqj8tpO9moWKIypIBooDAICji91hgcciq2Jcq50dkhyqIxcuioMZgpoEw2m+hoTDOElyIBWVCA9I0oDQ2jziMDTlf2IJZNgV25LmLTdyGpuGJBukvXLE5imwNCYImFtnk0qZJiOX+SeQctrGKIDNJgtwFObWAagGF0gfhiOiFoah8GhGBvAPhmeaY2YZkEjmAqgP5glgCMZXYHoGLahAhgigBwKhHJhYAXeY6WASGB4BJJhwgMMAQPcwGECnMBHMyQTQuZjtC8NGHIMAhhADFANMGBExUcjZ6LMMFozEYjEIdMLgdWgweNxAFTAYhMTK4zgbEKQUIzBoWAAWEQqMRDoSFj8FrTCNIXwGOSwGIY67WQ4QRtgaNBpHJMBPUvnDAGHXcFjDOKoEQUEr8p2AUEBJvuo4HMDRMeX+le/rqroiqwbfLSZzGV7OCQBhcAygE6HgT0egv6g7DDWVA0U1V23bdtYi87hKeLWDwKCdynmR4TLQBjILFkPEKHitqpgUsBFtPbvMF1a6j5ZNhS9FvqZEI6TaND+ROJPO/7pF+Fb4faus9d4WEXAvhLQvcy8WASEZo/EMSNBOGBpHtYLsKwM9WOwNsBchqCclI0RDB7pBTy+USymprVNbqc//5L/VVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwDgRnMVyFmjiioaQ8r9isPjmBUzIPg8cw8cHmNDHO8TE7QNcxK0RiNToBMjCwQHQzR4c6MLhB1zApgPYwQMDdMkjBiDEHgbAwNgDEMFZCaDCphfIxJ8B6MCTAGzECgRcwCEAYMErA0jSEzP1rE3lpDYZlMYCcyoUjRA4MqH8WFhh1NHDHYZgXxqgzmMTQYpJIQbTHgrMLBgCBIIMxvQdpjmDSCZENQYDBQEEIpDB6DAIBkBfMZdkgAobg7Kp2OjTAojCNQKOEYEYGA6QBiQUFrGIgiAMyI00RVk6T7PX3g8umURyUiBihgSSMqcbKQwUu5mw6CS5FQYkPS3BAwxYhaqcaKoKRGYEoCQaQFRS7WRoySV9DMKQhKYQIZAQDgiN4GBlUyqRuwULA4aIQgXGx0AFC/pcwhElB5gJ2AYCEJhhciYMmRO0JyjRQxEINjAXEhUAFwZdUZDmGGDhEQjhIwXnQyEjSR5aQwxooSKrJ3IrjxQoEFvkHUT1QiIADiYYOBghB1iaghUJGEJhAkv+RBFOwEP/74mTKD/22ZsID/NSwAAANIAAAATnljwYP91EAAAA0gAAABFARIED1upbKlloqLTdAQQxIIyQJorH36tZZfa+zeN7P//+4xggUzMgnKRjkj+N8867YwNwyU6TCTAQgwvUAVMseWKDCKwQAxZEr1Nj2CmTA6Qdc0tUW6MF5BVTCXgUIwd0HtMnoGwTDQw68wEkIPMCfBgjAzSW4wk8J0NXhvMKh3MmklNQQjNeCONZmMNBxYOay6MKzdMTFAMhUvMUwyMYCnMTQVNBSMMS0RMLQHMjgXMpQFHkIMMBNNICcCoOGRIPAJpTIAIDA4QTAUlzHgGwADRiuAhiiHYIAk5zA2cE1dAEGSw+NsXGDAZ1McPN2TNgOM+HBNQLIQoEGGb1mEEA1OKFBCLJpYQDGADIQ4KQgAMtAxkLHAMiBkE44MOAmJGlsAEFC5NyF4IbjQp5CYIVgDADkzTJgjVEQSIBywHBxAOBRM0IMeKpftSEJowIYyIozDIwgABKTYjDKgyUGZRyCCAlXZynKCBzFlWqhS0KhAFLWqjwVRIRGzCAB0GglLujAks/PmDAlkwsLMGPNScUFMoGW+aFgZeCSqTXmEixpMY4wYU6XlHBBtzCPYICiWICGggKXUZsAT5iQAcHMASATlBIaU0DARrThIGEkZgxAOMGFAtJdIyIxTcFETNigsVBQQzJowIoHB3nkV9Ia////2kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMG8EWjCuSfE4xDn+NVKKKzxDylsxUkBKMCOETzDVFKUw7IOWMIDPnzSAgeUwPEDsNmsIHzAyQsIwt4ErMPRB7TGAyfAwZwSyMFtA8DDNgl4wh0fsMLkAtTjL8OHzg3rizobRNaVAyhhTGAOOBN4wm/zmqXOXz4BOE1CrzT4yMOEg3+8DNAoMaEM0+JQKPEqzXRTMMB8yGpTewXM+B8wMHzDBPBRNAJYM1j8wQOzKJpMAcNUOMa5MSHMA+BDoQpDZgSEAXANUYMEJMqSESwzwkeFv6iKIkZl0DqK/MemQPMiVNacCp0xJoiMAkwYMGAh4EMCwozYFayqiVTBTRjxIuIhQUApJEQcs0ksZ4AAoAKaiyExYoaFghOaEsBriXo6+FCBoBpjBJMyKyIlLCjQ6wQmfFzzCCRYQgWDpq/WKNeApJIIwqwOMGOGjoVKEMSJvA2qBCKZgGEiVsEnUOqSxiAZjF5MrM9H/++Jks4/+DWPBg/zUQAAADSAAAAEy4ZEGD/cxCAAANIAAAAQOCVMiYEjBg0hg05pkZyyYjGDxkyKgiCmHHGEDgAaI1KNxqSBbwyYlpCw5gC78tVQdJBxjxiZoQNVOKjkNCRMsURCC/aL4yQABEYBhiBaEXEQFN5tH/4Y//+lBgiAakYKOOxG1r24Z/fISyf2uXTGITgjBgHQo2ZYmqhGDAAaphW6a6afsHAGCOiJRtc5jcYWwCMGBvhARhFYHmYI0WpmLHAypgloBKYFKC1GDAhQRjAwDeYiIuZSHcaTgwZUh6YdI6Y8gAZfCUdqDkDgsMJErMagDMTQcEjyMOi9MowDMfBJREBQ/GFA7mBQcgYHRAFBgoH4VBsyEClBsvatQQhADgWFgvMFBnQXOI0xijRAEAZmFgUNkiGzNjNEMRIySAd8aAa+kmzPWaoMAsNVXRFXk1otK0WGQwULqLDoQNFHTAdkkOOBjwK7CqOHYA7IVIGmzSDCoSN4kqgYBkxUR2XaXUlcKAkAAMNLYodkKS/ydawz+F4jKCLrgLEGlKNpehchpzqwNArKRIFVMvMbTKig80ZSJUJDzDdYCqHCzowWJCxQvuClStIx0kljOLY4FThbsxwnkWsbH5cR5EJyCYGBmBODnQxEwyoujCZKS/0mS1TSFxoip0sNMwNOWCHZZYoMghKoS3VqoJbTKVLmlq5qWdNVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMgAEgTEqw4o5yjlGP8wAPzREJi4wN8WhMbkGOjjUncExeYWsMP6qSzPGhFswhseUOnmXzTCpw6kweMKwMGQFxDJgDSQxr0O7MDwBrjBiAJ0w78Q/Mc4A2jATwNgwk4IkMD1BfTB9wS0xKRzY9XPU9g5n6zV1GOYZI7MWjMZ5EIZMjKcEAUwSSjCwoMQhcOTZlkQgw0mYREZcCQQNDQaxNjlcwKHQaORJJGDAAYfCxhoNAUJBgsSlj1swJo1HopYGlRmPCgooYpaclmUWwuWAA5RYvevsoFvmx8RDjGKDZIhAhNaFNvHO4MMOpNKjNaLHRCYiXU0TLwAMMocMgHBw800gIQCoAHFCwKMiDM8OCg4rAquchCcq0QiC75YDqWF9TUqzDjwQkNIOBIsOaDQxYqi6umoA4vIBUEYUWHKjOJiypmSYgMGMFBBNUZggidCnFQICrhBoFK1IQOAmNEpqs6IR4YIMXBKEylZbBf8SBx8ugh1BQAwhgxgQQjjTAAwOZtKBmwc1BokINl5R//viZMYM/jFkv4P81LAAAA0gAAABNvmRDE/3UMgAADSAAAAEICgILcJfMNMinAysy500IkKDQUyMoULAdmimBfRShN4RjCygXKmTFBgwyasIdtMa5R2K6fT/2Um/94E1EYD4BNGCcCMZjf7eeblQ4PnK5EPhiUwOOYFaBhmcMkiBhNQFMYFmi+mM3Av5gEYWcZ/SSZGEWAQBgl4JYYAyCKGL4hbpg/wNMYHSAxGB6gXxgWIouYZ0B7lCQnKhmmJoXGYJPDocmdBKGMIkm+4mAECDFkNDJkfQEQJUAsEgGZDiCYkBqYUB4OBQDQWC4NGBAggZEwMGoyTIIJgzi+xaABhpg0RxnghHAa6ZM8CEgC3mjBmRJnMXg6UY8GiwIjYZtWew4rBg0oEKwoFQuAAYZAGGAGIBGGKiAOWeKIgoPASkaYmUIhxoy5QLHUJgJGmJqnZqt2DFRv560DGHCwHBUcDBTcjDRKArHBp0SVCEWYwWZN2sQy5GNISTULjFFCEsYsyMp0CgQOQUC4OBDAgQw0sI5yipKOEA8kMl/DFjkMDRAjGGjWkAEkKhVMIcKNYMqBLzDI0mGKaJfluCIQWAAiYpbNbXmLEjFgGpLhiisa8wEDGQyMqxhENLhBcAj6RQZswKQzQUMGoBDIu0JQlCNcWvGQEGUYGCWGmGmbGDwB9jOiRQ6XUCOJZk4JtHABPAx09kgsfMTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMAID1jE7ghww+ngoP4tTtD0ijY8xr4EpMBcDdjcZhqsx34CmMBHcUzEkQx8wG8EWNOCTczAfgSMwMQHwMD9C0zJ4hqMwSEM7MGbAsTBgQWcwH8rfMHwAozVGqD2uNTE8MDCYHjBZLzk09zDBZTQ5kjNYNTFUkTT0wDCIRRQGjHsSDNY1jM0STEAcjIwITBgNAMRAWJ8y1IgEhUMlaYVDIZGAaQA4FRhMEBEAgVAgQxAJINCpHZAGLCjAgAieRVTAjDHQzyghpoCC5uS4olASwEhTLAAIHUxNWPEmaYoEGEpUkgBVcXaAF8dKAZaaEWYFiFYIWEg58QCQQdMEEEZgQlDOlDLGjEORCbXmEFwzacqMAg5tjohBCRQzQA0ax0hqsgmChg/QkWfq7MgKMdPDkokDRyMqjMgYMyFHJohGqDGOJiAAYQMkCY9Y8BiRxjBZp1AALDotDxAMCpINQBUiClAQBJzQ8fMGxCHYXAmZWmWGmbPgQGgTMUZM4HKIafC2QCmCpICLwAZBpIyBsxQUKnUszJICqbKE4ydFDTAxCIFXLTjFiP/74mTSj/6IY8ED/dRAAAANIAAAATipkwYP81LIAAA0gAAABHqBBMiYGYDGjKpCgsMUWDFlwi8nMVCQGdiBWaueaseYQPTudGrI9H/+yn/uMFlDKTCPxOgxBHohNMq1ajPa06kxNcPeMQ7BNTW3wccwqIHLMIUXPTJwwkAwRkLkMn7QqjBVQDcwGcDDMEoBhjEfSXQxCUIGME0ABjBPAKAwNYibMMhAyzAfAWkwucDCMCFAJzAHAIc08mTlLcMpOQ+5aTTReMbDc58hDGAIMOg0OmJukgmGwiYLFhnEJmGhgYQBJgtPmigABiYYKT4CJBi4pmBgMYzECHpg0YAYvDxEMqDUWBK5UxHkxfELhjJISY+YMkZU6MCBlwVow6srWGIR4+EEAabGThAFCgZlppwwYUBoMyKQS6pKhGUy64xC4AlAScJBRsBhjDoOQIjqKmZUltTPDBQYDTJhQhmUQ8hN7EMmIOAnBJs3QJMoqqSaeYhkCSqHo09GpxIbCGplQ4hDGHIAaqlUKARGdRwj4UCJ1AwAZFoaoUAQQVBAAABTwlSFWQiFgoAQI3faIGLAMAHARiiYOqgkAz4CDBARS3CpgGiTEogQLMaHgMDWTSkzAjS5ScgBApWiIUmSgiMiNASEMKv0HSmRhUUnmW/bkVR5jxAJBDyIdMBhYWRAY4KjzCijIkRQYXrETALACy5iQaI+X181KkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqhXpYwPsKFMDeEEzB3YNA2zQq5OAnB8TEpQWEwlYHxMuIErjCqgHMwGIzPMcFBITA3AUMw8knhMARBCzAhQJIwH4DNMCxG7zC6AJgwSUBAMCVA2zAUAskwxcBnMwSc6JXjB6XNEiYzsMDjw0AyTO1mgLlkyuMjLBVHBmYELAYgTdxgMdhkxkOjLItMfl4KFMweFTWyOMyD0wA1TFxIAQaHiOKkYxSFQMDAMPgEBwgOhxNZxgBhkixlABMBMGsMoYDF4odCBy7TcvjpTjSvTrjgczOAjMmHN4aM2VMqyNY9NSFMkEJC8qERQzCE164iWGGLgwaZcEYgiX8MsSEAI0Q9GpEYBGDcwQSqFppnhRUoBFASDGQAiQhFAWnmLRg0OZ40YdWHFRosZwmQEhwyVUoKvF10UAUIRiMEGBS1iiKipVBwKSCoMOxg0UDCYgNlYEHASYwkCLJy2oKtggYNIgUvQhSuWKaIMMCTGETCCRYmaECIhBnUZdB2E4gE7TiQdL+FQaZZKKAhJEmKKCwhEKhG8DpBMDDARMIKhUFCgMKL0GJIH/++Jk0Qz+EGTDk/zUQAAADSAAAAE6MY8GL/NSyAAANIAAAARpl3IBwxYATY8BKG5gzSHYmRGDNFUcDxhKPQBDQr/q3RAMQVFqTAXwhIyhy0FPZVmEzpWzogxjEP3MA8EQDTF0D0wvQDKMMoRZTQjwYswZoRwM54R7jAoQOIwTwEWMAlAdDEaiXAw8sKzMFgAOTAugTUwKoArMXRB1jBsAnYw2QGrMGFBMzAxQK0yACD4tXOSpUxZLDQ48NCqk/aTjNQUNGIQxKQTWLuAJLMSusx2TTCY9M/D4ycXDM0/MXiExg3RAgTA4eM4HoyIhgw7kIAMRhQxMEjBgiMEYNkPMKxNZKOGmDBJuF55zpvWJxzJkgYCTiIeMNzJpQ7IaAIZtQwJXJmxYKTGrLBmxGERjwMZM6xC8cKCQWFUsMSjMSQMUwEYQwzIBFgaQQnhUUDkQ90NuLMwOQbAJoeuBaqYwOBAgVAGOVAgQNSTGnBAFAYs0Z4SYAJIaYsPNQFGBA4HIBQCWB4BMChMFCCUKosHJxwuFRBoUxvBAKBGFEGxKF7y7pqzhiAZiXRsxSRJggoFLGGFgJMx0xhEOhjqwwg4DMC1KojBPghmio8pkRg6KMKqQTG/AmGGBQiGOwMafF2iJWFghpQCTZjw5j05mQAWYGACGHEkBJERReEGRRipFBGADKCUzwgHFzLmDHmpcDTgNSN/P7rpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMOXBqjDGQc01wOS0MaEIfjiGjYAw8AGBMM1DXTNejrQwNYB9MGZOgzRAwRAwawA5NaxRMzC8gCoweAEzMDMBuDGhRLswpoLUMANADTBvQMgwIAQAMVnBKTAZgRIwscGXMDjAUTAywV8wScHfMDlBEjAigAUwoQB8MDWBajBWg+D8P6SjnuIxPcOahTwxg5nJMiJTV102kTOFhj1W0xdhMRkzdFkriANDmolhsQyOlJhQgYyPG2GJ3DRmQxhGhqCBCCMBIM9cMCiBL8y4mBEDStOJJwZDG8RqSpsjYyNMiFOGVHnIGlgheRDhGjMO2CkgGRj0FQQYCyQYNGkUIczIlzHrRGITeL4A4OMt02zYDTGrC4RYVh0wzTcUEiygFPQMNMseXiCAwGImWVGDFBitQwHAxUkZ8iYA+PGh9GpcKnDJl5YGNEbDGkTCChKOFghiQ4OSlzC6hoVBjzZUBmRCskMGUARo5oQRly0Y0BDE5nxaG4EBopgEaZRIZYCCShgEQBTgrWFgYiEDwEeDJoCowkNGgKP8MgzZCQIEEiyMrjGRClhQJWyhcEMjFMTC//vgZNaP/mFjwYP71SIAAA0gAAABOi2VBg/zUsAAADSAAAAEmVRy0ElAocDJiyEZyAqQhRECBScVHjQBeaulBpfOARg44zkYMIBGG23Ta58LCBaff0FPmEXBcJgzYRsY2Ck/mDzBjhhfBDuaf6CGGC5AxBsCSNsYT4DjmC4AJpgLoFkYxoJZmDEBUZgdYNiYLKCLmANEERg/oKsYEUB4mFtgFRgYIACNAF5nAfmKAQa70waLQeMzCbMMQGIxubjJMYMUqA4eHTJQcNgSEykuSqRzMh5NQGw2qPTOQbMNBowkTAVOzRI6M0iYAngDIIxYHzKpeKpDMozBSUzhcASQK7Kw5kzIFFGpZiB0QATUCDUIGvkzUBlTTFywcBBEyiFoYKTBko3ywyoo4bwwwEHMDHJTZwSVTB4QdDl5hBIMQGNGgJeYQGZ04ZpIQAQcdM+HMACMWDAAY2pk9z4KJSoIL/ocjCDx5gCVbdzGFTYBwuYBAc0ZAMqJ6GXEAaCQklhjJCBQwAiJix4cgZ82MFQ3WBCIBFAsaBBIwy1DMGiDRKTaFQEZMGBFgAkECByA8iKqfBQpdg03UrISgcHL9GXKmZUmlBAKcmIiUh+NbyqGHhCAkDJleGEJmiKEwkBIzZnUVwaVDtRiQqDINSGROGAGtZEpRiEwGRGAJGQHgRCnEZAYDBIwPUxQSGSFJsPZCdXt+r///ppMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjF1RFowtwKvN07uUDrXzII1eo5dMKeCzjB6wOcw0c/CMCkAXTBqgMw0K0HeMCjCkjWL0ZcwEACgMAIAezACgCsxVcfQAQ6+YGIA9mCHA3xgs4+QYWYBSGTrSmaxzAoXDFsQjNEGzEEGjY9ODgsnjCMNTG4WQw7jP0lBEJJlkRo8yBhgI5iIKphCMpiiNhiWXBjSLZo+F5ikFZiYW5k0VJguFRheLgOM4xLBswcIEBFCYFjgDQFHOhk9QlCEBsgTmRBkDwUFGZQG5IGfHGUGmmKg4QYM8bcab8EYBO2UmhlQUZmoRcwKIgcIPBYSHThwOBoIQUMcCWMLD0iTDhjODjrExEaBzIebCAgaZaIhBlx4GAGphG3XEC40o0BFhLOs4yxd/jNElhRgoY8cTACsiYgWF4AgKDwAD6TPCUcgMkLlgJya0sQHQKOGr5pgYUEmHXCjYIMG1eoireHpxFdJipg0aCcSEFZUMCgg+YoMIxwtBEYczIcwqYHQDPoBEEBYEyUVAgFRZgAQkiVlMScFAhhBKBwoBZwrozJcCujBiTGBwQEM//viZNGM/nxlQYP91EAAAA0gAAABOK2VBi/zUQAAADSAAAAE40DNZigxekw5cFWBgCgFcEKAFMjCBlEy8ZmwJogAUSEIYHHIfAJ17GlTn0fQwMAlFLTCCBFA3xrD1NTBvSjmITukxP8QEMCMB7DL+kP0wAMDbMPOI7jQwwH8wJIJDNL8PbDBHQKkFAypgLwLCYikSJmEvA2RgUYHOYJSB3mDOiXBicQGABmif2SZikMmKziZGFp1UOGHUeZ9nBg0EmTxmZ7BBlszkRYMch816GDWCgMWGBAGBQ6YWBxh5rmAy8YFGRgd3mEQ6aaG4kETEBWMLBJAKZGEgyYjBAWAWgBJDDoguHNUWJrC8TDEAZTHvow7NogAScyy4YEmBSGXQHEKG+TG6JAqKZV0acsGCjTHRoOZgIa0IBAAJqGD9mKKGMDCoUdJCQwFP0TTMpjBvy9iahiDo4aMOJRUHv5h2AjBGcBCiw1IgeQKUmJTGLBmRHmIMDIVLgxjsBA0EQVAmDOmLGhiUCkDVgRQqZ4I0AIThBpewCUI9hZKDgZoURUXGNIGUgmYHoiFQYZ4aReS4QChI0hcQ0gAFlWgRsykAHC9QQrMUGCopBZYZ0xUQKnjEBAqIMGeDgI2SM6CsgAWBl5oyoiCgYKFEZgAK3yAUZIeUFRoy9xdVHgaEAISIDgAOmlBqrA4wZU4iARWyyYJPQ7Y5u9hTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAUAjAjBSMw8kF3N+LhYjw3DL075UY2MW5BNjBAAG40TEkCMKZAJTCtEAQyo8CmMHMCMDN1ytUwlID6MGcANzAeAKQwQwjUMDoCfTBGACowTgD7MIZEeSYogMArBfDCmgH0wDAAwMCUALTHgQMVmAzZEzzCmMLDYwqoTGQiCo2ARKAgENKCAwsgxEbDKoeBQSBJMCyNMCkkLA0w4kTJoVAUhHgKYwGgOQpgomGBAEYpAZngAHHHBr80xczRIFLwueNAvAJUzrhEI2hsypQHSjnFS8CmANTGqDmz2hnAeOLAhcaagqBogVOjQYOcjhI1gVpAKdmcBO+Ci4OKhwtAaFyxqhgGRGqRAIMNDQc4M+SMWKN7wAQ4OHGXGDL9FY1ogLhTYigsJLJhzsFFQSDFCwFYiRIyqcLijBjAcYAytjxbYRiSECmqaoIjIYQYOrlmmNXGMDmcSIBzaGQCQDvpixQBZiFAIEgVFiIcDDyexEHoiUCtAxBUzBVNoyKtOJaiQAoMOEJGCxddhQotNAsCAK2UihGCNYSVRLlFnRo0Fmyf/74mTPif5RZUGT/NSwAAANIAAAATjFjxDP81EoAAA0gAAABC5AdC4MLAwqoA0waKMcLlCMoaIOYEYckIZdMcIkKhxGLN0hE0KuZfdmqC8OGTBLw5AwIcFXNJWKYzPf1bUyEsnWMAUCATASgFcylQNpHgkMwOYl2CCBcwCUEPMT4CODAMgIAwFgATMA9A1zCDQ9swOcAgQIGAvgAxgVwfaYMkAtmU58djb5lELGCwYYtEYlUSEnHdjCa2KI0lDUwvMJm4wYCTBIZM6p9IAaHJiwJlsWJGIjGIRKFQaY6L5mEjGLgeIBsY2RJhUEhjwMKB4y2KiYDmtDC9x3DACDOCxYCaPMdMMKGQEAMMYDJIZVN4MMwqGExyz4kJMqxCVhhQZfOGDLEjQmxhyZRArYFzQs5A3AEgy5IkJErhAGMQLITwJGmAAjqEzAYejDBMSUBUAIkR4ABswIBOGKOjBsKoC9RZAwbMzD4NRmbEAEYDlxQuM8ZESUiEl1QKnNklMqGMERMGnAyQyKMziAzAwwoyLAEOFjhiRgQWMSJHAxQWNKlHH5vChjU5lBoVOmFJmdLAwyNF3QCyQBNh4iIzJErSrR1Dk8OmmAmRembLmaDhUWBigQKZiFT5t0JISBR40AdCkDJASUMIYGmCE8CIEBZiTQ6CNjBGSwcKMKeAIkyLg3KUyqAyI44icxCEDYhmOYZDNtDrpl1UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTECR1Iw6AIjPHjVCjkfyBA7iwlGMh6DDzDqQfA1z0ZDMbxB9TDAVuowlkJuMGwBOTMYxGYwTIDNDAXowLQHDMegHVDBVAWYwQ8DYMEWCCzAVRx8xDkHdMBlAijDGwSQwMsAjMANADDJjbM4LMzXPjNsVGgkZ2Dg4RzGZBMEDoxgKDIKAM9hEwWQTAgfJgmYJLxh5Jmnj2YOARmRvG2zETJsKGgyOiFDjFSCM4AwxUEzE4EMqcHW5sjoCEGDHCCSbsEBRYIhiEeakAcYAKoTBMw1MZAuiiFhI9yNBJNuTOmnNEObEcdUEHDRSzOLTDHjPjg6wInpEBM0jOSFDIxiBwosIuQsTCDhZkmMmfSAaQHPxpCZNankaEqx8LkzFCxogceSZrEZcKZkQZcICnDbokrAjXkkaGNThWaa5mCn4ksR5MotAJYHQhoEagqIgYwiBzsWQAEYbQOC/ampQ7FrJqCRnz6IRlXoqRBQ4LqCRmbseRAQoVMEFMAhFiaaYcwLA0x6s3cUeSmDJGcHGYEGfNikYyK4mPmidpMhhUxww1ygxQT/++Jk0Qn+i2NAg/zUsgAADSAAAAE4QYsGr/NRCAAANIAAAAQQFwAIKxhl0piE5lGBhRb9BcsUOCsiLOhEUMaJNQAScHR5nxYUXAoeX4R1RSe7EUIRipYcqYhYDvnJENnZ3DRfodakO7mIYAuBgOITOZ0gUlGC4gCZgw6AYYyICRGALg0RmrA5GYAaB7GAJAQZgPoC2YvCHFmDHA2JgHAAYBQMYwdwCmMQ1ArDEctO4r4qjwoKZjVbnQxUZ1Tx6MmmEQAFUwaLKQBDwOJpZY0AwTKhiMOg0yKQDAABMDgsAJkQDUDK4w2zjGpwASWBoWMEjsmBhh8OGoAOBhYREU2IMEFDIjQEYMFBMACNKUMDHN7mEFsy5UVTBCYrZGyDgwqcgQCD4GAEzMwAcwDIxp8LkwABAIswK40KE0AgyY8yBEYTBwA1QAhEAaoZI0YUaY0+kwNAh0maEKbwePTx4AZd2aT6BpI6vMbSAhEqiDAATMKTmDjEhzJFzFChrYl2QrAiMRJ1smUCqNmuBmKVIWAQwKhiQmHFDBnBrQCSQhHAo+YAiMUwUMMPEeAxoMFHBZmYMiDnY0ABS4tuoUBUhghxgQhohJCUDFDcWponmYAgJMbQSXNQADSQ0CdjSVgKBGuDiFyEATHHTKIhLSCAwQNLmToQJYwMiTPnRYsW+GjZgAQkSN+XnmAJLIIyA08xrgxZ9V06dWpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjDMyxExQkCCOdTcCjJ2Qb8yzQuBMBoC8jACg9AyKUubMGVAtjBNzCYywIFaMFpAJzUdRnAwXsBSMFLAmzA7QbMyEYG3MSjAvjAIgOMaAFzA6Bi4wxUF2M1RU6YdguOxZMGmkkc5PBqOHn4z8YrHIKS5W0TPAoIh0VAWc1BhrwbmSDcYTE5kgYGGhQYGUolDDL4jMcpgzAKEACUA8fTAInV2ZOCpkECmkjYbx8adyKwzWLjPmDtghUQElzqqw6UmIGEQUoO7ZIt5JVM0oOQYCDAGng46cx2YmEIdRM3MNnM+QBxYFGDXjjHwDOCBEyC89AeTFzHIgXjMIGKlQy6Uzpky1gwoALgTVuzc4DQzQQIBTIxQEHATJHy28FFA4w1MyAoWGGsUq0mNQigougDThly5sWxnUJAXMJbMQ1MPEMCPNUgMUIM4KNumOGTNfHKBZMlMrMEZYzwEBVhbSbkQh+NRTHjzvBgPLIT4SWNOlNOfBiQv0CApb0BIy09cSljTUzoMEiwuuAgkx59jRih51iJlTIq+MwcNyfNsxR7WBS2MCICIYAXj//viZNMP/k1iwIP81EAAAA0gAAABOcWNBA/zUUgAADSAAAAEUYo8GJFGJDh24wYRPYLswCEEnIWEPwaoEYAeFwZhggsefS5xhEwDYYgmFqm6MF8pw6bJ8b6qN4mFBhUBgCIGCYIOUqGDOgwxgiYCeZTQA0mBRgf5oQgjuYCwCDGBOg3JggIF4YqiEsGCTAiBgpIBiIgC4wb8QEMAKACzG41PjEs0cJTQghMXsg8wpTQ1RNIKIykjDJoxFA0ZKA4YtBIpGpiUbgEBjoTGIAqBAuZOCoWMpkQCmISIDUSYeEQGUZgUAGEh6SBQDJImORhoqmMSsaIBAOKJCCQsHCAdmKACAQsSAQDFEwoNiIcmORYBxR4t5zT4VADJcyRc5psHDhEbEIs5FE4Z4obpyiV4qFDVHiZwBSxnYBsHRioZizhZk3BgITgZYOtgSRLLAYgIABpARmA6A8dgHZYmaXHiJmxmmGFmRKEgEvSZoIDqa8jCgDPOQNidAx5gULGTMrxOmfNETUxfQEhzAGR7CTAAZHNVPGjZq18NCBWClICmmANmQVmQKjsIyAUoIl7Ao0CG5hkqdxsxxxzQXEhY4LhgE6MqrDjwhXmbbpqCRUDNDAkAcDA0gxCMxEcyx4cFm3WmWCiQsAD06ELDGCR40JCiESZCAFRQsnBKMHQTJIDPkGomcVLGMQYHRgClAEABqIXmlBZmuAliTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAAIXgwb4hKMJlFRjTTxwk0hYTkNOZHFDCkwW4wkoDqMVUFyTATgRQwR4T7MXWBpTBPQg4y1sKGMCsAOzA6AUEEgqJhygKWYJMBWmA0gJRgMICeYGSBrmEQADpzqAegaAJ+MPnjA5c7p1MN2T/nUmmTHRU5YsMtHwKLDRWb6EGWTYFHTIgc0dCOJGDNis1wBBQOZ7WXFMiIMqRRrNqgOiPMQXNCYBgI4YEyRkidGKQD1EM2HMDkwo4aIXPGxNAQeZB4ZlSYB4aQABIxwi5KPMXFEeVfRlQ5NZAJoyJo14AQCy+Ruh46FBrw65gdKGTCGuALYDkgqCC7IwQg1U4xwEJbmaPGGRGKEhbyakeZE4I7Zp2A4nBb00JMIFMwBzE0I0yoo28QDOzLAwEkR/MuvYWbQuSJxoAiMTNUxAQfUNSvMCmN+mCxU4gEOEipMXAllgiU/gYVL+l0U1QIzRvAQ0YHmGOGTAg4CbcAYksuoyYEvQFAZhyZijIsiBzACmwjIaoMMkGIJUjA41hYSdmzQqYjI5TEHBAceDOw44NWuNkgSxBRQCGTDEy5QVjOcYIAHA2umf/74mTZgP4NZUHD+9QwAAANIAAAATxlmwLPc26AAAA0gAAABKBGCQqWDUE1ARQm/utY4CAQBCNPef46KpHTnkItNFy+UxUy3jS+MAMRISY1eUCDKAGQMYoyk0HjhzE7IZNj4dUxDwJTALEmMCgasy7y9DCaEwMnvIy3HzxntPzC841IDRw8M4mILlY1UDzPQMODQUw2dzQxaAzqSL506eZQ+HphJuKQc8GobGBCZv5CPDhvkEaFHmKkIFKxZXEqkxQoNAMQFBGRoAIIhKsN6iTKRwyEnMTFjKi4z8DNOMzZQAz8yDCoxYtM0HTEgQw4MNAJzNjEBM5mp0ZAImGCRjI0MhZjweZealBaYAPmDoRnQQiGJLprJYEBoBAjPjkwoMNCCzAQAVBTWy83coFSQxIUMFDjEDkxwoCpKSLBniSZQ0GHP5lzIZ+WGZMRhTKF2oBAYhOgaHHPQYIVTCDgSCgw3MuAXKMFPS7xhI6ZgIGKHIKAQACFQCRICgWZMMGAmqEgZEiwPGJE5jZgWxMiOAKCIpGDjwCaEZFZwUAghBDH0wEDBoyZCNGMGKEYcwg02MpCCZgM8ADCSQHFyuhQ9CB0x4PMaNhUVQlCR0xYHBCbFo0kVIUA1qcNJHA5GNROzOEowgxEQCxAeHTDAcawwaFG9sBmxOZGgmQmRkRGZ8ZmsmRr4UBUUkTTbntj8bjEreZ/2qN5bkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoACAAEAcwHUl1M95RuTG7SyQxFg6vNJRPVzLpR7cwU0BXMHgFpDG1hcAxJsVSMsMHTjBiATUwcACkMDLA4DBzwdowK4HsMWWGuhYmQNKFswGvDNKbOWGI6b7zq4hOsbg3cTjUhgFk4YaSAUNprMajSeMGDoQhQxMgDLp/NxCoArBp+WABjwBzuxoCxt0phnhnVQR9M8HPHXMuBIkhlDzhGUFgASBuRmwoYnFr5hBjAUKjGJgYMFhBKUMmDSPIAQOEhgswZpo5QSEYUvMjvCVAjDjzFJVNbqY5pBKO5mhwcNLWGYFBcwVhhQal2WyAJF2UBphSAcag81hQgdEJQ2hYaEmLNpDIyGHGl4iEYzsIBBB8KBHHHkYCNigRGgCjjCFCQQNDwAAd4SJgEGlOAnyNRiSwVAGCAAwK5yIDS4BIQaFC5FECIOIR6N7UGHk0cAEQASHkLhorGQAGsCixoFZ0z0GC84hKgJcY4UY8MICJeUhBJAjRcz4syw0BCTQnDeCDIDiwRKwL/++Jkwwj9nmbDS/zTsAAADSAAAAE4cZkKD/dPQAAANIAAAARmEYIJGEAGGbGyXDoE+wMzgFIsQAxoYZMGKClNDFHTPA1wuI3RLtJWfbgpUlBowbkJ3OWkhhjXgw3A/bE7gMyJpTzSFQLkw5knVMJJHkjCsBQ8wOFLhNDIEdTDqwZ8wH4IvMLOCKjDSRpcw5QHhMVhKuzCwglUr1w0tmE0xOE2lhExahE9qU4zX0w5aHw0Bc8MLUzXB4zcLkwYDgxwKYwND0y1Fsy+SwyrKE1FFszNFUyaHkxpFkiN0yQAULl0ZniCZ2lKYZgIY0iyYBlKYggyYMDQNCSYQAqYfAAY0hIYIhmYtIFAAUQmeEhViCmZiQKQxs1AfKX0BCZqGgjjGremvAlljUTTInTDlBGBApU0A8OBmqSGNMBQWZcUVJRgxwYfEYc17kECVBDOM0WwMxHBAEMABeXDUoM6xJARjgxVRBAdL4woWBwKOABhShhokOc8OlGJNmNAg5cm+4JbAcNJFmXEIdRYCws0CRKcIGCT0QFS9JkjAsYM0SAx5WwIHGoLGHBt+tcxYVIsQhREdZmKiHvCg4wIRlZhiylA6NMEJMCFLUGhIkQJuREKUgqsRFDHlkQkBpkgjVCQmXqAQZAmj0YUA3JN5kqLKvAgOiiimxJUhfKWNVQKZ2p2kIOhEGBwsYMK6EPSpxqOJU0jd///+ipMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwzIKkOBXioDRRjbM4oBh4MYQxYzktRm8w3Ah8MS9ABTKGwbYwlpJLMiSDozDFgtEwp8BAMbUBOTCkT9ExRcLxMYoIwDA+w48wEMEXMJwBaTB+wAYwqgNWMIcCXjESAa8xHUUhMIKAuDI5uDVMpxL7zXcdzOEYDQwgjPQSjK8RjQCGDXhODJE3jDhAzG01zH9nzGssDKUTzGcfDMMEzQYoDUasiVjioAyMiMWbTfUs0kfMmMDIooeKgs5G1Ixko6CIE3MWMMczYyMyBvIVM25gNYDjFjwxkvMjDwVPhwuYMOGBooMWAcGlQGFTUYGjHRMzQONANGCGjM5kYcZEEGCnyfY0gGLCgILCIOMKJAoGBcIZ0ZCJGEBgcCGMCK5xEAmAAx0IOABIwsDARyJCphIMku6AiDCYAAJiBQgHIpCGmFFIMGDGyowgXVEleAAIdDgQBGTi6DRjgcQAQIB2uDAsZCPl6FU0dAMGGMgpgIaYKAKRHAwiFQCPAoURqawiQlmkQIhpKRPwGBJjJAVBpRV2FHhALMyMGChCBjoOEAIQPrfAw//viZNIM/uRkwov93KIAAA0gAAABNxWRFm/7R8gAADSAAAAEYtNPZghgwcTDj6OSDAlCNvUVQgWMJHxgJAIkFR1QkOIFDC9ahxaMCh4OABCZsUUvL7RZSUvr2TZgACklDAgxBUw45czMI/GEDRziukxWY+vNR7BLDCnQT4wsQG0M3IjAwuGcTBUJjMrsTgxLCJDCOG/MVhn01FQQjIPDNMRAPEx2QYTE3FAMQEMISDoMPYIgxBAcTBkU5MT4RsxFhcTDIGcMIwOIChGGEYAuYYYPxhDgPGHaDwYTYaZgyiEGFYCmaMqd2uaLwao6TvjXODNNTYnjMRzejzTSh5eaMoaMYFzIgBmQROeTIV/kJkRBDYCkEgjIhYASqwigYpKXGOEdAB8woQSojS8yhEhFlY0hCiIIIwZjg46SBi0yyM6pgyYwwQAOdrCgZiYcKFByB4NMK1GRIEgAx6NRYCFzChDKkVvQs6BwzyBYYBDwQQFDQCWrBDxYwQczI8qAgMiAQ8xo4wgUAkRYAYsEVhobQfFiqBaAsFGSAAyuEIMig1NVbywQqNMmJMWIR1S8SoIRzEQgcBQI8DBggmANYAgsxgcIJo6pDIzhQmk2vRa4GHg4+res0wI0wQBQ0wgKXLDwECUgdNLZjxFAIChZmAIgCAEIAjhlBK71Dl9CSkvCkq/JuA40LHhgQwEI8z4Yx4EChode+xJVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMLOFOTW0HfAzFtflN1TN3TAJVW8/BMqfMEvG7TMzSSMytoFUMR+MRzILwZ4wqIDrMStCczGcwvMwKoSsM5NDETDuhJ8wrcYVMPHBpTA1RFwxKsCRMK1CujH+QBswh0BUMC2KHTGsQV0wTsOzMJcCNzCagXgwY8SHIhLAwX4IJMCJAWjA+QC0wX8ROMI/AizBnwMk7G8DSLNNjuQ2YUDZmAOTDYx5DDIh9MgpM1ErjLgyMphEzMATBzLNBpc1KLzSbRNFD4CuDUFhFBbscU0cRkZxQdxIZlQbcSe1CSiRGWM8qH3IiLGJIn8kGunC003BwxowWPlgaFRAmHMQNBoE4aUskBX5mw40pN9GAyswc8w6swowDCDLXjSCCBAIjqJAcfRcChYMKnPCmNMsUAAlJkkQBBswSsrShUEEUwBQS6MQACoMDGSZKYgQTEDACjBCgErSCQGkIMAHgKFLpJLFUiBnEDlAciXp8JhmMEmDQCQEFPUAhgBBhhgOllVE+TX0BqHYuQ/CtgKBphCJCgiEYoHQJCJSkpA5GkeHDUOiqIEAgp+KGAEBLZp3l1k9QsTHDQEShYCCi4KRpashBQFGBf/74mTgD/62Y8KD/NWQAAANIAAAATtdkQ4P91aAAAA0gAAABOjsAEgGKAMCEgSQxng7ZVe9iwh///+8wugRcNDZLdjGxiSAx8g0qMIwS8T7CTL4whsHnMrYKLDGCxKAwhULRMcrB+TB5wvYxUoJqMBCErDDbSUgxwUF4ME3DKDDYBaAwGwKIMKDFaDA/ANgwb4LrMROHAjBPwjswc4YJMvxBXjBRQLwxjMJtMC1AWTAHw3Ew/sFNMCPDKjHmAUowbYBXMHPENTBjQQ8wHwA9MeByNCAaM24xMYxWMVicMUEXFsaNFDcMkyPMJwQMH0dMeykMdEwKA1MSQVMCymMOBGMWFGMpASAofCg6AAXDA40TAUBAwPTEQCDEgLjAYdTDoIREARpn5aAuoYJcIlZqo5kV533yaIswOGlNK8NI3EZY00Eza0hkG2mmyDAk0BvgNAnU5GZciNQGJDFCTSmjHFDQrTcrTHphQMYcAloWdNK8AiEQDUmmhgA0ZlSFhZgyRjhxNFMEHBxoZFpUGOSoGixd31DSgMv4s4pazsVZCAUWsM+LFiBoBKE1sJhCCdBWJMGLHSxbIsmmgI0ZgAC4zBgSBQZoU2BG8RgAhIVTAcwMGILiKHioNQpfgYeflu68USF9BBpJAIEK6HBDkBYaCkihghDJ/gwSBgDUQaDDhIoDS/X0maAgVKpNWIqCGatoCQL8uTa0kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgBMEQC4zDBGD0wLMsRNRWHUTHPlO84S8RdMHaBcTJeUCkwQkEUMN+BhDIzQq8whAODMT9EsTBKgYww5MsyMMuBsDAEBG0wJUHnMIGABzB0xkIw3oFIMGfCxjDShiUwZUEVMGeEkjNJQagwVYISMYKC9DCZwV0wSoEeMSLBIjAwAmIxDsetMFbAvTA3xXkwTkBPMBCA2zeYJTcIzTad3zVkqjGEGjtETzPcuDII2DDkjTIscjTcMzH8ZjCwlDCYaDN4BjUAUBouTAUKTFAMAglAxvDHQJjBARzGEBhJJzM0RTH4EwEPZgyAJg2EJ1QJjlwCUHBBnGTAfkLIgtHB8YuKYR2cMQZ8ajOHYTAKwIwFcAw2NgQEn4FPmkymRFDwgxpQ0wA6VkEIwuDNeBNmgFCoBVkoM2KsImGZsAwYXgS2KhY1iYwBBVQwIYy40FWQsRMKFDBoNGmAMgo21cwYIQjk5ndEYJIpmwhCAwKDioQBDAREAV5GS6JEgIjYlTBT8wwwVHrdHBQOEGKAkwtagVAkoEyQtMEMLIogoWwwtkQECqUEB5SZggzquGQjjNAC+4NGFrSUIzUrGhgkSRGRHCxEx4coBx5LR0R0wY4ONEwaMGAgJBoPGlBL/++Jk7A7/JWPEC/3VogAADSAAAAE8nY8ST/dWiAAANIAAAARqjosrBFQS1JZLhWhwDGDQh7RlYCEEYoyaFGmFjwZhm5/+cJKHymEAAshkFR1sYlUD6mCWBBhjzoI+YGoEqGGyCLBgz4dmYS+U8GMuBzhgkQLkYRWHFGCZAtJgBImkYTID7GBUgmZhjo4wYNEE0GESDChmM4RSYJcBvGG9hc5gg4LAYAqCvGFng5ZgiwC0YdOQlGC3gm5gA4b+YYiBCg4EbOGQGND0XMVx1NYS4MMSXDuJN2jyMzCnNHSkMIxJM+iMMYC4BJHmaAGmB4HmioUgINzEoYTLoEhkUjL8PwUAZjeChlGKZi0G5iMWxERQKPcwtBcxGDQ2lIwAc8UEys43LMymALQzDGzFkQufFkhtoxlZhjmYJHmiPmQiCgU0CeUHvihUiacsYAWSDjGqzAjjTsCbkPRRCqAwcKhBAGNIcBQQqjDaHTCCAEyMqHMekEZMt4YcSKgQEfNyaGgJCaJg6lgMKFQSBRLpDwUxBMaHIkvckOCBRFHaimOHEBkUZMWzlBp7TBmSRIHAwSgIo5hgqnQQGCHagwUEKZINmQAEAcLixUSBnjOkJ4yJBRw07QUBmKBpQyIRCAg2YkMJTAMzDAakyqMDArDk9UnAEtAKUkGqblUGZgGpaPBhCJGgJpRCXMmFAplwhiDixzYFndZzfUpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAbkuMFgEQzyR5DFgTNMKk7IQI9nS6FCYTIeplPqRmNuFiYKI6R52CBj+Ipkuv5giLJhuvhxkPRi2IBkco5NC5iEohmIFRkIFxntFo8fJmyvh8WK4oNZmAWBjEOZiCUxMuwcJZldF4QgZgkVYtDRhaFJmQDwcQQYBxkCBYOGAaPIqAAYBiKd0kCChx1pjAgorNUFMYDNsQSqNAFM0RUFMgmCoMIJAoOAl5CrGhIKRAgiYsmajWdEiYIkbMwdAEaAWZtiENTJnzJMBK0AqAYUNoAIlgGRgAMrsIWAw2HcTbiyUsYYeYpSHKVgzRhjOiiz40JbEaEkusWtBElk4aUBQIzwR1zCgH2SMMcRLbmWBGDKwUAnYQWJABijZsCYs7AQwmLvcJB4Ya4soQmGEIIA4GJEBVmNNnfQXARkyxkwoI1AEtqjmbYQzZHGVo2CNo3hbEQCGSERMxhYWJokiISEEAaGEARHYuMpsELBQgUAy1BmlIKbGOLEBgQMDGEXbJgJIBKrArZrDpbjS1SJKLMkAFRIYoMSONaTQHoajAsW//vgZM8M/TBkyRvd0nAAAA0gAAABPQ2TEi/3VpAAADSAAAAEfK8WW/GeeFoATA9w80xjxRbMQkMXDTdBK8wd8aXN/nCRDBtwicyk5AWMLvC+DATxnYyMMCXMHYCBTBwA/owngB8MKIBTTHTgYEwogBfMF/F1jC0gTAwKwUsMK8B8TA5wYgwS8iaMGDA3TBhw3Qzf8BfMC+BbDEDwGUwgkHPDA5MxH0A4MBKAXDCGSNIwowD0MAKB8TD5QEswBIAPOvQkN2CBNZESOCwhMRwJNRgmNMRkMzVfOIx9MTRwNZDYMLQ4MhUBNEAZEQkmSpphjKmH5imSQmmCoNmD4jmQgRmKxIGIodGCoxGIo6GLgbmHouGCgNGIooG1oDLACjj64RgUcFMFYx3h5g05DbA9Az5oO1msYDq9oJ4xpqx5nrxn+gH/kKQ4igxywz8Q75IKjlMzorzGBzcBQCgMyUCK5suI0xYOlUZQoNHkWDFDDLjWgmIPCAkI24KNDwIrZExklBmLOmSIhYCZ1e4oWLFr01wSfLsmIXCVYwYozBoCgRkiAhSj7Cg5OSnRosIzQoHHAaexf0zodkIQQBhIzxIwQFlMDoyGBNJehhJSAAEvWGCwqfMALGRhixLqslLpAobA5WHAAIxZwMKFAMIgG0EjQVEYvcYEgFD4EFlohIOQhzDABpsAhSmheMu2ZZqh3FhzB6Sxb5VMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMHXCmjHUD04x4sXTM0fIZzCbRNM27EMqAwZkZNahhmA/ABxgJ460ZNGFxGDEBoBhA4SiYQsCdGBhjDZibAVuYIGAIGCgCiIIBjzAcBkQwWoFxMCGDBTCkx60wF4CjMN3CeDOYwVkwKcGgMUIAqgsBjmCchDZiOYPEYA+C1GDujZ5ghgJ2YL4FZmGFgcZVAkjeRwM5uk0s4T0qTMPuUBuICGw1nCT1rbMYJE13CTFSoMalc4sOjH7GNSKYwaozPJhOWFgLCEz0SjFodMlDc0yAjBx4MdqcwSFTExuBR6MIAgxscfAnTOmKdmlsmSZjZAlGmTVmMZmtPmpRApgZ+MZ8SZMsFyRpUgjoILmmNhZ2AB5pjwcSAYAyp0ywo05FEYxKMVZBhEWtmbEBjsFGAqPBygECQxqBmgcbL2GcUmMPAQeCBjhNeJrQ4DEmpjAg4eMMfW4RQzFmUJBaRc5asxZEHBRUCIh7LDEhwKFBxElGFuzKBoaIQhkQ4IGgEsBkJc5IpVanRQfduK5S4CqwWAwCXrEYERBTFCWhGCBGRAAo2kYIgpbVPhDiqkmC9SEhFJiBEAa8uZbqtKUQIBjRZd4hAFQKFgs//viZOKP/qNlxQP81aIAAA0gAAABPEGfFA/zVoAAADSAAAAEiuOVHUhiIAwaK0NNFM6k5gYwMmZhaJQGNwDSxjf4/QYOoOPmvohtxgkALaZhcdvGFHgFZhDRGYZFmBoGCrgpJhPgR8YCCBeGHYjuJhnQS2YFyCNmEXh/hhEINkYC+NkGFkANZgiQO+YFcOTGBDBWJhdgPyZjqGFGAmgWxif4AEYUYETlUDVMMRAeTAsQYEwwwTMMIVAyDBkwcEweEFJMAxBhRO7muXsYYH5xEdmypYfQShpB+nGaeb/Opgk/HWngbOW5htekICNCm01ORwQiDVaJNABwyKbSi5mFUcaUKRjM8mqRYbiXBgMzGjEEYdEZikUiAcFCBhlgCSGOSmFMhFs38A0Fg2AM58sGPTmAzJtzKNjPKxxyc8+lMGHjhkDRyDIPAQUSqCGxcIxiZzQcUMMQMB3EpBk0ZkVgdEMRDN6nNUkNgUMyTNAXGAJiBxhDIjQmTMQ0AVot2Kq8ohBBwZGkQM0gIApHhBAhe5pEQGKCIOCTiwgARmVLlQCm4IBbWy/oWFq4DBjSRICFwoBBmQBLeMiJNAAFAYKRmwSAoeOEgUXGgZAaCwpBhQ0OAGICA5G0JGRPQKAy7ZihCA1kgVKp1FwAUBEIdDwRlAoCZerbJhYGxhVAMANebGwYt4pQmO1puCg6sLXmuO/QxDOnrWNqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwBgLfMTqQpzCtys0z8oG0MSqBejXpQakwzgHTMZDRDzEGQKEwboomMkRCJzC1gMUwpEOdMEOAGjBxR4cwI0FGMGrCJDEggdMwW4DrMJVEpjDzgZ4woUApMVWF1xIP3MD+NpDJIwacwVoQiMQACBDCNglkwfwLaMH3BOzAiAOwxZgTZMDLBfjAQQRYwd0EwMClAWDM4CTG1iDK98jLdXAuLBoaepg+WpmxC5mUhBgcAxnQDJlIQZkU6Zi6QpYCIyDDsydE4w3V8wnDszJAwx9C4wUBgwQMAxQD0DCKaEAQQACYqg2YMBAX+OY0GFxgrBmSJjYpswxozCmp37bKzSbzVPRAhBrA0gcyj0xhkmil0w7se1McEWLSgsaN+cSJMGvCMA6DYokEIUwEAGRPiSsxxQGgAIYNIOaOAQxCwR5MAuJTNUyUMzZYHCzCgJCZgiUOjQljNmRp0HQxUuPDCgu0kdIAgeHFQMdC40BDF3oOAJAx0EHFEk0iqAL8EQExo5diOwOSJiCTB5zAChJUY4SABj9pjLzFgYWCrFQGpegUKiCgREIUBChCKBBotcHU0TiYLsOBAZoKqzCA3NMAAGACCQRjk2w6EatKELkpTBiw6cLfAIf/74mTqjv8/aEUL/dWkAAANIAAAATvhkRZP81aIAAA0gAAABDMYaB0RQVuhEOajMymil3ca1bgLGErhYRjDRvwYYib1GSDi15hRwvEanCBmmAHATRh7B2AYPqCimEKFIBh/YIoYJyDAGCRCPxgngKWYMKJkmHIg5hgVwVGYoiCFGEMAapg/IXsYd0DBGBRBOJjq4aEYU+BVGDmHWBgUoD4YS6BMmDABwJgqoHyYM0KTGBkggRgr4GiYziB6GA2AdhgPgWAYQ2BXmBagO5i6cmnIEYDiRx5ykQaPDygzGHzAAJNONMw21DsZ+NbhsykKDFJiM2tE30pzKQJM5lcaXxiQeG4iCaWCRlQkGFROvAel6SYIP5g0sgkEG+CkSEzZ4yA4zCQZNBaMaRsETDLoDEh1bQUKAbsmxmdNqEmAcB1sFTAKsMuFOAbMqLEpAyeNGTFnphBRfIKBDGEjLmzJJDjDhM6GAQIDDnRmxxgTAXJhQSLEzIhDFGmlmPHl7RIaCBxAgUGMwWMeAMSDMc5DGKa4CVGTNmbdmGGQYXlFBwNRGALmMBEAl60TkfWzFtS3qvQAHpmmggE44NCiAYYtAZ8iNDCUKUCgsAKBivRQUUCBYgztLZWFYEFFQ4mkutAzYJa4XHg0OZAOYMMAUQUELBA4WwAwBwzRx1C7pcsQi3nMwNHSqfhiBZlARnExgSQiLjzOCHNrrUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTBcgXoyTcGaMMYNlTK/R/IwtspuNYZAYDB0QoQwkxHXMANBZTBhjigwokFQMBTCgTBUxCUwNEF9MAdAOTGJwUUwVAGaMVqBxDBbwVkwdcQrMSKCBzAmACoyoYEwMDCB+jClz0oxiYJuMGKBnTEcwQgwJIJ4MI5DwDCxAAwwTgG7MT8DNDBRgNIwQUKYMDGASDA8gCM3tCwzWWIzJCc2kC0MXU4uEQwCF0xVh4zUMMyeLkxZPwyvF4wvTIiPMxNMgxbI0zOKUx/WYt8YBj0Y0F6YHD6YuGeYWi0ZAgmTT2Y4E+ZBEIIA8MhQ+BSI0hE5BUKoARaMUUNXRB0ouoJBAUcOAaNKsPY6B0Y2dUkAmnrlVII0pr3QNVGbPGEeGTGGVfAwKQgjCCTAuhCFNKjOWUN4EMOSNkRBSY7gMiAmeiGFCDJU0q4elBiFFMWJGrEGCPmGFgpUUImjhVKNACoBDDgNAmBFQSYEuAShZooFJcKpgsQCiwGHpLNuYYKBQYqLEAMvKsOnCFhgKDpuER1A1SMVEI4CAQ4Egcr9GUAhBpCqaRPykAv192vJdID0mA4m1h0TGjm0U3BwQt2iWYAO19VRIVXAiAgIIW//++Jk5I7+9GTFA/3VoAAADSAAAAE7jZEWL/NWgAAANIAAAASMGKJhxixKE5ywESQgRlZwgcjxfq2BmBoA5pjSxsuYUmTGGb+A4RgF5eUaLKITGCUBE5k951wYXiDOmGalOxi1AV8YHEAqGI0hxhgW4OWYQwGMGI4gS5gyYCwYSKHXmCkg3Jg7Y0KYP8C1mCkBnRiCYoyYM0BXGKDinpjXgL6YAuBpGHXAuJgfACiYLeFVmDlAgpgSQaQYv0DrmCEAnhgw4M+YCuBeDAIGZkdRrw5GaPCb7MpxW6HkEIYuMp21Imvz4ahVJv5FGGiwbXhpiQGmuiEZhTpnZQmB2uNDACuwxYJzIxPM/vAxMPzCizNyiQECk2qDzPSbMgGQ+rI1kJMcy4Q2NITFDaQ6B1ZZw6Y1WM6PYSD2pmzx2zxhaph0hkhRhiJqWrXxOaZNsY4Ubc6Do4ERBhUAGTRAluhkQ0BYwScyw0ErDHOwaLM6eJjpmyphhCNCEaQJCNLJJtgoCEKYFhpRcILCQ4W6poGFGiQcwI8ILEBIgEmHAqYEI4MOgoaXzcULBkFDDgwIIAw0FFy/YXKgFABSgNYganG12DotBUHLkIwEBMiIEKsFKQAKL5FzwAGAzRJ9sLQIPYMu0whdOUz54GAyqIMGHAiUDKjLlAM/qJDCMOENwQiBxRDiOlDFiGGwkwZMEFzAiyRGX6QCxrhMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMMsRgzaK2jGweFM71r0xRNxD1hBYMTAZ495I+zFyCsMM90o0chvTD1FxNH4S8xfgzzG2W8MjEkgxByKTPLMEMKENEwyDNzI/HgMh8V045T/DANIlMFjkMw5BewIK+Zbg1pg0Cqg0zswcAozCLOWMy0cExIwrDESItMLAI8wvwpD7BaMwKo3phDIhhNEfIz4ozDA+OdKE28GzBA6BbEHQ8bkaBhYjAURmhQaYmBRxhBGJQqZYlxh83mLRUZKfI0CDIyFCR0YRCBpg4BcHmOjoYhwXXNcMNcoN23PuFM2UMfrEgJhqZwQRjAhxQhiUA5gMnKBUMzzo0RQ2BwFQAUoAxEVFmHGGqLF0hEcLLAVaBiYANiI0GLTeEihabYYEGhlIIiplxBkhiMI6SaeNAzVITGgR4SkYKBW9egGhAEPM0GSyBIIBFRwZTAZwlSQhC6o8JHQwFCtRZMrgRABASUxARRHpfJQWDmK9QYKEQlAEqoEHiIcXuCwUCEF8DgYvQ0NOBzRYUyYiDqBOc0tGJ/GdIYAUMjez0MEIjFvWVJcJHx+cYkFjhhAYQAS9//viZNUP/c5jxgPc1aIAAA0gAAABPDmTFA/3VoAAADSAAAAEZwhDLmFJQu0mYqot2GZwNAIHCZBeEdmHWlGxmb4ucIFzYzS0B3MFmCITVgRZgwLQDdMP9AHzJFAHowQoCAMWpB/zB4gK0wUAdGMC+BKjCOAJwxxQKAMBnAJTCNAvYeHdzCCg8Ex2IRWMClCMzISAKwx40CrMEACwzDoQRMwKUD9MJ6G/jASwNwwRsACMe7BEDBqQJYwJINkMDHAeDAogZw5iMgzCPk4LQcx/DcxqggSoI0RIY3hpYy3HUzMGQ5GBQSEQ0hQECCUY3CIZNgKYsh6ZonmYVgQYRp4YQDIYmgqaAocYJgYY5H8aqh2YNh0Y1kuYGByYJEUfhCZY2Z0kImxrnJtlYHCH9DEBEZTGbHAw+dHQLfjSzzoRTWPjKTjbHQAiAWoyJYShHEeorGFQB6Uxy4HhiKMa/sCUY4UM4VObDNWQMlONIkBT47qMAjjPEQIwMudMyUAU44CQ0RM1JEsqYlOX+InqfhoUYILghcksCXIMamYAlg0Y4CxkWdMQBihiysBawHbUUgMbMWDMAMX855E4QKA6NUphyxFbHQAUADzYaGlgOmSBFDUkJANLLsQImUEllgy0rKnIZkCoIIRAoFEIwMImPElyi70FA4UxIAAgYDHjKIK7WakJVTJDxJ5AC2iO7Gm9UuTPYklRflHKTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMC6A8zE4iRcxtYvHMlEDODAfFPYyNMChMGgBWjTiBJwwlQDBMG/EgTGqgVswRcCTMPED1jBuwVkwRUOAMPYBhzAaARgwwUKZMECAiTBTxmIwSQEiMERDyjGVA3MwP4GGMJAPcjA/wQ4y0Xo/PeY2gIA6FXI6wOI1V9s4h5Q0HN01NbMzqKUaFExTMULGeZeLWYJBmZEpUAwSMLS7Mxa7JRsMOjINig1EQFGnw9GGYMGMIzGX4sGFgemTCHGFgBkB9CzQBYEDX4NzCEBAQ5hmyBYkAZneZxhgCxgiC5j4FJhGC5gUHhhCAhgmGpgkCRimHJkYKxhkDZg0LRhEAhg6NwKagwNC82c8wZAwK0PRGESmDZmqGmPAmxUBDg1awwEo1qdfwGgmYGHOFm3ADDMyQAxCgAigF/MoFMZDNUJNCOMo9MMMABQMLA6CGUCE8XKDFhsXBlkxhjoYbMkSS2MAqZoGPAisFCskNEACpQFDFDAsOIlDX07w5a0URBAhcKAkWFuiRoGEUB5hioYuZaYsqARwwBBiwxoRZoiBFuUjlEiYmw0dCBC1GCHCsWYgEYQOBkDcknSQMLCJEIhhZBPFupQlZ4q6IpCoMiAEikjpDtdk6qDZ1//74mTqjv79ZUWD/dTQAAANIAAAATzdlxhP91aAAAA0gAAABCPzaHgrTU63fheAJGAzA2RgeBIoZFWTPGDjB9ZgVyUkYE0DhGBegOxoG5FSYQCB2GDLjW5hPwKUYDcBcGByCLZgToH6YGGHUmGcAYBgUICSYZqGuGCjARpgJ4OsYVwBGGCWg3RkkoaGYFmAyGJAiqhj6gKkYLyDYGIbAjhgpQFSYGWJcmAxAf5gsgMyY4UFTGA5gb5gawUKYGeAimBAgLhv2FJi8LRjG3xiuFZgYD5xaKRhyBZl04xgCPpiicRnUOZiAGpnqIYCAQw0G4xLBowmDwxhM8aL0wYNYxMBEwgDI0NB4EhgYBpkZSheYGB+ZaGSYEAKQBGeiICgQcdMyNFRBrg4EKGyNhwkDFTKGRgEYfeBq4XGn9fgQaYJYCTawZWjNABS4RwN23MWFQ5BQcLCEm2XAZgYleaAkZsEYJOZEwakQOljP2ACZMCVNQFAAAgKmmCmdGAZUODSEkZQkHATTAQxmFToiBGPFJHDRcZKsnMoVLOq2oBVLm2HqqsJkzz1R9BG+rGFNSsAmagMgEMEFgvPCz1pBcMYDmmCg4mgiMIAEZwmIs0j63ktUxW0g0cQAUA4YNCGiAmJAGGDmqQGACBlUdFmFUmPBKCAQ+xMu4vkQAkJ4YFLZA02YVOAQAUVls1uoSxIe94gDo9LPUzfukxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgBMC4BnTFHxGcybAc5MbbB/jBE03AxEwIMMIgBDTMIjU4wsQFeMB/HnzDJgfEwL8FAMQLD3jAdQI8wDwWJMBvAnDBEAH8xSoGbMCrBETBkxCUwxQCSMBHDDzDIBTwwJQFlMLhL5TECgWE3ZEE/ISswbQ43KHs1nEEwm5g/cyEy8B01MgIxdD8weHk2vEQwsEo11K8wGDAwtb0GiMKDabZiyZPioYFJMYyFGYAgkZ6FyYQgeDhcMfwPMBhSMnjuDBBCySGJQWGBAYGmQMmAgcARVjIMDCUVzS0bgIFxgsNZuARlkAO3mfAGJ8AQacFWfVMZWCS71KDLkz5hBV+BcgUhGEbA86ZcWY+EDEZrTZuAyhwIWiywaMKHEw8WYjzUhImHKmQImwnoBziBA0uQAgJZARJBw4hMiEBBwCmCUc+qlxmAJdAoTAEsDARQ0ZiAVCXAjHladh5k1YIQmGDmbGF321lz9AJKYkWYMOi0AQbThpM/ooILgBxhWBnCmi2hpirKMExg0LCAqCK1CT4OEIWqOAgfFRI2XTFSJMHQQDQteIdNMghFUBqh4FRIogYSaZIkAHQAobIgRYDBDOBAICTngYVUjocLgxY3/++Jk5I/+3mZGC/3UxgAADSAAAAE74Z0YD/M4kAAANIAAAAQAk4kuAIUDByIKghXKtRQ6IWw8wPkBTMVmGazJlRH4w5oN2MEjQ3DHPgCIwbkIUMNlN0zDeAWwwAIfFMTtAwDAmQF0xQgEhMEGBBTBmA3UwdkGPMBQBNjC4wgswDsEjMClGYTAGwPUwgIMIMfGBuzAYwZUwxAt5MUjAqTBZgaUwzUDzMA3AhDAeRVQwasAwMGFCvjFwQXEwA4BkMHBBwjAAgI4wIEDnMD2A+ioAdGBpAU4kCLgwHPMFaAgjAPQFkwhoFFNsGExpGjU45IS8bhbRisFGXwAZ5IgyPjYKTMVBIwpFjJyvMgjM8qUzDBgMHYohFICDpywGiS7MYOcHDUw0GzDwXFhwZABg4EjAgBMuAAyiOzEprLLGVAiZ2HpgoagGw3QDe0EjwbOQgIZGsMpUYwwccbogYUYeyGQhMNmBB8wMzgAEKkXC+YtsNSG4oEBhXA3u1TjVRFaK3BQ9QwfWMFpso6EIxwIastDkTcQoylDBAAwIyMmOEIhh5d1b5e8mqNBCA3BWMiYLemUqahAUSLzqFl+2FQ+ZZAtGy8FWMOCwafsacVPERBK1s3StVtEJpYASMdZiYcKXMTdLwhkw9KCDTdpGEQYWBWE/C9AdeSAARgYIAT5mMNMLbp1GkYUIgFQOKL7t1Z+8goOsy1VhSZMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMDMM4w03DDr2QNNJ4gUx1eRjzoISMfEqs4UcRjAqGjMu458zlRrjFmF6M70jkwXQhDC8IWMykJ4xGx3TQnHeEYG5kGG5GSeBwOHZGWajKYkBHhpzdFGVuQUYhAVhnyhxGEkCCZM5rphcA7iEV42iQUDBgCLMiAT0oDbMBEPUxIgBBoPIxYQ7iqAuYFZIZhCAYhAAxlEg/BwGINIAMHYKAwMADxYmgwOAFACEgCgqxYGQwQw4DLhc3MWOOTDFc0wKMMqGTmzU4IQMQljcCUCDR0SIGNwqkCw6URpiD6DkkxEHO8NDDQAw2a6KqYROhisa8ig4xECoY+JGDhBQYGUA40kGGBg4YmLhJUODPxcwMbMgLTAykx0OBwY+KhIVhCzB0LGQCZDh1GGKkQcmCwvNEcBUmS2aLQXRVvWDMQIaeNUAEUgEsapO0cASBey2cd4OUMulUQeQlmYqwCuS2CDzVNDlS3YFKBR4WVEjlV1ZVYGbqKKAgglbyfD8sAICxEQDDncawDC0e0OagKc6yTHVFio8RjCg//viZMqO/h9nRgPbzqIAAA0gAAABOGGdHE9zOIgAADSAAAAEhKYPGysBAF4XUKxFpoxOM7MsUoKgzU0+EHGXq5bk3YvmlQWtd9IZ2Oy+5J8bWh4DmBkF+Yt5IZu1lbGbOE6Zc7mh5PAFGCSMsenzhZjQBLGLAfkaDoHhgThymFmTcYMoCBhMIiGICCsYZAb5ozCmGA4DkYnqIxi7AgGFaHSb7YKhgNhGmyeN0ZuwHRiPlSGG6JUYGQPxlqC2mKqA8YVZEJpjgdGDGBcYeZAAVAjMEwU8xRACzAAAjMV4M8wFAIBCRCYZwExgBgKmNsDsZjHojwxq4MBcAGtT2YkGBgdDGGiABhsbuIJjADmN3+Y8A4QcDnwpMVA8hpIYVjEo0NjjUxGFDH5gSaLAeQ9QUMcCQwcDTDJeMxAkOCRgM4pzpvlCUAQWGwwESZCR4ICqJsvoMpAA9UAABHyahYDLQmaQ746In2VB3eHEx4ow1UDgsQLNJYAKAOLEKYKARtJpCzYwaTNNuAGDGBM9YBDqymy4NHjrxmCyU3B4gIRRIguOnqMBBZFdaIIASbxYVA+ADMQauq9rStpkGO4nQsQvuDmAcEZJoJGQUXIwcKikAhKSHJLsMgoRCtlRLSETIMcgOgEYBKCiOkiFwRalR0DNB1hhFNARXKBjHMCYGQjBiFI8GVBEwzMaBQYONGh2XLWntVYzGaUXTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMBTAZjCRAb8ym4E7MBWBOjBEwas0fIEEMDvChjR1QWkwVMEfMFMHADAogoIwVgEkNMwMUwcgKjAMaWM04LowcCNjAXMzMH4A0ynyfzK4DwMWtJ8wpVHjDLL1MNb1UzgwaTAqNUNRINQwQhADIfWUMOQZQAoImgqMoYCYQ5gAGalAEJgYh/mIgAeJA0mO+IoYJYMpgDlQmFECqYAYFRkEi5mBcDcYBwuxjrArgwF0wTgxjAWAFMGsKwwEgCDAWB3MNcD8yoKPYkQVDmgVBj8yZSdHOSRwqKaKlnpog0UGU0JWCCAYMNChYaMdKjCyow6kMuMRwnMqgAEJg0dOGBEFjVk9vjFTIx5PFTs0VGMhIyBRHihHcagDEAUwkUC5swszIZDDwxUkZ6BAgWjjEhUCEo8FGHjxoouBAEykkRkMAIzIhdrBiJIkMYKWg4oGgEaSCYTAqIYGApQBk60sx4OV2gMMfJ1YkUgSFKAGJAL+OOlWmiCBkZEiAgC4GiYEKJgQ4YYHkRW5JIGuK1UWIhAGgwDJhQcFkEi9SYUR9FgrEvMrBGkFkJocMsaBgIkO/hhY6XsLdiQ0mCFwkP/74mTdDv7rZkYD/tryAAANIAAAATm5kxYv91aYAAA0gAAABAhTdwAGP+ocUAKgSKkjFgtr75Mbf6Akj0/aqaTTnnuy/tfs4TBEAMAwdMI8MytDNzARQT0xe8vHNPGAjTAWwtQ0g4H8MGnBMTDLxPQwsYHlMAICZDBIQWEwEsAgMDpC/ho0FMDJA2DE6Q+owCMCzMHkFJTCJgHAwGIGDMpsCfzA5gpwysJC6MP/BLjBPwNowagIFMBaATDBUw9EwlQBGMDNGhTA8QMkwBkAuMJwDmgaAWGAuA95tMFoUJU30OswYDEz8dMHD2WDuPvIYMMibMfTxN9g9MKAFNEDjAgEgoCTBcWTEIaTBUCDEkJDKUhDBcCDCEkDG0hjCEQDGUUgciRhUCZKFJg2CQcBwcBBhgWPIXAKSaASWIil7ADBuQM8MShAa2RmVYBcKYSGZIESJz4AyYEbSGZtAW6EZFHRIuDwwqa4yoSiYIBA0KS0UmCAZmQxABMCUY2Mlx4iwc0hlexlEqlIiMgJCXWDJSqyE4qgIAR7TrAIEoFQaRLnLexuxeYWPsDAw6PrmJQYMBGVCokPCYkMuBL4YBKBzjJVCSIkp2ABoMCiJWTMGnA4isaMqVBQKr1ridTVwaAaim8hKYaZoULKmDiQJAMwsxRkkLCEGkAZEANHFb1cJbiQAlDERVa7bAUYiMXVDAhf9HmVQNfGqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMMaA/zBVhKEzCAkGMTYKcjJBq1k1F4PvMJbIUjUcTuExIEM6MQGCAjCRhFQwg0FwMAGBGjAcwRUxa0P5MYwBRzCxg0wxQwABMHrBWjBeADshDWzCSiOQxb8JHMIpENjRRzc4yvYEvMLlDTzAawT0wRcMIMNGEJDDFgG0whItpMWoDejAewPIxOUSPMCqAOjA/wPMxPG0whI8w/KAw/Moy/EMxPJUxCvg5v/U0WFwxAI81GEIwRD80ZGszBFsyRIEx5FULAmYeDkYBaDaJphBtn50Y5o1gLFlbMBVggEY1ebHqbdSIASsxhRpjyJjAwoUChwwSAIchDAHQRArOSZNAqNM0Ko0AjxEXODXF74BaDAVDww502YsxJkFCxogvYVLNfDiAEDGciG8YAIIsIID5hUpmyadCJrRgwmYUIlSalesMYgGYowPJAEFSNMeHQiGRD6hQSDhTDC9LIQMDGgyYgkTdAxYckBGOAIABEAHjgjFgIWylBMEDFttIFA5iQ6z0olqKNJpIqllUvzDClLBEAUQT4lAECGAFJIs0YIpuAjYkMBAZgD/++Jk0w7+S2PDg/3VkgAADSAAAAE5vZEYL/NWiAAANIAAAATqF/3JR5SdlCM7TUcVZsmyJ0NIYc6DRFO1prHGQK03bj9NLWMwBgHxMCDBrDBgA4cx0ctVM8kQ5TIwAxAwN8GbMNhLADBNgHswSMEqMTsBvzAegFIwWIOEMAQA2TBEh3MwZkANMHvA2TCyAOswKcFOMEHFKDBKwS0wFMMOMbpC8zAtQEkwAg4vMB/AkDBKQtEwp8E9MBRAMDDDQIswZIAJMDODMTGVgPYiA5TArAfAwBYCqMBOAYjZRUMeFQyiRQNATYtlMzrM03BjrOkMiIE0iXzVxjFCUdCJJlwUGGiSaXI5k8IGUmSYlTYiKJisXGSAUZUTRhwVmRQoLL8x0FC1oVEJgcKh7MsmVnh5oZISDjgCCAQGDZoVmlQ03xhDYqaM2vMsTAJozEFCIFgRAaMjBFhxjixszY9BTfIiS0DDGAUMNqDAB4wwghDGOCr5EY00J4eimuFSIwQgHAC/hqmZgQ5hCZmQAGUGHOl1V0g4QHJKQGi1Pp6BAFLUMDrRliNYYAMmSbAGCR0EtFd5gS4OIgEaHFVa1aiqFEJIvAiuZgeHD1gB0CXgBhNNZKIoCAo+jgFxKSIoSSISTARdMsFA5UGBDJE10ioQxgYtSEKy5bnoGoVqAM+QkBhUQjSgMnXXlSH6XNMy1/X8cZSD9VJMpupMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjB6QxEwQUG7Mv7F6jO5z2g0aZsDMgwDjTC4gTMy4gydMEeBNTBQwlwwLcFDMDpARDCHxzEwTAEwMBpELzFiQO8whwOIMPPAtTAWAEUwg8FAMH2CWTBfQ1sxXULYMFDBnjICBGQxOcIfMK8BUDDcwL4wKADrML4EZTBSgGMwKADYMcyByTBEgDUwncBrMAFAfzAIwGQ4+Js0CCQ1zSoHIsZQQaakiuZEgkSu6YIhGYWLGZrAYYrA0aSliZ9l0YTFiZkjqMlsZrjkZBkYYXoqYGjCYBCkZZkmYXggYxHsYogKQiAY6iGYDA8YWikZ9ma4eYooFT4UBhHAQVDNpwdRMtWJuRj5Zgg5gwAoCAq4DHzVXwqeCcxqTZuwL0iywirmrBAFGZMOYAsID5nRYKeAIsaICDs5tWgCSmFGmJMBGAt+Y5K5RhiTmGVSGPMLFAhsyjMxJYygZBQEniUWUIhEwNqLMCvNCjDJJinRoxIFamEAgk6aNaBUZkQhhgKKZhRoIFBYGBAo6KFEhFOEQUKASYeWSHADNXSVnEgAOFgIypuIQRhBRd4dLRELgFqJxqwgAKSDHrL6j0JWUw4BpgXHmTDipIQLVthVEPAWOBUqhkXtYmRF3dsoulxU6FB0//vgZO4O/zVlRQP91aAAAA0gAAABPMWTFi/3VoAAADSAAAAETC8jYGjcm3TkXVBMEpBmTCrwHcznApfNJiNKDDw2K8xpkCDMCLBVzOEx/gwuUIXMBzDXjAvgdQwSYC5MB9HBjBwATAwOoHUMTzA0DByQnswXwHKMC/ASDABg/MwJENxMCeCZTHZAlowd4LOMQjMkDC1AbowYMHUMHHASzAswRowbYO4MDPAAjA7g+oxAQFxMC6A5jCOgV8wF8B+MAnAzjt4VzHIWDJxoTFYZgvRJoSIBj0NJhy1BjONZiEy5kwA4kShmMcBlUIxkaJxhuKBieUZpQMosMRjwU5leFZgkSpmCJhgOKJiGVxjwAQGH0x1GUwJBcw5Egxgkz64+F4ABTtMEGw4ADgJvixkqJggJkBYwXHtxjZ5NAMkDNI9M8eF/ICFgrQa1GPETZHwVAC5k4Z8zYU55IOVBdoZAKZcaCDAkJMeGMWaTWDExhgIySMmbBxUYBTTfAEOZkCleGIC34wDCgcQDgMFLbESEyJ0ygoWYmOFgIGFzaDYYWMGGCxIGwzHCzHj42YIctYqDAKVBSIeOLNZKAQoCDM3VskUXZIDgggJF0xEKJAiZKH6KgGFF/kFFbGoCAWXdAIVF4KgTDAxEDAQQSOmmAodE5iUCYZOIASBqUhdlM9LxP5lwcDHBIFUAY4BTCXCHgcBjCwYCAWpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwO8IiMBJCNTQAzQIxSsqjNRbYNTPoQBIwYQAANDGCtTAvwKswCEb2MCDA/zBUAWYwAonxMCDAsjCUhxgw48CyMIuAyDC3gh0wGsAsMJODXTBLQrUw0cK8MYSDMTDZgWkx1EkPMSGA2TAswoIwrIGCMCXADzCyQQkwg4AUMENErDCxwocwMgEQMEdDpDANQMEwLIJeNnEpMLxBMU4WMfwsNHYdM2kGM3gTMnX3MehCMsFJNCBVMVhdMY1TAobmP4uGWZeGKCiGjYEmTxiGJhDGkIcDxsmcwDmRo8mDZDmVgLEISGDAoGDojmBZEmW1j4o2Ew8zk18wwHE+4wLDwnAaRod8YQqzaDk5jDKTYlwMEOQDMYUM7eMECMuZPquAiQKtgFnOi7MOoNILFJZhChhhxhjBsC405M4ON4BBrM0YcLBgMfbAh3eFTEy4MWCGfBGvCDS0wJEqnTalAOHEQMzhIEjDTiEPDMgwSsEZ4xYAFT0YEUTHERELHiq7CY0ABYNKEyIwMAzSYWpA5QRPmmCzQx4JsSKgMEgqWzcgAF/mxhC8xYlOlDoKkBEOWUBQqR67pczFR//viZNsO/zdkRQv91aIAAA0gAAABOB2PGE9zVogAADSAAAAERIdHBgQhOAgmo+LCEs0rgMFS3VElo+BiBbGEWYDUwDAy/BYoYUWJJxZDG1FHbjMuEguYOpZRgXHmHdU4Of4qL53w8NnzeWCYRxCx2jqgmE6CWYmqsBjoBumHmM2YqzPRhmgnGBy00YoQ4Bi+kmGIKFoEBIGQYa4YahcBg3lWGkaA+YZwSxorP7mS2DCYYYKJm5BiGCSEYYaxrpiBgHmHaNYavIXZgih5mGWXGYF4chgajdHCxEYVMRjZ2gJMGbtmbyJJnk7mJqgOgoKRsIfgNM5ixIGl0CY9ORpkgmaxIagJBiJCGKGgBlWNLAyAaTCZVMHlUwSGjIQzMmDUxUCQIHATQMuBMf2ItgQNO+MMkENAYDRg4iMwMCgw0gNhABQGMJiYsSCmXPmWDhwM0x0xRoyIkz0VSIULis5QAyLAoyOUYloz5TA0gtHwyAsHFy3Y8nfxOMxo0ChWxmDAKXNAZYi2DiBjw5MNB38QqjWhExAotKx48QCoESAGLbxkx5FOgSBmPDGGGF6V0hgIcJt1TSQqBJBPoQhkgU7AQHHnKhxhgiXotZTJjokHLwCwJCcmvFSEEpeWcZUBQDtmAEIUmbDotioExQEw4wBNCUQwFCgAiRGaNKEAgRACv8IXJRCiEKizKMmlGpHGIMjQCXt2WtpaTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAAMwIsGuMEZB8TOIweAz8oXrMv4KhzWqwJMwWADeMeCJyDCIAZEwDsbqMWUBcjAhQOgw4saRMLGA4TBhhFwxHYIpMELEGzDPwVgwOwD7MEPCZDBigRQwp8JvMb/CbDCcQwQwiQwoMDJBSDAgQX8SC8DAbQVowG4PKMCCBQDBAwIcxq0FJMBdBRTBCgeowN8C3MDTBLDrL3NriYzjOjEwYMSvkwoSjDooMSpc02EzML/MUu4yANjQj5MkhcyqpDSQUM6g8ykUTLJOMDpwz0LjJJYN8jwRBQyS7DHZzMHoAwemyYDGUyYd5uHRD78AyUZSgcJmU7AoROVDKGpjRhoyhz0osiNbLMKaMfIK1hj04XMA64qU5JM1pc0ak8xQFCDBrwM9MK2FFI0TM0lWSBiw8VDDAeCMCHMYEMEJABYVLA4WjWFx5nBYALqXqogJMrGQjwADEYx0h4SAp7XTAhRAgBQwREzDoXBBB0LgyQsBSAKTDwFR550v1bCgeyRBpaQoNFiqjjIwKCAyYtiW5JhCTrIS7wgLIPs+QBNuARhpCLUwgOMBUOCVSghigYYwEYUySs2hA4gVJo0phCcZgAERQUjf/74mThD/7oY8WT/NWiAAANIAAAATrVkxQP81aAAAA0gAAABAfEQgDDEiwaQGYxmR8TAQglAmFFExBIWFTupzBmQjMw1YLxNDQBrDHKC6006IZHNqNCJjA+wqQwJkqDMCSBDTBKR04xxIMYMEvAqjFpBlIwawEpMDAA6zGtAZMwVAWKMKaBXDAvgbELh+JhEwVsYEADCmOmBRBgYwTQYwOR4GNNASRgBYYWYgaDGmCEhihg04EwYIMADGCDCE5gQwQ0YIcCMmE4hEhgYoNcYFQB9HrQCcvIAFqJmk+Gn7KZ4VhnVLGQI0ZxAZs1PmUwMZGdJmGqGZkSYUYhQdDFANNznIysJjI48NwC4w+OTdRmM6G0yFFjGYaMLEc0OcDBAPGh8eQcacCd70Z8IeKEcNUCD5uzx2MZihxkgZUUGgKGhMIRGORjQAteJTyRyYc8EcjDxTk0jDGzSjSAmb2SDppv548iMqnLThUEZIuNJgUJGq5IZMGdLgGOTA48kyKky8IUDhEaVAIWhxLNExtPssm2YWLlsX8FkSZKgyLJjEJthBAWFEACAApanGiyXST+CgcGCCsOjSt4HM2JrrUgxMxQJNpJkvuX9ZMnMocWqTixSxATsLBCQK7DAVBTABSiXDoMHBhsxBkKDhlkmOgKMwbamNHjRQgUCYEZAALIh5gATRlB6i7IjCqkml0BkFBMFhCkZDT8VUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMA7DSTBzBTg1mcEJNdtPADO2Bno4kUDmMDND4TKBTr4wmMF9MHbD9jM4AFMwzADmMonGYTBbQFowtgdjMU+CLjEcQd8wy4TVMKuCATACxj8wU8NKMHuAeDFfhOswaUFWMVLPYTICA0kwVcHwMOBBhDCXwpAwqYWFMCcACTBTwJ0y0ADXMG0A6DCfRAcwFAKBMAmB5zok4TP1EDYIMTCs2TJlfzsIeAcnJlfDprAPJh8WpgiNRmQXJi0AJjyVZMpBgANBhiH5kopZgwIZgYAJoMCpgyDxiqHJgoGxhuZhgyD48OJlcBoACUwjKcyRUXMmywg6uZOocuubo+coybaSZgkb4IMSTe6zdpD1nzBIDXCTimzGhTbagVpAEUz6k2q46pYyK4MfglCYkgYpyFFpAvATo2ZICikqgMfRFAIwwhQFSTDTDPoAqJMSuROCgkzY4wAk3iEwJA0ZgzbE0Iw0gIOevKX4MQCM4GXOYluYkyIwZjgq+zHgTNiC465mFhASB16JvIpIPszMwIMIKIkKCpqwIGQg4QoRTLlC4JCcoCRHyIqCBgGFmYDBcCYECShxGBMGGHh0EDwoqDhwapgY0ENBQMIQPb9dwXLrqDj/++Jk5o//MGNEA/3VogAADSAAAAE7EZUMD/NYSAAANIAAAARpWBTHCyRliIwYSvTQ8ASYlYoGCgEaHOlCMOeAnjB1w5A3agzvNC4aYDVqWig6CsP2MAhC5DTuizUwuQBrMYLMDzMMg88wsUAqMZeHIDBWwGswSY3LMJsApjHWAOwwdUCdMB1A+TFgAhkwbEBeMKlB7zS5wSQwdUOBMfQP7TKEwd8wHEEOMpMC8DAVwS8wYcNmMF5BSTBXh6IyOQXlMAXB7jBog5owV8DEBoPOYIUBSGBEgixgnIp0YDkChGAGgP5hIgNyYAMAYGEnBBRk0pmIpudGRZILg5PiImAUVAUtmSECICEZ1FYNMpwhcgY+GUx8YZAphgkETWMPEY1KQjAI4MUEkAjx0wBchvwYIcmgymKBG5kJXm4DmlAmYsifA2rw5SUyTsLBzV8DQljUdzOCCBMQiy9hiwigAEAjwg0pYGgjShjFBzNsiIeaKiDxJhSw0yJApgVSpzGwhIswMCAVWRIGAaUxLJMEwJxJABEjRiC9oKCiwFdw4PMYNHUhjyLAAaCS8LJmOChBJK1pLTlYYQ6sUcsxIgqDyUg/ZMeKwBZVa5MJZUKhoeAwVuoiEiwERiiaEYwSCAqKzFkJgQWj7Aktl0redRfpboeFIJTKAVATBEYDXUikrCQAS3S1ETmcxt3i8EYTeEg7L21ga9ZzgbVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEw6IFXMFRBzDXoR5oyuwu3Nohdrja2xFkwIwFcNT5CQzBZwaww1w+XMw2CljAzAbYxbMKtMDgBQjBIB3cwdRlDcNAJMWghgyXQNTF7iaMAgKIx1n/zXsR6ME8WQ24PSDlHEmMcVKUxyUXTACB0NHxSwypAtDFJY6OFEa0wRRojGXPaMWAB4wkBaDJEBOMLkLkxk0kTDWDpAokhipAoGCAC8ZBophgmhSGB8FKYGwSBKEqYrIepgAgFmBGCiYJwShgwAMFAhpgpgGGD8EMGAWAYGoABGmDqAUYPwOSGZgSglmAkCsGAumASAIYQkMGVC0WzADg0mJDG0JAQWABAEgHmRFg1Mv0HIjQRDDMTAhAonNSPAhBdoKLgUkaIQ7g0tNWfGk5gU5xSpr3IKHI8iAcaYQPGkgDDlTAgCYHK2rrMujgZLUFI4JUPd5JYgDmCQFnIArK2GVKxm8xEx4lLtTIeCLnpAcUbCMAmumGMAJAoa0UwwQURmpBvKYcWCgYoAbK0UzigOMpGJyo1wiROyYsC5QIGDxExIFfUNus8rSjYpQiGFwJEBCgZ0jFCgCEBwQVTF0QUJBQYYHBwUCJjUFkA6//viZOEG/tVnw4v+03QAAA0gAAABOyGPFS/zVogAADSAAAAEVhKQARQIdhhFCWIRRMEc9a7uROSUtq9b5AAKQkB5kwJWZzkFfGekjeZiHLpcaQCJ/GDaAbxlxwssYHkDOGB1FGpivQPOYJoBiGBzAfJgJAAsYOIGRmESgWRhPAGmYCODbmC2gb5gSQkQYNMBUmDWAQhkkAS+YS0FdGJEnORigQP8YJoB1go1qMFdAVjCZQvcwXoBnME/B5zG+QKAEABRgVIXeYIoCXGCBgzR/CjmUzub4Xx09smGsMa7aJiQRHNtOZbMJjFOnRCuYPUZpgzESPM2pgxkG0MjS7oTBBzTNNCowWhTFiAMhhIzaVjCQiMLlIyiBwaATBwFMSzMUHM6KL6hhYFIgCGC48VPGKAg70LADNgR0gQsDBgzQhjXIzEEwEhDLRjEBtzJj0JiWRgSYYeM8dIjxtDhEvMzoJjQGoBzsLHgCHMYdAgVKJnRohpKISYMSLBwpOkhJiAKYEINKwEMAw8QuADTHDA6RNSFGCyNhehbwGGpkAoyBhxihcvDhQGiNdMMQKMw0MAxVrhjAycIRBMMDQ6F72/C5RhtKY8NUVRKAql5UCkxYsBR4horBI3hhVCSwZJEiHpCBUkYAGLGyQUYwiBjQBSGVImcKGZSIyDQQdGBA8iJiqNWMMQGISDIFDI1RdL5JRtUVn0p4xLiTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMDYBDDAvAgY0xkoxMigBVDQCqDo0CcGsMCJEXjO8yWEwacHuMK4OWzClwiEwBkF7MEsFEDB9gOAwOAJ2MKbARDBCw7wxmkGKMD2CXzALA7swwAPFMC5EqDGJxNEw/QApMipOQzIBAk0wk0LsMOhAjDBaQJ8wYwQtMBdAlzAfBsEwNsI0DgAww1wHSMENBATAxAcwxuVUxlLk4xLQyyCg0GdY1nLMxAUM11fYzJAQaWMDWqYpkIYvl+EJKYmHUYoEaYgjaakDSJG8ZRmKZ3BsY7lYZIE2YSB0Z2lOYgAWYJDmYHgGY5h8YMC4ZgkMljMPUVwWDM+sM83MScAoY7Co0QIHXwKnk4OdkTcwz4qDgS3FtZVYHq5GjKkpgxBUqmh4sYYuUFDVkwVFNBAMiIMsoNAQM2lEv4kVAQiLl+SUGtRL8ywEypwMJHISGPGAwqkOagcBqxgBY8jMWKQJEVgFQzILgYfC5MyIQioiBIZ8qIxZhiRZ8HLA5mylSYCuAEAIyJFOMEvByJKoUTJyA5AXCDFCEBkyDICs0THi+IsVIkYjKmUBBYiYc6gcYwOJACUGWnKhxA1Qc0BpAAYwqAmRKIMMAP/74mThj/8wZEQD/dWgAAANIAAAATndkRIP81aAAAA0gAAABMIFJpwyCMOVSRDEw0Ub4BB25LDhwOTP+WAAJAJIKELOf+mzMGyAqjAegRY0Nok2Mq8BJzOSIwIwhEAKMFnF+TFsDIYwTkDPMGUKjzEKwDkwPAEQME7G0TAwQFAwA0NsMBQBEzArQzswwIJyMEQAdTArBVUwJ0BHMGlAmzI6QyQwYgE1MbYQ3zEwQLYwN4SYMUuA0AqCpmA0ijxgFADwYCiHQmPRA5xgeQDWYTKDmGAEAphgCILsf9LBtNbGrI6ZAcptpiHGyqChEdshJnglmUUybAGBjIUGQTQACIZMPQWHxiEJBp/MDAYyTORUKGHEORk4wIKjG8ncwx+ODXg0BoDKBQhOBAA05s2TwwHs6Tk3aATQGrrgDQY4meEIchcYk6ZsKZ5OMBwVuMOFMvHCwcDFjPsgoaT2M6GN4MAJ8ULGGDoihxEAn16BC4xoJYRxTIB3+LXFtQMEElAs3RkT4L9mONmLEpMGEECSxBooOxwswJLSywiElDNJILlwQBRbMGHVhAwQOkSkKDkEJQaDlI0rYIBFoGWDwooOoc40TD2KmDBighRoHBBkOAABdcs4PERUuULC6xIHKEYCEl6wSETBSSAwIRgSYOEKjDhR5WQiWmmHBhAdsDyOSKgWdQyOAQwWXDQCvJAjvN6KgHXSaUhavUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwIABBMDyAXTPxSaszkMgeMJtigDNKAvQwaAJeMN4MxTCYAGYwxIeNMhVBhTBNQgUwg0eAMBwAVTBZAkQwBYBzMH4CHDEBAzswO8C+MGaBTTEUwZswSkOFMW6FcjBVgGEyBAvYMcBAtzAWAbsxPgEvMBvAyjBywXMwSwAvMGMBhjIHgNYwZYEPMA/DmzAlgTEwM0BIMOVAHTA2QUAwAEMKMANA7DAVwIQwoMBXMCpAfDA/wdYxuDDFi1NXEgyyCDDx3MEiIGpAxgMjH4KOYF4xcEzEE3NPm0woQD2CMM8BUxfIwhZGIwUEQsrEBgEFGJAeWVMNgwFHwHLUz0OjHBwMImEMNZoMImTAACBAZuB4QKTAwUMPk4FAYIS5kEVGGQYYQKA0PjAIsMHBEwyCDEQxMdBgwKITAw/UcAIBM6gA4igQIKOwcxDTHRFAQQUfSIGtGJB5YDWOwRGjwQsGY4gLTBIKGxNosIWbPhAEJGwy+IIKA8RdYOiHWDPER2NdoYCGiDAqDmBpQHPjAgqABTiFtTIGNiQLODcJMZUG2w+PAmeGhJC+CNBZgMyQxDCkhQCcJbLCsBjIiCDl2liyoAESXAgYOmYiFiEKRaUBOLXa2ULmA0XUa8YYcOr/++Jk7Q//RWREg/zOMAAADSAAAAE8WY8SD/dWgAAANIAAAATlQWbgkcvMFErOUpdWF5mAOg+pgxAMgZzIQeGFIFRxoC8FQat8IFGJKiX5me48AYNIEkmEsBCRi6oEEYSwDlGMJDAJgqoHEYEoCCGEvAPhhbYLYYrSBYmASAhRgBolwYCKAMmCnCWRj4AceYOUBxGMKnxxi1AOQYUmHRmDVg4ZggIQ0YMUKBmBtgOpgeQy8YVYD2mAfAGZgxQTgYGGBjGAaApZqmsBmGjRYzk0iIMw+Fg4ZPoSG4zqb8xFJMxrUUeq0w5D8wTMImDExbHYx0B4wxKkxlGMxPD4yyM8wzDYwcNgx7IsysGo0oB4x3DAwVGsx3DwwSDsOH8aSiK6Z4sF1QQ/EAUwCwnBmvOGkdkEU7ww96Qwho39oycEy8EyhoyawiNnAmhhEwVo1C0wA417ZWYwRsdNGOBgoKLKBgskGUJ0oQABMkGLA4SFplALkYUYVHYYxC5ALogYViYNJiIgPUQEENQqIgoqwMkNMMBM4ODqqNqEscJA6mYgWoKWaHAZllAGLgYwl4KCh1YWlVtFoCAcsB3XBQ8iDgImKjzDAxIGYweZwMAkhlRQQYEipECMGMDBScxgQRiRJkRYYBIhqmQYjYYJCmSJtqkUxhgBB2thYqlSw5HgtOhiDkg4OLxJABUAhglqJAy9xa1AqH1xvcpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMC8B8zCcwe4zW0q3MsMJFTL12sw3MwMQMM2BCTR/ge8wZYEiMDkGSjGRwDUwKcCVMdFFljCDwFkwXYGOMD2A/DCCgzkwKEQKMF5BkjAzQfownIGQMGLBzjGyxJMwdYOVMJpPizDpAmEwfwKzMWFBMTBdQZYwXAZQMAMAODBURPww+0MTMFiA1TBIQXkwgYEZMBsBNzelHjDAlzHCODMciTKgVA1RzAICTO9pjJEAzEZfTRQdjFgAjHI0zFERRCYZnMBpi4KxmikhlyIBhMWhnqJxguF5qCfRiMFBieohjGEJhEExQwsEGAJViQtInGOgFRMwJI8wbCoeE8xPAkw9EAw0K4OAYMGUyhH8lDUx7U95QgKmIvAx+IkQZmNkiDE5o2BEAIZwOXmKCm9Mg0sBkAcDDDTLmCK+C4ICkwcENOcM4JM4HL2GVEiygu0ZIAFxoXUm8UmRPGZfCqADIgicVjTMyi8AERALql4aZ6IwJANNEuMAvDippXamBcsyI1ciPBlALJhgSBBCKBjwwoxQgCgMw5EVEBgsiAvWIyiBytqDyCZDkNMwgAXZMmLU8AiSvUhWGERt//viZNsE/yNkxIP91bAAAA0gAAABOG2TH09zVoAAADSAAAAEkoGFLTDnJc4tCTA0XQwqYYOY0oDBCOQ8bcoQAHESWpGRL1ii7X9L8z0PNNbPe7AAAASW4YGQHxhpkFmpEyAZ/qjZjvxkHyUCGYQAXRvllpmJ6HqYOhzxkZi8CQZhmPC7mAkAYHAkGFcGGYVIehjiB5mEiAsYLo5phJAcGHqLmZw4zxhri8mUIuyZVodoqFgYQIkRgbhTmK6IQLFaGGyGaZ1IJBgUgVmFYIuDhvjB5ChMcFYyMJTSI5M3GowQzTeoCGAIZRhJlAQGVQkakCRiAEmLS8YzHAKPhkAVkxmMEqsSABgAZGdRaEAQ0IMRQHmCDMAREIAiZjBKQYgCIjBhQATDx0WYGaACRiixyhhlABI2KwBlTqGSAcxR4qDFkEyQkBp6IiBYaGBi04kNQbAx5TMtMFAEMgQIjEFhpixqPRKBAoQ0ABIEYEGtChYAycWPJGEoNMtvgc6CxYBLAN2M8OMQCLkGcjGIOl8DGk0BClRMjGBRUCl4DMEAaoMIYQRAJEFhaAkwYwxABRQQBUDxpOYQaBkpgxxgAxkV5dp7TDBDEjQKiJloGJhQgRBRIguhdoBDAkomMXoEQRZzdwAAEjCwJRHKxg6NUuChMEiWpISA54YwKFRgWNBxEw4supICZSoaDDBaEEJUiEMh0OlrCrliTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgABcwHEFcMEaB7DIFyicxNkA3MXaBbjaQgzkwvUOjMogGujCdwJ8wSMXSMHUB9zAWwRow80A1MBqAwDAaAC8HA8pgVwOiYiWBzlQC4MCZE7TDXQaswU4IdMfiAmDAAgGExPAk0MUjA9iwFmGGBAO5gJQNGYBEJ8mBAgAxgXQVWYASGkGBwAxRgOQSgYMuAzmAUAZB8QzmCUMcE1Jhkmmi/SaRMBkYtHDMIZLN5gQSm7iuNEQwIhTJw/FQcaIA5hIYgGTGSgUZFWhvstgpPHB0IYoA5h5cDzxGggZsJgOH4BG46AC75jQBhYEmSA6YUDYFIhhwRhw4GDSZABxMMQM3GRHIocCJhny4qQmwWTVjoxjiDMZEiRBr1NNYLHkGiux0I0kBj5Zxigh5QyCCZjQUBxA8yC9R0c3oy7IEjM4sACi5BgKGPIaBLczbxEAQyYbRgsCZLQNIHEAO0qqcoRhlGFEYQg1azkBCCo6SCdKCq91hVMSLwyAyVc1zTJqFeEWFGgQwRHGYmWjQoWgcQK2YsJIpgGuE3wGOL9tMQGSlbQ4EBjjGHDHmKGqEZSD/J7h4JdAaFMjdSk/P/74mTcjv6WZcWT/M2yAAANIAAAATrxjwwP81hIAAA0gAAABAS7jcAyFwjCBLPDobioOgYUv3Db7yeUUkdYSE1DBUBAoyaY2ONFyLijR3lfM8gIm6MNLE3zXJzgExK8ElMG1M0jCcARwwTMAkMDzCrDA7AaUwLgDXMCBAkjDKQXMwhwWaMFTBbDEWgxoye8FZMDsECDASx5UwhAOCMVNWGDHiA2owO8AqMDUBOzBMQXwweIWFMWtATTBfgJwzaoM7MDwA/jEmR2YwDAEAMCNA+DAJAIEwCIDIMMdF9DBUgOgwDIV9MIUAHDAogGUw2MOXM7GQykEzOaQSsMtBAwaKzHYnNCAMyahDdklNHIY5fWDz7GMHt85xSzRQDMptozqNDCoeM0h0kCBi8JAJeFhJpBZAvMmaUUEU43agyZoBPQ68HGzGWzLpjsMzCRDqtjPhjEkwoXNg5fdLweSILl8BoIusWCg5iY2QePgLSDb8DznhhSaQCJDQKIMMLLohRSNTDRqDfyjUmC2YKKgAIAkSRSMS7wwEZEIOFzUOSbAYNsZoqq4oZJuoDQUBGQAsBJhiqcPqRSSDgrUmDXEHyoCSqV4hkY0EFEJuGochQ2QQAEMEDi7LtDgRjz8ppI8pKKZGDQGPDEoMiCJDKFypQJW5gqbiaooBDjMeLguoCgRZYRgV4PpLkXltrDtaYc2zmx+nsV4RPnakxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAQQAAABLcxkHEZmSmGmaIKZ5kXjDGZfKCfBAsZhJihmRkxQYJQUhjvhqmZsCgYMgYhpUBxk0HxiAThgUQpkKIRtotJh+ChgDRBuGDBjyWJ8GUBi0KZ3CyYL3AdSA2PBkwvHA0GzAzDBQwaZ43CRcw6AYxuhEwTFEwaEc0fFEwYD0x1akxwBkwiH024EYEhUPNiY3AWYeE0YSAiHAuYRiasEqwHAkIgRMTAIGgpJRO+DBMk36JopnMQ9AV+ZBIu0LCF/zTJWEqbsZBCIFDBooXnDggOCkocePgUKIRKQAXEgUyUJi6JIAQsctWZoIjEhUMJFIeGB4kSMgoQMNIGMOJiYGZzDaNzTdZOq6Lu0ryTqyMVGQKa5bRF9AWJH1HyYMYUin+tlLswByjMECEQ4oOKTUUnnYUohCwasyIifJdRH1lw4JFi4iBAwobIIqSLPkMDgcFDB4hGg0MLOAQOARJLAREh5CpMGlRIczMwyAalGrWmIlES0KiDEqWDmNLviCgA8lICyXRsmAWODxwx4MgRERIAnSYeTGzABC0iEKv2AKxuXbcv/++Jk0wD9XmhIa93S8AAADSAAAAE9bZ8WD/NYgAAANIAAAASalj+Xt3jBDwM0wJIAlMYwKFDFGw64ybNcjNVEB9zA1wSQyE4sFMG8A9jA+RNUwgwKlMFXA9zEBQfswMcBeMBPBOTBBAYYwOUEcMY9A/TA+AKgwOcS6MH+AdDAIgdUxNoNMMDCB/zCRDwcwKUIjMEmCTjCTAPIwPQANMONArzCAgD0wAUJCMXzBAzAYQRowsgHOMGPAljBFgFoBDE5gOIC0YN0CYmAvgJZgJQKQYVMAcmAEgOxg24RQa5Ixip7GgxYZLAhwaFImmGj4ZhDowYzTNFCD8YwdxmEBCEZH3goYYJ5uUTBlsMGEYzwAwUcDADAMBBMwIACEEmIgSBEUZJApiENGKByYOBhiAdGXRUYRGprYGAESHWTGPpGVWGyYggyc8ELdQjqDr5gwai5lghkJJNGMANM4wMWUN2JJBZNCMKUZyZtKDC5cYzbc0IU0aMtwWvNKLTQQVKBwNOqwBYOBQwWMGYKlBos8Y0WCgJzEjvghQa9exUaujQMxYwFJWlgaS/oBGiQ4MMJequLqAVKFwQobHCiVyAAWHstBIh7A42uQwywBEEtR0EmCoDH1IlA0QjtMyWkEGFaAgKsYxgQKAW7gQMBhTW6NoDF1ugQKvlFSTgQCNHmUhUYiqYIOVAgcBLPy5DAvW5zWnyq3727+VVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVgAAADmAFgIhgkIL4YaWQrmJdA9Zh8qzyZbQGKmCmgDJlg46AYDWAbGB+iV5gxgEIYCaB4GG5BGxgBYG4YDIB8mBVgSg4DBmCMA9BgAACQYJeCImD8AVBgMIOIYiED9mANAMpijwWAYtCAZmAaAIJhJQEaYB2CdmBjB9pgA4COYIODXmKRgchgHoDqYKuD5GCZAKpgCoHKcalIYfiMZluQYKEGYtPkbFCqYagGaeNWY7CMZPk4YOgaYYAGY6myRGcYDhIY2huYTBMYPooBQAAB+GE4zGEwXmR5OmCAamJZ8mXQNAEFjC8EQYHZg+LQcENCgBxQEnS/JqxhMUNWUBV4y7AwrsRoD4QTCijSnDTBxGaCgkABhHFMEMIBYs2DgC2UE4BQmfQqCpPjApHUw5dEwUNg5gInJcYHChG+FTwWliSQtqDDzxGGVI1AowZcSYkmaA6ACIVIrxEJgt4YUEWeIlojDBhWVBUakUlaXwQ4rJRCEAJc6+lN1/EIVOkxQAdKhY09KcQhDEghS8KHTRAkCBjBwskBAkLAV30AiEigZRUtUuoKAC6oQEColiBhyCXwBQAkumyYwuDmAYlZ4iyMhgwSXvgRMIwiMHL//vgZOWO/xlmRrP91aAAAA0gAAABOxGRGE/3UwAAADSAAAAEgUZDBIFEv2b46lyCkrNUkx4k50ZpasZsgMBAQowIsJVMMoKdDATRC0wMpsPMWUC/TAfQdgzt4M3MIiAqjAQA8Uwv8HZMABAzDB+RBswA0COMACAVjAqQHUwHYGWMPkCNzAKwM8wKQVNMD1BPzA5wlYxacKJMD0BYjBHTI4wYYFeMk6HMqmNMCxCO1KwNXSIMttxMDH4MbC9MHdVMAwwMVZhNNQqFgOMMoXMBSMMLYUMCRjMJh5Mi5uMGwVMhzkMQRFMTxUMZjIMShyMQQPEIgmBwxGMyRmJIOmGzEGQQCmJAWmCh3GBQomHa8mAYsqiMAA2MCwRHRBMwIMIXNObAoAwfcAkDTozukyyxUKlUgZAEbUKa0IYnGRCTHhDaux1MaDM7gVJjTsygEBGkAo4pBxUzYdVcAPQSNM8lJRAGHCRUkZmJHOwdKKTCQqzMmPEI8qiUdxGgSQMuEMcMEKEFLS2S/iZIkwYBQBihfUy5NP4ygwRAwqCBhKGRGZCowODFrFL00IMIDYkTVubQxJIwp0Rg1cBB8qGDBHAAVJXBqDZgjhk3A0tBwQaVIXgQaFBochL+AwIFgjKE1UIygG6KThc01ZEEhTAvwUTBzEHAUFwuFRrDKiElAIIUAKQBQIgOMeHBIOlTWDh5EqZs09ImX4pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqjAzwEIwLYCZMFLL8TEowZswzyJ5MY/CtzAGQPo0z8YZMITBDzAsg2sw9MFiMEHBOzCaRAgwLwBuMECDOjA5gVgwWUGjMahA7zAwgJUwowHvMOHAUDAhhXsxhcMuMB2BRjHQw/0x3QC9MBTBtzFZwDswFEEgMIlDyjB8gRYwMoMlMZYBXDBCAHcwsAKmMCBAgDBXAvE4sM4wIEAzyq4IDgC1sbXkyHNGZb12YhgkYjnIabgGOB8YDoWYOhOYOCUYUC0YSA4bErEKhAYOqwa6AWY5BobHFqYXEOZDJOZ9imYTCmDiBIQJMUTbOmOTEiYyMeMPEDdgMWlTAg84QEMALAuemGnZnouTsQsnGFDRiwgYOImXjRiYAaqls4ETaAjIxANMkFTEAMCx4YOjJaHL5jIUOlJlwKYeGmsEKlhiwia6VBwAciTAIIMECzQxIumZCpLoMHBBkKDBZKoFD5kQoiaIxQrOXIAJKGHqvjNQ8x8mNXBxojASqDBgiVBQDHl0xIPJAsaFCgaUiuMOCRkUMcFkqhoKUzChMCSQvyW+FhgcDxICQkGBCocSpdlwE5wIDiIFMLASEABgaChImSAcEBBCEAYqCCQ4OA5oAsiiYKIF+jGxAoNmPIfFuh4OGhJJ6XlZQIgws+yg//viZPQH/6pjRQP93aIAAA0gAAABPJGTFq/3VsAAADSAAAAExoCLuMKXgutL9QdWvOAwBoBxMBEAUTApSVowVIBQMROdLTODQ7swU8LLM2gJ7jAVgNUwYgQOMF5AVDA8gFQxEYFBMFQA6DA2QuYwhAC4MCTCozBDQqYwGoE4MIMFsDBnwf4wFYPZMV2CtDBngCwxDI69MExCXTAwgh4wZ0FWMD/BZzAgRXMwToEFMFDBpDGXAPwwaQCqMK1AGjA1gGEwK8IPOxBSEipNR2hMKQ9MgrmNhR6MCD9MWXuMUw5MvD8Co0FUNTDccjEUPzA8VAYGxi8EhvYN5mQHhpSk5kcE5h0MgOsczLB0yUZYxhEZASJAeYGgEAj5BwOlyTAwHjAcMTEEIgEGBg0C5kIDIXA8DCuYbgiY1C+EE2YMg+btia0iYEiCQ5lUJsEyfhpLJoS6dpsQCtQ9EDI4YdCWhQuAg2UGCkCA0AQYyWMQOMHdM9LMseAMICgjL0wqjYiZAiwkuSJGwYBMWFMiPElJhUiShNAMoDR8GRhKHN4HAWU0IMyZFVAROlCjFCWauACC62B0uqkWACI7ETJAAcIjZQZGhEBAIGYsEAAqOZaUvqAmaiCjyEtWcvkQDxCFVAPARwCiIY4AIDRoCIqNHB5UKBghHEtKBBiPaQheZGtQ6NqVspXkYcxUBoJggcHJhapEPFFKbG9uTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMBLAmDA1wMswlws/MNnDMTBwGEE1vECmMD+ECjFhzxswZsCSMDuG6jC1wCQwL0BFMPNBIzAQQTIwY8RXMMCAFjAAgGAxnQBhMBzA2DCnwR4wlACVMEpC6jIgguswBoIqMTQPPjF8QfIwQAMUMIOA+DAqAEswjgTEMGRBGjAghC4xh4H3MBmAqjCSAYMwFcACMA/ClTDKAI0wAoAUMEGAyjAtQBYChUhhDYG2BAGUwmAJfN1D0CtwFOAw8ATgDpMTEMOXRnAPmOVGaBjZh4RGwLaYXEwjD5tXBGcSEazYgeaTGYdJkEQAozWqDBQeMUC8MbhiQEmOCWLGIvaa4EKCcw0HTAItGBGanEBgQZHifG1AiiE25w1pUztEwikzCAByjAGwUeKHpiXgRWBAIx0UCCwoIOYdM4YBCQ0i80x4WOGLPAt4HAQKtIphZU0BIWoGDURIGhFjmRBDSUx6gyAA4psMKmBRjQkw6s1IlL8xCsw4kyBUAB1jCkwSPKUgoGxIu4YEAIlBk0K+0O6FBilio4IFEKNCS7PwhaZAQRCR0MysxgmggRxUMqAcGFAMVDKLCQUUJFlQKCaUXTURC4RYeMrhBSUgAP/74mTjBv8MYsUD/NYiAAANIAAAATrRlRVP81aIAAA0gAAABApGXpaO8a7GIrleNUQjOFpVjExl0GNFZNBVANgAADhg/QN4YFEC8mORgcplhI82ZMalbmsThEhgrgPSY6OZEGIWggJgfYsAYg0CHGALhJJkMYaKYA4CxmBCCEpgeIHaYA6BdGC4hsJgCAAeYA4LtmDAAepgWIfcYkWHimAngnxj3ZB4YbYBzmCIhXRi9gGwYGcAtGGugyJgjQDOYECJQGCxhKZgFAEMYOeFRAEB+FALM74cTA4cMGDoz2SDCKiP5zYyiJjYekMwCoCrU2EQUEwyQDBoHMIhAABMxQVzZJKMCBQwWSDFBBMGDE3g4RIqGYI+DsYCCcY7BCKZhgRjJICFzDBCIcYkgWtCgMy8oOLGRaCxYxKwKgSqCM8ALXpFI7mGGG/KIDQLGAXpQ02EESKhcUZUEh8bFUikY9ULACAOWDQcfFhhmQwiOkCoeHqBppIARUYgPQ+JhTDEfnzR2aESgkJb7ofjwUwy8iXo3BipNBPoGAWzGDOFAq5DiM6ED7CFARIzBog58ZEqDlAciFAphl6YhANJihkchjlRZcEFlawoJEgKmoOAs6Q6pEEAkzQcVNmiFkIZiEkBAECiQVdBwAIPgASWAw0KM5hLNoPJBjIpVMeFpPDwYs8TKANeMMLMeiUGMimUALzoVqqwublmlkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAAAlQwkAFpMCpF8jXDDU0y+ojiNGVCJjiCRi0w2YBOMzCG6TCPgmoxD0T1MYQBPjBzQP00IolIMDfAVTBXgZUxMMBZMD6ArzCyw8gwOgCsMDaHNzC+Qs0wlUKVMzTFdDBWRZsxM04vMOBAuzCgQ2UwzYNnMAZAYTDnhxkwyMF1MFdD+jJnwNwwCgDpMBOD8TALwC4wKIEMMLHTZcs2NqNTSDRy83i4N4UTCq0dRzYCcx4wMDOxIoEJEIgUOSBEDGuLQgMyqpmGnQKIjIzs0EYMfHTFgMBYZjgq6oGWhMRrphBAgqWGaGZaqdLG0c1iIwmqkpcmFIxECDhjJZEQYgmKhokcXgGhlwpyi27ATCLEbhFSY3hxKw0ITEIBIQCGGgaUBLpMQwwgV4nGGkE8JIIbQCmpZ9x0PwHmX8DBjHLSxcILHw+mY84Y8xUFgAkxEMiqEQIsOSFApBCMZMEAY9SMqnCYJQAgAgjMMlAOFkwyQrPZmX7HDw46PNjWTDbbACAHEMaNiT/++JkwwT9+GXDm/vNoAAADSAAAAE3EZEaz29WSAAANIAAAAQvwxhLw3TUXTnUOxQxSBwADgEKQAaAQQsmYqKtgYeFxz3JBgcPL/UvDKUyWQMoM0cssnsgOyf3VMuABq/MJMIAxNxMzvzTyObaas5bGQD9RBLMRUIk4oxGzDtCIMI1eE0IgpzBRElOINKcwWxUjCGEoMUUUUw5RBTKeCBDBIjG+E+MFQNcxQRCTTWFEMEgRc0uFxzLbHbMJAC0yoQfTGdB0MPwuAwlwzDBbDPNA8NAwBAtzEAEiMNEBkwdwtDR2EwUeAXkY8LmiChyaUYEim2PBE6mPxBoAWCi0DSS0QMGmJlAJGw6WPFBM9OB6I1zUEyBp+YhuaEQCWRx05xiJq0gWChYACBZKCNaBFmRiCYsfcQBNDQiwsVMIcDIYAWGCTmBAG9FiWALQjOkzCKUEIGaDRAZFEKkqnkQx44YF4jqELhtAYUIhzS3MOaMcJSpRDZ2IwCwIIGkRNBcxBItYGJxANAIQoIJxDgwmlFQSZhQNMkSQFZApQaaDA1gZtyoOYggwYw8VDBUUiAIoAIzaAASTgAKKkjeDhQwJI0cjdCAYIKggsGTAoAsEFkIkSd0xYQWEIB1UBUqqYLFkjRoGu9RUeAuvKEiizRhR6QbMoJWoVgwcDBgAOMLYUvGBRpCiykq1bQINMQCR7cN/l+IDFr2PppMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAACYFSCJGELAsZrawlWacGDymphHqxrqoUMYAICzmaYDAhiLwZkYGaWMmJDA+ZgRQR6ZcsLWGAUA3xgV4vAYHCGJGCTAjRhv4XWYHcA3GEXivhhRgYUYLKDcGNVBbpgpAaMYV0exGG9h2BghQDCYiSCMBgMUYKeDtGB6A4hgWocyYIUE7GA/AYphOoOgYFoBoGB5AmhudFmwWAbKiJ1FUG+mec1HxkAomATiY5BJnI/GJAuYFLRng2mFy4Z0Npq1CGigEcSUBmkkmij0Kh8xiajARDMqhoSGBnULCQmMfAYwGKjGwKBqY3Bsz5h9jDhQUUIvR0kRMENE+AyQOqD0QyYEKjxHUQxMgcExgIBK4CHCCItwzQLJjZAzGIiiIBSgCkgUKIx5iCUKBL4tyDmREUe8aUDCMaCCygDJgwwyAVOCSgwhgJBhgmGTFCCqIQuBQAs8BBQkORbAwkwQUkAFqREGYoIAifqdBcJINFNM5XSAUAADFC1ZwuYJiYKHCAGXkFAjhF2lSGHACRccAppISSEELEBUKAg6PRZBhTTWPKEu4gLMAGLpgIIvEdBN1FgDMTABwCJLQFuk0E//viZN2G/pRjxKv81aIAAA0gAAABO02REE/vOMgAADSAAAAEWgqNY2EAy4ZdEdQpjmACICBoS0pRCQlAGMDiAZjAQg5g2t0cLMMyWWjIhleQ1+cT2MDdCSDMezBswpYBCMFyOgTCdwMkwAMGyMfVGBTCNAUAwXcYCMNGAtDBbQeoxI8OiMG+AMTCgwXgwzoNoMBjCqDI6xBUwSINwMa7JcgEcgmFWh/BidwPYYFeAlGCYjVpgnwHGYOMCCmSABLRgtwISYCuGbjgGCYIWB5mDKgcZgm4BMYEAEkGBpAQBgioGqYIWAsmAqANRgYQAQZmGGISRmz4Yc0G7rRkZEey5mSmRkkofOfGRxh0VkDjg1dFN1HTHQoGLgqQgIhFTkxQOJkAycjMNITFzAwwwMpGjNj4IkTKxldRkTwMCwdVmXjRlB0hLBw4RCJjwQBlhR8qiZjpiDooxtZMXVQMVA4QDE1KRAIYmCCAQzhSbwQFiTABeCDjPQQ4IcABSdA6BgXDMNQisKMQqeAkyE0QFiM+Lmw0iisprQNVBgiH5jFpZrTIxFKS+qc4XBqNXIoEzEhw5oGihYplQs6ECoihxhcYUiGSRUYhDEZyS5UDERBkEjVANOHTjyCN4M1AwQOsMHFMoSbXYFhQaeFQzLDMxIO0LZmGWYrClw4GGJGU0LWA50O6LgDTRtzqCAcQvKESgJkwgZ1K69lRTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAABjBRgBwwEYGmNWEGLjPMgS4zWtkGM0VCYDBoglMwmYvsMBzApTCViusOImzBsAQgwzIN+MAnANTA0Qiow9QDlMCsC6TEmAJMwKUDTMIhFbzB9AQowJULZMMrE0jBhAmUw+85jMQQAozBMAY0xIQE/MD3AxzClAGkwe8FrMAKDbDEcAhcwEABjMCKA7jAhAAEwHMDfOfr82yyTWbnM2j4xeiTHSbBBCNCoc0QbDKzeMoBYwwLjGASMDj8wIDzEoRMiB0zQEjFAvMHlIwoGBYVGoCcZGChjBMDxMMAAcxyHkRjDI9BArMMlMOEBisKGPyEYQAxIMAhNtMAgbFAEIRiYLBYYLgPQApwqgUXoRHViYQQ4IYixxslRslDN8gBRKVjA6kAaYZgyJSUY6MY4imJYZAxKYZqChQwCvGOMBqEcUuEVVKgsaWeAII4wWzQcVTTua4haSqyFVyiq5woCCSVksUXysCDgjFMUFDmGupbLqFiUyBhQHPDBgKRNYUGEExz8LRRSSAMgVMlJEHDFrCYUaKR3dAHLJ7sVCoZMCi0JAmcAKkGW6XAFazICFW0xxAf/74mTYj/5SZMUT/M2wAAANIAAAATsNkxQP81aAAAA0gAAABGl05KEsDOgaFeBNOaBMSVoVOIQ38XbR6scMBKCCTAfgYk1a0NRNG7JmzQL3hgxRkE0MESCDDHIjEUwOgH2MKcI+zIqwfMwEsIzMIRCDjCcAJQwRUPNMMgAxTAPQ1IwZsI5MG1BbQoGymEWhURhcQJAZLMBEGD0ArpjaxQqY6GDDmAGBEZhqYPuYHCB7mASi6hgXgLMYGyJiGLOgrZhEoIEYTGBrGARADZgSgK+ShE1GuzswMMvC0yQ5zI46M8EY3I7jJAoNWQQysHDCojMqhAzINDQhnManky2lTI5XM+jkzCfjRRcMNCo2Kuww3mUT8a0IQ0gTKBcARhMQi0y8czk4zRI3gYX7EVgz10Mehyw2B8w5FT5lBgCKmQjGUWCNqdNGAnRlkxgBxlB6VwANQ2OgzPjkbgQOHDgyTB0ZrZnTo0PMIEKMIAJgESCjQcQEAkBDDGCTIFQVTLimOGDp9Ai2IWJg4mYooZwwEAUA5iywJBGBAmMIEgQcEhA4WdIQDgooErsBABBkiDOytUvkgMEQIMnNAMkIFAwNCgU2sIaAEzFKRyH3Q7N2TkRwU0S2AgYyxFYcGkxZ4HQWGpSqwJGiy4AlBaOZEeEchQsaQWCYKUyVppQTZEu0JhnTYGHCM+YAimQkcQhgIZRQaGiyqDVJgkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqowEAJXMAABGzUEhDYwPMCrML8fJDKIAdowTcQLNC9GADAfAR0wkoOPOBEoAx2C0jCrM9MZgjQwSF0THcGWMV0YEzqxyjFxDEMN1FQzZRLzBwF8M3U2kyVxgjS47CNhsSExQAfTTlGuMFMV8zdSqzKUEVMT0QU4KyijB7EUMOkoEOEAMTULsyBgJDARCtMc8cIweQEjB9ExMbACgwhQnTGJBjEKMMvVAwQPDBYdB1kNODcObxhUcGehkaEERmMFmK3YcAFBhArmoIcWvM+iUFR0xsCjEZPEIkMAAswWGgoBzAYCMDi4xGXxZnmBCQZmQpgUamXiEZjCxh0AGMBKYjI4JA5pgEGQgWYlNggCRgMQmIBwGBgwiAB4hGBwiYRCpgoAGSRuRHoxUZRCUTGouMzAwLhAwMRAUKC3pjIFGAwCBAMGDUlC40AAYAg4LDQVCAS0xb6NS0jC4cdtPgaAltEgQA8YAKKQwCQ4ILGQqVCRB9JZCNAQYDBBZkODgOBiCBAaDgCYIBQBAqx3AMCgxPgvqmgWnRVUuLpqcGAgMQAJAIxIGAJQR+gwfEgcFAO4I4AiIHLvAgLQkhACTxswwQhFaqCRHJnCtkkgVrAQI22HAKWAEjSgoiCIwc/4kCggQJmQLUD/++Jk8Y//ImPFA/7icgAADSAAAAE+FZcMD/M5CAAANIAAAATFTAKgDkwbEYeNtNP8TeHk7s2uS+ON5uD6DCUREc3+AV8MQ8CLzDeCiQzTEAoMNNBqjGqSLQwdIHJMFrIETEowJcw9wMNMluEgDBYAjow6kgKMagAijALwncz9MPUMUTCiDLdzPIxBQIWMGXEUDF7QlwwM8GqMaSBGTDKQPYwLoXJBStkYFYBYmA3CFRgYoHUYIOCkGJiAYhKA4mDyBM5gDAKwYF6CQmEVAWZgOACiYZQBymEyGf1shhBZGjdYfRNBwNaGd18YRAxq9IG3EWYQQIrnTpgFMPGw1hLzBwEMECs1kfzFr2NBiYx6EDXLeMAiswkRDU5EMQDUwcYDLADEYsMViARlIy2EgcejIqiJjMGFwDEwxQDDHooAyyAQ4MOkYxqXwxcmHRAYdFCQxhQIiw6ITeacFxo0aGIEqYWJBg0AGSxcYcFxiMPDSPMHiRQJRwxSCDAwbQStjRhEYMAIAQJrMU+IQ8WzBVKCgyGut+DVsC6otMX+KhAhAEni0QFqRGW8loFhU0SIY8CVOi8behzqoyiADDKzPMOhH6sYzaNKOxzkKgZuJDGCQ0VfYYcsGjuXJSuMZUVcJlwEqEFFRIObUQU1AA4GFOxuBWXsfgdnKaC1kD4NCxAOaBpAATKwGtGICAGwYKNKTdqHI1Q5DitMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAF6zAWgEwwF4HiM3iLWjJBwOkymQtmNdMCYjCIwDEzQ0dLMEZAfDAVR14zwSwDAJE2M35hUwhQ7jJyEJMx8WIwiCoDDdIFMR8OM0MzvTRYF1MM4kEyrRFDAdIXMXroUyUwdTBKP4MrYC4wLAsDMBRsMGIMoxMU6zOBC6BggIXL9MLEBEEDGmQQC+VQXjBBBXMEcCkCgQmAWCSYM4JZkChYGAFxiCMdwSGVkxpS0FFs0lTNjcTWQsx83M/JTN5U0E5AIeaqPmVjZj4AYoXA0LMxDwMPhcPMCEFmozEQCIwgyk7EiowAHR+AwYYSLmFCEuEYYp8VEkZi5BgAGTA4wAppGRCyqSWhZxUg0YuKmspoZQKtcJkQMCAERO+jasgBAiMpZ5BIu1JNNQFD5gwA04wwQQDPUWoQYLSK8Q6sXRZVTL5oBFgkvFQIoF9EUE11jK9eVQgmF3YXin0uBeksMAAAoFAoEWy5ZYATAgKAgcEOuXoSdSqbM11MdS8RgaqyZin1DwgPSbHgwwkDHgd/ENLJeMDC48Do9hYCMEBH8trxMJJzDQFIiXA0LBQmKA//viZNaM/dxmRZP+2nAAAA0gAAABPG2VEC/3VogAADSAAAAEy4DCwFJ1VGCI7D++4XrwBMDeAVDBFQIQ2JFOfMmDSljKywp035oOZMEoApTP5jR4wSAHbMJOJcjE9gXcwlkIkMNZIQDCxwqQwRsLKMPvDoDBEAn0x/EGcMGIBMzDTCccwlYN3MMXCRDFMASQwF8HCMjgJqDHywEkwQ8I+MaKCygQEymB2j4pgZoFkYQgPjmB9AuBgIQIyYHkI1GCjgTZgQAWWd8A4ZOkmYkC+ZNhcUCgCApMexFOQFhMsjHMZUUNFkLMXxKMjUbMahOLnCoyGOo3GDAgBAdGDwtGf4VGEwEmPoNDRdGFpGGPAFoWDRTmKoGg0UjBFzIBDMiwFEGnJh+h5Z5mDBsQB1Mp2XxiHoyWAD0wq4wCM0BQ0gMwyw06Myyg27U7U8DcAAxM4JLFUWog4kNDjNHRCCNSBB00LHBJOYEUATDuGBQBcaZJOaIqYAIMFxGFMFJM4QESMCOAcULimWRDQYVJAIwXHQGmfKGQGAZyFxCaQKJNOCo4zo4QCBEDHAwsWMEEEIwekJXK2taFACbDXx5eh0RCGiLA0lx5Eq0MTDQAHDlYUAxaVmaA1xy4IiGBcevokEgooqMvMGGVHE9CEACihEAKAjXQEwDCTHESBwGHEzRDhgwgJTETxRuJBhihY8GXOig9DnS3KqyqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAZhGAeGBnBZpnyR18Z7QCLGfimd5rnwImYSuICGJkl+5WBjmCMi8hgc4JAYDkC/mFMjDZghQLkYDMDFGCVgyJgPgUIYQoHzGCgAD5g4wJUYTaDhmBjA9BhrgTGYP8DyGGunVRhcgToYN8DYmFlBb5gHwDAYVoEWGEmgcwFC/THGgrowSIBcMHZBBTA4gI4wF8DyPXHIx60zO7oMuAgyGozIR8FAIZjA5oU1meC8amDhoc2mQnIYPGZj0hmFR4YRSZQUTLovMKIAiayAs1wCDHYpMjgo1cMzJAWDIiEBIWBg9pFmZjUARNQwAg01C5PtmAECAZWHXy/IQ4NsvLasgMMDCoECFCkMnsYRgZBQX8BWYBTFUAdnM8FbKYIYFGwABmVTmaGICDTkzLHAEhAwgWkmJDJKhxwwYAu+DhpgFQhJSIwas4hsxqIuWZhGZVABQhiUpv1YiNwcEEzEgQcHRZABg4qkhJm2AmiEjIFvlipaBjZJ4qBRZEYRYXRZMSBAU/QkMlSJLrjoR00BZKEHhUPAkOYsCwKqxUwoBLAEiSIhTLGISpNIFAIqMBxkyhhekfAptJFOQBAjBFUJDxhYWxBh6NRe8Rm3sEJImP/74mTmDv6JY8UT/NWiAAANIAAAAT2djwoP91aIAAA0gAAABFRxnc+BmCxgFxhFQTgbFSuimfQszJsfNM+cxgHGmE8iLZk2q00Yj6FPmABjFxjdACQYLACBGR/EyBhqgYIYGaEYGGPA65h5IsuYsIIImCLBXBguZbgCQGgxK8JuMsXDITBZgmwy6cYTM5uBqTCsRc8zA8KxMBDDnDFRSHowg4B7MDMC3DNehAkwqICJMHaFwTDAwqUwhgH2M3igMMTAM+afNPx5NKSONPj6MfiAMjixNDC2M9mkM4CWMZTxAjCmMoFGMSAmRRcGFZxGHhSGLgpGRCZGO4xGJYcGk4cmRZMmECNmYA+GC4ZAo3xYUDEsezIbDu3AAOA4I5mY0oA37sHDwvFM5IMoPNoQTjAM4DdDBgzWqzLwTUgwE+NPWMAGek0DBupzi5hXJ1YoIpmruCIUZLMZ0QBUB1IwAPF2TDCjUijRBxAMMgCB0kzTQ3xUcYAZeZ0KaMKJGjDBRQIZNgIC5fwRHyqYMmGMWUAQQiSkgpCIGijYgzLIjEhx4CIxSNIYQCjM0K8wJ80A4s6ra8ZmhaQkDAJE00aDAAwUKRJEQhTKBgQCNMGNkQS7MKDStDAAFPpXP+Fgo8BFiSfym7ZEEaZAoBEkZiBpgxAYUXIYNgPAH8RICocKAjUrEmh0IFApEdMWCElhEabQDP5O8rzh/UxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpAgAAAAIYAyTBjQjozVBM0M1XF4TErpHs04gFoMHaFWjNvDU0wWkHAMGfBtDDQgoUwCcELMZFG5zAMQRYwFgJuMBoCxDCQg14xMUDAMD+AhDBSxEYxAQGkMFvC0TBvxZYwJEI1MHJTyzBjAScwaIRUMQPEmDAvgBQwpsTRMJsBLTAyxBAxbkMtMEtBkjB8hAAwbsEmAwFUe9LBC+DSiuMIk44wXjWCMMGJAybBjFTBMRxYxsXDLBqMsRwOXpiAjGeiIZpBxgsbmDggFVIYoERcUQnoxoHTOBvMpAQxgSDIROHA+DhaDjhiNcgjANhc1xBa0tAZSJsJg5UvkGAAJMzYE0zYARwNxszcTAbOEcXCBma7jlWBzxaMzmzQ5EVZktGIOVWQIUcKx2mq+a8tAIMMUAWlQBgOpHMxSDFLHUStpSoLhlrgx6CRwEa0BBDOREfLh26OIhGSkVulszBGNkMHFkQYGIBpz6D0CxQ4Nai9WGFqGCLsMAFRdGBORLlMRUg2CrAr5E2w0UFGjwpgnhD6L0RWCeVXhiFiXatxoIjQIOdCHEGA4QTdAySB4GLA85mDjyBwCG8qIU2MBQxRgAomyE3/++Jk4Qb+QGTES/zNogAADSAAAAE9cZUKD/dWgAAANIAAAARgHJxbVlkwM0IlMB5D1DNq4eE2rAH2NmW7zzHnCQ0wWcL/NhzNTjBAga0wvEYDMc0CejAtwKQxy4tUMKfCeDCUwkIwRUNPMN5FIzGwgt4wpEEGMMDD0TD4g2gwBkD+Mr4C8zCUQZ0x7o9hM4PElzA0gOgy9gM6MEiBxTAnCG0wwsDQMJXCrTOHQdIwcsGOMORBdjCmAYcoCJz+VvjHVEjZ9lgCB5oST5iMRACMgwTdcz1SI0FWIJI8xCNwzBNMwWC0wgJM1sCQyOJ0wgKASO4xdPAwKGEwwGIwFUEwIEMxTSMw0FswKEAxHB0kEcwFA08n8x8w0BMSAGBhggQbEkcEQaxOAgIQ5Ny8YCBBhhmhgdpwJIN7jSQz4cx6Q141rxvrpmiRpZJuBo0EMrMDKIEUAfEaIudTuQJTPJTVRDSjDCwDHjjFljwjBCtMsLMMHMmfMWDeIFsnhA0AAhhAVATJrBKmMEBNQEVQHEwEGAgSYAklUYoiwIhNg0cYYgOlDIqEmzDkjEj4dEjRkhJiVEDDBk1AgyAAHBhpOCADN0gDHojPn2HGeLgAWDQqsCqJf81JkMUmILg5IZdmABRnBiqyNaaYZmDERnACJoVQGqHEwEIGIahdOAQsrBJAIDMuWkmqASTC04xGCHSJVEsJaxbzt8pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjBDwIgwPcAmMhAf/DEVRLkzDjdFNJzH1zBygjk1ZgRvMOAB5jCmRqswUIIDMBvAwzFQy3cwm0EuMNLBnDD2AjEw+oMaMHpEhzBDQIswWkgzMHgBLTCbAvIxvUTTMLhDcjGqj7Ayz0M6MDHCBTCCAxkwQ4EuML4EOjB/wdIwIIWRMbQGQjApAXUwR0YtMCaBAjA7gzUdfYyNQgyaf0yWH4wYVwyPAMzAFU0KNE0+DI0AOM41KgxnGw00UkyFAM0FMYzgJUgA8yqM8mGIwYNQybHkaIU00JISbMw/J8MeExGEAx8JgZCEwCB0W0GNCGBDGiXmRqmKomFDmvzGMchcKbqMac6YxWYAEZIMNHDjlgxEb5CbUAbHEOkzZKTfNzkCDNwjWrTEGTcIjJiDhlAwKORzlRQzYGBzQPwoNAIQv0LAzOjACnNOVN6mBgU1ZMFMgICIQZhkpkDJgECc5ICMO2V2Bh5CEEKwoYkogw4IzBcQliUIChAGTmMHg1+LaBAaBJcFHQQYMaCSZLlGGDhQETThZYWhMucRVCA9smOhg1MJh5gwiWyvDCDBo8TOQqLAoI0ZIBCTEpjRlQIBZWW8VmNOABzFR8MPOCaIsGGFVgoHUHARcHORAekC//vgZOyP/1ZjwwP91aIAAA0gAAABO+WPDg/3VogAADSAAAAEfZIBAA8VALZWESNGhSQzCb0UwB0CFC4DwYoCymmgwmChjPdWCbTiEkmBFhbBoP4d2YHyCJGFJjc5hq4FGYIoDtmBSjzBgDoCKYTiEKmELBXhh5YGsYe6HoGAcgxhgTgxWYZCDHmDkBcZh0omUYS6HSGFGpfhg0AUcYC4AzmRDgUpg8oQ0YCgLKGDEAEBgsAbIZkUEqmAiAH5huwO0YQOETmCUgTB0Yixj6UxtkThoSRYOTw0JIkohEwGQA0TGAy3Vc0BHYxGM0ylbgyKGUxMSwxSF8wrAgwNKRYEQi0Z+jGYMDGaMlKYiBsYWjKaYF0YChSZolCIQTMIhLMYUEFE4YcXHm/KmqXApCbaKBvQCGh8I2BI06gbMm6LmbTA8YZJAZo2QvBCvLhGlbmDlghoaUoZwIxFo5aEemNfBrI1BE3aaHxUCcIUZlMHCTEAizgFCGRCLmMyUNCTMoKJSQEKHRLAJgZtQaAAaUwCgIFNmFYmNBEoMuWZ0UZA+gqCBJgBQOamUBAgmgMRMVsMELDgY0VTSKxkLKgAKoRCcQUMIiKqAiKAYEmGquRQi3pgRLV0UV0mUDiolmpUKkQJlT8IFARwFAKizSSoLFlQGXpXBC4YCmvDmGApnyEVAiEQuoLlnVYuhMjb8wCQgisWyrThXktMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWgAgAAAAJuTGVoMYYQhEJh2QjGjwOEZs9Z57JhVmHAMWaYhbBgSBUGBcO+aJo2YFEkbjP6GGyY8nKYbgCaXGObxEAYBD0ZMGgaelCYnBWdYFqZWFUdjtAfRFKY3tkaVK8QiQbAriZjE+ZNu8bhsuYjgcZitYYTFAYxFkGO4YSh2YPhsYhAMYKgKYehCYRAiYeiqEIDfuzPADRNTY7TMjTUUDCGh5eZMyBgxhQxvQZgDB2IiJJkm5uDxQKMYihm8IDzzES4LnxCZXkosA0aQysQGFDyoxwoIeGJUgEuZEQu4SGAw4I2xrFJw1pQoNWXCqwtCyRarBgUmLB4yAkHUDAKVbxECAShxzIDggwYAQk4LEjMAh5SYE+4ZsBIcCMILGhiBwoVMgoJgxkaIUBggMASIYXM0OJVIGFGEVAQImWIxSYIqEDqIQEMcoWcAgZfZMUyghKAwBcxxEKDAgWQngQQDBYGKt2DBogDF6RY0BAbhIngIU9wNPgkCnk1YMKjIgx4I5r1f48RMCfMkHJRxwHBKwAq//viZMmE/atkR+vd0nAAAA0gAAABOeGNEA/zVoAAADSAAAAEUWkg5QOHTHng66JHAaKFgQiNgpJAj9tEC6AyIxElxIpb5SYEcC6GCDA5RiZCQ+YkgTJmCPmUZ0AohaYRYIjGLrlrpgh4OUYJcBtGKKgVBhBYFwYl6FSGDIgkZgu4SyYBUBBmFPhjRhH4KmYMoCtGE5j9hgyAIIBQxIKA+5gPgJ6YKSjRmFFhQ5gsAV4ZFUEHGDZgv5iKwiWYPODMmAVgvhlmoF+YLeBJmCbiOJgT4I+Iwfg2c+jIp7Nxbc0kzwahTRZnMrB83IgDI5dC23NNLkIUhieXGRkQZ7fhlo1GNB6I1glyYVaAJA5aoweizQItMZVEw2nTApDMvCNJYYMY1aOp5NdIPwnMHYOWRMg3DOIk1MgsMCNMmIAKkzdQ2QIKBTEgDRnATQAJsAhypBMgeNcUMo3BF5NQxIVxSy5hCphiBIPERU15wwBs0bJjpwnBnEoJZGJQKYByELBTMFTCtzALQxWaMoAkiQ6MwiKmXPgpmYakYscXEFR4OLEqw1IoZAB00mSBcEYAyWoMeIUxAUIOUjpEw6hUoJDmSFgoeBgkHIJDDAiz4XCAIAPI0AzPxGXFgQhLFoQwsowyFOYtKEOG2LcCRKYWOYgQ0YgTF2GYjRNQsADHGSSGlxEAMgBd0WAO+5yQjKaech5SpxIZhuVqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoATALwV0wGEDVMnnUGjJvw7cyEweYOkBAlTAvQlkwTcq8MBVA2DBlBLIwc8F8MDAA4TB1JqMQkZMxCwHzIhJcMZ4iEzwSajF4DIMeFDo0pATzINEnNm0lQwsQyzaAC7OgEVExsSbzMILPMNML0yBGpjDJHIMJs6k3MzqjEbEFMcAawyHQijD5CPMukPUEAQGDGOQYI4MRgQhVmASCWYHwKphGgvmDmDUYWgrphqAKgIHMwQhUzBMCHMAENIrDIMBID4wJAvRZLM6pjYTULCRlfoFSA87hI7s1YNNRMhIjNBHxabMmbDEjkywjMjgjXQ0LhJzRSIBgwJOMWCTDyEMOjGg0AiRkRwFAkzcMMJDkogxLMsHjGAYBEI4AGBioMCEBJnQmYOKggPZOYkOmBnpkxuZEPFkDKg0KEQKCDCRNp5dVdhgpUHH5MhAJGAxeTEphQmGE5jIkTFAGRQCEKImKCaMBjAKYcCotAItMpCwunmNACrQaDA0mQrMCERAODRkZUOEoMhPAImtIChIFCjFBIwYZMJCw4EBAWjyKgq4lNi9oMAA48MyBnoQubwVHA4UMDBwUJrIMEJmbx94ISYaDGXiKD4kYOonql+YACkRgBAP/74mToBv9fY8QL/tryAAANIAAAATqtkRKv8zjAAAA0gAAABMwwRBgUnYyl6igKWoKASgIoCAQMUrSIVyq7HTUADBKgccwIsE5MlUR8TFOBKwzBxL4OH5CGDAqgbcxbwkPMDFASDBshlowr0CHMByBDjD0Au0wIECDMH2AczCXQF8wCcHKMTMA2TAjgQAwlURHMOQBkjAfAlExTYFoMC4DSDDPD/www8KgMIoBSTFzQN0EgHRgpIbcYRgA3GCGB55jkwUkYCkAumCSiYBgLgBqYA0DLmGggohgA4B6YDWCfg4D1GQDEwBAAaHgDkwKABvMHDUxAcz6AQCgSNEUIx6WDFj6MXikxMBjMTIGQkYgQRiMRGBAiBXyZCCJk9+mUy8BRqagK5gkEkxDMjksxmNzGomMTgkhFRj8OBUPmgwUmgvYaEJMADJQKMLBAeBRjIBiIJDRYKCWQEpuj2CILjQcgowcDDAYlIgMhzMOjMaAyAImALnGokKsHg41AUIK0DTEThUsRwSuElDWtGIAg8sJHWULLh44KPMEtbZghGC6IQSwyKKgpcAJA0QhsTBL4F0ARARLgwILgLHNAoAAu4YyqoL6cCZCVZgLF8zZGWk08wwHcFE2CJXgYZ2WlugODhys2CgFAwq8Y4bF1MyYVB55odV0vR32eIhhAKAJT6UAMEJiFB0JazUI1hQoEZCJAZGWGNfluqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAACMAbAzTBNwasy4c+OMTwE0jLwoUo2DMeoMFoB6TLNxxYwbkAtMH1EcDDOgHQwI0GBMZ9CDzBaQCUwNAH4AQMsYMYDUGAOgLxgYYR0YYwJqmAJAZpgQQaYYtIAEGBKiEZmM4LiYFODfmDkDWxhu4DmYHiFaGFfBSZg0AN+YUOAsGMQB9Jg5gMoYIMFzmDjADxgbQIGaLWBjlOhJQMggcOFhjYGGXDcalJBng+GY7WbIbINNhkQ/mWieY7OBl0jGBCCZaH44Kzcq4M6m428mDMqkNKisw8KguMiEQGPwgKKUwaADP3DxFTlWyqKNshOPyOIDNcLFqRVHmECigow6Y0xQFOTwPjEARReADQ0uMKVQyMUqTHHRQsEGCxuzIsFMOcHq4AXCEKKAAEIMCPAUcxQ5SA0PfVOJ5B0ULIwMfITQcGCwMcBGcBCoEibiMEBRCzlLQcAHgRmQwyDMETZQVAAoHZWuMwIUlNmEBpBBxGItMa61BMB6k/k8gCJNKWNGHelACWgU3TULdhUSXTEYJuzJ7I4LMWCVCCBKt5gQ4IGCM2Dm4w/N4EFBMHF3zNBQwwYYaZ8KEakmzHlUIS0j/++Jk347+7WXEk/zVpAAADSAAAAE6aY8MD+9WgAAANIAAAARs3wPWIqFVqNWBb6rwwA8DeTCqjOlx4IY8IzWjl9/Rg/4F+YC8H1GzAICpj05DEZ9foWGFADMhg2wv2aCcI/GA+AhhimZs2YDmA9GC7jGJh04VAYJaIGmIKhQBg4wBSYIuJ9GEQA/BgGIEkY4KE4GECg2ZibYtmYpUGxmICnOZgHoQAYIOEjmOzkSZiZ4GAYd4NLGDdgdRhwASgY9cKlmIZA45g5AvAYYCBSGBbACxhOoBEZGPpfHyUplSSYI2HJ5BLoHBhJxNQdm9Gwiplgyb4LmfGJhokau3G/tgCTAK0G9h5jB4ZWsmDJJuEyYYEmUvAZAkQ6BBwGDxiaAdnM8KOBJLeEqwwRMx4kwg0xRQ4NI4pYyL00R84YoKiSgcCCJzqZgVBo2BVWCo404Ax5hA4DbjbFzMQRkAHXzPyk7gocBzAxNQ26UdBLJHBJjQJlU6hgiFGpImqNGRAmMQmFBgQEZYaVQIsLLhGAMA5OhcFlJjjadazWrRZGYyQpkg40MqIMgmDFjtFxWCMsFlSZQhYmQAEAFNYwgQwJ0cOLHTlGSQ8LEJowiUwpGDh5ivMIBoDAUFMANVwvpiZmjJli5EVDgwVMmqBLEQIlA5TwwKUOCwlE9AAqN81/CVYIClqzBkRY0accDgsTWcDCwk+WCh7FdMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEwu8ARDBPo5pUTUMQtAZjlE2sc01oGhMNtDZjRtBdcw3oAtMbmJIDVtIKNAxLc1MwzzEUV3NnYrEwGhzDM4UdMkoWo0WhejOXEDMeWSkxJBxjBIMMP4gCQw4ygjZQDDODEpow1EADJ4OzMdQKI0bxEDAXDXMJdQ42cDcTJSNqMswzkx0wrjC2BmMJEKAwNBSzAwATMDAA4wFQXTC6AuIgiCXmd9GaSyaZaZWGcMEBkZhQ5jihsUwgPP8akSCSAS/GoZhlQEHA0uFzZhLxoUBwVJigIHlHFTKFqZmiSFAEyAMqjSJCPSgafJTYsLLuLfXeZIeYQGFQZA2CoZXRimYoLMiPDCBeADFRlAZACGkCBCIiIBHmpbK2AgUGFjGKTXvBGBgYkEgrKPIGzjBcxiNHF40UzMBQjAZMoI1pjBhhxpZYaACwd9BgUZw2giCBoEFmINmpgBBMLCBIwIDQGVDA8wI4sBRIwZ0AY8gZISNIggi+AgKoCDHigcmMaaFm6Mhc1EMhBgQKZgKGZyUQXIU6MSPNScNIRN6qMGOWsA//viZM8M/lhkwgv+0nAAAA0gAAABOIWPDE/7ScAAADSAAAAEhqCyThnT4YaJBJm0ZhA4YFUpTfMwYX+UBDDjw4M1xJEviIhxnRwYSf2kwv4rANQjCVQeowSQhrM7kHtjFHBw02bhRBMJFA8zCQwhAywQGJMIbC3zJ7gqkyfR4jQVa2MJ0QYwuXSzHoDHMIYq40HQvQCAqayoTxg4h4mZIx+YkgXpqZQpGwoDuYYpspyPnSGWKVkZcpuRkCiVGIWYuYn4XRhXDaGS4jKZDQjZkmhoGDcAcYhIhhgsAqGAqGSYA4QhgSAIAwDUSAxMAkDIwLwWgFBPOKMSNEmwGBEAcxIIIXEikGFB5KISpQyGoDsAAw6g90ToGnJoQQObHvyG1CGmIHUUAAUbd+BphlLRb0OOGFZDzJBc6ZQMaBwtJNA1AAOBQFWMifSaNEMAB4x5YRAHkAJARMTIATGCSsAYxSaQkbSadoaZQOgIM+CIBjLkEgQVMgNBiMHEQoDMMWIkBYODLUQCGghUAIiiH4KAxdIlJkSGtf6VQJYBihclFmRHChG0qxWUxQQODl1ghApuDjRaMUAowlqYJIBSRQVAhQsY0iNcRQEQlh40hQIRoFBA0OZIYBhQKGkB4kDFyjAABAbMMLInSlhmSoYgMwSUAMkUBToyJgzYkIrAQIZ1IlcIih5zpgh5hW4cFLlq5ARIs48lexUqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowTCgRDMwqAZSNZUEbzEAQIc33uASMLxBazGDUv8xawdpMBuJKzIWAE8wW0KeMe8C/zAOwZgxYIMWMGJBQjCIBcwwokIWMCSFpDEHwRswDMK9MgRDhDD6wNQyZEfLMLuDCjBTAN8xX8HoMDqE8jDdgdMwNwK7MFDAyDBdgJ8wdEIMMIjA7TCJxYMwlACXMDtARTAyAH0x1cP6GD/wgQCho5kaMag4hElUxMkOBGzBE8IxjRiMxIYC5WEYpiAkPDIXTiXgVBmRKInG/zmxAgKeBrwPBnJdhZ2bK6meZwQYBCKnBlgF2JMDMsFMuLChhCaY0UmmYgOYUWlIOpgoiJQqSgkcM2lNXZBIsxBQEO0gx1CSDzYQgu7HhA0tMSaPeONmKBBcDWjP00AAhGjKIGPRImUFZweYmBkBhYwIgyhARCAxCW3AxYCjTAMQggTe1KioTAgACkhgWZIKl2YMgMkSiCiiYtAaQ2DhIFKmIkJBmDSmSIAE4YgCYAUFTqMoAKGQGrbYgZ4OCkxgmoBDCAokCIgZMEMAVB//74mTLjP7OY0GL+9WSAAANIAAAATXhjw5P+0fAAAA0gAAABCEZuBBM0I8wYEx5deQOYBbiA3IkHFrZtwQGqhdGasaaEMzEx24aZmTJjAMwiYCjTGEzdFh0Wn2maBixgR6K8FKWElwbVIwnsghMkLIgjOOlDgz7oDBNMWJ5zGoAIcyC4Y0MIABKTGBLHM2AZ8ycRJjIEHaMz4o4xaRZzCsFQMo8QUxQB9zQxGxMOMKEyHCdTBAEzMo9Fkxiw7DDkLBNcFGwyMQxjHbHiMHwCcw4hlzC8DZMXUWcxKgQjC3FBMPALEGDGmI2F4NAem9bmLDmrHGoZgQIbDmTDDaVzRBSOGa16Z0Ya0CaCMZUkQkTRpjAgzvGBQ2GBGFm/DiF6AzhviBhyxhRQCLGUCmU8AMMa0YDDJniYwWM8aKosIgnqRCpo5pIvuYw4a8casQlbYBhYMOCAIAkxiEZiTiGAOSFpE4mSFsQuCWe4ZmCEBgYAYUmNIjatRq024BANwQqNAIakyxL5SoHJjJAStwYceLJ0/QcGBpMtuDBCE93gKPThAJhgREtXmXdZczUIOsbDDQMDkiEmKmiEA0rKTDgS5QACJ6Lxa4BjLbtRFSzitwQFIymRGsHYaykaAhQSBjT9l71Aki13V0Th0GFRZhhqWBa0xCUYAseDEwAhGePGMHGqEoDDDiDRBRYmhekkKEwSGWg9cntIkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjCIV2c1hCrUNlX4mzQ6B64yvQBlMFnD2DEpA+o19c+KMX9HQjAjgeEwpgKqMFmEnDCGQvMwl0CoMKxCyTCfwuowbgLjMWSCwjBjwWcwV8QOMCzA7zBBwO4wcsBhMGICJzDwwc4wLgFhOnI08kUjOcdPBzEyRBjaCAODO81SYDlXzN1H8GPY86pjEahRUNOi0y4JzCgkMpgcyUIRUtmQReApmOCMxIXDCZ6MmJUw4IDC4bGAICEhxgIlGRlMQBNjEDEoQcAUJIwqBAuPNmHa0AmzwGEBAIKYYIOjE6w8eCBLNEChCuBQg1M0z6UBPDikjGgSE0GUzCFwoYU4DBwWFmqPApeaEGbB2JeoSu0zJEzBEyY4cFk1kzJYIFiXAygkLjgAdcNQJIFX4GIGFUESAEWjIFiJoLEy4AKHgQUGSRCBMCMDA4GXiFA0kZAmLMhVBDxgyJhjw8mCwYUXmoImURGyCmSNGUECScSMmNKm7Bp/CgJPaECNA65gQYsjMsNMIgAJZr7qlQYkgaciCiJtxZChKgQu40X/++Jkyw/+O2NCA/zUsAAADSAAAAE4EY0ID/dPSAAANIAAAARnZAHUyKgQBMzNBF/jzwIPjQABAkuAQPMueKoAxJcRpRZqycSUv+DSaOTUIyaN/t/9xinQzofjoZ7mKAXNhhbEZoYIKV7mCTDnxgWwCmaYMPjmCLDcJgl4ZUYYeDNmBHBFZkOpXMYcwAPGDjg7piD4NcYdSAXmAMh9phHNhmIBRmhdx36FpjUWB1eiJxWQJwq1BkKmZtSZhiapxrcnRkYJIMN00XMoxPPAwwOow8IwxpDkyVJoxRCgwRBcyNG4wEEcxWDMwoHUwDHQxyFUiFIwrAYwJBIDIGYMkGYEAaChhMAwIMCAPPABGkBuSJqUBsUQiKA5sAjpWzASs0cE5gdAKDSM2YdYa8YIiwO/BUOFi5hlYJXjLMibhcgIxprDpkWEAggcFjpKIMYbCiAGGzHG04AU+AzYxJAIQhEUzaUcGqcAQCXINJNcIKgRgCOiQEtErQGFIJQqBNCUMUcFjZMfLdyUFTF+LUSfIIw4KBRgRijCEURmihYQXIDl4BLhB4vyAoAMIgUog4YgWhiVhAKWJpyA1J8WNGAWCIAZAMYofNmJcmMGGDcmyBkp9LMG1iQGCU7AQsCHQCNCIBEIFhoQMAAMEJRJCOjhUaoCMmjDgGUBZwkSYMCIhErIQS/iEq3Z5y8xKKGggsULnoAgxPLbyq1MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVFkwr90eNHxaQzDc7aMzQE0ePC7RlzFrwkQyKUF+NRxF9zCjAfIw9EA/MKRDDjA1wiQzCxf7MalB1zBgADMwboDYMMRBxzDjQVAwVEDDMKJBZzCDRv4xg0ChMFTBJjCswScwQcITMHTANjMJMNZvwzVfj9TdMXIcyqwR8CGfbGF2WbRNocFzJqICxWNPCIx2BDB5FMVjUxgSSQamC3IZtPRgg+GBjoYuXxjQnGCBcTJUykCzEIxOFLBK1rprZRz+BcQ3SY0BwIRCECFrplWo8aMOzAy0iCjSQzIo45swo0MzDCMlJJiB2I2CI14ww/wRgTSijNizANThzTAsAMMEmZjWqAEOsmILLNNgLMUWBIMADTAmDYHQqqNRKAIoy0c0pkGETWHE0jNLDDgBUKBCYAYGnRBLs0K8SEhw0uQuQMaiIUBkZkiRCNUWDAJIHTmMIGBxYAIzUDCJeWxHCA6RETARCgI6GABgmpAbMEiNKRCwELgwoZa6ZNil8NBDlqwaFMIjLog0CKCzIAzQhrCQhmSqPAEDl5gVPAJUmVFoyU4AxggEm9ElBklDGHHmnGG2TGNLq6KDQQXQc//viZNyM/pxkwgv81LAAAA0gAAABOtWNCA/3UUAAADSAAAAEAw0LjS1gMSBho0iEADBIaZgSZQ8yh8+VLP6jIfQsI+RcsWM/zszDCkYZ88+UuyMi3DizB/wBUz5QfSMSMFxDA/hLQxCQWJME4C/DLvWowwi0IfMVcDSzEAw9MwNkGmMNcENTA8ghkwpMLEMD6H2jD1QEA5KNY13fU2KLIwohcxTTw0gHIzAOg9bD0EisaFgoYOD0b3iKZmmcZDF+ZhEyZGDgZCEeZPisYpBqZVhkY/FAYKh6YejUZEJwYkh2ECSY5AsZUgiYgB8Y4gcYeDUEFsYOBWYmDEYjC6YdisHLSYNBYFAfFAOMWgcMIAiMGxHMLBUU7FGBvGpvxJmDx1zpiR5kYAyLMQNDRJqxRhFpiT5ukZinA0vMEDDywNEGBEmfFG0Bi2sOfgA8gOHZBhi6ti3zWmiqBpzNvgYIAyoUTiy4xio1ok1IowAsLp2vhEYRAkiBaqLPgqaNGXAQYxIAFEyyQkfVcZAGOMCAmZ4yQhASBM4AAogWPjBMIWtoJQwuQHgQYRNW5MZBLoGLDIrmbRhKIwolQMwQUQhSwCaGYUiIEBgxqixgxIjKl2THAjLETACESSyY00VUZqYQGIhghMongFkEAm4hxswIVAACkbCmyjTZAeW1ZOWtd0iIEyRHYEEywRLzF/ihuY8SnzLFHvWqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEBzFVFqkyFpXMMwklnzJ6GoMzf49IMFOGUzIehnYzdcr9MMZDvzBiAZcxD0C4MBqAxTJ4lVUwNQNaMMMCzjCJwNUwMEEgMB9AzjARwGowAYCAMARHqjDzAUYxVSIw9bMzFHswSGYxeBs0wVMweE84xRAzQEkyHFgy3Ec0KKQwiKcywH8wdI8waGswZEYxgNMw1DAw3AcxOFkwUBswXBIwIRYyxBAxeCkwrBISKAQDEYkgoYFguYThIEAyc2aKoQEEM/zPw1MSASkMi2OIsNyaOjGAKQaZm4ABDQGwUkCgyZYsChxoDxp4xszBj3BhwJrhpmxbtgJis4CjzFBVVhosZC2XxEY4QhVhgYhErIWAgb9aCyQHMkdhR+YYOrYBGgoIJiyCAwwALiTBhmTKUCM4BiIBXCAKIg4IBCAY3xjg4KVghqENTBkCIwJC3dVQSTMShLgg0uAQZQvZUBhRhSxf0gDBgkgRg4+MkAcyMOON2FWKIgAkTLchB0MsGJSmIAga6CqZhmCRBiRQUGG4YGPApwBBJJFrhADVqMSXOkYJDxlwpmCP/74mTSjP6zZsKT/dRAAAANIAAAATgBmQgP8zNAAAA0gAAABBigBhRRiCKdkLM2FMASFooQsMINBq0EEjawTJKBYSA34MSGF2BJUFSEaZzKVxOpT29GIiBFp8XxQmadjbXGGwFIx9ugw8YnoCOmMyDm5lpxwUYSiBGGIgA5hiEwhMYOoBXGRHs6xhzYIYYToEcmCbAPZhOgQaYIKF1GBchHpgswAoYUONmGKiAPJgnwHMYScBlmBmAXZgcQIUZSeh0OMGFECcUYJmZJGUxiZEZBuKKGOVEZYYBlcWGQyiY7HZiYwGIzYZtF5g4NGBxcLDQyezDoZ/BSqLAaMCAswARDEoPMDC4xEFjGY1MgggmIRiMEhUUgIPjojLpgIfmURWDQ6u4oCYGARVAzJxECQIBDBYIBQBb4x6JSUemPg6OhMYEZkUOjQKA9I00cgw1fIWFR6L2HJ874q6KoDLgRwBRx4ct2RRA24wjjgEOkUjvM44BJGMUywxmiJkHMLSDnBCcZLICADqYwmWY8DDhEMlYMTt4SpoSU9lVTTNBSgEMMZgYAQ1Az77AANKksMB7486bKwO4CEhgBAwKrE17WxCyCsTBLCySxnOAAgZMIgTdlK1WvAU0VMLqG+aNEILogI2ISTtBaGJROStAIGNQMwCAMYnmSDCxEWAIQOfco3gRKUQBFVBL0gQEnCQF05cw+VwVBTEO9VUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUEA9mEcs+hjnSrmcGtZamEYthx34yUyYOARfGGjDh5j0p/eYLoEIGDvg1Bh+4DSYGgCymEWKiZhQQA0YMCH+GBNg8xgbwYcYOAAcmFHBTphOgJCYJIE2GQsAUBmXCB6cUpo+4pxHHZjquh0YaZmes5oQKhhYZZq2GBsMJ5jaD5hMuhqMVwcyhjUQQFLcwQB8wUBsx2GoGiqYjC2YjDaYEmIYhgsiYABHAgYiMeQcKBhgHpikCYMAo2Z4QnQ7cTRDC4zKPDpKRA/O20KFBpQRxyJiRo0IHRIEDj3A2J5MQIJiIsDupq5Zi0ymYWbBV8aUYakKDa4ANEMwwNM2cgySc2ektmY0kbE2dNGYG0YsOQEDWnjDtzCmQYDOyLMJiMcHM+mByQ1iFIYoUiFEnUYsiCiw8jMSJaaYYwac+aV2ZCIFBpMHASVgqY6m48QApMQLS2RglbXDDoTHGDKGS0plyYwHJQgiPG0EmZQF7BmAMjTDlDMuTJGxGTBU4cekpIxgc1JcvaFwYceAy5oRmlQcbdgzC4xoAxa4HIEFigqLHwEQEZUzxBY4qFEJgw5QyBI1n/++Bk2AT++2ZBq/3UQAAADSAAAAE4LZkPL/dNgAAANIAAAARQ3ioBEgcNBxkDPAGMHTxbQhQGeDJEGAAChYqFQoqBg4wyx8S07eRZMFpdNIP//cAGDLLGIPgQxxxo0EaUixMGFzHWhvFZqaYmuEQGRKhnJgb5fEYSCHUmBRgiJgmINEYGQFkGJrFvwMBtjAIAVVnZk4X5qKR5nqwhhuRB0/x59sMJkaOpz4NhkDLpnCDRneXZt0BxgslpmiLgCEczHHww7Dk1JJsyTCYzHHkeTkyvGkxBFsEA2YdiuIQUMSgmMDx3FA+MG0kMWSDMGw9EABGJAQiMFRGBwXCMwLCgFEmZOQACoRjNdqCDBkTJZR0XaB2MvmKmgYIMEqIDS7wIUKNphEaCYtKVBoGlkx01Msi6GPNAFMYUSNBkRQYGEEAMAgZ2YASBlYsNBAIRHYdKkwHJXdMERNYGBgYzS81qIYTgomGKR1cSGjADR7yPAgwiYpAgMGkQGFmOQGTAGLXkAAQljBlV8IWI4GHQp+gRAIAxohBVJhCUzxYGHQFDQUEiUFoCDGCVPgAmlvJW4pWmuFEoUx5kw6UMHjRYGpEBKi6i4NBpbSQxpMwAQtENCkKIILloYi0eG0bzGIBECHAKlpVDpUjAkzhQ3AQRFAg6xtlhAgCoARBDCiDBnDKGjKF0AYgRAZsBlpUFqHrSkUah6Ou7ZUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTCVlIEyaFW2N+oc2zCiyQ4+h0rmMajHeTJFwoQyMYwHMHnBFzBGAKUw0oHhMC/BPTNsTrUwUkHvMACAMgwNMMGKAcTBJACswUcIPMCaBczCzSP8wkoF1MEdC8TDogTMwBsUxMV3AXDBvQR8wvYBeMABA/zADAHwwNAC8M0EA1ClD+SgMyV89HpjSL4PzBQxOQDTAuC4UNGG4ysJwITDAwVMUPww6RjUgoAIfMSDMx6DYHMDgAwcBwYRRo60sxDUQIzIDyy4AEGcyGaJjWMQgwsKCgE1AtK8oVjIo5B1uJpR46LARkwJ01oyyYA+AABKchoQGTJkhKMAS5j0oUAhF4eYBYWYc2HICEoaNkicNIQhEFSwJFA0ucIYl4ATgqMMkEJn4hDmMAgwEzsBFygGZYksGaELHRwKXjCwiGhoWOCENwYRQTRcSAP68A8JJRYGUhxUzIUrEBg4eWBk+lSxL9EihH1MIsCR0CLUxgsZZmnAYYuQinOM4ELrrWQaNMuX0JDGDMkWIYAMFxIYMW2qYQughvEFCRUKmSLAy+AQFFD/++Jkz479/WRCg/zVIAAADSAAAAE6KZEMT/dUgAAANIAAAATiSCmIQJQRFDYwplRkeWF1BaqjUMjh0Gher1jyo5+631iEYmQS9nOAHYRq/ax0Yx+tmmQXo4RgWY7uZfYLvGVHj8hiFQpwYUeC2mLwihZgt4NaZ6wVFGCmhFpidYDWYN6BjmG+gC5gSgUSYS8DsmCCAXxgVg9SRCuRggAeCBghAwRgXfMEXBUjAtgUcxNYD0MCvBuzExgWQwGEHkOfCNNMU6OAiJMeSUPsCmMs1gMZRtMnUWMdybM5iAMwStMog9MnRyMHgKMLioMrhcMYwlKAjWOYpBKYShQYNAiYAEIkibMEZckf8uY8ODkBrwaBQuOERIMqC3EzgITKGkVGyHEio5Ao5IMSRgrWZNKNBzYmTGHTHjRFNE+BgIQjGGCMCz8a2v2ZAYAiRkR5kU4gMlEIGizkoTH00KjosVbDGwDDUAtAM4RMwuDgoWIDQk0YxNElCshAIQGkVNDHmxpGb4aY1AhwFgbTEJFMVDAjKBHNGoqkQMfMqBkhKVKASCUwigSQCzYGkFcKmJACzAYEXMVk3/EjYsNlBhShmxJgQLWDJkyICRGFGiIoFxgoiDiSNxgAa8DGj4sFQY8oLwrDGFAl0gKrJgaejEyJuIBRlSBkSxkCtcLHh5UBDIqOMIPC4MxgI35VOcxZRMYmrjCpezN86t5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMJoXGDTChsE19xphMW8cgT7/jQ4xe4k0NFEC8zRpgCoxR4CkMMADqzE5g4YwSYTdNdLP6zAzQYkxZoSrMERBzTB7xpswn8B6MGYB0jA2wHQDCyBjx4H6YKkIWmEPg2BgRhC2YVIACGEGkHZjtAX6YD6HrGImBxpgqoMgYkGE5mCzBEwOKNjAJgC8xecHjMEUAhzxyIDWojTe4aTJhRzUJ+zFwlTNBiTCkOzKcNDDcJjQcajQENjCshDIMIDE0YjGYlAcbZlINI4CQcnBAF5jMEZjAHJh6JJjACIoP4jA0xfGQwXEIxDAc0bo0Sg45wq9Du4ThWzo0TSBzBl0mj4LjEWQSETkMQ9NLDC74aamNPIcQdTEtxiWhqjBqyIEMF4THkzBtCQCddCLoTNhzUYwCRBUwxQwFQTBCSsOZtYDQZIGYOODDGEiIGDixw2o8+NXCNExEqJkAIKIS4xTc7YAwDUaAmVWDSIUUhUmJCxGmQKWOpYdyMOkRGNLXrXSeNgIKGocpLBhOw4IAFFyUYYEQIRAqEInRgQxkypkgCuQcmEQcwIwHEyt//viZNOE/0FkwgP91aAAAA0gAAABNh2LHU93TUgAADSAAAAEaZ4QYsEQohYU3Mz4wtiTFmFDQMWYNUVEXPMWcEQMKiE5jJgkWBIU14LHiEGYccFgYEDjWYQACUYQhmxFxmkfuk0AGAXJHKYnZdR33ieHzWdUZ+Tlh/wIsmRMe8aZ475pZiSmUGEWMhkGAETiYz4t5rXKSGAaDOYC4ehh4BpoUuRnITxguqBmEI5k5WxsCGBhEMphQLJjC+JmoBZjfSJymSpiAkRsmG5kOj5pyYwydJlMXBhmAJvEMxhmORouZJi6AqqoFFsDBmFAqBoQK+MwxMazNGqMeNOCpKqAyAZGcQuQULNSgBxsz8sxZ0e0ghSVBRkVxvjw+VHjJm0pxghoAg8zBhADGhZ6ZoKChZow7viyMCtCwhQ5gREaEcDDxlx5RaAAo0AcwV0zwYBWxKYbIMYECCQgKBGzAAq0ZMAucs0QKwccMgKMAZAgAKCSY4iuYIiTBxEYCo0oFDiJDmRJisMOAwYTSFAgUICIPIHmJDFQIl0jIYUEQmEUkig5Or0xIQyAIhBlBAIKNABocy4JNRYgkdY0uU1QwMHhcKBQIcfCEYFEmEEGCII0g0AFi0ChUUj2IwyYihbdEKTCHVE3FShDhD7mBPCQqHjOlTIkCypjhgjMhZorpQ4BDwouNUlCiQxJYSTJ4mLDgYUiSlqNDXS6TEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAFSzCOydMyscXmMUIInTC4Wcoy6MwJMPJCvzLKwNIwy4ROMamCrDBkAg0wsUPWMC1BQzJnybkwIcBCMEmCgTBCQEowm8FgMD+AEjBHQPUwJoFCMFfFyjBpAL4FAo5hBIMSYBkGGmC6AkpgnwPeZFSALGCPhaJj04UiYHqCamzUEGRydHTQYG6Q5Hb+OmkpfGhRIGExsGQqcmMQOFZ1mRw6kh5GDJbmLZRmsQ6GOpEGHgOmGIQGA5QmEAFiRLmQADgEBwYOAIkFJSAIY8WawsHDzcLThYzR6jGrRJIaVQT7TnxjcXR0YZosdcaNKRAqWqDihhG4kKBRUwCgwBY0AcGtCAico4oAY5eakcZU8IgINaGLHoGAwYZxGiAYIOUJ0fBQOY4mFwQRiRqAAAUHiR4wAJTIWqCF5Hx4K8ZaEgSs6UpKghQIrBFti56MCJwiDQWluWjThBhwSLpjBxEeDtMISRih7+ioEwQVpQJACEMYIEHEhU8y1BMIQgAGmQDMpMOwbmX3bwQKwEwIqRiQavEBhlj4QYChQkTpsomgI+ucYDDhUHXkCZpG48XEZMxhEwolD4zAhWIf/74mTbjP5/Y8ST/dUiAAANIAAAATsZlQ4v+0vAAAA0gAAABIBGFXoeGaJL+RgGhRlzAjMixUvXMu/AifQAmJtFCpqlAxScQGQ+GcahLZ7JpI6Y6CRemRCDZRjaIwqYqULOmB9A6RhjgWGYaUDlnExMwY14cZitHWGCyHaYlp/5ishxmOchiZA4NJihlPGkcKQYYg6BjPjRGFUiSZhgkJinHdGf6J+YNcOJtcORGPYO8asg4ZhaCxGv2P6YzoypiyF8Gb4U6aUIVphNiCmJKQwYiYZphrBGmGqDGYJAOhhbgqmEWGOYJAhZhbgWmBQFYAgwjBIDCMH8DEwxAMDCbACMDcCs/CoRmASwF6YYoOyAMalOqkGgoQPNwgAAgSPGaPmXoHH+iUA7CE1MMwBk2KsqqjesQQeSKExgs9KBocMLsp0FyiKIFRxhhJnypmgRk1SAUMUnBXAxSmUBXIBIAJgQKxksOMUJAqLNcFCqBEos8MgzHCBUSEHBqmBAg6KUimerSXQEbZkLLAFDJARgipgQhfYLKQclUmouYQ2FSIsYMELAwoKCS7BCGYgWyLrGRChhh0k6DICS0hkw4sRTmMgTLlixoDEAQPLAIiEGEADgQoEo6uGhgMCzAGwqIGly9QSYZ4YA0glLbhcgPGh4OyZOZI8yIIxgEMOgwUQCQuWFkIYiSbKoMRCAxwg+LM2rt1Qonbe8lUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUABGMC0HCjIFjWcyi4PoMN/WLTfWySQwpMIdMryD6TCIhQIxukCcMEiBkzCUwN0wZgERMTTFqzAjgIUwosHfC4AAYMgBuGB/gTxgHgQIYJSAMmCLiPZhBQEuYBaFEGC6gdRgNgTqYIwAbmA8hlhgXIFQYG4BYmXrAPpg+ANQeYxiZsA6aIWkZJIubLcmZdCKc3P4YQHyY1K+ZUDgBSGMlQFMUQZKGrMDiZMeQ/BwnFgVAaLwKAMVC8QCqBAjMQAIVXBg8y6UsoESTiDA76CbpukQtNNS3M+5MQgORcNoQKCZ9WpumJk75105ihhlmBojhiiJoz6T5gx5lypbRTwIEl324kxZgIKrIAlHDLEB0mFwqwpdlEJGYiQl8BwmDn7+GOPLCAUHmChIjIiyRUgsJEhSwxUJDQ8wId2mChgRUpAJTgLeF+i8zS28GgQ8DW9HgcBVtSdIg6EwQGEAq7Fay3w0VLRkRIBAkzAUEMnHQRBQAr4QglYSgqHCGUiyJjJVAGBAKqAoDdYuOBExFZTHiwiIMgTAkRoMaQ0rkgEg0qREwSRMCBAzcVCCEgHDgxGChxnhRd8x4QxCYaAOwZkmLDkXAMQUBUEZL/++Jk5A7+dWfFE/3VIAAADSAAAAE9VZ8MD/dWgAAANIAAAARZdt378oihgsJSUahuwmmrajyxkEkW6bwIrjGAdgDplGoyaYl8T6mLlCvBhFIFWYkwDOGFKhLJlBw8oYMKBbGHWB2ZgXYHsYDiIcGDaArJgD4joYJQCRGBWFGZhJIP2YGSHhGB6gNRgv4aGYhsAQmBYBbAkVwGCBksxgMg9yYCIC+mIMiARgBwWMYhMHdmBtAIJhqotwYHwBsCfbGtAlm5wgGp5IkRjmdIimj6+mGw3GuKLmdpWmPwgAIxTGUARQ4DHgeDJYNzGcqTIQdDCEETI8SjGYDChXTDwWzKcIQKLxgoRhlQPRhGOgYCBg4JpwkZsrRrxx/ZJ2a5gnxySRgop6KZip51VBq9AwsNUSMmIARUwbECBxAgSnNbNAIcVHGzSmMEC0Uw7U2p8wpITamWGCV4xyYUbjhgwBA0xgQGTMLTXlh4CmqXTMgxL5jIw0gYFRVOQKXJRJhkooQT2DCYs+HgJICUOTPMILUVVMZgAACgFGipEwpFUSB5jBok1L0GZABVMZgaXXCBy8wMVBhcQlk3QAjGmN9vXbEhI6MjAKMg4QDgqaAyoWIYkuEA0EBiBqogaWUWLfpdAIMUBDCi2QmBALFEIsWOg58ACYJBuwZ0G3WGAUxEYUIYjQYZFDyMaDgoawRbz9QDAjtQNMy2ztVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUw6EVlM1lLyzWdCE4xfgMhPuiDhjFZATIzqEQcMUdGRDCnBW8w08DiMFNCuzAbwNsyVkSvMFvA1zAzQxIwCcC3MF0CzTB9QQAwkcJXMJCAPDCgAr8w/MBJMA8DADBlgWEwGoOnMO6BdDBQwQgxhgFcML5FmjN/RFEwHsCxMfGDgiAE0MSnASDApQP8w+YMhMFIBXz4ZjQuNRr+khl0nhlAa5j2AphErIUEQw1OAzpSECByDAWMmAFMbAHMNCyMxR7MERoMjg/BQfGDwxmAYGGKoCGBopGMgBGBwFGCQRmRA5mBITFQTwuGJmaJhFhkyxi5RlJYJAmEgFrB0+JQgxWZAmCohgwgBIGuEGeGGBTjowwiYz6ILGxwAEIhELAoBMM1ZswiMwqQoQGdHGBNGFJKRMiAMuYApcDhSROAnIOgl2mlQaCAZMdEIoxgIwgBbREUDgriluBge84GFp6F02tGiHjRRQ8x4KKAYSClxh14iBCw8hBKnHjJacSIJnsJVXFg8kLAYiZoYGXCGQBmCRK7JQJgD4c1TtRnDgCjxhiQcUCgNl6siAIDAlFC0zeFwyAyVgxEAbdNunCoALGkOplRqfysyKxiBJiB5gQJWELAAWVo6ghAAkBigL9BMn9h//viZO8P/u1iw4P91aAAAA0gAAABPj2NCA/7TcAAADSAAAAEi4BPia1wGmmmNFtJjG0Y4ej8rXmJiBq5l4AyUZgoK+mXahwRhQASuYU4NgGEwAIBowg+4YFeD3mESjmZjLBVmfAIOBi0zFXcxMiEKMy/HqDcxHiMVA7wwkA0zGoGFN2QAoxj1FTkgHLML16k+1a2jGPQWMI9gswxBcDjYTOMeAGU1ZXQDFSCkNNVYQxrAYzEhL9MFARAw1QqTFHASMA4PQwHghzD5AgME0IIwMASDB+DZMMoA8BDQGIeAGYzIE5gghHDoDBADUYQYOpgNgQmBwEmTCCmAyCkYJoBRgDg+GAGAgYBYCJg7gTAIJ47AIQsQQPAUQ1eIImnBmBD4FKSM4C3hhXZp0JZ4xKULvTfwTWETOpg6SZESDW4UaGDKKwAKuAApm0BBGMkNHiJgQ5mjAXpmnQmZWGpFGCpm+VAwca86ZI2BT4qWMeAJmoKCGKDheGbcOYpoo8YMgAkarhEeMIPCBSAglMErsyBUxZMz7IzQMLCGMOkaoeSFzGKzAny4ABhLyFATUl+CpMhCkyIGjAEKBzot+aQ6ZUgZgoJJhYkmEYEEvUePI7EgQHVU1EvmxKbDyIGjTBJzKjQSLIVQ8CGAL/hYACBAgaMwMKNMcBN4FBpQAFQ4kARxinQCdGBJAQYMgzCJxkAVQA0SohUMu6lTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQABowMsMQMvCAozcjhZIwghm2N1DO2TDGyNQyqwPdMQFBNDFwBYYwXMG8MBGDFzAeAIA7cUGzB6GEMnozAwRQRTJRNQMLQQMyYA9jE/CcMDNs4wDAWjEjFUMcQD4wQxbzNgD7MNVRswZAYDCSZvOzA+AylA/zcdF5Mc0UgzZTyTCDBDNIgfExlQXzMOORMAIEsxKAoDAaEOMIMFwwtgezBBHAMOMGwwJRDDBwAJAQFpgTBYGC6BCYTwO5gSBBmI6AyYAIIQhBgNkSNyINDVNWNCHRygxhh5szxjwJn5QPOgxkZ2MCeJj7Jj/hk0wseAp0ZJnhNmrLB6gaenjEjwE04U1AACmDHrDOowIzMYAMoHNykQbJlAWGm9HGOHGONloQoCEY8VKrrNMmHV4LHAQyYFCgJJRyRplFamYNKGFAIvmuLwtUQsrAyAKlzTsgUOMSdMQDJABkVpiwYMEmGIEKxPYFVCIMhKAC0IEDiExiAcRiEOOmgcdVmTNQSBzBO0zgJGRV5lwxKPIhhb0xh8WAIIC5a7VthlBoyUREedllNZYMUHKpCBKWmVKQgA5CNM4KgQEgyyZlxaO//74mTcjv7PY8QT/tLyAAANIAAAAToNjRAP9zbAAAA0gAAABBqBRgAJhg5lT5vx5cg0J4KgTFiSU0Ysaaca8amDsWdINGCECOhkUpZEZZIPxmM8gPZ85ITKYsGFNGXChtJhpQeoYG0K0mBiBLJg94V4YD8BXGWOCYhgI4EEYeOBamB1AnRhOITiYLUBGgwRwMDrA7DA+xkow2IDgMETB2jBcAH8wAIEfMOcB3TA7g2sxRsI3MHiEjjOQA4cwTINTMM8CujARARcwWkU2MBDAJzE0QYQwakEVNq/sNjgKNVSmNHjDMvhdMzCAMqQ2MUR3MSjQNCB/MWhMMFgsMpQOMagfMKhJEQ6GJYiGOgYGMoEGDgEmHQPhUCjFQDTAQKTBkKhABIGHcQhAYdDcLAOX3MFQTBwUmJQkGCQamB4NhwhApDQUXZgGDxIFZhUJSBAWJcx7w1I1+yJsyhDTfLImqenOYLJOK0d4h8ASqQwRPRHBXwEDMgQ74Ck03TT0IL3niEZ5y+gaWC0B0VFdXIhDAyxEUigZ4A0ggwZgYYiaoiTBrnAYEHBF1AaAHQmkCAlgYoeDxEGBVBJA0zwIYEBkgCAEONMRsiFfF7Q4QRioBk526grsQAPqPBLBiRYcSqkupEBRlXHVgGCgQEcLEgE/2ro/pyK7eUlEYozYRhJENnXKFRC5oki/5gLv8m4nYFQKN+IF4r61UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVABTTcMBYdM0s4xjbUNMMjPsk9JYJDHHMJNFk0QyCSRTPLEEMXwIgxdh1zAyCINU0aUwBgBzFOC/MWQgMxF1MWyDMdRIMbgrNC0+NwBYMATQMjgTMODmM6gzMrCXPQwvMg+MNJWVAygGhAhmEYfG6DKmRgzHLDVg0gzOh3TGIHzDYnTDYYzCgeDDYOzIsjTDYCBUYjJ4FzC4IUdxGKBhIBQUCEBEohiIgTMULJh5p1QKBjTg5RkxIgyZAKCDPtEjDO5RhIdoQfM6ZnIagmMqDFNhDbLUGYOHBFmuBHiAu6bYIYI2ctYZAgYEmTFEMTBGhZWIC5jQxVFmTBhiQCrRCIMaEEgoKDEQR3jNDkigMCBJMIBpqyERhAUpWKXJV+x8LFk0hAGFipmTZhCxghJsRLBAUgERFagcHMwQBAKBxIqPOQcCMeGIA4sFaOFgCIKwQQvEQtY6jJAhCCDJBYUY0iYwWCRJiVhb0Rii+Rd1LVKVYSMpoiEQ6qS6rHVhstWYcyqUACTFnUlEAYCWIkRlWIMPkw4QkBCH/++Jky4z9gGLHG93TYgAADSAAAAE7CY0OD/c2wAAANIAAAATHj5IPU+XsHEaLI8NGiyZQVbhUHBliKiX7MHaFITFMlBozeEsPMhMgoTr+kCgxsIUdMvyGFDDegaAyL4LOMFbBYzD0wEgwLEJPMquAzTAFwFwwZkUYME2A5jBrg6wCAV5gAIqqYVYAhGBmjLJiTgNSYGqC3GE7AyJgH4OMYrYA4GEpBBxjA4DiYaKEdGdChsZhfILyYYiGMmBVgrZiQYLyYSqB5GHrgaJgNwLIYe5YbFCoYgo4ZXB8amn+YXkgZET6aMlYYYLKaTFAZSDgYbjCY5KUZREgYMCCaLAmMh2ZSCuYhgGYJAoYDDOY5jcYDAEYChqYJDSYdhmYlAyYdBGYnCYYQCAChKMZSkMDBDAAYmLwkK3gwATEMJ0rhQVBJczAoNzBIJ04T5LChxoQhWgQnLtNB07jhGwGLGRKYI5ktsQBQ4hDOFw0RRBAZCRjAHo6HUgbkFNGC8lUaZQBTOlFUqYgCXAQIqATFJCA40DBDBhqEiUJrFFRUlJOsUOHMhA802ogLEI+NVgRgoDwMsW8DhAc6PQBRIElI1qJCMlKwwyEe08lVjVASNgUQsr/BACa7oLMStWDEQAMBQkgI9hwjdVhHg0JYGNB4JUDL2CwjTGkmIUFFVlrBAk8xhy26BiDytoIMWEFS2YNmQHsyftnVdVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAGMEWBIDHAiWAz50OCMX0IbjvMhhMxwYWOMVWFSzBXAC8wwcU9MBvAeTC7AcAwNkD0Mc/C5jAwASkwY0UFMBuBNzCZQg0wO4CaMF8BkzAcQOkwAoXVMBmBhTAeAKQwNYCdMCQC4DDdgDUwC0SgMDrBODB/xSUxqkYmMEhDBzCNxEwwREGFMGqC4jAuALYw2IJiMBrBxTBjxFEwhYBZMAZAqywAkGAXAG5gJoBgYCeBgmBGgNJik6e8EBg8ao0G9ORyicbRMKVGxKBh4aYuKmWBxhiUZkXmUSBw0gbsfG/ShvZCYabomGNIBqwwZs/GuHht0MdIaGcgxtJyYSICwoFS40oGAoGWYRCNhUCml7jh1NecDFgE8OEMCNHkhZjhxipOEqZynluztFHpTKYRQBb5qKo4usdQ5kGlK6i4DHAwZeIKjiz4ODRAM1EumBWV9KGqfNxIyBjWcH40bwcG4osOAqlTETya6AB0GZMsL2m6aPTsrZc6lolKGTklTMVGig5cPHMpgDYS0sBERiKYMDAjZxpgRJAM/JgEFBBYESOQmJPCIsDfgUIzQjVBBJRg+gwsHbIZGY//viZNuO/qNkxJP7ziAAAA0gAAABOoWTGm/zVoAAADSAAAAEYADgAMYSiCdXwiEYUWfDiS6w1QucgGTCR4lr8VekpQwIMGAMLVBhjMDw3EwZ5AsMoCIpTAzApQx4sJ/MFBAqjDkQaYwFIBsMG1AexoGOMPUC5zASQBcwYYHsMA/AZzA2gnEwG8CdMBkCajBDQGAwM8LbCAysMAvjA4gC8wDQFOMEkAiTAMwdwwtQEoMFYBuzHgAfIwLIAIML4BuzAHABIwDoKBMAXASjBmQakwCoCWOxM4yaXzTyzMojsiHZQYjGrANPiYAK81UTQ4JmSg+ZbEhnMNBxqOHjUxCMCKomBA+YYBZgAEGWQEYiChokCGFgwZ3ATJzDwtauYCFJrARlCAboC8ADrDPGTDGAM9N8JViPAlYAZY+Igw6yMyVAwQiFmkdjUsCTQQABLsxIYHIxakMBRCMCDhkARb0e2GHHtsmYLDWxF2E1zMBhIEnq6IGgFAdMQa/ETQSNiAiVRKWhiS5miIGlA0ias6CApgA5hxCwgiEAkIDAAFCiQUzREIGlvlTg0My1gg8DQZQImFGiwMZBPwZEaBrQkvMGEd4rHNSMiGYM/7JXrakDBZiQAIMEwCZHhDskyImCl/p8LizELjBAjTCgSMKoQw84MYGpLDRIRjy/Sqhekw5pJgYGFYFAHEkKzBEAqHhJiCjBxIA+VziFTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTBQgW4xL0V5NN3BrDGM0hA6CcxlMQpFeTDwRWgwUMH5Me+BZjASQIowQgGQMBkBHjFlxjwwSABKMIlACTA1gMMwbgMmMHlApTA4xMoDAJJg+gOaYl+C2mBZAQRgwgCkYCmD+GDbgSZgO4IuYf0FPmB+CzRivAtCYF2DtGLzgB5gToACYQWGtGBMgvRh9ALmYP0CAmFAhaRgfABSYHgDvGAdgQhgAQCgYAUAhGAxAsxgL4AcZVWZuwBghmAaKAIXB1qM3vUxw9DDYONwrEyEBS9wqIzWAYMKhgwHPzMZhNTyUYDZiAVGQxqYPMJiwSmUT8DvSI3sagIJiQHA4yGChIYlFIgBQCqRi4GmOxokoZVHJhQHGDyQQAgyIah5JGFgyNF8UMJgAGJJIfDhLMFg4wGMTKBJMABo0kS65gChK5pEn+uZIogHAUTHDBRIhzLNRWQuNUQUQC5AMEMsoKEGBYFQjqAEBqjhKyaaiI4FJAgYBXGBgdYOEM9AJggMCATGaXyWfKpIbWhuCChCMnaBBDSSKNQhQXBTAA0yfQYqW1BQSQCHZqKwgKrVjL0shY8SBgQgQPIQDoE8ZAZoJI7ggNYMY//74mThDv7/Y8SD/M4wAAANIAAAATptkRhP8zbAAAA0gAAABLJizfdWYphmy1ryyRKNtRYZFKMKjRiUUT1W+VhVuA2YBuBVmCOlAplGYMgYAGLjm3dkKBgn4ceZIsBSGAUglBhZYVeYG4BLmCqge5gAYLgYjYGlmCmAYpg4wV2YD+BJGCZg9gOCkDBJQPEwagBYMA4CZjB+QGgwFICfMCcAqTAmQgowKkB8MCfCNTB6gIEwN0NEMb7BpzBXQSkwBUFYMBDAMTDMgK8wEUCvMNXBFTABQEk9dgzR46OYiAITJmspmGh8aBeRhEFGLpSZ2HRVJhloTmBi2ZbCphpcm9ggqiaVOwMA5l4LAgDGkySEEMz+sjCBPMyGoxIPjHJEIhIAAmYPCZg85mVhIYfHQEChjAUmQgAQCQw+IzBg5MShAwMDwUWFDRG0TYDdIgBBIoNKBLhFSNEGo4Z5iP4XhDK03REoQkI3jAIPIEpTBTMU0WEYCAqRgtczkFtklRCshGZgA4EJdAawwBS/Boog5EQxGKUQDr5QSBDxiPmWsGPERKERzkFoVh50oXak0ZVwOGW2QKBdkqnl6QCWDqygc8wBAMFcGCg4YzjhdExSTLHa+QBGCgmcIwB4ECBCyhKAXmImREcZZSgACENNgyYkzy2AoufCajQcOhiUXCMUz1hqAxBhkseGCpZqBj3aY6IjL38bPRWr1UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAHMAOARDDyDRUxt8LkNYPNizUZBKAxcwDtMQQExTBMQiAwu0JgMJ4AsDGvg9owiMCaMXjGXTAigbswP4JOMF7BDDDDw6cwYYBRMDoCczA0AQwwGkI8MC7BDjAEQBMwuIDQMDFCIDCowUswFoHVMQDAWzBOQukxycPMMH1AWjEsAfcwRoGeMRpAJAsCTmF8A2BgNYCiYSuGlGAVALRgAoLGYAiAvmAWgZBgPQEkYEEA7DQCicE/GBvZlYuFIYUUDL2Mz+jAJQYosGaChxgqBAA20/MFWAzVM2QTOxsyM2MaQTCxAWABgHN/HwAhmxJRmQYY0CGEB4QLAoaEZMYOQmUAqcBCApHAJEy0hZowDACSzwRmAcQ50jCQDuhr800lTAF0ziSAQ4CF0hwICiCKTcKXCquPLDpANHEYAXECERCSg6awBbt1jSdCjQjYMAdP0yRyhxDgWQaRbMA0DBtbU2HQRKVVwCPBQZFMrYLMgJciDQwTSADQWDJh0BQCYWgFFy2qbSnKoS1Q0qWWNhSCkikim3FgkahEADhQCSCASIwLDAJQ6iwOYFGFljUYgDaYbqwciFACzoMcNgkMfNVBDkHdH/++Bk4Q7+nmPFE/vOIgAADSAAAAE71ZMOL+840AAANIAAAASgMOIrrAyTKAEYIwwQcyVvSuwmDLgYZgSBYObXsyGm+tMkR0BgxOYS0J/GeRgHxk3BVqY+cBHmKBhspoBQnyYBuFGmIJEbxgcIDqYL6GlmAUg2ZjvQU6YRqEqGFIA05hVYG+YI2FlGG0AIJgEITeYECATmB5h9hhGoGWYFuIbmKHglphApP6YxkFFGAIiRRgS4KOYJiEMmFkAwhg1QHAYhyGVmDiBuBhZAheYIcBymCogrxgGgDsYJEA6mAAAcZgTYB+YHSBRGD1YVijoBozwcMiADb6A0J2JEQDiQMljYCQxNVMTMAFiGjPhjJEaiqm2GBvrGZCqHBUQMWzbSszIaNKNhKAGjYgPQ4oBAoFSYzQLMGCQMdGFCQKATHCQwMaFCggRhY6LnOWYaXGIhoqVGHjhfQxQoGAYeGDFg8mAEJzAQE8AQAHCC0RhoLBGo2QBp5JaigAGOS8OQYmUYmPGF3QaMhJCjjLzJIMIACpgktKIkEWMVhGAmawwq2DgwgIMmUMQCA6gRxo3qaJuiSxcQqiEQxZ5q40wMAC2AILCNi+K+RUhxn4WENw4FYlgAsbs4RvUKMQZAMkMY5hlmiNQ4xQNgZhAksegJVgBAABSAYBxMBiow0RKmAol2hLh8RJFARiQjYKA4SCayYoTqU1dFKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowE8MyMLlLpzO73740SwiPNGyJcTDRRI0wqsUcM4hKyDHvwvEwSAo3MmgAcDA8QC4xI4Z3MMoBNDChA6YwmUABMTnJfDDFgXEwl0MWMFnAoDByQQ0w7YDaMGhB9zDNQIQwJ4K2MFPAczBVgRIx3EIYMJ0GGTNhAekwY8EbMdzBBjAvQ9QxIgDlMAUCVzAuQqgwJwB/MODDKjA5wJYwI4B1MBoBODAEQL8wGMAjMBFA/jBRwI4EKwxCLDEEjMnAgy2FzK6SNgsow2EDCZFNAE0x63zDIyMKFoyuQgMfDFhfMFh40a6jEohMds4wqWzXj3M+G42KhDG5tN1DkBHgywZwcbTEJiMVg4ZNpgYOGBjwZLAAqCSwaYgYCMBV4MaI3DTDGohIRtgYGZ6xDEBCUDjZkMuccWBKJaRk4AjaQFTgd2bw5MmwszoQmBdQOCQZJnEEyLUNlwSEg4GQVChoCQwWUg4ZIQ0UhqIggqUdqqiBAQy90i6xgmoWABQ32AiYgPhJIqlaqgu5CemqzpB1OBRqfeFiTwhQVExQ4zQUUirKhql5G3/hteiBy6pUjim4m0QGkV7/++Jk2Y/+wWZDg/zOIAAADSAAAAE5mZ8ID/tpwAAANIAAAAQyIDjAQMl6ji0wtWW2FREVU6KRPZ30FyoEXSApUSg6Kw3OVOW1GCFB7hkZQYafG8qnnx/zEhyTY4eYVoKSmfQCtppMAlqYnKC6GC9m3Z0ECqGP6GaaJaJRjRB4mhKeiYnZCpm41TmZuNyYmwwJjFhOmG81GYegeZh8JvmRmFsYNDyhk8hqmNGm8cTYs5k4Q2H1QW0YuqSJmyjlGMqBYaSpgphREDHL4R+YbQXhvDAgGGkGQYXIPhgwgpGJeEAYRITphMBXmEADIb1AmqHht7AbyNBBGQkxpKkAmswlxMBNjH1sxhhMpHTIWMwgVNTODKSg5RFOTIRHImcSZkxEbbgGtqhsjCcoXmAqQc+mUJgUJmBmYC5lBGRMwGdwITgUATJWYYEMiIPBx8Ci4GDpKEgwCEhExwRTjMnAjERUVGQAHmBCJANhYdUHLAYpsCggSSQ5BSZWwEAAscmLCCPCPwoDmCiIcBrtMDC09QQDw4gCAIGHEIOKGdp5EgEgYiQHAZf4uknWzBhJhAK3oFAlBhYdYIVg72IbqJEoKreHAzrmAgapk/2cM6nFNlFRQNS9LLKgh54U11NERGkOqy1XQXA2RshSmIBBAxWkVCpGnIAhhABOCwogkHAxibRknFNk00vW1UxVKy2UW6sTcefwllhn/9VMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAHMDGBrTADSSAy0saKM7sPNja8QQkw2sDUMgiEoTJQwTcxx4ImMJrIBzE9gRkwI8CiM4YH0xXQUjLmD4FAOTRcN0MBcWYw4yqTDtDJMSwVMxTQNTARFkMRMCgxLzKjAhBEMCYAI1cRTTDdXGNxoF0xYCOzSWGAMCgeMzqxSjCxAGNF8dExlQNDQbD7MBAJkwWQazAdBfMFMHEwNg5jCcBOJgZDAuArMC0HkwBwCTAjAUMEgLAwKgCC7BEB4IwUjBRA/O4UBqUz4U20ozLM/aYATDsxzpDx7EZDsZ0Sf8yVSJkZ4WHHgFCN0F3Zt0Y0tIbaozaEBUWDUhixZEAHBYhJgQkaoQGCXVMIGX0RPC0ppjBFkMKbTWGhBnQZiB6EwxwIuEBBRgzplxMVLBUDABIuvAKnQEHYYAAoiIISEO5gyI0XbuJDjBC0PAULYEgmLgExsQCAwqpQhu15bbEyhGmKFQq/kEAIAKAAoIWXIkynQcDe9n6/wVEMCAZu/j8lwBGLj7BU33tQBtyMsLBIR6VjAACXjLtmbCmPAA//viZM4O/qxnxJP+0vAAAA0gAAABNw2fGk/3ScAAADSAAAAEgoSFzIogc0MGrgYOemBSGNXhBoIuGISmJCmHCG4FDBERhUaxUGlGqmNJm1R8FgDgK0+z9R6ezV/iprzAqAPMAC6Ro8AxKZecawmUZiChgjoJ2YpqEjmNUB8RgRwSqYC2MGm8CEmUpfmYb8mx4rG66SGUQknQ5LGKIPmmRkGT5MGJpYGG4WGJgnGJI4GBU4GH4XGRgbHQ4IGC3uGZa1mYDGHZR/mhCUmzxgGGp0gU2jQYMzbhImyA0NgUDRjqKRgwZRhUUIwI5qVZwDRVtGvTHP0mqJGsKA12Z+CckCbs4cIcQDS7hgSJ5jJvZplfBsQQ8wMqpNsON/HMBmMSZEpwaQASwEAzRDgUbN+UXYHFjCAGdooygGijCoErEERbUECDHrRYacUIVQRpEICDggOMgDdEw4CYAyKASKgHTCAqACYsECoMRjhEFQ4pmGCDBitAUYIgLEwIelqkDFigEBIoZhCyHd7wgioCW6QgSHSMMEBEmyQKDoOPERcxYsAAl1gokYQmQhkSAiSgeVgQU2MOQBxkw5IeEjKUhCpFrCToAKl7jMgDBhk7xAXAxIkDGbMjwIuO00vkNFxCNUBIB5dZWAz4VRky6cYdGJDlgzABhTwjKICwuQT1XuFwQKmiQcOEFvyEM9MeSBdCUTq81fxN34E6TEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAApJwwX0HFMCRKODDqUBAxL0PHMeAEQDCWwpMw+UQEMP1ClzBMwV4xIgPxMHsCpTB7wPAwjQH0MKFAODC8AAkwYEInMK+BYzBNQEIwAoEwMEyAPzBSQB0wPoDiMGZBTTAVAJYwBUF1MBSAFjAWAEMw0UC3MEVGQDB2gfowFsFlMUQVNXh9Mg3hMfAsOVBGNdSON5jEM1j/MoxDMMgrMVAdMLAcMUxWLAfhAKBA1GAgVGBIQGAARmFALmBwLgIixIbQgGTCzGnCJsyGBhMBTAIsHSphHIi4wsIbog1KcJZjJlwydYSQDH0RBVMxhjZDGADZTIpkArxgx5eRokTIJSXCFjAUEeQYPCGnUizQDBwwgYM5YAqj2AXHAoBddKwLIhCBhqCFVookACWGsmSYy8BNBnTQAgcMQR1EmQwtNtDceREsF9gQBdJZ4dXAQQcipAwVDOJRENocISWQhuKGDrkBlDLEyqg+5AwrGIEHhMsEwlA5dCMsiDCRYVNILwEI4KDACauQEgISxo0GllhMTlVoQRG/mZhwU1CSTY1JTw0EbUboDGwEWFQTHQLAS1AGP/74mTXjP5IZ8ab/c0gAAANIAAAATrpoQwP+0vAAAA0gAAABEcAxWYPYGGGYxTpAwACLSULmS4RBIYp+39JMCwDVTBiAmgyFNpBNeRkSjdGTpswYUL2NBkDfzQJhaMxDsWmMIYPTDB+g2AwKEBdMzAL0HAumeuOAYMYgRpYKtmBCJMYzpNRi/BGGE2ECIR/jAgRbMjMDgxVylDV1CXMAVGgzdxKjBRswNNViMwiTbzZiCAMYkuM0izajBUJeMs1RExOQDzOhS7MYAFEy+ANzAHAaMFAHIw4wqzDPABMBgGkwEgJQCHyYY4CRgEhymASE+PBeuwYE4AxgrA0GBwAGZMqATpkqx1kw+MPkVMO5NC7OM6MibB3w7/86M0FTjRGDedI0a0WLkTQYjzUAO4GQZtzBsWJfA06M5qMyYkUJA4UICQBIuGFRAQITGOSPNONMIDLPIyDWUmeGhLFAgDMTGKkVghIBr4XEK7BgsGhEQzRgzHg0GS/5oAYySFSYWEGWCIEJtAgDlpkRBjSRFZS/McQb1PAKBYFHi4KBsiJiZZQcCA4KFCkBKHBxJ2BATTRHtKQ5bwBAEAAkmMMWT/GSxeMSHkQMvuHGEZzMo2WjgpOAuWYoWZUWl2CQJhgokVKDxINdosoY43EUTAqLQMBwgxwowQwwQ4MGCAA1pjQGKkhQsJCYdOhBVaTJXkpHrZ6ra3scoLHakxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqABFzAiwVIwQcYANfcHCjRWgPc2McC8MHJDlDBkgzExp0JXMRWCDTBDx6Yw2UERMCDAfjEJQW0wMIAwMEuByzBVQLowNEIIMDzBcTBCQh0wIYA0CwDWYLKBrmByAlpgQwBIYCQBKGCtguQoH8GBdAnJgb4TsZK2B1BQHkOzh3MlBVN/jqMwBmMZ3qNQnMNCoQMWUUNNScMIRBGjlJBzMGiaMagIMsgbMBxbMIDAMEg0MmRKMOhaMTw1C4bGKADGUgrGlOnHtGQRE5o2Bg0WMDFz7GgM0Nl/MAfCToQrCvAsseEabpEZtoZsgaEQY5aFpI4NEkBM6KjwVPkIM0ZoyqJXI6TRtFDFOaYSZo+YkMBURiTQVOgZGYggiqMgkjgSDHDSlDH0JJdYSGEiJIFYUoOsCGARZUFQi4xCKLdBiYyAQLDTEBDPAzEqRUATBDIAR4OUIQaJBx4MKiNWBgRCFGhIZmXqlSDkLuloXIQzIiDLigGFxAjJPqkVJRCEQkpqMxioYKhpTYMOGDQIBQ4UhQiinSGHSg8CRydotYCEYNEJbAJGqELDE2jFEAYQEQRA4QkAv/++Jk2Q7+rGhFk/3VIAAADSAAAAE5zaEOD/tLwAAANIAAAAQHAgJvh5CYkAKABQCICBnwYc6JhgNByN16jSSAFDi3nQldPfMArB7DBoD2Yy20j9M0TkjTexzLYw+sFcM3rAPTIKBxoyF0N1MEyL/jGJBGIwUIArNhJiww2AkjCqQWMIQIAxxAozBvEAMMAZsyAwMjAZG6MZUEUwDgWzGPCLMFAWgyFQZDCtb0Me4pQyFVTT/tCcMaEqI0xzszGxE2MXIw8wbADTSKKrMKAJgyRUSzClAyMQYUUwKQIzBhCbMIsHkWD4MLMDwkAHMBAG0wjgRjAaAUMB4NcBAAmCSBqCQQjAcBeAQWBCGMEDEZc6R8dUnVcHS8GoanmQA0IZECSOgRjMu8MMqMcXBJc0bc1wItOErjdhDVEwUTM+mETQiomwjGjOgV8ECxw6ZAUHAVgxARdQ0QUlUhC4UQFQaARgBMGHKAYtSGEBICUMoHU0VMWhM6PHBRgnRkVJlE5ZULs2qgEQWhLUBQegFMaXdssGRENEYkUJl7TADx46OG1NTFiDMAi3gMKioNPt6wYFU1nHTBicqB3fCqMzyEehGNDLUfgsmhC5Zb8wYEiJRppi9zDDAAOY4+KfIYUMOIEIIy4guIFAyLbvGACGNBsEdVcpbmBzHkAsHTXa4sEAAo8ATCYS09JwLCs0IEXmR0k7diuF3mVXtMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAAGjA5QTQwbwsSMpYKVjMzS2k0G4e0MLiEgzESxF4w08ZtMQRClDA9xKwxIwHDMA6AmTAkxTMKgJZg4oU6YD4A7mELgO4QCSGDBBTxgOoCAYByEDGA6AcAyDLGBBgVRgCIDkYEmCxGA5BURhqAQmIBhUwcsJIMEfAqz0F6jPsGzp8jjVMfz4djjXgvDLKmDH4ATFUwDCA4gco5iILxg+NJioUBkaIQJFkBJ+YIBmYvi6YHBiYPkeVBHMPQtMNgAMIAGMcAqIAaMkAsDhLMchaMORXEAyGBgjGBo7gQbjEgRzSvD3TToujxCzRpDqhzLEzqkRY6cMeRPDQkQdIEn5mS6PyM5hiZlw8GpFBiMyZVxhAmcAHLFFSYwxUEABZ4gFQBiwEwoERkFAwCQIiABBCy4QCTKjS9hjQ6vSwFMQQTdSnTuMoBHgSSKdSqAwODqacYQBMORMsCQvWMNGzXBEHyy9AtsRnkAohBGOAhccRKDGFAECEIEBGwVNJArQUgAxIYUSACxkkJxS4Q0AJoywoeJAEQkmTKWZlUGYUGCSgCNBBNFVm4csEhxaAw6swKBcpcohAomAkEOBxEGUgWbZ//viZN+O/rFkxZP91TIAAA0gAAABO02VEk/7S8gAADSAAAAEGNAkgy/wNAIDHKSQMmEDkiW40EkM/nOCxgbgQeYRuadGk0pzZrERHYchoD2GI6AmBlXAHaYFeQlGLoA6ZMKXmLVBWBgcQI8Z/LOhhABxGYgVAYXwJJlYD6mE+HeYfI7hiyA9GAWIUYaQXZh6F4GIyL+YI4Zxhdg1mL6LMZ0gkxjdKfnC0p0YgA6ZjdFoGKgLuaAR6BgHBHmm4coYv4EZgIHcmCYBmYAYIpgEg7mGiCQYCYDphegYmBSD0YEYEJgnAYmBCFeYHYGZhBhThwKRhFAFmEcAuYCgIhgOgBGV1jgYr2HQggRGYeuapydCKY/IE3zmgjWmDSljQ3jYnhBwAVAvsVQyW5iwhhnhCiDBZzUhnwxljZnkJgC5kE4IblYgeeGKCBgExgMsByAOLMWemaGgkaiqIzLGhGYAowBPjamkRAEDCqoyIYQhUyU5V/EpNgSYYOFkoGDyEKZMcOlwCDd95woCDErSjFkDEDzKiEKFoBgAw5YWRMyAIoxYJPckILRMIHMwFMMCBQoZDAUkDp5MMBA0SAlgKYUiYEgvAoJGfDBwxCeSnDFARgeiiBAqZBUFjxhmYCLhyeoVD5acsqm2QmweEASxMwu6hMMeDaQYskgeAARKDIQJE7IBhmAQY4CCyTZkQyuBQA06kbSSWc11TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAWMBwA4TAmRMgy2M5GMXeJ/DSEij8wS4SUMCmD7TEYArsxIEF9MEHCLzZ+IZMPcCgybEYzA9ArMrsHExWAKzBCTwMFMVowvy/zFWB3MMMSMwzgNzB/FYMREB0wiQnDKbDCMEIU80QB5TDaM0ORw4ExRBsDNwHjME4U4wdyXTG4AJMvkr8xZQwjGcKEGilwABQYSwQJhnAOGEkFMAAUjBcBeMDbMXTC8UloGx3AGUZlUb5Ib5oA1ZGjM6PM2AMQ8CHBynxspxtKhrUJoxoyOMkAMVYNN+O1CNcKK1RE+C7QLCghgBvoQFRDEAUuuYggEUAgrEQoFFgK7V7BAgYIAECjWAQDhqWGIB0gNCDocQiTABkBK3FcoSg5chxIiSGhfsw4EsuYUWBk76J1CMuh+aM+Kj0ZkfkMEvC8odXA1oZHo3AYIYIADohngZdBNtlTkJFAQcz4wgICACAIaEGRBgEDEZUCABQCLOSgIu1TlD1AY5aHQAkUVxIMvMGCWmJHmFEkhchBhUKZEwnMMDAcACEBgEaI4CVmzFtIAwsWMGSHlgWP/74mTRj/4yZcWT/tJyAAANIAAAATnZmxYP91SIAAA0gAAABJNzQozMlSzYkfEh4AEmBVmDCmJGl2kcjHgU02wwNI5XS2WFzBLgHwwFILKNGrNyzPmUdo07UjrMKlCHjIzQbUxZ0KEMJBDRjBBwxEwVAEHMCtAlTC2wjQwIEEbMGqCRTAWwKswXcTrMDUBAzAxgdcwT0A3MCgCazAigCAwL4DKMEGAHDAEQLwwx8CbMCQDrTBqARcwWcWIMGVCMzBBQdQ+ZhkzpR88fAozoJs3IgI3FVw2ZqszFAgwZFwwgFEABsZbAOYPCgYmCAYKCaOFSYlAeYSCWYoAmYjA+AQDMOgbMIQgMSwPN9JKAB3G5rF4CimkvhVQd1aaYyAzoC+mqnjVQEtTJSDbnDF+jApxxiIgZhhw86NAGNeAFBwsfLAERh0GTKhV+FlhQiZs+Y02ZQsZ4SZQkYAmYAQXgCiJD4too6gCGg6mCSyV69wALApIy4I04sShhDJAKu0eCmGBhcaOFCginSYhCskADyY4qFBUEEQQDCGoCUrnLkmLNPKmEmYs4DEU+UeQYXRNdUcAPmgCWaIAYtFkSEsv0SAk5XUFAQ1FjEXKA6Y5CNMmEHhbA07gIIGgjEDACU1RgZZITxjQBrRw8aVpAy4CFS9Is2AwIdODSNLoqEUxTLFzIjAaSQpSYMkBUip5HVYWmdN9aWiuZDUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEwsICfMTJMMTVbTnQx5wamPAxDijGuRw8wLAWeMhYAODKlg3EwdcfzMc6DRjBQgEwVT3MGkFkyH1XDEBCsNKYtIwfQ7TEeJuMTEIYwWz7zGRBwMBA2Yw7glDAyB3NgUJoweT8zKpLpMmkR8/wR2TJzFPMcBLIwzxTjcQD3MBoMMzH04zA5FKM65FAx4wRDBYGfMFUCwwhwGwsF8YNYQRg/g2GAiA8YJIWJhEBHmCeAu4BhBAXmACBSYPQDagxgsAaGFOoAzIDjLljEjjSXDMhzRjGXmbIR8dsm2GGnmmAMmxFnSLDzAeNCMGGLTDgRUkDCY9WIXxEzMYAMQIMGpi5p2ptiQsTNOqAhIxg8EtBFDeo0AU2BtA8xgFAWFSY8kBSgqBQxumsVRZRfA15SKxzAmRIWPHQNGBRo24ZagY+EYiFQKCQgOMJGFti2gGshB8vwBA6kUDC65bAEBlrkAAtcZMkQHQcdRSSrMSUEIYvGJAQUbDnqQKC5gSiaa/y+xCLaekqPBhCHQbJhYVZmOTLvAxxCQOgFguip5CUZcOZXAOnTQAB4IwQyA8vv/++Jk1gz+hGXDi/7S9gAADSAAAAE5mZsaT/tpyAAANIAAAASjeFg5kBZpj41nAA0mACIekoQCzAgW9QhLuF7C9agsLdanvYogGFcwJMBpMDJISTFbxVsxRRETMxDGIjAVQTUx24CcMMrB6zDWwYswPQP7MccWcwYQHTHaI8MGIIYwIiizCHBpMW0g4wSwQTCZEoEIBphTApGK+CWYAoZBiqBAGAQE+YrYAZgcjmmTyGQYdaTZohkNGJWDyZzwWphDAtGSSCqYRYaZhIEDGEWAeZNolpCBEYGoNBMBaYBgIRgDAKlUEUwXQDDAiQykRMyXzABoMXzNgMxY6MpGxE5mEEIGGTMQIx8/B0IFU4xZVCxyRmQGDja2MyUrLDgZEaG1KYCtzaWcasTG20x0tHGgFXhKNmzjoUJTJlRWMwkMUBWIIwRnpfkoOiqJjwiSBIKCkTgM6gEEMnHREAgggMgBDHSoiNDCg4ysLFQkxkQcMaFQCIgokbqYyBgEDAIQXNL7MDQqL7F1EcDAQVtm/HAVHNUxMHkwYwUeAnDLKDAiFQMWD052QocgYBJEAUDIgJhBflLNCFsCh4XC0rogsRp7J0Io64gOF3ZUk3UdDUmFVBoHMCDwSPQ6t0HAbTwCAmKnpgpQYWgGGA6q5QRs/BgUWzBgA+wGES4TQBY3tmDExfIQgSwAWAUYkxGHQXDMOWpXbtUmEdVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQAAClDAjgHcwLArZMWhLcjIhUD009wggMNsC5jBsxDcw3wHOMAzD7DA5hCUwESnDArFjM6s+kxDwpjG+L6ML8GswARpTEEByMMEUMxOABTBWGyMU8EQEBhGN4F+YWgGJkdiEmLkA4Z04JhgkmqmwoXQYhAHhg8jEmGkJSY3ZEBhCBZmOkeWYQgKRjxBkGCMCSYY4M4oBSUBajQZxgaAgg0EgKMAjccpWUMjVJUFAIROfCMmoa0ZUwYMaYwuKFxEmNzcFIZ1BRxCZpzBckWOkgUdeHtLGssnOVmEPgwWBBBEOJQKCwBHiMS74MEpQIbCwcLBC2rJyqBEIVSJkC4YcBqQz4AgIy1dA6CIDICClnjTnAgOZRGW8M+IGkYQagcoRhYKgIMUZAAg05wMKvchyCBgOICwdVgEGnOLBUolKZ8ISlElQyQOiAUJFEVkeLAoWgiHTBpRxkwAyFUFBSYSAmPLPoELAYLLAEcDmQFR1lqs4EOF6gQCX+Dg6hRMHColk74hQSZ8apUY8yYwSLHS9pojY0bCELXQa0EmxvnIkQMIKNK6CGhnxoAJ//viZNSK/jlnxZv+0nAAAA0gAAABOnGNEK/7acgAADSAAAAEApkIRTCSyolKjgkOLWlaMQDxY4y90r0PS6rS8ytZIAYJGA2GC9HKJoAx1CZNAc8He4AcpjEATEZrKBemH2iAJkCAX2YNWImmUCZuYHoRhsJObGJsGUaJYmJhNiCmF0SiKAfmRYVaYSIX5gCIxGAACgYOIX5gRAIGBqKiZzI1pg0pGGpORWYt4+R+yComTkFMa+YSJhBkgGw4CcZKgDBrSmgGasAWabYtJiNgUGNQJEYNoPJg9hxGAWBUYEQCBgrAuEgeYqVGQA5uY6YMhG4AhshOZGho2Geno8CGKC5kp2ZChmKJhvBoZeYnEo5pQ+YFAmABJgQ6IA8yAkNMPiwEminpmguLFYBGAUMAUTMFAjCCIzAkMqGTGAgoUDFw0QBQQSCERJi7QkILmAwSYmHkIgvwDCo8XiACTUMMFjPAIKE5n4aITA0pUMICw4mFQZLRPEoKDKyUxcUMoFg45V+XoCCpPREgeAXGAoqYqCAI9MHBzCzkwcdUwMQGhQxKFIsoY0JNfCDw0MbGhYwIEWmm+CgIwgAQBoEAwEMKFmUqMkgKiurkIBEhEwl1hw4xIKgoiBFASAIGABEQv6rcYWACQoUCAYBP6kUpqDAYwoYQjQ2QfCoBcFAhpBkwMWYbA2Be9lA0gCigBBIKj2MgjEoyybsyTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAAHJQeYwhwftMyKG4jJOk+o1EYt/MJKAxzARhQ4wGAQ8MWHCxzBvAucxIsHyMCHA5zELRg8wTYDdMK0BuTBFQCcwX4GIDgZ4wOoJSMFnALjAYQdIwdoBhMARBQygKVMExAmTDjQHEwIQLIMCFBCjBexJ4xHQV5MB2ALzBSAzQwLYDtMRHDNTAiwCkxO4EnMCsBLTCZgNgwC8DwMChAljAWAIcwEQArMAmAERYBXMBuAADNAUzYMAAeb2GsgNuTy/xnJ8BDQsLAADjDxswYjNOHzSz841oNMkDcHEzwkM4ZU2hAUGsqpihGdAOGQjhGBGJFIQ5DI4YOIhwIbUSLSM1LQCHGFiQ0ECALQrEYEEBIwBhwEKCgNCCEqMNERwpMyACYGM3ACAAMcIzCBIyMvEQEBpBCUTEZjQAZEelA2DCFEoKGAFJQQNhigYGLAEGJQxfy5jIqCwhcMREmMOpu2Ia3EJwiBRKAgxrBrZM05CwlSA34FNDoGjE1YkINCpPHCYgwFE0xkeQwMgUMAgIxbOSqgoxnDO09ghQoMNwZUqtqAIzRkbyZxnKGasJQCXoA0IFONwUwf/74mTahv7uZMUT+85AAAANIAAAATkNkxbP+0nIAAA0gAAABCmNGcGTLG6ACIjInNFUyLE8TNlM0UGFDRBGIclItUKYA6YDDl2O/X6iBFzAQABkwNAJyNEYGmzIxzSQ2o0mHMGPDTjJXAIgwZwRnMIODkDAmgKQxegPDB2ABNIxCwwOAtjE9KGMC0BMx0QZDDGAsMHgiYweAwjFLBlMcYFswYx2TGABWMLgYsyXQJDDHLuMzQBYw7QUDihEjMMYXYzZhSTC+EJMcwmYwnQQzQlHwMO0C0zIRajC3CvCwCphIA7GA0CuYDAJpgnAiIxnoTCSU2787Yo1HYowmBYqClgwWkEkhrY50yJpTRmkR3gJtlBo4B7pBvvxrnAMIGnhmb5mFNmvOCzkzL86YMiAAgIHYDUEDALkBYXcjAouOGGiqHYapYz4LuTNo08U8UpR06IQJmx7Ch5om8YQADSZgw5hhACEmVSgkAYkgCAZiAQEAgkShurChSARocLMUKZkVBaFywY0LC4VkKNzfmPCIymQKJiGCHDopmIBErrCAJeYyIRA8BDy44VSmVHGMBGXAgoABiAKXtGROMGCBAMKlDCkRYkSlm6qGoXgocxZO8MTgE+TK0qWuISC2jasXEZg4RIQgAMHAqcyKdBsgGGQAloigCNCw4GYoyXiFDIiWsoMEHLZhCcw543R5DUMRhwKljFJiHvEVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQAAYwCMA9MA8IyDLlA9Qxi0QxOj5CeDE+RCowkcTrMKfC2jGBgxkwTMCtMWRCQTABQGYxVEWzBwIqKBpIJAgzAXAxcwOkAtMETA6zBegT8wKMNhMFMAgh0FrMDMAnzAZQm8wkUBiMCzCeDEcAS4wTMRlMjbCijBLQWwwH8B8MFuAgTCWAS0wDEEfMP0AzjAPAO0w9YDiMBtAsjAowIMwEkAOMAlARzAegGkwEIBvMBFASDTIcxshMtEjQRkwRCMXCAsUhJCFwA0ofMQIzBgwFH5CuGarwGrzKKU5y9NzKgCpmiH5sSCbAtmZK5RtG9vBvLACRA1MaMjFDKRw2cdMJITRFc1AtLQB1IMJMcsMLIQhKcviPSgSgwlQs2Y15pGmmodsBgkhZs4jUmxr4BtqChmpmKEhgMKDHSJ1a40gzVcgQW9BUAQEJ7AwlSbpF7mhMkaiiqBlk1S55CMn6tEsgYBKioUFCh4KlLuGAQgICyARExQMXN04hEUGYPL2XF6wsar9GtyGkRkEKoQga4AhBxIBBGCCoIBYJ1CEvSbhKSYFLJjA40hHGFjJQNOAin/++Bk1w7+kmZFE/vOIgAADSAAAAE5fZEUT/M2yAAANIAAAAQN0BYiXqFCQQqmWgJsmjCSIcQ0Ui3NtktiEGpIvxDcZitjK0NF4wAoFTMIkKmjLNAssxNxerM3FMGDDbQ98yTcECMCHB5TGbQPEwNoFYMImCWjARgCIxUYM0MEHA1jC4AoYwGUCoMFKDWjASwLAwHkIZMDGAVSoHumA8gQZgXYSuYA8BbmAUhLJgqoHUYNSAVBg8SYH8JTmNlBvxgcwP6YUKDCGBcAdZhO4FMYBcBvmF2ghJgVACAeHtxloOGQiiYpLBhc8GZjiZQLgEIRoI3gESmERcZtDxg4yAosmABYJFQGCsGBMSAoCSo0ITIZXARlMYG0wGFBhIDIdMAgAWBRMFwEGTERFBoiEZqM5g0xSAQxBggNmKBKKBUwaKisZl+jAQab0O9OoYCGFox0khOeo14iZYQmHUkIiywsVmn60MiGFUksnKmmZrwGDDOwCMaQxacwDEA4ELqmakcIQwUFAjMTrEw5hLBly/FRluwciAgBU8StFmQacBRhQAVbFVRZAve8QNMDugsUzUQlGMUMhHccAjh08fQLMlkzUqMX8YSNUgolcMs0t0xDRrcoSZ2i0Izg5FTE1BUSwSQKQMmcYtCsgzijcaUzTmLCIiRA2Qt2iaDBwFGtIsuDgjSbN1qHwgASRKoggASDVua260WiqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoaAWzBoEYQxxcUOMGUZqTp/DQoxI4bjMQeFwDAMAxEwoQQ+MFpBZDK9LXMMYFQ3tzHTDLCyM7sm0wbgQDLJHtMIAEExbBZjEjBVMGAp8xWR4TFaPNMXEOcxDDITLNDdMM9As0gB4jClCiPkQeIyri1TU0C8MbAn01YB5jGqE/M4ooIzHwnDQkLfMEkGQBAuiQd5hjCXmFIEuYDwV5gRAGGYMZvLqbcNCS8YKxGaExgx8HapgQOcqQGgKQjPTMi8wRPMQJz2YszsoO7+xpINv1DEBwyYsNcNzPsgIuDn642hwKqAHiauTAwc1hPMnEQESGijYWAzHzIkDAuDEhOYATixIYyEmVmgNMzDQIxJUHAgyo+MaLQsgGzCBko8ZEQGGIJl4gZMVmXhBhhCbmToUmDkIIDCiAXeaAlBwsnZBxdcOGzHiktMpgY6ImOFRix0FQ4wIECgUYwBKdqVmKAYshpkgUXBQgZyJiIGMcFjDgELgxg4GEHCZzFhUCZgYSGI1GDhgQPmGAxVF3IMBBBIKS2LJDIEl+AAdEFBOqZAGChgOAZxsBQOF/YLGRoDAFsHBa/iYXJBUQAkDI7rmKABeAgAZktoxYcA25CwemGUAKxRIljBcBoLvP/++Jk64/+ymPEA/7acAAADSAAAAE94Y0OD/NYwAAANIAAAAQT6gwAQClME1RdDPjxbEyARB+PsoH9zIHgVgzhAMhMO0DcjH9BgUwZMHfMBuFCjA9gQoyKwItMGHA7TEXgkMwaEFlME2DCTBMwS0wEkMmMBdAdDBQAK0wvMCiMDMChTC+wHQwbER/MRbAmjABRV0wi4HxMA0IADLAhEMwWYJsMNkC7TAbwgowUYQxMDmA9jC3RT0wMcBQMNtDKjBFQBgwJ8BFAQHCYDiBkGAZAJBgCgFAYA8AHh0tNKiIyKdhoZGGz8YtHZj1cGHDGAVobJJxgBAmHRWYlBps4kBYlHep0YhBpuy7K3mBF+RQEwusjTgHNRtY2wDDPIENYCY0UMjT5CFRyBR8IxSYvEJigdiEDpogYxiMOgUCiwiFCMXGMJGYwoMzIQ+MgA4xqYDNQkMFIYzEAjDpeNADMxeLjDKTA6RxgCa5kjxoGZs0AYWPMEMybPSFJSxmQpMRBgdbxjkRddKpGQkQCMSFZQIBIJC5YjWGAFhVaaZYPSA0QIBRpnQKom0YREIRgUuZJQHBgSCThX88Bews/TozAq6Y4mVRaiycZjTCsDXB7yGFTdDUOoQhDCJlkocJGQjTW5O2Ogkoh0cCoojCp1LJMIIVvMMKUgkGNAE9lqp0pijxVAOnfIy8TEUqkqWAgpmMjg4I4rpNOeqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAFsiAhDCHRHYz+kZgMpocFjPcht0xdQVUMMZFPzDjwkEyAsGZMK4DWjD3AnUwaYN0MXrBoTDeQIswvUL6MEIAeTCJhOowM4E2MGJAIDBAgLEwMIS8MJABADAQgVgwTUB+MApDpTCYQPMwF0R3MK1BDDBqhuoxysKVMBpAqjRchjZVlz48tDV9VTQPLjh4iDkKVTGQMgEgZALhiKSxgmB5haDwOHEwEAYwHCMwxCIwoAscBIxNCAwKBAxBB4wVIYCAAaIwBYwVXGxaB088LioaTOckcbfEZEKPWDeETkUzkFT2YzFITGgBAZMMPMUlEgIVBiIEELgQQGRAGAGEJJ5kS5larWjBYsLCRUeJRQFJMQhNsnGkqEYABGAUmqKiEwYxagJAR8YCGVRGDCGYLpXFaAeDohp1mnUDwxr7KwcFJBhfIvcmELDyAEXbMEXLhhcAMh0kgEhHpBhBoOuIBTkES4JiCaZjKQ4eZYE4ocKYyg8CihkQwjDOsMhEiX7BBI1I9AEGHgcBMGpLMmdBmwDFUMnExQQEQ4EYUCAAhoyIFeg0kGRTHowYZGnZNJNU5DFJhgxkZ//viZNqO/qlkxRP91SIAAA0gAAABOjGTFE/vOIAAADSAAAAEhhiBZMu+Ag5kWiNYJKgwIn0GFEH0IwsONURiyy6tyosCxgYAL6YPCJUGIjkphpF4/yYQaLmmCJAEJk6YVwY3gGfGCqBIhgvRdcYpKCWGB/gfRhUI6YYMOBuGCOBqJgTQF2YRiJLmCdAhZCErmAqASZEDfGFXAn5gboQ8YK+BSmAJBO5g5oF8YB+JpmHqgoJhNopwZGmCSmDAA/JhtoHkYCUCpmBSgwg6AimHvAYJghwAaYfyD0GBXAjpgEQMcYDSBhGAyAFJgHgDcYAiA+GAoAKvDjDg0FSMAjTXiozM2NWGQsbGMgZj0ccAHG0MRhQKCHEyc/ODezJWMxE8MTFTVycAh5CsGcHxpTsZ0gGHEhgoGY4LDxyHFRlY2BnYzU3IBIDAxiwwY6pfs3wyIMBMA40KzF70BgWLGElXmYS18xz0/SaNAWjuKEGyUY4IgBOUEhFLVEpTMCz5kAEohMqm+aJIoqxIkABJ6W4YuWDVXLcAIyYg+yIjkPQIGmoMHgQ8zLhexTU0h1aTcWd8iwDhjBHXmYQAGIdoFPGmmLPA0cxXm3UfCoR1nGSmDzHCIU0BKBEGFmein0jcuVp7BHYCpCCoZuYD5lol0DKvHgQcMRGhU0uQFBCqMYgyepUMNcNTEsws4mFATAGlSaLCbBGxVLuVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAABKMMCAASzBOSKU3isI9NNNOhDQ5RCswU4OpMBGFCjDYxSEw/wIVMCeJNDKEI4MSYNQxdT1TDUBjMR0v4wVQoDNYIOMZEPAw9AgDAhDDMTE3ExsAazEBE4MDUFowrBlQwc8GHFmW2L8YHhgJvIg1mJOPSYEgeRhvhiGVwIiYpAiRjMiPmEqGUZZwEokPQYOQT5gyAihAKpggACmB8AQk2a7ACGgOIHhCGlDGXLg1gGIhmkbpSZ4oKHDSpi3pgCpvqpsvJ1MZCuB3Mw50lWiA6AhRiEhizQyKGDwVNGHYLSWcY0GlSiSHRzGjUxzGPxGfIwhFRNoJKzgWAocCIyOFjRk0IjIiTFgDAADEAFxJuDJowBJgYOCJymCAmFLg4wXzKglXQIDLkFjwKKF/0nAKILAoi1lQWhPMCBGm4wOChNGd7GcgZiX/EBcxj0aarXDDRiRoOAFlEAy4QaEByMs0rcPD0wTCpE2WOJ0q8TPSYASAADwUVdgHASqJCBJZkVGLqTdQUeAxA14AoXMaaZ0YcebguYIiaZuZP/74mTMjv4dY0Wb/tJyAAANIAAAATjdlwxP+0vAAAA0gAAABEQ14BCyIABD5siBpQQMDCoEwBwMMGDKFRMRLk5DAiSAOBVJqBAGDBw0DJCuYWEF1GGDrP5uexMedZoVvnLvjBhifosYaHsH9GLoE1xij4HOYQCggGNGCRJgOoqgd6EOQMDqMQECoxShETRRPUMowG8xcyCjBVASMFiFUxFw8zGSGBMWoHowpBDzGqA8MOV9UzzwnzKloxPzdiIw3zXTdSJ+MDAogyQydTHvAHM985Qw7QTDGQJRMMoBYKAFGDcB2AAADAGAZAAHRhAg+GBGEcYPYGjlmCeBYIwBTAuBhAQMha0eAGMCYFM7SkCpjAgBEVMOCNugNZZNsrMITMCeNqWNdRO9LEmgyBToMy8ATwxJISLmGDGjaBDceap2l4zGkmQmINhzVZxhiICUmDPGbCOOxwRljNhzLFw46s8xw8wBo0CVBKyk0hdQ4yqg0YyChlgWsNCmBQ9LlYcsyYYqI0AOPNLXUYNMacxD4CIs4MKZNkfRTT4cNK1BAAjxc0WSuAW2T7MkdYIvGUEIBItw2vQABhT/DIpiUZa6mIYgaOBEKkJkFiMgasAmuLAVDTMEUNIGZ6qq0gusJEwUKVcIhYFeA5UtEyIoEjjYphQYY8MYkEOlTCAzBgDApjSgHeYeOBk6jRHwhSy9QIWGqxSeWS+xtUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMDfEGDCXIFM9VFjMNI32kzLdlN4wNM3eM5IJKzKACasxWQKUMIDJVDSGCLYw7ERyNjZQXzA8wZQxiIKgMFXD1zGSi3swisCZMPRAjDAJQEswxAOlMUPBxzABA1AwnQCwMB1E0TBWwfcw1AVXMk9ASDDeDz0yNYTkMSSE0DNZgtUwE0NRMhrEtDEnAwIxrgT5MKiAjzC8BRQwVgALMEfCDxYF+MAAACi6KK5gEgC4bCgmyZx4xYZc4AqBONOTKiM0dPCrUa6gmiJxk4eFRkwQYB0gbqgGG15o4KBDkuKbSNmbuI8tGSORkQIZO0mIjprAYxcwMDCg0bAMBYiJkEEEZEhCUr0miuQFi1Rmhng0VTFAQswgAACCmp1YMoNtNMqPiiJljn63YNBAdDO0dEQSHVwEHomkQKtKLRgqhcMbLAjBRYZXxtBGwcHMgWVhwKPABKsYhLAU5ZAtqrIPEGeGFjrbWgdAWuY6DW1lmqIZL4DzEI7CgZAHUCEVWhS9/zCCCxSerKlF1CCZYoDKDgQcgAQCjkQCsaoRIGlsLhmGuY5Z1rhQoYZMN0SXVuXQkEW+BIL/++Jk2Q/+T2TBg/vOIAAADSAAAAE7OY8MD/M4iAAANIAAAARftfjAG3QhbmVgC0RyUA6kkCUjGn9mcaxg9YIMYegkFnToDzByHoVUccoQqGB2BbhpAoJmZsucUGRsBAJhD45EaGoEXmB0AFpnBRysYOAGUGFPgzJgi4CaYf6OxGEahbRhkwa+YFKAhGDoAvQ0KRGAlBi5gyAB8YHsGtGEDhGZgTIfKZJqBRmCFj85nGQckYOkFEGIthQpgaQQGY4EE+GByhABjy4euGAQhhV4oyYE4B7mCnA1hgLIASYBOA0mAdgFRgFwCYYAAAxmH12GHUxo8jKAXMWF4waTDAokMloMxYSzC5PDiwY2IJh0AGEweZJJpwoEmNEGZIBxn4WmBTCYoLBk8aGEB48ph4TpjigiMgA13zAAxBBKMPgUxQDgCCzDAhMFiMxDyqUbB4UhIZDJeH2wNcUQiOAxCRQyHzRQFVRcgDPiUg0icAgDHJuz7nL6qxhnBjDnAinaawilSMo6KjKhNQnOgFhQp0YVYMGEYBZk/AAM+Dkl0J1rpM4s6ySqUFTUJJqLlgAykiIsSbFSS/CLxznKuEKAQsBiy44WCQyGQjPNHmELgIGgNnGXmEmaQYQ2bRrqoZpKGISDBjkGUeNAceBNMo3mTbHQqBA5zND06w6CZIJEUwTA4FhAgTUvQTg9VX5iGp3gliBhpzOtPLJMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAlJtwweQgzEoMlNqVgM7anaj0KJDMTwaUxfxdjQcERMgsIkw1RUDNgB4KASTLZSxMOYDIwygeDBfCHMPwWUxAAZTA+FCMJUG4wWA9AED2YKIRZgUgQmEeE8Ys4Bph1AcGP6EMYTwSBrGB4mFcF4ZAoLhg7gImD0HmYbgARiNCbGDACGYEIuBgEAxGBKCOYGYIpgBgQGBMA4YBIDpAAUaNaaRIETQdHJSAKImDKgJsawyZEiBTRjChhzprQhpoRg355YZmnQaKNs8MIzOSPNs+NQHOmxESgBmDJGEiSJUZ4YDCpnTIIDCgky5M1SwMmYBhcF0VThjAy+aMJA6UPghIeZM8UQgmYQj6OkiRIyaYYBsSCQhqpmDQdTQCbFsTZ1AxRhDMlbVVEHNloEGlHhAKXGEDxoLwAvh3UxyI4vo5AOTAAydgGHGlghct+lalWoELCF0yQNAkgmGBS5aKaHRJgEkxohFQQJIvanmrDAAwIShJbgpZlyOQkHICwUlAXCT/RBNgo3wwIYZgLS2hKwtLf4zSxGQYhQ0uDRoiiuXVAqo0cqoUOih6//viZNQM/Xdjx5vaziIAAA0gAAABPVGRCg/7bYgAADSAAAAEhhQ6+7j9RGEjgspg3hWKfBg4EGgKE7BhURlKYlkExGh0BqRoU4TIYWqN1GGjkQ5p3gUMYPyHVmIYImRhAAJ6YgyAVmA+HKZn6Thk0hmmb+J4Y5wmhhbibGJIJ6Y4iHZp8iSGEgX0ZEYIZjlkXG8yRaZJPbR1KFNmQYvKZshrRi5BPmy2MuZT5EBiTGymLiOUYuiwJihC3mN0JoYAwPpgtCtGD8JgYpYIJgSgpGGSJCDQbjAFAyMIYIEwTw8zBxAVMJQBQqg1BQHsCAdjZGYe+GCShizKZpDmysRnR4NepvyWbMclAcaQdnQGxiKwbOkmeC5gVAZKBGaiqVZkwSY6OGQnJiBUKKQQHmuhRhRyGARp4CFSYFCgoLCyAmsh4AEMeNTCwgQjxawvwVTBTEiJhYKDiI0RVALoFAM0YNMyAjIQUysQQnChrB5gAAOhxiYO11V4hJSIEMDGiIHMbK1BBgISCMSIUqBoNJi0wAcMPBhAGs2MdBh4xHBNAIY2Ag5rLamHiQOK2BIIRZYLAMYmBpDmABI8CmVixc8QmJEZCgsIQFSZWRAkSCCcSD0oC6aEuCBIxCCkHDZdUiCwqAIQAQfMIIkB69A47BgGKgIhB10GChoGNTHxYlAUaiyyRJEGGICEPsQXoYSADyA50bYhfxG1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwRUF/MKkLvjNDWMU6y1KAOtJKETA0SO4x0wjNM/AFfDJdg8EwlMulNz5IMxwRBzCR3RMOUksxpjDTC7APMcJVMwGR+jJ9VPMTsYEwgQBDAWDYMQ4mEyMwsDGKUcM38VQwWEeDXPDWMCCiQ5y2mzFdG+OAhCEwNBeTOoLeMhwfw14ToggYcxQULDAYD7MSkDwwlg5wKD2YmgaxgxADGCGEibYTHfHRvwsZqsGfp5mUWKF5kYCRFJ4oyaqim00IGajKlY5IyOMGjrCIcGDRjQ26INOUjqlY1o1AieY26mNtpl4KFlkxQdMvQRpGMbITBx8CiqDRgRiAAMqF5kJKY2PmBjYGHAKGmHAxlBEkmMAIGRWDJQAoACCQxEERoMKESYJKwgyMqNYCh4IAgaChYxEGKw8eEBAApEmXGhjSAjyYgFskMUJjGhIwAGW0YSDmHkoBEzBANGMGkJg44NDBiIMShRMlhhGrCkeYSHmOjZILjxUJDZi4+YuAEoiQGaG4MAwSIEIkMAKHRQYRBICHxACggJQEJ/Q4gMMQFjGghGkmEyzphoQECpYGi2qegcPtmMDBgg+JAErEHGT5aiGGqIMShAhAHHBx0PDACDGvDgaDh//74mToDv8pZ0MD/tpwAAANIAAAATudnxAv+2nQAAA0gAAABBzgEEkxqWkgONSxpLOHEgS9dp6fNATAIAH0wTk0YN22MxDOgAVo37sVoMNHBKjNKQ3Mya8YPMTXECzBWC9s1uikDCBHhMZt5Ix9wKjETQiMJ4WIwaVYDHMAQMpoCIwoQ6jEXB2MNUKwwqQCDArCvMVA34x9xOTEKSEMcUWgy5jIDvvNLMccyYyZiqzAxKEM5AJsxBwzzZoHUMnkeoydCczBPDAMVADYHDbGBCD4YLQKpiPA7mFACWcC3GqkBmhSbI3mqM4JpzCAQ1NoMlsjSF8QqZKhGZpBzbMcqgGii44Jm+Q5t7IbqiAYTMsNzaH02JLGR0GlgVLjIkUxohFoUGi5cFFpPEUIAuRA4YIikwwJUHDAozEcMRGgUbBxcDhoLiAyCGAhiBQyEN4EBCvSyZjYkEG5gwSAoEyAVUXL2CwGYMBl8lBkOAKBlWGBAZjgGYkEiQUBgELBpmguFgtXoGAjCwoxkQY6j6HCNIvsxQBUTZMrAYcBGEE6w6SBg4IFhECAjWUaR4eXUWhh8HDjCVMlJJloYhBchJeIyIGJgoLgRgoQhMCARNIkBW5GFg5EGpNCwEusw4kM0Bn5MRB3WQnhQLMDB01RYCSpBAKEFICD3RMEHyoVlmZeFgsmSAYMoGsrAoWLBIsEvFLXJa6/tnKmpkxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMBOBLzBzEbY0XtDrNril6TE/DnIwcMi9MdhHwjEVCcoxAscmMCyOwzB1BbcwMwI/NL+HEMPOMGxeswfBPzMVg7MEEW0wZDjjD4B+MS4GYwNwszB6NaMWsQYwPz0jK9DsMBFvAzYDZjJxV1P885Axzw8DiFFsMUsRM3GQEzDJDANqtNEwlxqDKjSMMKAHMxPwLTAFAoMOMIYwVQADC1CeMD0CEwSQKDBTAKMC4E8wIwJTA0CPMBIAMwOwGjB5AYMAsAYeCgOveJkxtjJqBZgh4qmMqWB8I4qwzhoDaiQQHFzA1AViUEGgJpGRtQxtDZghIoUDg5hABgwxAXIiBqRah48FElhEYIDYciJRoORCEIZs4peZ9iYIgCqAQuLfoCETDJADCCDnTSKCYIoYMsIDJKJQ5GVDAVGFg5iRqdS9xkQzEaTDQYwIkSSiEAYEMFh5iBIoBLiJpoGEpkMRIZrjCyoKF1AEW3+EIAeIGRPKNEAQxwwHBh4SIiJmCYYpTSTrWcowY0SFxDqhiw3/++JkxYz+nGPDA/7S8gAADSAAAAE1FZEab3dNQAAANIAAAAQg4wSgHIQKSCghWAeFixkwB0xAEYHjorMFCS4BjhpepMoAEygOnAm+LEHDUWMCLNEIMKMS4BUMFG2ymOCmfDCw6A+IvlwXZtFQEm3HAECqYSzdhggV6HiW7mf7RORimEJmswO8ZQSU5nuBmmGUqOaX4oBg9hMGhgesFAPDCWG6MCgYOYICMawiMxxdMtiRDCXMOgCMYGoBxemMCqGYpGGPLDHGB7mFfOndkzGDa9mZ4Rmg5qm5CiGQ4wm9zAGPwkGP0NgpjDBATWbAAATCcEwgEiACzBDGQCYU04Ywic3YJfJkkJdk0R9C1WZYRn5kgQOSg1QYKeDS5iRyZ4XLLxN3WNYDBRsBMTQKzLuDWCTQggEFBIV1jIh2TiSUMLIyBdYRZS5YsoDxYhFhhQ25IaIlvjJBQE/BzAx6RaAKGkTIIShUoAEYKKGaCIVmIGAZyJBwsUAxBRYwYZnSniAOYIUDhRngoULI4BB8WmGDJtwFsif6wxgwpfwdEloUYjGOjQGluDzIKD0lFbRQaFxYGHBwNFQRg18igIMbMWBwAFAkOJjxo0gEiq1yIGADRpBYjMJnDR0wZdnMCKKgIcqrDBADMoRLTmXFFUeCAKhwhEq0mCHoXiwAxBkwhowAEwhJIJCBXRmR48KecqhC4AYif2H7GKpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAASMG2CPzDeTGw1dNn7McwW1jd2CJMxToXWMH2GMzF5R6AxW0TxMGiHZzKXB9MckVs4HXbTAJEVMjMWwyMABzRhLSDlGTD0KxMIUNsxCBIjCbCLMKY2owMxAzAGKyMX0aMwgQAzYwDSM8QaM+OhETJyBGNWIhUwnw0DMaL/MQIX4ymUpzDKG6MbdWIwpgtzCcDyMCEKowegKzBNASMCIAEVBMPqmF2psWZ5UJ40YJ1GQimbdAUibtyZ0cZhgJBxCcLDgzEIVAkYYwYtQ4qmjECCwXMuxOoENafGnBrEQjSmtACoIy5AMag6+ZAcbAaGKTBhASRMWbNYSGA4ZWMShFFQGZmKIAJaMiwEJMILIhjvmEKF3wMVMaBaQTQwAUMQNJiwkMMOGacvAEhhGFLnIqt3Bw0aUAJmMBiwbbIqZB4DAwFTlCXykDEgjIBQUDRXCABhxBkwQ8JMEKFAq1kMSYm5IJJpLsnDAjjoLAk0CipQxJgwsuQqTlJghlgJgBo6ZAwkaDkxBV5gAi//viZMUM/i5kRBP+0nIAAA0gAAABNsGPFm9nW0gAADSAAAAEIayEby0ybivjOhAKiFQ5ek0BkxgQiYGQRgpsYsOFyS8QEJIhBhyw0NHm6poCAogoAtYXeg02BlziQdtYApNNww9RhTLDA5Oj3V4+BJgjTFebMe0aA3/R3zVUK/MKEzgwfAEzf1GdMIwMM1qlojA6A9MegGEAA6mKsSCSBhmAsIuYnIGZgJAcmBACoYFw6QEA7MKcWoyWwEzCdLdMlgfsUUMM7w28www6DJtKHMJ8LMzmxFjANBWMeA5oxAw4TFzNtMLIGAwtwFDAEBoMEIIhrwWAZEgEhUCgOAFMAoBcwgwMjAdB5FgIgUBMAADQEBGFAFpEIGhLo1SzA/CgqnIpeAojBdOtUkPHRjcFPwIY5AVQWQKaqABEQComPOoGjAhzFGmmRJnEaSuiVpksgLoD8mYaKJn+sAojCeLXIWOssQw20Jxirm/KRggJ0ArGUUOriRaOTLDCMXCWFQUgiqr0oZTyHXUhC6xiIlaZYVCSwEQXwC6gOaWMAyQOMKCFUEwiQM0rcYJIISESY9W7JapBEY44JFpTgFCFQAk9JnlNLCxQyYIQQ+M0RwSGVHFNQUyFAxp1BIDCVPqxEyxppCwcEpS1ojIGiXGeRgRccEs/QYOElphy4JEiI+agKa0Ch6GUiAwDTg0kWQ/piAZZRYZ7IS9aTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoG6rMFGA3hQOBMq9HwTKNwF0068KrMBJCqzAlQz4xBUEpMNmAOTBHgbQzZRvDC8CwM8FO0wcAhDCJHwDBODClDuEhEzBHEEMIUEQwKAGTAuB4MCQPIwqgWDBDGAMacA0waipTFCDHMNU0I1lyGTEJAmMtEIIwSgzzLAHIML4KIxDh7zBCDzMEolYwugUzCEClMBkEkwgwd1tmBGBqVQFDHRADBogGBJWMgOTFyMwkhBoyOkhdiwY8LGKCxUCzFiMxFPRQMURDJycyVLCgYhkCRsy8pNluzTykysRGgcWRmWGIDxlRMJFMXCDsAhwBATBRVSAJBQKABUXMpJQgBHA5p6RxiQgEBgOBTIQ8w0TWuXGC4aAh8RBiQi5QSKmEiYshlvmQI1J7qTEQU46v0KFgi47CRgTTGUPLRJHocjDBooHlCQAAFuHZDhshDQgfJhdCUFhUuVBIQIIVCAFBQGXTYCEAqOMvfNEtPoGAb3Oip4so35f0gA2LQMwwu4/sMJrKUBgVBwcJRmiHgZb6eRkIqFARLpkJh4ePAoQFmCjgcPhcIAxwDQP/74mTTCP3MY8aT/tpyAAANIAAAATu5jQ7P+2nAAAA0gAAABBLxAYSChMdAAMcBraYIYH0zbWV0AACxg0YKIYQShZmkGpnRndJJKch6VMGJwhxJnLwZ0ZYMIgGLzhtJgIRFEc3qXJhOkfmr5XMYEBFJhns7mPMAiZVQtBjzAomFeV8Y/gjJhcBImDyCiYZYZRm7A5GFYUMaeYU5hpp/meWRiYxKaJ+BmHGKERubMBhBg0BnGF6jqYZYJRnrrYGCOBgY5KqJjyAQmB+LsYIAb5hfA3mB4DeYRAEZisCFm0oBmJccOFG5ghqbIF1wDQwqLmGkpmBXfMPDWGBwWmuaI4muJJrkKEIwQmmAE5g4UYOnGZoBhJCYuzmOmYYjRcmHBI1MRBHVZsYAKK2lwwgrR1KgMkcYOEmFlZhQCYcJkhAGIKlhj5IYaVCyW5BCMs1BIa+IUFzZBF1xoGDAsVFTGhEiIoYQlIczCRwwAaLNg0IMEChAHmFjoMOgSLGKgwGEDCQowwJT6MVNzIBQywaYIY+Dg4PMqHgYVmhD6gANQTGBkxASBwsKAxiYuuZGp9jLg8HNAFOQEZlYk8BANCQgFw0BAYUCgEJBcaRLbewPBhgwWUFI4ECRg1JLZWEAhqhgVAAAIo/CpSGBRhIG8AqHBUSDkECCRAICR0EPwNAgIFkAKEEZgKUYmFjCckyAQRL4QhUkb6Cj6kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowf8JwMLbcZTI4FV84kSJtNzYTMDAviVQwaAWTMirKITELRiYwM4uuMWrGhDBSANQw7UuPMAVA1DDqBbYwK0CQMMbAxzAsAQcwa8TdMF+AaAYANGBtgHRgZoGmYhwD9mDYASBipoPCYGSIvmQLhFJioJt+YxcHhGBNiIxjCAR2YGuCPmJShbBgcIC0ZDsMbmDdggZjqwg0YY4BwGArhI5gTAAEYHwDcGBAgFJgToJOYDIAuhQ2MgWgcqiUsZnGmhGI9HHQkRkpGYkmG6JIMYzKFgzwwDBQ2U9CIox6ANdADRIAzRAMzdQWKN5wNgONB1PmdHIZE3EE47TAweEo9kS0wKMoQK/DBTEQ6sliYAEEGAUdMGrBBoy8kqrDHEhESNWcN+EMc+NstItJgDi7wGyMQgKpgyuExoUxKwiFwGZQCBQxmRpEkYyJCzKy0RAKCMWcMiTMEREmhljhiBJwjxlSrczfBjNHwcXBSYKk0SBo6EPgKACgYcPAUExkxgwDKFlCEgFQ4IOgkWIzwCShBAkGGaJAxEBgSQoFCmDAOOAhZgEQVEmhFkBoWjhmpCax20ZYIZASNGzBCVuESC+CDLBIYEkgXKGUBKz/++Bk5A//FWLCg/vWEgAADSAAAAE6uY8QD/tpyAAANIAAAASIJhQyJN1dJFIJEPAQFTrAxcwQYyBNazFFqNmAlgtBhSh3WY58mkGJjmjJ0sgjYYpwFtmbOguRhzgsIY8gE/mBPDcxkGGdmE6HKZhyRhh+gQGVCSGY1ASBjNHMmD6EaYECDpijhDGAYCQYUQaZiFiPmMwPyYgxMpqGh4mJ0OUbpojhjbBqH0oFyZLww5sui+mCGDEaUgFxg5jUGomdAYMgiJj5lLmMMFsYhAaBgBgAGD2BaYLQCgGAyMDQI8wQVOOQTJYAwkTMObBQGMYbz07IyBBOVDznnkzgsM/TjRwAwAPNYRzLZ42UROJoDY6kz4VNQGwaOHCoxoFidcUmstAIKzLyA0cwAC6aYEmimwOWxABvESgoOYEESK44AQUTDxhQeYURBwaYKBGYlxQJmTC4UAzGQIWOjHkUxUJMwQS1Ji68ZmImHBIcgmPohMtmQgzB2YiIRCwonuCBNhxigSPA4kCGJiFqfARMZMDiokpeYSBFuzBg8RgwgAjMR4wUEZYPAb9AYOboFhYSBC+yxwSFKWwhMUGABdUrBDBBRAC7wVKh4RVVcAKAYhAB4ZXKu4wMBKoG1gxEeBBGwBEADCwQOgQHTFLu7HhNCARAosBoeEQokYND5dRWVJMcAHDa0xl2iQDReEAo10mCi5sMM0n4dUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEwbEB1MOELxzd1FR8zuuJQOAsL/TGehk8wZsbkMFcGxTLHQ3EwYIqAMZtC8DBBAKQ1VT+zFBGTNB4ckxHBFjGkXUMQQBExFjchYP8wgQkDCMCkMIo7MxTQDDBuEpNpMU8xioFjUVCNMHXIg34lzTISMvMYI4AwiCHDYPNBMaUQw4ojnTKpEXNwIAcxvhMzG1HQMQgHAwhRLTCCACMEcJMwqQVzBTAxMFkDkwBAQjAMBCUEBQSJgbBRkIL4NBEMCEA43DIRBgv+bAb4KcmcausaymaGOE1Qm8Zc8NHTmhQIXPxFMwsKKpu04GKgVYIqJSaNAOMUcMAiUxMsQLxAomUKiy5mBRl2BnzKcwIQh2ws0ZOGJPDKnkZw46IxABEGLBiNSYtQRAzTDzSFDPgA60AhJk0JgXIFGA4qY0CZwKZU8BSkkJRZkAK8kE4ABkTsISlD4wwdCMHIx0+/IFAsNL4jwkcELCAgIBACQrqmVJgpWVRjsIBWVhhQxxIaEL0L6DAEOFSNmQsLMCPLwqbkw0aAoDwUSUUD/++Jky4z+umVDC/7S8gAADSAAAAE2JZsaT2s4iAAANIAAAAQQwsoTSFdlUIYhAVACchhDaXgybXImQvkyY8w48y5cCInnAIoDDAQOBRAvoFyQUQmRBipEwYwxJweAOO98/YsIwBWsGgDGNgPEdBykBvsWnH0+4OYA5IxuxCpmBeU0YXxRRgHF1GY8ISYLAohkeBWmBCC8YjY1hhOANmLiO6YNgJpgkDkGCkCsYBgeZgFgBmBsICNESlgM0yhxEDCSIWMlIA8xIRfDc5FvAQXhmRCdmDoBMYixFRgVhrGSGFsYJAcxjegxGDUDyYAAdphPgumAYDgYJQH5hCgemAeBcd8uXuCygmcAgeIRZWNAxQzQA+VARsw7+bJYZ9qYNMaY6d+SZygck0bIMaM+KuAkgfWmaykEfTqlwTFBs4zh85bccWGiAlcMLHDBlQcwY5YBEMABgKJRcRjY1GZ6KVRlCgJ9BoocAzYsEHAlqQi8RDFnRGCX0ftRx5AsIBG05liKDtgbwuy02IrkIGTdBMIxAUX1BRbslEasZvFIRoJBgMAmjjQlIFBhCahAMAmWchIGFQSQZgQyA8iWgGAW4KhssShC4YUbWekYXhCoKMDNjNBfBhwCBAqKtiDbFyEIxQSsEyaTGIL2pNtHBSAZ8I0CJUINRvRUAoppgKYDxZcJvmgiFdVjoln4kIg4gpBnUCP/NTlPpGpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoABGMB6AFzBlirY2/goBMeFPDTujwxAxKEaEMPxENTFPAV4xygUhMD1E/jKlF0MZEHk22T4DEeB6MLdNUw6ATDPcVtMX0FYyLwkDGAC1MDEZkxVBczBZOJMnoLgwbi1TFPFMMUkbA0wDnzJ9ffOeNX4ywQYzbPAHMNgegxEU7TFoKyNZApkwpgQTK4OrMTAMMxkAmzELBaME4SQFCzmGyCyYIYFpnaGY6RmGRQUSmfArCNabDWBc4NNMGHTgTs0Y6FmExihMnKDNKQww9MVWTB0cFOxCbGgDRo4kaWnm/GAJFDOSMcRQ6PFSwRFJjBWAkIWGBoZDBoABRWCumpgYIbDJqhUYWFBYfXMuUGgo8FAY4LRA0NMFF1dmCCJlwCYOblZmZIEmLCaUw8JFYQQgQXBTEyVWgs4k4KjoKPAMdF8QqOoLl9Q4RFQYw8IVVGAFP9ACXUUHRvCoCYUCgQZLOA4MBRsAgNVggGSQEFgNhqcyoQEJGKgIhGgSKJkkoOYmEAwpAQYFwkGA60DFAIRhJeMGACJi62RAADVGJEqK4GCQaChgQY//viZNKM/wJlxBP+2nIAAA0gAAABNsGPGm9rOQgAADSAAAAEYDDRwYkUmOCoMABUCMJAwcmiEcMERlFwQbGEg4snMDLdoBAoEiIVC46KChCIqOigMYUGNZQBxu5lZ0lAIKbcMIkD8wO5ADHQN6ODvY8+L2VDIhBKN20awy7ydjRHByMKoVYzdgpDA+BFMvQM0wXw0zD6JMMOMCIwrSvDBpDZMIQZUw8hCjEYBLMFYH4w6BfwgJUwFhsTA7GoMJoagx1jazMTZhM8AfIxcxtTINIAMHQP4yDSaDF4GIMucOYzExLzIPJWMFQGYwdQqjAqAaMD0DAwOAIxoPcHAfmCNvODHiA4EzhKealImSNLTtmQxGYEqGDwzuZUuPAgaQNkWNqbAMMzb8z9U5bMAmS2xkEBsjBy1Jq0pvTJwUoKpg5GoQzcwYEkAiyYBOwIKBgpFBH1L8yJBCQIhxnBgKSGSPGQJGkLA44BAaFhjpRmAQjZHQEGMIPaIwBjSjZkqkkUn2PDpNY6Yago0BCKRCAEMgo41TS5YCHEbLIUbTCLFkldv+OEBzaCZKxVAxSWtGQEi+r0wJCogi0XLV6KjpqpBJsjyYHCMY9OBR4KNhCg0ckec45ZtsUMhYMDgBgMXIUTdPEaplIJmFWwiaGBDzRBKrtA0U1A10kSZyAgKZE9DkRUjjA9OErmMeDBSyYUZMQdCJOm9CXqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAVcwPsD0MGYO3jLOiDMxkRzJMShA4DCJgdcxYMLoMVUBwjEWwpQwcUKJMSSBmzBnQgU0df40Pwk3IeEzJhU2ydM03fE0ZIwzjUoxDDcywKYzQT0zzQ481j025DE75is6gckp7c7dhw9dcA0XaI2FSo3pfoxeJYwIZg2lMg01QA0dIgxfEMw1DYyCCkyECMFBqYRiAcyqZyMUODUjzKITpWzLtDYqj4mggWbNwCSxjQYAqHXtH17HX2G5ZAkSaYOz0zLY4LA7fI+d42bI6KQwFE2RFQw2LQ2MA684wYIw4gEgDKKwUoM2EMqYMCHMYtEA8xQczCkZPGJDGFDJ3qojBUxR8uCZ4WZlAa0YND0rgjWpEuKjkDkgXCEwMaLphkIJWMOADAMKAwwERBjEFzEEwMhRMDExQHR7SrBIMBMXPDE8DrWEQsEAS3KWgwKh4RIF9KEIDnbaaPBjAljBhE5wMNb4eCF0E7mcSMxA8DFQIBQoHhKv/74mS6BP3FY8UT/dLiAAANIAAAATWtjxLPd0nIAAA0gAAABKSkTHBysESiQqNVCYAMlqvgypM0BMygsyAczb8HXwSPS3VjXGYcCAsIVHhikaCxQBLkwRCdCiFD8wIYv6aFMxaDGRSCKEA81mAUC8b99FBqjOHHnIcOaeogRjtsQGWmKobcZYhiUDyGRcCWfHNSAB4OvL7MZzANfjaMEBQMbn0MxybMmmfNag9NtDpM8TzNEEdMNVHMFWeO2BfNcyMO9odNc/cNXBCNWSrMOUeNoyNMSU4NyVoOAytMuz5MXz0BheEyjGCAjmBI9mLIQkRCmJIOmcKHXbGKAAKcADysYYgHHQCWBVUOQDVExQaNBTBQBGHGBK0GimiemPCw4YIuZzua4gcCKZZGZJCTDzVmTkVjMkEtjBnS2TxF6BIaVAKExDIyQYhKBcObJSFA5lxwBIkCcCujOoAaYMkvDootiGBAVAgg+GEDACGQl/CyIWNqrqqCMe3EIEGVErFSyUMY+FQY1JLRDAEWHGOAEiFM4BEFcAoGQGDCBUkQcOQmiJGYpKDQ5mywiCpciAEMAzGjQ4oYcGPCBY6HFAANGQ460GgZQNBg4RggxIjDEVRPKYcKOIQU6bMq4GGE6TBBBpEGKyIIZgOFyMnLCMMpmhCJmoUCRELGDEnQ6uYkUYklGGBCAGakkQkhCYOeJQBiEMHC2/rYwExBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAgAApaYwB8DrMD2d1TMkBkU0bkfUMTiARjF6AnkwM4GdMLyBIzA+grwwm4JXMQKAvzA5gAMwwMNeMCFAtDAawMM39AU4LF4y+Us1bTYzGC0zEMQzUSMziC4xx3AwaOw7yZ45i8oy6kc54NMDKSDh7NA7YMnx1ME3DM5Q4NFXzNFUYMLSRM8BUMByqMLgTMJxsM2yFConmNAFGEAhmAwvmAAlhAzGJIPmAIEmFgAGQgJGIgtGF4ig4jDCQGzDgBwIAhg2BRVC8wLKUVC4w8FExSE0w+A4weCBCcaY6HMgSUMIfCNYAEGZimQSmkLGkHEWYx5MgEkBgyRoyxowR0iXGldmfMiTkW7CFaQhR1SagG140QQxrZaxgDYMEEo43LYxqM3j8zRM2KUz4oHDTEpQKVKg4mABQubk6MBQoBYAOjDAFjUCywAFjRgC5q3wGDg5AYpQmQZYeY4wbA8CF6iZigQ8FMUoMwOIRgFrCyQypQyZgRAxkenKGBh6CsAYIisKXJAIIwA4iIhRODBCC7KZIUFLxlAIcKQ9fgcEGCZpBmDEhAgcFGoDAIWasaDlo0DEBlgyNwgFF9zH/++Jk3ID+zGPDS/3TcgAADSAAAAE6JZUHL3NTAAAANIAAAAQAjSJwECCpkMOozpXEMIEKQK2AW824oMDDBoOqqCvdbmAkQAGQBNEkbkwVvUDx7JMPQwnQ1cDHzEmNoMQsdA1IQLzFVHMMisqk0uAJDDBC8MRQqMw3xXgSJ8YFQrpiVDGmBCFiYQIjJhrDTmECDkY4Qw5g/BqmRgcuZVQ/ZhKDlm25kZpTRgoiG4Tub0JRimHmzmMcrUhsaBmvtqdRRxqhWG7oCcTVRng1mPxEaPTJrIOmLCsZCE4XABi4GGNUkZiVZi8bmEBmYGBxjMbGBRMZQCBhQWAIymTwqZBFBkkeGGwyZjRYyZS2gMMgJEgWKExYa7uyaVGZAidhEZDkYUUY98NMA4SbQoPLwCKS1Inhr2glGEQgLkTMkgKLMwOMUNNiNbCa94Y4WOH0+TNiiUcaBYHJDWRwE0AR8BFQUHASdfwgJCASYI+iwZUeZZOYw6UTlDQumAh4SEOYDpwjDDRYChhQiY8kgFMWSEA9CWbQERFBCFMEPMkBLmlDJvH9IhQXAAJwXYEiwNNgk2CIQCAkrUxhALl0BZhSAVQGNIEoESFmZJAoIWbEQ5h7UjMGxgWCsYBAmhHqqGQAGRdmMCmUHEIIxhwqIDNUzFn1Lg6IYeKaZWAEZARayPJjIo18lY0Flw4yY8QZaICrgYDL5y2nmuVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAgCBjPAseZ/mZAmUEKqxv+Dakaq4cQGN2B+hgMIEgYSAJ8GAECL5laBkIZm8LzGHNAwgWBjjCPQD0wXAEJMGYEeTF6RT0w5kKVMQZE82yTaIONA/w0SkD7YBOGnkyutDPkDErMUqMwaXDF5bNZngSlRh0DmWz6cFAJ1uLmOVQY/CZhZdmaTIDhGbaEhjMbGTiKY+LJQLzHIuMejIsEoz4gDCoCJBcYXBQAExjRQwVEdQwIsypczBk0cEybkkMmqCCxM0K81Y4NPCMATQjVsQEmN0/JoBbE1x8xBEy5U3S8CGgFVO7+AwUM2ERY+g4TIJ4G7GmCnD084BwwjMLkgYgKxJiTgWaDJQWjGzTC6ExohuBlhBmzI0rGixcI1YAyRYyJg57o3oo1YowpgHaAcrFkq/FSiQQRmiQADlKsZrgJq4BjBgKFGDRnMDhiiAjCgAYFVXMozATMwYoxBsQijkgDUh1E0bSLkb//viZLQI/k5lQSv809AAAA0gAAABMfGRF09vTkgAADSAAAAEsYZIaIS4KqDykOQQo0pYEozJCTLOjEtDXCAMNet9C+wClNSCjkFVznkDNljAkDHAQxCCgwjNAAgYwwHGTJMyAiODzEtAx2W+TqZeyoHKTJGW5gtezxOYQkQVsAwJTaW1a3YAIjkiTMaMtY6KOkz3NpKM/z/M07HFDLEFHMLkWMwlCSjUGC4MUMk04kB1zCuF3MNwR0wVgejCTEKHg8QogsYqoM58Jya0Mm/G4M6TI3U++kMZVAhCMaVLfAA+ZISZYUcQaVgjLgjIAAagPRrOKRBTsxDwEFRIiZXEbcGIAACNkyM0QQ0ycz6M4yUZWG5EBUQj0MAAwcBgKlwceBxA161KoFBk6ChYIAAKChEw054QkDGFkRDA1TFoDIAzRlCUsSCzUHh6KWcQYIAAKdgZscNYNDRVoZASOgwUpBJcxwFMkxwYx7cIKgEYAQCWxrThrBZrAYMFhRQEBgMQHiwiGlA4STGPFusXbMorUJAg8wItUSWD6tRbAgoXjR3VeiaqvDIiFAYk5hfxlacCc9KnEyEiHszCh0OFmBCLlhAiAF5ywNSuHTTxMUW2LDWyGPJvIIAoFGKFFyEUFdP7Aa62ImJJAIgIASAsSXoaBxJGZTpASr5H4HQI2lkm+X+ATAWPpdJfAJGIBiuhZSPAHWfu9gNVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwLYgYMO27bDDMyxg2gU8MMXRToDFEAK4wKgF4MABECjFnRR8wCIUvMpcAcjC8gZwxlG41KF4wCH44YNY5jt04UOAztPwzFHIyCKYx0d4xOLQ5SWQyNGYFFWJLQYID4YJgKYAj6YrCQYGgMYuEUBgtXWZUiAbKh4YvmAYyjGZAjeYBB0YjAuTAOZEiuYmgaYTgAwkAg8YbhMOhaBgBMGwfMSwxAgBt8Y5oAVaCYRRzjgSgHQhYsBbEbaAsxWU6QaQLCjwJrZiFMzxS5S5C64cgw6GG1ASTyBU8FOKOiQDxKSABJbYHGsLDChKsAAjwimaPikxwYWokwwGJGNoNEjojPCVtpgYmAoljLbRWlD7BUOBh0lPuiQCstKgKYxIqn9TrpBLwmCPILMYAuxOVVZ82YMuN40zRkURCAAvyJYRgGbEAk1ATFPIBWcKFuy74iUJBDSPDgnnQeVTf9StBOxYQPSxdQZWpAueucIBC6MTlTfsAMVJVRe77M8MMBP/74mS+DPxWY8MD/crwAAANIAAAATxVkQxP81TAAAA0gAAABPBVYSFG0DBN6mE6cAyKdBfhzC3g9U3qGSLNIwAdzGMCIkw4xVeMhqAqTDlQX8wD0HNMiNEXDB0ArYx8QFFMGtAgDA6gYIwWgEmMB1B6TB1AGwwUgP9MB5AyjBdALIwDIE7MCYApAKGdmDkhfhiewCWYN0BkGHggVZgwgGcYWKC3mByAoBgnQGWYHCAcmj3GbNO5uoCmkpuf/dRgx2HjQgeAgJipSHFzaYmFpgM3mkxINEEyYDg4sDJNMPiMyaGTRo3MPDMGEgwmQ1MzCYVMIEEw+AAuGzBgqMkjsgEJkQaGIi+YVJhhsEmhBSaNgZ4WCR5yN5uT5/fZigJ8UBi3RhixGHMoZMsbNGuMQXNmhM2rMGmUDA3Yxg8BCjcTEmTXtjHDCcMDrRrQgKSGWGAUUYIUTIAuzMa5M20AxsECkQAMgMWFO2BMEHGkQgEhhQOEBZIrcEE1jgUQZEWCAZgBCB60kqBJKMCTEDy/5dIACTHg2Dq2FANfgqPWBQHvAGB10GVBGNDltDHHBYMaYMCkppwBiEw0dk5hAw0JEl5hyZjxSBRFNMifCAIJCApe1oLFzLPEUyyRplxlVRkDhjRxk0AtHM69MikAwE4pElNGcGmEImMhAKCYAeHrjILzFIi+pqCA8oMeYL3A7IHCB4WwJ7ZtCkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwCYOWNPqdGzGczTM1v8bgMYGLPjN3hVIxpITsMGJC9TBggOUwhoMQMG0BIzAVglUOAFDA3gEQhBBTAmgCIwIMKUMEhA/zUBUTFl4zSxqDmb0jVLJjfbITSt8TxM2zaMqTekHzfMyTClmzM4aDM07jD0LzMtEzHodjQkLjUVCAQXQlCBnUTZiqL5i2JSe4GGEKCaBgUMMxPMJRhMPBSMYBcEYbmKogmAYSGLQkBA9kwSGBATCwhGFYLigCuyYOBgYECYIg4MMgsBQ2GCofmHIMiwOGIwFAwDzDUHzDYBTDMMTDkCyQEjDQFjCYDTAcGzDEBkCBaNwRoDiEAmFFAMhAKlxxYJk7RYGhGBJAASK4QFYsDaPpeBRMgAkWAUwOCYBBKJCWgkMDAAgFPwMFhYcAgiRAOIgIRdRvZeGAEXdWglQFwYQRqmAgGoLMHclTdA8UANhbIGcGAgAIQJwP4sdL29sQgGjMhzKwBSBUVZ+IwBXYXjUIeBXiVRgcB5ABKlrvsyGgQIgAUtV3/++JkxYAOXmNEjX+gAAAADSCgAAE2FZceWe6AAAAANIMAAAAxAu2OACRACwgssTA0PAARAAsOIwTBAINXAwIBwdL9LAAmAICmA4Ag0DF+mDACpyJ0I1IihAGjQDMcGQBZ2pKIIAAQkUFMOB8Q5rJzzK/rZPpCM80qt8jUa9mMk8/MwlxFzjlL4MEoC0y+kdjEcCUMR0PcwqRfTADBYMHIT0wzgEzBHDzMmH8MKK4MG3+OadZMZz/NQ5lNVxlNgDtMWB1P2mQMXg0MCTXN5BcNqQHMpR1EYWmKpamKoOmC4LmqqcGABRmBIQGPZGGPYjmPRPGTQ8GQQ+BcNzD8DzAsEwAAjITAQhwgNDBkODAkEzBIFzJUazD0JwoB4FAQdBUsAQBQICALGAOMGQdTiEABCgKGD4FIbGBoVGGYaBADs4MHwvL7gQIjB4FjAgCDAMFzAUA0Zy/xKBAoAJEJw0AQGAoskoMkJ0SCQOAtZj5AIDwCAYOANQkvGQAC7SHjKVKAYCiFLRVUwAAoJCRYYRAOW6FQOCoCkQMp3JiukYEAglbLGXJThwJwwnuiuXGXCiYSgEk0gkQAA4DoPWVATGwgEWIAgDRIHR0BUs1RwtuM2LAOvZTQgAZkiC6MbAGmpl4LmaWgU88Uh+GX6luPtNf8mAS2zaNo5oepcqCOqytflv1GUfyIAaFWhAGhishW1ha60rFCJfVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVN+FRk6SWRTg+biMADiE6iQ/jJJ70Psg9UxeRKDIhYZMgYf4+30ljDcHyMaUJQwVh4xkNEwiwwzFJBNMCEDkxKQYTIPUWMqMqswzzFDBeG5MqJUU0wRAzFjBwMC4KswNw9jGHBrMhUdM4ZDrzHCCsMVgREzKxOjAPAcMKYA0wYAWzLvERMPIQMxHwyzBnAZMN0KcwnwBjA1AdMKQF8DAAhYAswBAO37MB4DswdQcRoOswQASBYH4CAKGASAAYGQNohArAgHZgRADmCMA+oWYBYHhgxgpAUCEcAHR3MBcBkHBJBgJJgmgDhQBgwGwGzAiACMAAB0wJAHQECGYBQAoUA/EABSzg4AogAlMBoA1ghgXAIITjAIAaakTAWCoBiwjyFt1qhAEQWACAQFQkA/bYcYBYABQASoOYAwArYxGACliHAABYBQwFAAizlUMADKAJDAHALDAKwwA+nWHSIIgHn2MAQAQeABCoC7D1SqAjoAwOASAoADGxQAxGYIAcX6JADiQARbBV6qrLC+aYb+F20l0smusnQHJiNFVhUskr//viZM8ADwBlxwZ7wAAAAA0gwAAANeWfIH3ugAAAADSDgAAExo2KQWg5KwrLU9mtL/ZynI2RXcRte0wrALDADC3iWRdFsyIy3JeXgR3af3xgAUlALQVUGRMVmgFuMXauFQA4NULyAAAKUMMEU81JlQzNXGRM/1K4yzZpjgUJvN057Yy7zIDL7F7MAEVIw+ATzB9GvFQcTB5BWGAozCZAcMFcFowCBOCUsjM13jJsODHOxzLLjzg90jtNMTypLTdZcgsTZEjBlkMxm6Xhpu3Zgil5oiHBlubAk0BoiQhgWNBlkGRkAP5ieIJjuIhguHRjwAZjEI4jBcmQgxAAEiLIxFDgrAYSHgQBaEBEAgxLrBApmCoEgYdQcJiGBgOAIACVPxBsKgeieFQeFAQMCAPAAFhAVFAWhUCygPoSBgMBQAjICmCICGCIEBgXBALLoJgZEQAoLqXA0AggCRICkBocCrjkQFp5Ok3azKYsAgCaYWdcgmAtAooABVZlzsqctOTuUwEABpjoCS86D4WAIRg4AQRMDAPDgFHQMFAPgxUxCASy2hsgWEVYw0OASAC9kqVwxRPVHiDRwAH5iCl4XAtPEGAAX6YkkcglLaorNqn8xxVzLn/Lmv+IgMZwX3LxOUFwIBwFqVGAoCKuJABBQHCwLOsi8oesCWeTUUzL5oLIoMTT0UUMBQGdhLZLqHYDywbDPyix3O2qAEwT0NAMMTYQjBEAZg0d4JuMDHThDU2g680C0QZMSQDCzIUw3QwYoSaMMQCDjBngyYwQMBnMIQBBTAUgMswK0BaME7C4TA2QB8xFADtME8DCDCJgPwwjAbmMA5ChTMRgcswvszjMRmB+TDtRKcwNYFGMPiBdjAlhMAwa0CKMKmGAjB0whswT8EsMGlDaTBjgDkwnoAxNFmsNZAQM9qWMrApOWhCMcDcNmhkMymQIRtNNyVMaw3DLfMRU9Mbg1MlSnAormcYjGF5HDoNGEgkCgNmWwXmBYgDoJGDYnDIsiIBTCgQDCkHjHAIzILjcJTIdDMnTaBDLIDUvjvOTjEhAPJnJxRhlDJoFhZk2ZMzVcOjGzRp1mhSm4OnDIGedBAQy0AROg9ISih5wZpISAgVCA0tLIRFTHiFU2gqIhAUMAjAABAzLEo2ZYOZUACRadgiVCMQcAShoZAKKKEJprAaMxeAVOkwFTJfpdYBBRgU/gKNuoYYAQHQ5CjmlAOhX/EAtNgGBQwYIxCaxEHMcLMqIMYOcUBJBIGYQKYwWSAH2KgYhADQNJxBYABUGSQawNfZgkhKBVhLxCwIBUwSTIC7D1WhgBS1iY8WccuGAT5EIWiRHhYykIkSXaf2GmiyBhTKWuRuBH6jNN0dCVTLlTmsxgAVcMdfKTzBxTwI1ogHDM//74mT/jv86aESL/dWgAAANIAAAATwpoRIP81aEMTPWwFzjSKWTNTFmw8Ex5QQOMFLDojDEAWswwUFaMB+CUjAzQLcwUQD/MCvABzA8A0AgDATDXgL0wasBWMRYCFjDxRg8wGIMGMioBlzD3jHkxnMNBMM6EQDA6ggAwogFjMBHCGjBAgTgwYsWBMB3DwTD6AMIwWALzMIrBkTBoQOUwl1gXpDWbXNbBw4T9TT5AOsHI2nEQIGzPc0InodTGBk6MGRgKaLJACJZp8bGd22YZC5qIJmHjCVQOYwMpgMemJAgQBMyIMjDpDMTFYzACmHGybGc6nNengQGhoGeWHRBBcEcswbuUYtQbkYZHARWDkWyq3NoSNohMeZM8xEZc4xoCwhKgZUCswLt0izFDAMTLQAE8pSaEAY8sPTi6YkiEYYGmEBropCp1pkBYyZMMPCgxUY5yCkprhZjlIkdMkhGB5jggIEmRMGTHApM0s1Y4UDGbFmBBKaGCFiAWYYAZwKnuYMe0uJGGJIaJAumYoSVSa+SQAFg46DMGAMEAWOqkIAIY3AgQxwkyZMQj09i2pIKU8ZU+YsIt9CsgDvUuQRAUO5ihZmhJrgZoAZhxwQeLXsRQmFqHhAxxMGJLlbK/iR7MVG4szlzX1nZmW40vKvfwoeYazJzvIRXyqp0JObep0ujE/O5888/mKKNO6zklCAwJsgmMoXJBRY4AiyDiACOFkCo+ZMB1AnuCdTRilpkAZoS8zCEZU+gAYQJHxA+5sMjejIh1GhomOK86w6OifJduSNIaA48dU8nWoAFziNBN0Ims0rCPKLSjWgzgYsxAUrTLHnm0coYwpFIMxACrwaonIdCAlaZxZxOkFDeoLALqi4QkZoIFVlzgcwRhQ2ShEiGE6XxbxMtZxaRKVCNMeNs+S4AoUlkSEx2xM6U8iup0tRkbhJuojA74AIuVk8rlUOV44/ygi825L5UyTBQuDkFvF3uBHbVetethYYIAGgom4In1n+TDARCw0P+QjB/Qf0zS4tjMeNHkzSrx9Axd8rSNx4BfDD9XwAwSgcoMU8GhTCNwLsxEwA1MSgELzBjQEAw8UAYMA5A3DBeQJMwi8G7MGCDgTFgQbkwZcOtMM6AgDEShhowQ4a+MP7FEzFngmkzGkFSMNzEkTCmgTQwjkH/MFREnTC1AP0wOQeiMDyAJzGjgJIwZQEeMELBHjB0gnIyYiozFC0wGtcwMQkxRTgxSiozuBMzwj0z+OQ4iMUx8I00pAo0dNoyEIY0ECYxOFsy1CAzsDwBGMZ2iCYUmaZDCyZIDkBAsBAVhBQA4pTCABzCYOggezRuw5QYioYp0F2JjJQgWDFM218BRjinB5wGORU0PxRtQLkz+yzKrTaHjTRnnNO5Md7/++BkjY/fHWdEA/3VoLLMp+ABWNBzeZ8cD3M2gaoxpQwAs0GEboQ2TONxhgaBgYIqZfKpADFTDiTPgTEkihqIApizJoRSZa0y54GnmBVkysQJAVckAYMAxQiaKFhdqZRONLTGoGyjgsqBkKTJDQcKFQRkA6TogCj2IwYcvWRClGxAKHTSCZQ0sqDBbzBgcxYUxJAeHqFGYEoS04ZI2xACAIpnqmBbUSRiSxCkxociDjzwtCGE1Y1VwqAAxsxocuIpo+PQSHcsFHTFA3SEiwMBBxgKjwwWgeLACsOWaUUWIrHGFXIhN5SWbe9Um0/+gZrXhhVdH9icCw/JQSNEfKHEq2HKuY4XLScMQjQoiAivFlpq/QSKwLLMqwc+XRBib0Pa19VRjjX843Q5XcuPQipCY3FS96G653ngOFRR0FY5RH0qzCMunF7TWFB5O7D8RBYSK0zYwEBjr3w6oPaUrb6BKVncnlDkUWa80f1Gy47rxJIR5aZbYCGAgGIC1UU4u/8ckGT7luwUOFUjsUV/ljOSIYGABaBzWts7eSnzp5JBxgtBlGJHQYYOg55ydG4GIgXAeNgJJsM3XmPQJAau4ZIAHdMfQMwxLy3DAcBtMJ4GgwHQNBIRcw9g0jBMC+MmsRgwaSkwMICZFZdJjCjMG1mS2YX7gRkChPGPgUwYS4BhjphlmCsVWYPIBZh9GpmKqKAZLgBhhmkQLAGBwHqZlaxy8kmKw6aXFJrpGmUUwYPGZht9Aw7HGyuIQwbVF5iZcmDRmYxMpicUApTmOzgLMgxKRDGQvMXCowQHzBwKGkmPB0gLJEezFpRCogLMgRomRMwgIua+5pjmERAAAEiTECIBA5xEQzeDHbHljPlNYcOjVVE1h25i4IEMUcOBJCBIhD4dDAIoceWuL2EABihhhRcNXAcRBSXjelvHYWkYBDWGdo4NDdkDDhQlHJCWupVQoHdEu0XFERitqUiVYtOtliw6LLSIdmqny3bLBAFBiGixkIVGnHexja/4++7KYfZWlFEVYIu5FlZiszRlbGjKXO62VW1hbzpZwMvdNJxGQIkJ+Qeho5BclTdqyu5C7agcnbLD78RiciD+OxFLGYA4/+dGDAwJgln8BgYVJYTgfAgTBIJDi9fiwlmYliWZr4Dg8gMFFEgkEzp6ZmZXnZ/C3ZY5XFiy0ztGKc2YGDm/8K99tfbtMzM/9te/N38PKiQTIT9+lN9yjPsLITuM7X2p2zMzM+3fFjklMLIMsz11wzISJoMfBAkwewpTmYA9N+QRAyiRuzBXJcMI4X0xPAlTDZG7MIIBQxPABzAWA9MFMGcxDw9TAMFuMUwGYwbiNzE1B3Mm4TQw6yVzL7IoMT9Xgx8hODF7FpMFkQkwewRDAiDfMLcDcxH/++JkNw778mdIA9vFoJBMmRAB7OhuGZ0iL3dn0dCyYcAAs0CyGDAbFaMGUF8w4QDjC6AKFAsDChkb7jB84zsBONLDNZI3MeMhljEh865SMFSQzCDpQvuZKVAETElY0FZEAga8IkJyCiQzQPRDMcHgCNGYFoIFyqNIoDSzEAbADbo+pJscddMAI6I1hdj2DHze4wkMgQqMqmQAly0DKVYUChCEKRN7EQgvFAQOICUu6bYSkZiho1xDd0WvPw+XLaVCXSugYFW5MMWCiC1MOwnu3zNXlQXUSRJBobJaFmMBLAO+1tLZdS7pqeom+axp23sZyyZ9HRiDhwPI3CbhC2VrwUOgSnhErg9lmUuuLdbDEYg6OMDK3uO2RJ5sqx5PNwK5MQguA5lTJNaAX2lU7FaXnJuMy1iN46kKhMBfh6nI/R6RNR6UorYj5fJyjUUQouSdULLGP45jSVRdR6kehqgNJHF9OWBFpG3XsLiXYnLIczmrXA5lUfqHTvYCujvVKhrMuTRZZIaGrJvHSvGk3miswlccyGsCucmViLctCumUYJLVITpaYYsXzkml4nEECJoAoGpeEZ9bFb9+ZhWsCUrBqZQ1haCCgMzOiKdMgMD03jQxjEdPDOQwc41A23DIWE2PhgvMU1TFoENPkOMeRGMRxfccwlDsy8FsxpD42MFswMGk0xCA3HJExGZk94bw0XV4+oAsz+NwwlJEw8LQLnkZ4jmacQ6ZJkQbcjCYYKqNEiYcEyYmknNoxgYkBwk1AvM1HjpUUyGXB0MCJkycTMtKjJ0AmkDNBECjIZHGIBRMnGhlqxwYEDhMPBBaUmEwMEIrg0JLtl3yqCEQGRCKKAqBsMQ8iqAsKg6bw6ACIBBQcjALEgQIJBg4LJQlchIFK1BUKIAISHUJIkDhgmhinovdlzNJa3z6q7GgJqKP6+1jLPls7ONjk8TdOBY7A8wvVyJqAG7u/C2ZtwXlIFmrEkK/YjF5xXCdjeN/C3yf1t3/jkGNwnohKHktwuLQJNbS+Z83lh742uuMsDYuvhX7dbTWWwqbPwiOTEaaAEAhIQUinEly/DaTkdUgzhWN94VSxuLz+VSxgj/5rUx8dGRiXl6I+4SkodKF1zFM2sNhBj/E46tMpjtWDU8JzZCA9eB1p6bW8xKSg+KqJ5mIybjW0szjzTcbpWfdafMS8iPiqiPmUKOBwyjgEpepJQnkYGpwrJsEdba6dKjlCRk0vLC0VXHq5aZmZslRLtu7ygAFYwLA9DDPXUMJwhU0PjcDEoURN+IPEwMZZTBJBIMdMcswYyFzBkBzbEIzGAWA5wwSFZiQChlmQxgyZJl2YZkg2BoWG5wEPQqVx9kkpm/bp00HJvKbpigJhosCBgYwwYjBobFBh6dptaDp//viZDWKy+tmyJPd0nJp60bBAEzQctWNIM9zFonULSCADD9QkYb5gSEJgORQwe5hmBRgCW5ABZkmH40E4Qf5iENJrCJ5dQJ2iEaaX+AAw+rM63JpwxeC4sQjjDszKGzXrRI+bsaEIjHBG9LXBcWs4tyqnCQUITRWmPAUtUBwiDhAAAjwsIXQBQqeAKhMNDEZjAbDi5KCFBKlkvMvkIR8aHS5CABhQxYcrHDUouKHHy7paNhqlCmrcXjfawmo27My2kqRhUfZqXVREWWriaCAbipBEAVmqj6YCRaz2mN89rJ33Z2oesBbgFONZ6Kb7zb2xe6uWo05o69nDdihYa8cRb5ca9m4LoTxVja0wMrAF+20XOkAAAb7lyRQOzWVCQp9RYcYIC4LxvYtNxnqaFGoDnqbtXGz4UIP+UwUFeJ6udb9ojJo5EEvni9YfoA7AiCw1D2YGZ4rUmRVKpSL5wvWPuXhpG7ZlpKmQm3I65M1q1XKvHJWKpdSL3L99WmoYG6XgZTJk6xe4qPTouoZwvc+atQobDdL88y0VpA+0X/YNDVgDZhmA2mXml+ZDRGRrhJnmJUv6cewmhqgQcGXaHKZiI3BggDMmByE+YfRBJhVgEGFIFMYQoHpgdAtmA8MaWdMfUJAAEgDQ5ZixhVGE4LIY9JQZhBKvmNACQYzgZhgNA0mBGECYMwPBjOA+mDEYOYG4d5hTCLGDcEkPD3GCgHCYkMZxQ3GP06aNJRngkGNSWZpDRgAsGbheY6TphAQhkkGSmYNA5kALGJwyZHFBjMPmSgGZMHZgEaixZEIDMAh4sAYIB4cJSAHmCgeCgSnAj4ioKrLZpBiRnJQHigi7JbJAIlcZhsFfsZODDGKgK2EmLBDI46HBrwqEC5Bgi1gYM0yOORpAZ1HNLROUucWUWWCorlaS9ipFcsvVhYy0FbaFMFrUdUyqQ0QBiwB4adScMbESGasfSmCGBhQTMtgW1DDv0gEQJg14sgSxGQqJrRb6Kw+mShPYo4ZdVfgGYhmmG6C/RYgsNLSH0hlKE8CAiwaRKYocNP5NFa50sWWA3R55JI1HMs0o3WDvl70g1wAEbK5Gv5ceYCIH///+ebAy2i6HIfiGGcMMVI4mUfZ21+XORFJtragjXFMGCQWw9U6Y6K6ABroFSAprKMBDMYyACsTcRvZ8ZsnHT001unzHgRYqHwpn8dsOhtIQsXxE/791ZWTQ2ND2e/zhWauxs+////in3AePIlX+/SmX9tQ9wDMM4Kgygh+zJhAGNy0ecydWGTXmAfNdsv4zQAajNIE6MEUPkwHwcDAUIeMAYIowwgZQEEKYEgCBgBCFGBQI4YjFUYFtcZHGQa4LeICbPax1MEPnNFSFNawJMpQaNDRTMtz1M3hnMqXyP/74mQ0gAvqZckNe6AEgas44KBIAC05mT253YAC2rEkCwGAAMagpNqBwMTFIC4AGT5KGFwLGawGGMQaGGIYGM43mAY/hUBDAkijCkBzGsJAsEJjQBhggKQNApD0kC8ZBIACGYAgOYtgc/hh4BRgIGwyCgAB19R4GVYVgmwhUAVKFYx0F1MV4cZc2VYW2+y9GIsLbigoOAYkwou0NN4DAeXkSLEAAoTlrobsNLyFxhABgWAhZgEAOlRSS6Zaigv+2kczVjkSgdo9LPxFa7L3rhyfnXc20aadmBWsMOdlzGj12xKdLXVVkaGSx2hF40lXVXPDkteZr83RtJTpZaVAAcVLti7BEEyyIkpUjWqVmrxX3+hjF7WZR9yVkN7FVfINiQAoNIJi/aAmo9j2DwBJ1US8JdIMZXWlNz//////9MmxZ4tIZbE7DgJgXIToyZMEXHLEFxxiEgfILgOi5x0iC4hYZAxFzkWJYPjFEBt8DdwtLDAgHBB7oN3jnCC5WJ03dRDC/KZoV+UECoTbFZEuImZPk6TJuVFJupA1NECYGUIIVUi4smC4gR5FyDk+r/uUzc+XFuyG6CKDoGgAAEiQAAgET1l123u/5i2Pphe9pg4upopFwCJwCHsbNDauQ0GNsyMHMzVDswxEUyCA8LA8DkQMQj2MWQzHA5MFDzJD80IrNd2jRiwxEgM/NjABszZPPeADEHcx9wMVPzBxEAGZrg8Y4NkQsAAMBQplxGYSDCMNEQsDQAAASgIQchQFFBElGVVQcXgpBAIUKiCmZawxIQQRFgSMQDjBSAEBEOKdqLPEYYFF1AEBoJGZQ6m4YMFNNUbg9lLuIT2ABUCGgNK5G5CY86VTdy9bTljFAMRBYGC1pmAg605axhcTnVlL2XpWJ6JgStWJhgYANCcRWRnNcDA6x1bFhkhn+QlwwwxmQKDi+7CyIHj1qlR6fxeSdExFpEzuH5XXatL+swh9f6uG0qA4EZzE4cZUvJYdmSPrG4baa1kOBFUFB1juTbp2cKUtHbRg7+svc1UbIEH2XEwG6MWTxZrbU1Zo8SmjvP8wRpaWTRZ68mAAAAB////////////////////+//////+sJL+IaKwIrsDYSXmbiZwglpfyCaSXI2uK02H3TZW6JlibegN7F1g3QRkLyl4QQKMxF0a0meRhR0NArH7F+0inMKkT4AB1RM/VuLgIIGnK7onGvyWdaVQPtMhAxpawiE9B9iKtDV5z9udA1hYFdMNMZeKBf+3EZiJWrNilx/67E2vw/H3Lh/n////xBsECMemaCLd////+PV6eYzp81QAANEAQC221ZLp9dt/zCp5OOUcyAtjjB+MXogyOMzi6UGisYaJBhgEHaDuRDEDTcwkOzAZjMjjkxuD/++JkHQAKk2VQ7nNgAqeMKMHATABpEZMvXd4ACioro0OBIAEDHxFABGZRJmUEwcwmPkBqNkainAkRGE42IMMZIwKAmsMa3DEW4xtVMtMigTMWLR0CNHLTMwMxULNTKnkSELemDgQwFmDAZhYISgJmQIYkDGDARiISCQd2/LzIMrxMcCUHVmSVWNDUSBzCgRSEmcdgaJyf7BWQOKrcBQRWdsCYzOkJSOzaNWgBs7WVSPardSUDXYYdBB5sBWArjsrOTqao7KwSRbLWos7S/Y+68vkaWrAVcyKFJDOTYrRBpqt0Fl7VQKAuy/kBoOxJ0mSoPsHuwC2JzFb0u6SRrldhczr40krdGsoLZdVZtBFnsbs/yJsMJhQp3tsefhh81EWV0610nXHUsgeI3ds6irXGu1471nKwKdLxMWnxqAAH/////6/WN0gIsQswV8VkoiC5fDliCi5B9CPwFjAOEArgB5RgEyR4esMkHTibBBIcwQeTon0UCXhO40Q0MWIOJDCYXVDuJ9E1SL4oclBuFKTjJGo6hChsOsZUnTImhyhwk+I+JEZoY4iw4jwnkbBhooFYmR8jnjtGcGgRNNEyELE2PkUEMMZwcKSRKE2RpAyLEXMv8vC0ifxcYyBoj/mhkMsJ2KILAAAAAARLgKEU2OI00hQI9jf8wh5U0yOw6pp81MRcx+MoRB+Z4gIZXlgHEaY7AEW1EgaMjwiMYhTNRhcxAjwE4TBj2MPsQ4MYzAvSLumeg2HDwIZJjgAGixcBXyjmaXHoNN7DjHQpMDgoyiFQuT09RgPAUFGMguYQBxQETBwmMEiAwEDQwCkwXIguW1CAgIgy6BgsEP6EBwYBzlCgREYDRZWovpQeflHHrdOKuIpQziSOG3N62dqWwhi4XAtRe0Erddl2msq8WutNhLF1xVl1sraGxBYjOJuUQPTx2fdK9DjWJZArgxxyGUSp2J+DYZg6QvHHZitDViBZyEUkhlzlwHP1ldvHF26OhCJTKVN6iu4FutLgV0ohFZBKJC5MEv8/bkOUzBy2aROPsFYM4JdFuazI6sWJJ5qzt60hmcMZy525TDWGp+n3Qp///////jHDhEdBloPSBtYLpgAOAIIAAh64BkgdaApIvAueDLwYmDvhjILUh6qIrUZQLpBc0OeLiKZaD0QbBodQDkA4ITyKkNcul42NUFf+cJITyLCITEmaGTpW0SBCCQzYuIi5MqPmA5QnYrEOFlCUiJGYzJCFI+ZW/UWRWpECDGZNCdiPIkdNRswAAAgQwhAvDCBQkKpPpkLp6GFpKaZUQr5smGygorYzYgpzAvAIOnynMuqHBpQGJxdlYDmJoLmcjVkhvGhIWmGMaiEKjKNvTBCDDdkYTTPsDcYDTXstjBspDHIJjCFz//viZC8O695oSJvd0nCB6vfwAw/YbjGXIg93ScnarVvMB6dZjCkRTK17DCoiTZcBDIwrwUXZn6JBIG4ZAxkILYYORMpowQxhwAhjiOxkdBjnI5Y0BcRglY1tIRYO2HcJDhYJ8A4cagKGi0HjhkggCDnIc+aKNHlyydeSjKwzW2aGPBgAcHGxgMPCn8EYdhSCZnTUmAt4qmwJAOimvxCNQ0IFF1XIChdm5jQxCNcIyBFW5NAYBJgo6BQEpiREWFpwuoliJAn3T5Z8p5lDpUau2dOnHWJMfVM/LLHtcp44EaZ1mj91E914pHooN6w1nLdYYVG19EuG442z2NnaPKXjYxTyGQJ5v43ZFihQkMnQTkwceKmLFBhEECKBeLdEljDAC2iVbBVkhwQYBwOgAGgi+gcwYoXcaioe8kMTM7K8Z+vR8///+xGDopA8MJDQoEgQ6mI5oibQaUNbpVd56WapSoRPI4a1YecmXPyvlm1IuZMYxoXe5QESaqgaUWeFdLkxX61Nj///7x3EnmcWHmcxK3NS6rz/yfaJsNAh0cnKj8OspabHYF4vLTEuRJR+qFFKJWze1revbkKeodYlSvcDtdyS6FGC0FiZE5UpjDBqHH0JSYvkd5hfDfGivCIY3gkxkAjPmFeLscljIZnVYYXCsPTkSAoY3B4YMOkBDANYj4MbEJNcwOMvnoNDQhPoRdMfz5PMguNVilMBQcMzQKMB0oM3A7NHpnMVU9MeRwFC0DiOM3g3MESdMxxcBhfGJITGWYCmEA0GIATmBo/gt8es4aqgIDZq2YdgAiEGETaKTcrhZqZNmDnpzDIApmFBGESJXD1UAk32AghMsumWtZC6RgULCghQiGGHwACR5EIlTVsKw1IwdRiGVRseBoBaJb1DmOiFIBgcv8OCFnF+BUCOBH9IgYQKLaJakolEpCpnSqcrkbE1cqqsOXHLF0PXIk3GBorIe3GmNbV27zpNeYM8NRS1N2VKqRZWJlUpdVQFfcZZbAkuXdZfZ0XkYykU7jfJxrNXW+gsBSCgBWBb0GrWepdzEoeXcx+QQS0xKOVQK3VYFvIBU1dyXq6dp+XftSGVRnuNLtCABf/uk6hL8eyFlhJEaYsInw8wMIEiEkDfBOh/ELFpCPBaRTR6C1OlsQotp3HenzxJUVZLBSgcoWoU8d5LD7cY1bf//+uL1zMTEJxGxsK3NZRFVJ3CVuIi46CQ0JxKFi5gmQpQ3P/WxTciVg1HJRIkZKiVSTSgOgAFYwRgDDGeGDMRMc41LTOTB5aRMU0VkxUWtTBAFZMmcLQwzCLDcMBDVlbzFoiTFMUDC4jgoApKvZheERoUC5kAUACcIxBRMxdZ02PBYyt7MxIE81lKwrAUypIMyHRkyiDU4bPQxFRcwf/74mQ0jvt0ZcmT3dJyAAANIAAAAS49kyAPd0nAAAA0gAAABMAYwDE4wWDEydF8wrKMWJsyPCcwkA8xIFAwJDABCgREyY8ycYcYO0YYgawiYsMLJgKbMsQEFEHCx8GYdyZQWZc0oMCugqUAQsBGkkAxCIgzpNDQ4o0GCFoTgUTIDaGwYPTRT+bOxdLVMhXyqsCNabwtI9LQGiLQYMriHFh1drtYS2dQNNtLxnSWosEEQtuaUUfhLSkakqU4U8FqKxLzhMjwXrMLvhyML+g52G7MwWrDMsZ467yu2vt6IFtQTUY+3GVILXmgP/C5OlfRpAt2acjizVfj7QySAZW5zTH0RvLbl81PzrvtpKGZr5ZPTRFy0OUhbVZUbWCIgL/MfYzV3H7tXK3VlmMFAKYwIz/jE3OxNh1bww1ZyzQ/EeNeJiAx2QzzLYEwMK4745rIk3qDwrIc3QC8xzTgzADIzMhAxpTcw9GUx2eowLHY1ckIwlhM4INoyw50XQI5gEgxSN80nDswYa8w9F47EG8wkFU1qC0xdP0xqEUyOPAxBNsxGB8CpSBiBMQiPMBiCEhIEBaCFAZJaZScdxqZ6wOhC+I7DNIjMBwA3MxzIydc2hIE4TJDiEuDHQNFkj1Gg1Q8ChmsqjZKLJVWDx8zQQAgTHBhCNXQmSg4AhzfQejggIdVXRbkOPRALCU/U9ayOT+thkYcmWUusBAWRA5ClYYAqYkGQhhZiuN/XrcaVNuuxMYQhX2WDWgraWwUTUszaAphGXAiZQVV8+ytEHv7GrIyDhlU64I4/KRzip9sJddlrIkL1+qXtqpq+FO3ZPpkb2UafxVArLWmhxUrSKXk26yZlgNpQ1z3mhEvoW6M9mmCK6uMlb+Uw+jLEnZyv3+1TEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBML4FUxkw5THgA6OcQJwxRm7TUjB0NQ0K4wyBODv5VzH/XjcM/jY1pDBYajCFJzCkQjEwAzUVMzCgZTbcgTMs2DM4VjJdyTD47T7oujYbSDXkOjdsgzCQ8w5XTFAzDScmje8wxgRDeAATFZAzMMWzKwxTUiUyQZPC5jJSgyFaMNSDGQEwlJMTWB67MRCTKgkiERIMMCATFkEQhZhyiYghiR6BgkFJJcRIYysKMdBh4XMZGFiQQ8LdE9mbuPfgeHIrEHDp1UhUIS4bE2z5tSWaDgkLAawyIKmLqo6KcyDKLQYsKpquYvMIQBy15pGjwou9KFWFXLEnefaovqKQRD0APfOUsOrFgKVN3w+o59uI8pM7/++JkiQ763WPIi93Z8gAADSAAAAE0/Z0YVe8ACAAANIKAAAT9tlLoM+geJQp+ookS+8ibEks+TCG+dZ+pyROzGIPjT9RZjK/Yq7kaYK5TXnpYC5UaaM70Z9iUtn1hniZzKqteOOm5kMxqLRbYUCxg4BWmTUOKYDcGxxl2umKm5GepIt5x4XMmfmR8bR5rJiKISGFMIKYtB5YVIPNFEOQiF7MFoDMxxjMDE2KAMtcIIwzz8TGeDGMOc9YxQCeDeaAIMcmMgyhBUjJ4MaMP8oczngpDF6R6MVEOEyXhSjAZCmM6IIAyHipBoT8zBQbDCRCZBww5kBiGGJoC0YQwQRhAAuGAyBoYKAKRgmgmBYAgYAlDAFCgDVPcWASf4wEQWTBAAeIQITAyAaMBoDcwNQITAAAGMCEEEwNQHQECCYAgEBgaADmASBCLAPCMAEHADrkYYlC26dZdhHxRQtA6LTxCAE408XTrI6qUF1EBQ8Aiu4lAFZWpinG8D0wxJowutliVrQlzGACAKhz8IAUKAFWNQYtNYebgZeyPbftaf9YJGiOocETC9Cp0+lioLvM3rXlmMOSskUOrLWyhmxd20BjO0vEgWJOAsVOcUACdOqLADMQXS1hTRraCJsKt7lontHWDbso8xhgKVcSnyYANKxXMMKUN2lKxlVwCAOAQBVjJNoLwheft4sdECAy37lxmhjkbtyqWblVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMNUvI3y2nDFNapPBMAsxQG3TGik9OcsvgyrwoTBgT2NgFAI5YhOjUaGCMIgPwQgTmOMTSYhhJRh+BrmKGIgYLgepiciWGOaRsYYCN5iSiFmA+D+ZkBUZhKBvGDYNCbHJYZhxhKmIIS8ZGJABhKDKmPEN6YHwFJgHgRGLAFuYNoApliCMGD0KIYRAfJhphRmBQHYYGQNBhsglGDsDSYBoHKIZgWgFAECUeDiMHcC0wFgDjAlCJME8G8hCCMBoCAwEAMQsDWYCwIoYF4YDQBQCCDQFOsFwFS0YQJoYSgFZgagZiIA0IAtMAsBkCAYGA0BYBAAHfAIBA0ACWWRqCAGTADAXVRcpLswGACgaAoYCgBjcjAeAQAwAIKALMAcAYoAHVIYCoBQkAWAQAnLyTvBQEZgGgArvbuylW92kzSyYMAEMAcAguiSgDw8ioYAIB5AAQDACVOE/y3CgKspaZdLREcEvW9XupoXuX4rUqfwIAqEAZGAgAQsRroOAMAgACYqeSY7qlrGBgUAEIAHUMRyWAGgC2Yp7qQghgiY7E1lqnhiFJqpxr9EIASmEgxDAAHufuiGAAC7qRaC46AMg2u8GADJfsFh5L5ChmLCH+LpMxQdn//viZOiADvNmSAZ7wAAAAA0gwAAAPHmXIDnvAAAAADSDAAAAke57BNZwG+b//D3/88BAKZDMCZtSTxGmgO2f9UdRiELwHsxYKbDjNZmBHGmTOD6YtJNBy+nZGNMK6ZxARZi3DsGKsVeZBIsRilAvmK2TcY1wPpk3o3GD6CUY6oY5iWDHmREHiEWGGJQXuYcJXxhVC8mHqLKYF4vZpyixGFEGMZUpJRixA8mIUH6YQ4hhgzhugIgEwTwATAJAqC4I5gOCPmEyEcIAmzCGBQMDcFEwSAFTAgCWMCoIAw3QbzALAXWwFQDAgCoEgYmC4AuBAPjARAbDgCzA0AvMNYFAwfgCzADAOVMYGoEhgQANgkB6AFVyICkKABp9A0CgEAEkAGQ6AuCgDzAWAPMAsCYGgLAgBEwDABDAhAeMBABkHAECQGyaaYAOABBgACGzdDAEAyDgBzAJAEAABKmJgIAAigACYqCVFMssLAIuUYAADZgAgIEIDqTZCAE1my41RQWNqgX4iM1ZLkaAEfoQgCOGo6IAD1ejoAABAOMAEAeSpgp9DAAgyAINABoTH7UHfdukOMQZg1lYaAHlWFTSi7gylR+KvSnst8wAAB0xTAEAHLdGAmAsWVfIZAJEADBgMgDpRqHl/lbHGU6Vw/6gb/XW8UEUyTlo3Js86gNLqDQBDN0QmHoQJcKEgwAVAk96KEFgz//T//SqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowFhbhgiYwT0GjY31RNkc6g3BRAjYSYaM6UJQxiCZTExKEMgYZkwnB3DHBQWMdIId4zHjANMm0UEwnAlzhomTNZTjStsjPBlzHsfz7cjTnoFDwMnjJNRQuQhrwOJk0chhimpvMJxgiYRj0OphYQxi6LpkIJxj0JhkIFwiFoiBwxgHgwbFYw8AkwWHQHBOYRgmIAxAoDmFIImCoFmBYimDIVDIUjwPg4hQCDhIAYYEBAFhWAw8FBggDw0DJguBBfkaAQCgGiiNAwIwOCwHg4CgsAKmRa8YA1H5E9rpgCAxgAAxgCCAYAreWBoHBABSAZfi71WtzL1umnIy9yk/mGMNbnAaJrNm5tskOxBpjDUtH5fBfnG4MGRDZYz9bMHoJ6ZTd3lhmGJgNhdRirfNcgGKNDT/YhQ5JQodFCv/74GSdDPvmZEeHe6ACAAANIOAAATW1kx5vd1JIAAA0gAAABJbKKTat613lh1rvG5MxQsiDKG4QG/rjluW7ptuy19/Z16pLDTc3Bf2PvE2VfC9YM6ppAHsBbBD0YrwxXgl0pBFr+pwAU25jCBBsMQgro3UT6j7ZKLMdxxw10xzza/LmMGQiIzlxNzFvJSMOAuox5QXjIQMRMd0BUxMSDjDjHSMWQMgxLxZzE0CJMRAVgwIwjTElFeMDAgUzPQ4DECVUBgKRkqnhmi2hpcbBoOaxiciR1mcZkuxRjYKhmyaBg0VhiwCx8DhzApl/pkygEgmOTHGchHMwykuWMizJjTYCBaaMLxARMYfRkOCBIGgyoNiiRWGiwqIMAJJjJzgpgiawpnH4OIh4QCAwYJAhIRBgxsqiOjjICDEAQwODFhrzRmiwMDl5jIBAMrQ4AJUY8AOm17AIIOMzJjTKG2RCSAwYMUPBiYWFGLWA4MW2A0AMDOkBQ40NIg5IcMsBC4FWMEBAIJRvGQw8gKg0QA4kXPVao1DEOQpYaQAoknOliARANAwSMC0oVmKWCg8cBmIGNbZHLxgcQj1KTCFS+Y4FRkSCFQIOPl6ygeudNYILGwJgAWWsfgWIoUAgioeWUHkYtNM6cLJIWkQ5AMY0gFVw4IDDgkQRnABkCgh4UWYAZkAEjJADSGQaxewKjjCGgMFDBLNsoeTVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAAGMEQUExCRsTaUabPrZM465HJjUBGJM7R28xFiezEzHWMSUWQ20Nw1oGA7fxw3XEw2PgQypIEzfPU0gDc3jOUz8CQ1AN81MMMxtqExJNAzjoA70A4wjO0CsEYrA2Y3mGZpCyaXPkYWHkYphYYunmYSjONEkDApMfA3MNgwMHSEKwpMGgfMKAlGgnOR0/HALwZbifJrHlegMMXGKjEqRkNIDEKDAsHVoYEI7Zgg8QDtgLQP0TGgQcuaJAKMMOQek6PYcTASQcPEqzFmDz7dEZnAftKNsS7FYVglOmhsVUwa8lq8ajSCLNLFbSwyuXoZ1Ay13Jb9Dk1iGnmZA4EMwc15pN1r7UlmyReWUtc2Ws8vYtKkLtNrAjAm2gpvIZgVQR6Wuo2uuwtcT2sCp2UOMwaLLPdt4GBf/74mSbjvsIY0gT3cpyAAANIAAAATjllRAP8zbAAAA0gAAABAS1y3GlNH4bk1xQRnDWFoJcUsEslZ5ByyEMHAfifbulesEGBKSLwSKOljBBgVExOYWvNS1ZYjSJD0k2OxQ+MpNEfDDaGbQxgsFMMsIEBjEOwq8xJwOpMM1DKDH5C9Ewe4G8MNnCxDD2hF8w6AGKMGCApjFrQMgwYwXPMCTB8TEZwqIwF0IzMaABzTECS3UxG4BVMT9BdDA0A0Qw58KaMF4DTTBlQyQwE4W5MCZDjDCmQWowSIDGMB3BSjAogUA3euTpSFOQuYyTITRJaN+jQyIqDrqcMTH4wWbTPCMNBgsxwIzK6MMaC0wkiAwrhydN7BAxEcCY4mbhYJCIzIugoZjNAqMgn8xoKjLInMFFUzOTDI5fMeEwMcwIF5jgImHSAABKgPFl2MCsHEcVEqKwnQe8Q4GYITKyIAFzGAUFRhZQYbGCwVODBDVMNYt3zFFPUM2OwK+KSgw5O8YhFrwEmDVTMFSGEC7HEEYjDLKmQ6ocUElhII0BWwkSOKExYoQ0UteFJwNYWWZGBglgwQIsIzwOMTnLmpiqbkwi2S7zJkMHTL2DwC3ggiJlAwciXMVomXhDPS0AQmhNBwidiqSJQJDRZbujEWsKoS7zeOWavpU4kSy1eqQ6+EnlCC5QhEWDfxgiqJMQvFpIiHM1Vfqvs/v5qkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoATAhCsMH4dY0ijWzuZWoMqVgIxJQhjOfTjM0gNgzlY0zpOczsMsxjhM5lTY2SNkyxAgzABw0hC8wSNwyRLQxOV0zzEs08REyEDE6qH8G+uaijGanDwYzi0ZwioZcHIZGj0aTtQYYlsZTjEYDFQYphaYXBuFnDKtMRE8BC1ZjxFDhlomCObMQcqMnmMAqU8QkuQA6ZKwCWWkpercUGBCZYGMAMOEHn0nnrFgkeFlpjImDQqMrsuCjypq15Z6jEkUBbagbLms2XPtSw42zpMOjzX2qMCVhYAplPtCj7SYejzaQXPQLK3ZWFirwRhnLvQ0o3UtUeD9Sy1AUw801fprdJt/ZDyU/IaHClnIKlzvVYi6XZybr/++Jkig75/GLJC93J8gAADSAAAAE40ZcID/M2yAAANIAAAAQJdN3sYzJs6bGWwRQxlz24xWHZBOvq2rBo44Xw3Am3K3SQzWvVLODzVYuJYwnoDfMy7HXzf4z503wqqMOB3kVjCIAV03uwC0NHREETQzQEsxKQ3ZMSbCRzAFgxIyzoIpMivF5TD1DFMwXcHNMLnBpzCbQGIxJIDoMNODFTHLQRQxjUaCMKEHkDDGAkEyVINaM7/CjjHkxd0wdwNAMCTBpzH9SBYxGILeMdGIQTADgFow0UANML5DujCHgrcxdsD/Mol41GADc71NnnE1S/zDibFQcYKGJnc3mBj2YhCpiwumOhCQgQzcewM4DMzIM8xEYRpgkHgwmGfjQZkGRiggGJCcZLERk8AD0KIRGDheKg0GgIxaGwMOQoYCEJhw3DBmEC8KjEhMJhMYmBx6pM91T1EVQFTguZAYCKJQDWCHjg5YHFEwoDUNRw0oD2MBzoQkJVEoIVPLrmADkZARCYkgWvWYw5W+EBlYKqAyyAQWGBRYCWM0hGVTQDABQIQhgEFCMt5ADCGzM7RBREYYKoChSyn0LuJHoA20YCscFDiMZNQlVEYqm5hAKQUAGQ0l05QMAZxSSEAO4BBHtZUzl5UOicjD1O3aUsKhKAdWoxQFAhGKpe7AOcA2BMISApwERBeIu4ogvRR4kUXEWvgVT8YoqfRFpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwZwQTJcC1OLJGQ91pzTojy8MgwEc1j4ijJYIYMb40IwSxPTIJA8MKUyUwzRKjLzCgBhOJgZAzmCKLsYIQgJj/BnmGEQwYeI+BjOEBmE+U0aDIEpjgMfGQKIMZUQYRhMh7mH2GOYOBWZidBNmXqDCYWI2ZhegVGDOMWYIQPRhbB1GnNBGeGgYAhFSxGGKipiJATJQJFDJhAwJOMEAhgKAAABhQRghnQQbImCw0YwMFQmMBGzJhILhJsAYSi5mZGRE4cKpBngEfPRAokLGA6x0JrOiIpcNRNZAig4BAYv8GlBRmRiRlSMqbKtWUP+nONaGQh0hxdZ6mGMzXAxNo7N17lgasDIWxJ0tvMlzHniSSM//viZIiO++hjxwvbxaYAAA0gAAABMLGNIE93R8gAADSAAAAEALRo05EiFkL8fZiSLL9tuMAgZhq6Jlx3xcpBV510sHjrcFY40/6+FoRlrLtOa8MvdBiatzjo7IbvpjBKdaxVPu5Nrmp6GZTqX2mmn0JRa+3z0LVoVFg4LzsbTkTUXwiqpkTUZwl4go289Sm6q8wCwBzCNKON0cvY+LYYzFpiQNB4HkwcopTFGLLPoAPMkFXN9wlMxIsMfLzMfyqMEmfNWQrM+B7MY1xNkS9M4YUMGiINE2EMiTRPxRROK7iN8CaN8UtMVUXNPkQMYmnMZCVOPjKMhi9M6QvMYgEMYRNMVyxM6fPFjAJk4SY80c3rs0yQRGyJIbsYZaoFhoONmgLAQOAU4tAEsw4QJDYVOB1wz8cQMDgAwazQ1BI4xYUz4YyQIIDprJVhiAOhAwoDhSw40fCxCOiw5NwwZYkQg4EaQkHNkekAAkLdgSCiMqBiYkFTVAgkDZjHGAcHM0BWcpaMiRUcTTDEiS8AiAMFXaqVYdgrMBoAOgXuEI1dQsMX61ExIssFgoBLxu8hOX9IryDZZMMAFAhUxZCJprruQ8Vc5TyvsmImMpYlehs1RSlviyawRAGRfGABYAmhBFYBMdVROVi0BKKL2W4XvCgKAodSLVlUkFCjDH6XoruY0tBR1dcBhgVDmYQarcgI3MpIhwNumS26TEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqAUwShGTClJLNaI+8xrGZjZGXGNDAWYz5GyDKzKUOC1JNJgwNlRYNa2dMHJ8FupMKz/NuyjMazMMbTSNbRgBipGWwRGkiWmSjNmNJ4GxaVnAQymzwiGLohmsBDGvwAmYIaHL5LmFRPgKZDHY3DB4MjAsVjexjXvzC3Th8TzwjJhDXADbNDIE0aAKkQxMcvGg4YyMGXKGBCZBBEBLlAiyhZUUKh28wZUAnFBwQBLMDBZSIQFXUpNoDE2Al/0B62ouAgq8ESUnF/JjKlU0Z812vBzJVYGHU0FMsRUAgQaHKHCwh21LkJbT0vFHptFJurN3fh9ykt39U1YiyJayFC5HnLRr/icXqPomA+ayXEVujjxPCut+51lFFEV2KwOkrl+5ztE7rd4OgCy4rv6mqB5qkMOg40hlWDSnOVvd9/Yk/kFunBddh7L37cWAGV1omuskAucnlegyVxnNIABIThgWwG2YQsBqGTTg/pqtgJMZyEWGGYOAnhkp4TyYyMDqmHQhNhgSoUgYcOAvGEWAyphLgnuYKAC8mB3BCRg24BMYLsCEmCiAthguwCgYBqG0mCwASBgkIaEYDcD/mLsAZxgGI96YKUCGmKCgs5gFAGoDQNMwLsIwMCrAgTCKAqowKgCBMFUA3h0DUMP/74mTzjOrFY0iL3dHwAAANIAAAATZVkxhv7zaLNMGSBAayEgoAYDBHgF849WMMIjhxoxRrPAWzcIE4QJMTBQsCowgAFJQYwcOCAYwAbM4UzBgMzMkQ6hBULERiQ0b6TGJnQRRg5FKwln4UHwwgMGY34jToSTM1gz6DifAyy0yZMSFS+Dxi4AEGAXwCiGZwcyXRYAYLCXaAEEgK0RJ5Wnq0JQmKEBnTQLStY4hNACIsiCFWKJpNKZTChEHGYsqJMFUbLQsCJMhVMwkCZckAEQYNURnEJwNAY0hNXab6CcMBBxynQ8EkaFgUwX2ZWueTgloaOMd4ACg0BUxdIuSEEqFPI45iAER8ZQQISVihQOlChI6IBEWkoDU+k6wsGtVHcrSMMhAOg6ATACaAxS1oWHTIWkykAGlUsKMgKImaa6UAotLQGhovScZPyqKpHlfscz9/FryykznXyL7/TfgbecWJ2lKty9Ly2kLpkRR/HwtqjU3JhLSV+fpW80baUqD9hm1fr/9/LzhKfGhYO0xYHsyIhupLJGDwG5AUmaY1HwQy8PgTj0PpRIhQD8RBzMiwSy8aj4I5UWq+xKfEcRCvHhgNYhDEGAHw4Kq5kvE0jj+WDMwK5AHEdhgDAD48HqusC1WfrObRg0B8GwYAYBNCdflhlW/S/XWIa5EoP1kNtaWo1Z4vgq0yuUmh+cQ5C06rfcvm5WNylTBHHkMaQbw0+GaD7NHXNVk945+Aezc4rlMh8HwzvhAjDOLWMccTow0zbDGNRwMYMDIw+TrDA+AgMFoC4w1QzDN2BxMK4y0xPAMzANNNMBsPM2JhDzJEWLM/kh068JIgGIwiFgzMUQ0uK42XnUyAQA2YFkhIcwXBEwRDAIZDRY6IYkKnBlg2OIzJkSJkgKYyHYwQQKBzIqQcWGgRpy4dUYY1xBIGCC0QMPGCPFyV2p9M5UMaouZISBGGM9T6dRpSuIk4CggkAbgyaLuMDgC6FyQl5JU+0COsXccxnM8vRgcdTRYfOIiCQB5HwZni8Kx3+dpwIhAC23fnY+77gUkJeCL5QzA7oQw3BoMCS994g3C9FYYZZFGhQ9GqjqQ5dgR8pdbksy/dSB8IMp5TL+Wobb+R0dSo/bvv/A8NcldSdgmbp5xxJBHKOYgBiD8SjFsEAC/Qpr/9QYzHrzjyzbgzQSjkHkHzRux6eZIwAiAoPN3BMK+P56D65smw0ZadFZdIFK0XiY+Zx0bpEJADBIDbPjbJAg5d7DEU5////////+ONahjzdRUMbiocxMYQAZMCmg7M9Zy3h+ETXgIVJ0a5FfCBJr5p04pqjpz3oOFMRf6M02N/9cBhYmB6SguXB+TE70qEp9IFiASAxtTnzadgdOPmoo5qyoDmgFIMPWyI0ij/++Jk/45KcGJGg93UkpXphoIBusKw+Z0cT3dNQnklW+gQbTiSDKKMPMIw6YAg1mC4TKZHCLpgTgtGE2W4YoieYylmZvk2ZEq6Zs0CZIEEYl3gauFUYk26aehOfclaZIlmZqrMZulGZfoSdaHIbVUMYqFUY+ESCUhNBSPIj0CwomIIxmV5SmHAEmOgyGChCGKAMjwcm+cGsAAgcYIaYpWboCBnZI7OcNMkVM2NOKXEIo1SMTIGhJjFkwpEgTm9UmXWhDtgLzkwtQQxAoAjSyRjhRkhyMqY4FBAQULRAwWxouoqAILrdBAZ0S3YJAFuEoCIWUH4SWUMMAXiSAkJigpgQChbQxELYKwdDyKMbTuaYwBqsfSDZwXLUvetGt4oo7LdoMibJGWIhsUdJcLcowqoy1yl0DghsjZYAHjLF4NXG14BDIKYwkgijmzxy1YE50h4LLlgkCrewhqwkIU1QuZWvdabOl+oNFlS6CJ7QWOsJYAy1TCEKkZeTDU7E6kqRIYDi6qqjz007gL3jdP9JD9SxgABQAAARf/P1vPn///vW+4Z5ZVY8z0cEzL1ETAzHrA6pcNliTMx1Q021lHgZfoNlT26A9KyOD7jYAtOCR0V+w746BAh2M2IDMWsaFlgjDiw2o+Imxp8Nt0a5z///////////wrwwZCpHOIxhggShxdCHLtyvcxv08ogMkADlIw1ldOpezY588ObOkwRcbYtLbQSmXf/5o0CYqIQ4BwigBAABpu3cCgAzcEjTiMP4Fc0mhDbgFNPykwmGzUYJICwKiAwwYjEVYONQSgF9QEGGBBY9LGEHJg4EFSsw0eD0cyqMFk4zQcAgaGE4BUQEMmRmIIFhYeMIAkgw4Xbik2tlyE/S/kuVSEgIxEHVG4zmBAcg6DgtChGwt4zDlSIpQZ46g4SEHEYp+uQqUKEAbBvqclp0KRUpgdI3EWfr28BaLAa6mOhRNw/06WN0T4yxwnwco+gkKlbHFjFqVo3yGK1WNzcdCeLuLUpEsyF9TcNGI9wU2INWRTmiuoqFsqHqZISMbAZZcTjSjGVUqlO1iWTmJgmxbUJUhhuR4IYfGHjpgOUwieIS2abEMRarXSAVSVQttgm4ho3FOvpUzmBf3AiTvcDv/es4AYgFAHm4KEdrBwDJJMAvEqBuY0dciSKXjlp6JQQAmepBGycHIBcI4TcexYQ8GO3iHgpxcRkkkH2DEGmAKxjnOXM63c1U+phCC8Q2ND4zsYBWBDymBsDhG6DdIYhZ2EIdQhXCsC/BiC7hpiuJ4ckp1EzFCXAkYh55pxrV5By8Kct49Zc59f//////////FFIoJk+5/qdbqz4qn1t+YFYFRh1kIGYmHMavr0ZjAEKCWDJqnCPGHWCqYMw9hgzkLG0//viZPME+RpmT1ObevKfbHgQAw/SLFGRIg93ScreMiJADMdgQxmXbTmXCGmESJmCx7GoApGfo3mEpmGS5RGIJkGkJeGQjYDsRnWMIGV/SGpwhmnZfmFBRmPg2GRiYmYoVmGUFGOIPGmITGFhmGJA9mUQHGMICmLIpGAgtERXmNYrGGJDGBICgkKwSDOO6Ds5vxYJRGwEGnHmfCmCoGHahkw2gVGUxwMwcMORnKeGJMhnkCB0BoVEjwWHmdAkSSBAhGX0C4gxYIYKDo4MPDwtHgiVl6hCIgAWFqCKqqCOjDLw3o0mvDi/VE3oaK3ib6J6kWGx1ha5nDb13XTbM2sjfpvIYyU5dBiVto+DaSRKBjMUd2iWS7LetIylUExOieRqnY+wtscMsEcpMaKQ/PPtD09C8XkbX6SHrVJMPHBLwuZujh5v41h325RFkrsupLGXsqtNeiMOPJBcadVmcMwiml7jRX//69AWn4FDCF8950hxVI9pBRU6X2HGlwPonCm1h0TBVInzSkDwDQcBzJigorpnGZAkSYpoGXBMI90aASqieJmllgQSAQTpeiQ5dyjlJe+Uf/vW4SAxW9z/XhzSbTBSyaThWAAQUXhoEtZMxoGBF8HsTcMYhkpKCZ5aVxaAqghx4AIGBQcGCdC6oGyBWovBAAZQLEBZIXUETFaB+5En///+cFAFQgpfKw5gguKDJMhSKFgxJ8XISTVMQU1FMy4xMDAwOBcTByQtMtQeg7dWzDZoNrOcoWY3QYdjGUAdIqgDE1IcPIhZOqmCMgZiOk0fMTAfM3CuM5iqNsG0NmjmNapYM/ReNR4HMCeXOlBlONTOP0kkNsikMuTzNRB2NXJUMOzkNxrVMNECNrwXMjzbMogNMiS7fwxdFgyVJgyEB8edgwMJIxzCww0HtHI/gkwhBsoXMnrAmftjkE17Y3jUBvgeDBEcwQ0zNQyYw6wQxw4lMgUUleaIUEAzDk2emNACQ4CLDIhBoMIAosHAoxKsxwYwZpTlTl+xoCIgCWJa+G2hRVbYOBp1KrhYCgFEIhJFA9YMSEFgVLzAAVF11JHpkIXA4iWAYYGT7a2wF+CQKwccEBUFAsuexMJE1DQUApoEQos2vMw4FJJpTwrXk8fbEmMvZULUJSpaxphr7ue+PGeLLXdHXLfh1HtdtLNJBZTpMZaMmE9q7IAabC2txlrkxAMsjaji0GYroVG2FkjKnDl9FLHmgdkrNIeZs16W7///46iimMsIYqgYWFFzsnFuDjgImjCfOfY9XEf0NYijsATjTYOUpBAaoSRTxlsYEBoSowQKlkAAXydItk1tIVvPZU0eKxSAFpya932qt45iJzH/adCONK3I2UrKaW+VNFE1pmNP5XW2noAQmSrxXC1pIocBAf/74mT4jvveZMcD3dJwrIyIgAMx2CY5iy5PcyfKIrHhAAenaBKEkwjwA8QYQWGmJ1HAGqhAIcoZ4iQhMR6Tf///Iwa5IB7QN4gyMHzFoUkSYdCGWQ92ICh6JJLAYAANmEgGEYOotJpJDTGMYSWZfweZgpn5mCiGUafNZlUlG8iaa3NhhtDmBQ4YiWpiwqiSmAJlNiEsxQxjEhOM0IIwoFDwgrMY8E10XzQ5PMcBwx4ABRbCIhmoWMYdF5mMJGLDCHAcw6OhE6YxwzmDqDrRMJYySDYYOAUSXDhAcNGAoFPhQUu+YKCaJbIYDYoITUrCsExgERVJrhRieCNNebizZMh0VVqGDk51LUW1cujPtdi9yLt0npZKKeBbUhfhwY8zlnMueVxp1XU+80ep4vBdmK2L87Zk0vikPyGRTL/OTK4097OJG/EXh3U9QympVoO0lLK6Z1ocj8FS9/JS0+QyqXvLDz8t/CpBKL9SXbt8ibg2oJU7e5pMQvwBQQ69Ey/cVd+H4fkcZmLt6ZqUxFr//K8CaCRE5LoBCJmHKVRjIktqiZ3Tcrycn4CmFqJUfaEsRpM6hynbtz9hQ2KfpcYkByL60D6GMwzfZPRYTuJ0ZTeN04cuJfjqc3TMrW00kiaJOU4To2RMVTCu2IVCcmFxwrW6OnXA5mclJksU8Rmg6///////////5EjDMCpn8sGi4lIhUGhk0kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowTiQDL7HKMy6hoxG4DTQ9sbOaIck4yPtDL9EvNfclYxNh2zOWC6Mbg6syNg3zK8BkMcYwkwoAizHmE+MTEd0wdyGTC1GwMfocAyhUCTFOLWNWIJkzfHMzO1FDMiIiYwpQ/jEWGHMNMZcwtgYjTmFBMNoesxXw4zCoEaVqAxFpgcCBmF6A6YfQBZgLhFmD+CUYEIZQ0K0YWIJ5sIMaOaGFKhuJgAUY1NDFrQ5xdNHXzQnkyWJMyijLjM3MtNUtBkHOzITGlg1s4BhgBDMwcIGSAMBzCBMyAjBoGVB8wIEByQYKRjomNJgJCwYaGMCwGoiSIkq4HRDrCshrWBsCWzARUY28LAC/XmAXCoE+ANNUJ6cKPKJaLwoZ9FkKaArQXsr9M51UkQYWlS/BgiboXeNDJRJpmNCM4XMZxHEaKg11CW2JnSuWVBLA6LWy4EMoJ25IkKUDgnZTSZY7QhQXCc8LkJQJBM8IsjCwUBORPkcO8EAIysDZ3WJjlvUGX7laA4OMyJW9MtS7BLRjKjrYU7ckNn3hKm8jZxJGZM7/++JkzY79CGTGA9vGIpwshsIDD8Tp9ZEmT3NHwAAANIAAAASzj0qtBooIAA///WXdY87ztmGm6uYgmdRQZrzlgAqEw1gUfLYopCIZEFIpQ1lhcpp5dUpgbJwI6LDcTSUqJRCDOlTP4r1TNUfvWJcsDPNaLOhpvJ9NM0F8/OlFMcCCpj1SbI+ck6ikWYo3lw7Uy7Th9lxXT+O4p5+hrotyjOmOoWJcvHcXf///////9s429SSbLawKp63MqmUUrCqT+Z2Xb0SCYoGYYMA35iGmom7KQgZ2qZZnqAamtCSyYhwgp7yLGHJudCURl3yG7VIagGpmpxmYS4bbKxnxCndygahcJsgXm2JYZ+3xoslHcpUelGxwGAmG14YJOZkK3mp1yC+eZtYZlATmO1AYOCBk8AHBLkIU0VIkhHQCmmaGNEAiKAohW2ChRiRbsBPAuAHkAVFGYPBQkEJAcEL7AKWYk+NEhoUGIxGNzagMAgMFfgMFhA0lApUpdKuY4AAC+kBtQtAMBCIAzumYky95bStkOsopZ5znRjbZZG7a837WDhqMSFmTTb8GzlO9mozCmcUjqssbhQstsJ7uRGrTRGLspfyCH/rKHv850feKH4ck0LdJs8UZ9DMEz8ebpPOXKmtVIYusrgCBWN1V1v3UgKBFZVUlYkkVGWhrTTWpiUC7SilGopgDQaWSZLSmeRCNO7SMEZpXosJMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowd0JaMXKHZjAMAsw2aweuMEyXJzHkgf80tgypMMLB2jLVA4kwD4dVMANDHzCHSLExFwDOMSxCvzARATEw+UFdMS2CsTA0waoxMUCzMJwGBTAvwYkw80X5MDRFvjKHQ9Exbk+IMPyALTByxdIwlkRCMONB6TB/ArQwGYQhMUEGDDCZgyswRQAZMDDDTTARgCgEgohmB1nJlibjvpiIDnV2aYPzRlxMGPZ8ZXI4WDBp1jAgVGFTkZ+JoG15ixyGvxYCI6YtMo6BAqajD5eNvQQGIM2IXjZStM9IowyeDLxCDI4bO+c1Abgub1aLyQbUMoSHBJqlJqk5mEJh4R9Sp/XRAKNdIHyYReMeeNaZOKEY4aUGBWJvFxlSq9h6uCn5tYZYAGCthBgDAwQdAWsFDDMgAonIqRjCAFTgkCwcCDyIIVBw4IkRgxDAwAmC6QwBJD4GiUO7CUP2GkwFcSSJKVTeHAgcJRCAJQuoCQw0ZRwKpEucBgqhhkQoMBhA9cpkhQJCGYMFB4IYhUYIwICYBUqDkJaUcMxAZCixQCJAgmsOCSYiAhw4vTL0BAQlC4gABRCREhhlQIQpQIGCBmkGrDhUSFwoQfMCFFk4//viZOSP/uJlRAP81aAAAA0gAAABO8WVEg/zNwgAADSAAAAEcYTXY0tkGhAMQaKv0DAUTM6mVgwVkF7MTbAwjDDBCAzC5BfMcqVWTDEAqEyNtgEMFvFVDJJRQ0wgAaNMI9CBTGDBiYw6UBoMTJCgjAmBFQwYcA3MVTD7DBAQ+AwxIFmMJWCZTDOQWUw4gSGMIRCGzKFwQ8xfUIiMdkB2jDwhIMwHACGMSbAfjA3RdowKAKoMHJFhTAfgnsweYELMGUAezAwQCEwbQGVMiXc4AtTkxVM8hY6GKTB+kGiIc1WZkYJm1w2Z1rBMcRxlmAQSZOMQAYBlcaGrH8Z9KBs8eGTUwMB40aKzEIhN6EEykdTM6OMdgQOR5ioAmRCGYaEJikUGDQmYWCZhUJAYWmFA4YYBpiIJjoVJDCAQKZMHBiETixQM2A0xsI4PGQolWKgtBswGXR0LmFAkj2oSYyBQ4AQMlzb0GWwLKK2A0oE3GQGBozJCCTgyA1WR6oZAR3NNgwhjRnMksCkmK8PtmKEIkSs5saGYgLNYUsFmmSDhBUkMPJAAyUVPFrS4YMIN4ghNQ4DlAFCmWmtBEpy94gIHpi94cYcAYhOZyDAy1DuKDhDZLCPCCoDIzAFJVYicgwKHQqAjSuzUGByZNmTIISWRBDwjMQnhcoHIlyQCUMlI1gLYCjLHJRBwIeCAoqYskh6PzUutVZt1MLkl8xomJTNbNqP6MUgzwODTS/LXMRPx0whDdTZvKIMAswkzCQdTJtIbMgwVkxEBWDCcLqMK4AcybjUTFhABM/YMYxWiFDILF3MUE3UxmUCTSPBYMSRz0xwAwDJ5JSMR0HMymwHDHJIbMOADszfS7DAOHPMd4LoQkOAAHUxHQLzAyDpMBgJQwUQojC2BnMLgHIwOw0jBsAfMJwC4wKgYTAoBYRaMGwCYwRANgSAYBgrQgDYwRgIDAEBjMDkDgwbQHEIR4MAwDwZkph4RgQA5AIAAAggCgBQOBhMA4CwBAdiQFgcAKYGAEAyCiAgBjAvAFMBQDMwGANjAVBkeMeDRFQCCEAswAQDAsAaYBgChgTgRIdxGAIguJAoCoC5gCgDmAWAiIwBVPCEApgg6Ao9gkAuHABAwA0aAdJgU1YHiLAAJaZN5m6sLBEaGUIog4AKLEAASGi4G5NHQZL7IxrRQbRfBQBSyQwAAGgFL9fxJtRBlAQAwCQCImGAAkwAaSCCRBcgAUBwDbUQsAFRhwCrJB0AIRgBP4gYsE9aKChQYACgMVtMA0AgGADoGlolxBABKOyeaKRAACu0OACT4Lhg4BNGUGgAI2JrJ/rYU5MAAANKZMN02UpipuN8ii/r9TsCRWg7ZudJAAAQCk3JJ/+QAAQpR9qIHJZ/6z//1///Ce//74GT/gA8rZkaFe8ACuC0VmqCkAH0JmR4Z7wADvb8YwwfgAFBRAxDP6hCEKg3PYEAoFAoFAbJ5IEEUekAAwNtqCgUEiCGzn1CAUCgknOeqEAoCgYBMVtqBQEAQFBIjR7AgFAoCgIAbDbyAAgAAAAYDAbJ21AoAQDAIEjc/BAgQIITn4IBQKCRAjb1QgFAoFAoDYrRyQCgUChAjnPwhCEJzn4QhCE5+CiBAgQI2+AAABnwAAR/AARgZ/8D+AAiIIjh48w8luzO4bnMZOp8yspQjPYS5OHyK01WwZDJuElO7J6YxLiZTn4LrMnUdIwyQPDCYGkNAEl4yFDOTAiE2MZIQ4wDQqjBoTvMvY/MwNFyDIcBSMVAcgzoAFzDWHpMpwrk1+AiDIoNJNBMCMxuw+TJzGFMfoBkw4gYTA3AXMAEFwwnQMjLmGkME0JgwKRKTDbBBMPgEgYB6AwNhg8A0mAWBeYDYDwFAAMDoC8wFgIRoL8weAQjB8A6MBsIQwHglzAUAUMBECYwMwahoLkiAMMBUBIwEwDwgA0wDQAwsAiYCgBYODDMFsDYwIgEDAzALMB4BYeBeMEQC8EAPCECQwRQTktQoBq9hbdaiho8AqXZS9MGwC4wCQMhEB6GAZBAMAGAGMCgCoEATg4BYwDwDgwA5JQkAXGQAEYi2jmuWi4xdBowCwAlOlbTAHAJAwBCNZMAmkCLAkmAmAGnwHAHrZRBRORIUrQiUub1YxbowCQFgQAOvYukqm3BAMGAIIeGAKACYBICQFAJJgLVKgYANBwAAEDgE0B6ZqfqSCPoKAKUqUAbusUuLGFhlrJ5s4TKU6UZbKtNB0GgAqsfiY34MAMEQAyGaObxLrQ0SFDgEzAUASBwATQLvMC0yVeab6qCmqk1/Kxy5n7WVuP/0yN2bw8Pe12985X13+f3nf/X7/8O8z/9ZfnvfMN09m3rLeu65jlQtG/u7dOxTL9dbsxkHAAIfmAiAS1cwOgHBUB8wKQCTBPAVMfQDgwiRFTDzCrMs8scxwRfTBfBiMDoXUzTRgjJqNiMLYYwz7hCDrZmXNb0BtH+asZc7jvRh8g2hADzVt575jbMUYgwwegFR4AbWWWWWWufzet49x3Zt9sV5+9T28Mcu/ll3Xd5a1//rv7xy///7f5587rPdvnf3nlr8cssv1/cssu/zf///+O//Xcd45f/////53s/+7b5n3/zxv8/lv/Fg6IlQaTUqAAATQAAEQrMj1f2/n/KC2N3kaMfDoMrEwMYT8MDI9M80TCo5C1PmQQhGJJ2GEYgmAAcmRh3mNgwGUQEmRwvmQhymDEJulyIwYDUBj7IaztHwoBnqwbGomXEABGjQCw7SfGCA383PQMDVDcxk6BBmYUFGODyegCDjIP/74mQ8gAvtZc9ud2AAo2wmsMBYAGvxjSz93gAKCKxiA4FAADtDimiTEpjQqYkABwWZoUlVOMWCKIBAQcLCAILUltXTMNCEtjEy8FCJYAwMJhQDb0ICAqAvkluCgcvWCSlykTgYKJmxU0kJMZChCKqZjBiBAEZEioBpFly0XQwASABoCGCRABo8AYDZislCEmKkHhoYQqLqmFCBegMGi8IOAIHS8QPdwLgipG5L0BwKg6y4DAyVSN6fjpqlAIc3MxIOBwaAg5kLQ0JyOIJCWkOy0tfSXKq6qaV9aYLzqjcV/mbuzG3wbk/UvXe4kul7mqtSUVYX6GAB/VoQVYXFJOqZszUm5RIAuNAyfSV7pNYYXMzvC9gcIpJigEAgVTdmqCYaCGSL9azW3//////6vlQLR/FngYAgIIDNi0CPAxABgBBOBgOBoBlTKCBllJOBhSA2BnYkIByMgIBq8MCAYTwDhEfQDLYV8DEUI0DVLr4DCSvIDVSnoDFaicDwmq0DJVFQDFCLQDNQVcDe9zIDdMEcDFwQsFgLFV2fgZWREASDUMD8DKMOwCwnQ8Ro7TAuPq3XV/+gYE4XCmVxxlAiDHP2dn2//+XB2G5oRCcEAABSjgIEwxATMy7JA9Tmk2EpE+VFQ6Kqc1xHQ03SEwBJASKszWKMxlDYy3G0wtO0wMEEwLKwKAmb9E5qlhmZh+Z5exkV7HOEIahxx0QVnCEEY8UJkkdGWyoZwUZl52AZ3FaAMZKIwMBBZnmEyaicDheCACIAcYNDAcXAYCguAx4NA0IpyjQOGQK+gWB6SZgQGAIBBAlMJAoUAycq2g4Dl6UtV2OU55bGB28UqeEKA9ZQNAJeEu0BgEDAKX0VMLB8v+CQKsKgPWiX/ctHcuhJFlOa0B3ajFIs4DqPozVBh10USoAH8YUj81uDmZF807UAS23vepK9MlG+RrvT4RHYM00ssj+kiiM35bBrbtRleEMNYTcYMwhvIo3F33BR+fF5UgmMMoWW8sYaGj6xlgqV6bzXE0EN1bWCzjYV9qwIKwDD2Ubj8va0sAW2buvSBwoBVwFln1SyaHHqS5lUrXJP///////ymTRECPHoQUEfk2QcoEqV2F6Fo4apAwwAZorhowNlgZgaEJQBpEBiywGBCAYZGH7AZ9wBgE4pQFHAmpZPl8vjnmyAxhEROh4oCyCicYmyuv9ZfJwuHSbN9OUCclMc8iaybImswMCcTugUy0X1INrJ9NNymfqMEUS+kiRc/QCMBECIxTjnAASyZgaDRgAGBnIeSQZGdnBgJAdmZiQUYdgnQAG40xhwxVJkyfPwxPjkxrEcwIc8yISA0pBMVp8whH80aikzC0o+AgUx54c64HU0tSMwQTUFUAYtsKaHHmbxVWBhnM//++JkM47b3WPIC93ScHGrCPIAL9Cw2ZEgT282gdcsI0QAv0LBwMKh5MqgOCo7GBQ1lAfjoihAYmQAjmHAOmQwcmEY/g4eZBEIFIKInCJmzAmYHAK2d1IdvCZxAMpTBUgMJOjCMyQP6YCsZBg0hMyJkEmjCjA52ZESFBggWmeUA6UY4AYcCCgYhYgYiYYmNGBZWHAzGFxwWYgKYQGJDWGg44FgysIKRs9LJIHGRDDo4mFqQfxxkPAqDhTQFYS+Y0GL4IytgTNLaIUlo0YXnayz9OhUqtqaMaQNQUaelQ8i0Je/qLLvsjmYvE0lIeft9Uz5OghWELeg0C4C0FTMIiEDJqKbt60h6oGa5DishECQqp2X5MIn1iMvVuehOZgD/L6YAmSz2WqDtffl+4DYe3srkGMhn4AgSHbwEAB/9j4eKBLkHHgpDrDVhfiHibgE4COGgOgkZKw0y9p4WwcBN5DuZYSiLoCkBSAOZxs3ZJI79SwFYaBkDgJQhh0b///z5TQQy6vd//4dq9jQ9jW8u/hPpND0PL+h6HmQdCor/+pGdP3Vn/wdCHofeI8BYwiApzKzFBMdoLM5FCyDcaX6N4kpcz9aPzGSGBM0gWow2xqDHCDMMEgskw1A7jJcBJEIuZiEiDGMERsYFImg0WwYYQDpjPg9mJmOEYDZgRhijYmK8o6YXITJgMDNGCSDmYlAUZiDBhmC6BSZcYcxhaiVhhIJiLBZmEeC6YaQD5mUCZ+LiJMMKHDlRMAiouAA4VM+NDbgIxdBKykLnxgwyUDBkz0FDQyBwMGSjZR0y0LDDgS1THRsFh5hYEaiBFggYGUFxnoISAU+EZBEATmAjBuhR9PcDIGOgNfFReksluiiJIktqgPLzhYs0QzODLsDykuQfAoazDCCQyIiC9LopuRZl7ap6L9UALjl6k3gcYgBayBQEH1Gmgo8pjIONZTqFhkBVK02Bmtl1BwBx1Lmvrmkjpxtr8mSnRKfBZ0bWBb9Qx8IYZcn2XfLY+pRDreapYHghLBjSUSx7LvPc70CroL5o5pmy0uqgsFiRAGXQcpAWylHktS8Cp1kOAlSYIKtSmDgySdyF/8IQIB2BjLYroNoBaBPIWxEtUjWa5pFuHqLkvk9ExITs9TRBuiEg2QIICSBhLamUNVOj+FuJkXInx+kxYT9bFEW59qrnAxEh3jGG5EGJcPp3//liUx1KKNC05fDNGVtLd9R8ilv/6fG6aJ0q3X+XlDlOkvqhQAVswFwnTJKM5NSk6w7WTKDeSIANl0Xo2bkLDOFIcMiAc0wsyaTtA3jV5hDTaVTZI+ziQCzgMLDQueTEEbDVIgzAyBjJVtTTyITHceD+c0DIwEjrsYzBd7TMEfjbY0TEBYgygzl4+zRYCTBANTG//viZDcOS/FjyBPd0nJ5KxhAAynYMEGPHE93Ukm8IN00GfPAYkDMslDJkFDAUER0IwsEQXDcxIE4IE0xQBwyLB4xNoClASAMkJMfFMmOMunZUctoZgeKigFqMYHBA0QHjRnzhJDLlzAmgQQaSAkjwoKA4eXxLfJ+kwUIDDQJbJKIbAWUeYmFJ/goQZEUiizxuhAHe1XIOAlY6Ake2vLvBQ0EBAgqg8hwJhygDHmwOSDARKCEYVgrPRorSInIjsODgiazzphucHAWpuKqF4kETNG5slc13hIYqRWZ2hoDBDM5YjktJp0TUyIiaYDWl5KXNBbdB6Ul/UgFLS3DQnUhtHVZsqHQjDlHodXDI1F0fXpWInUBAxgxC1xoC3jXhETTTXgrluThKBNjgiPu7Sy2HKJWqrl//////+oBXbFGtO9Tv9JYdaS019qOJS+XSqNU1NMzkWcGnivcYlPVnzbiWGAyAGlhl+xEWlcZzQRgTRlureoileXaUjRpKITBGCMnmfCRT5iJQwCIGisZwpu//KtmVW7P/Td6zVERNazUolg1v+x8pbftCWMrIkSLQGBASBiHqaHSpSqYwXCRqmm8G/2WYcIqjRqBETGoyFmY+zLZk1EFmNCSWZMamBkUh7mJ4YoYg4g5jFGDGASHeYrAUBgljcGM8GSY8ZKxipk6mgSO4YhLPBjSiyGkMbGhzmHABfmB6EGOwhHqaqmbyZGOoMmDxeGMwfmeg0nNCmgrHPSmLqGkonzAHQZGIxmgPmdNgpiAG53EhmoZjxRtLQSnOkHLZmFCAVkYokcEqCjBzEYFllYlLZJVjZlEIQyNomEJ8z5IwpUIimDFEI4FUhIcTLDChxYAZcMyUMLBwBAEgQKDIqEL8LlT7SFMMbJiYoSLjprKaoQKvLqoS2XJmt3aaknPpjlxIHZBWLARlrvymPO2puzBSt+n4d5waZ/GDxRuaYjC0oggk0RWBkbBW6NacuAi8CtKEorBrTRcT1VjdhBE2V0Vjxd6k3WLPWre38NNfSObAt9SqaQ7qDu4v5iQ4CZOmk5CqKlzSF6BxUs2xJoKSbXkFH9WXSr+X7D0PdVFAAAEIAdyD/////////++RkfyMj//rKIapAToMJ5ks3HFYgdBbxxtTLrM+sIzRUTbDPMKO448kzVhHcOazOGd05lYxLKBwWKsOPuzQ7OyjQyVNliwzGfBAKDGUXNFI0yWGggPS+zz/xXrFOLCpnrVAEwQwWDKnLBOlt4o+3BOTzViaOQcZ80jLgzZpO3MREioyimuTDwDnKx+DL0UbMmMRAxuDiDCWCRMv86MwSg5TJpC5MTMYYyLBXzCKJHMM4lEwfCtjGHS+FltDECJ/MLMOAwZQ/TDFGBMKISIyBCDjAbAKMIUIv/74mQ7DvxbY8cL282gdisnwAMN2C8lkSBPd0nB3yxggAw3YEwZgnzBbCcMLcHE5MoNcADIigy9FNBKQoUG/JhrD8YYekDMSiJhgibSbGVh4HDDHTgxU3KAsxYVMOADGR4xU0M8MAMTmLo5m46RCgJFTFiQWJTNTYkB7x0kRGLwbcxQ2lC1YJhFAjBkByJNeiiDkRoMeiNAgYcFARolOV12bsCBCiCRQMMHFnki0/VvioAEBonxLIMGZ8uQyAnYQwEQqRSVakELE9F0FxAaK0hUDBwqCl6ISWRLAu03JRBciLqQ5MevtPlWAu+5CaBeAummI6kUTYkMHq3qDl2U5F+tfU1xa2re2z6LYLxsTL+Pqre9Vhu6SCaCmKi7YXwLapmIzSkvs5CYbXlVF7Jrs4XfI6N33agi/Gef//////hH3ft53IYi6M5rakEWQaBb9aaGjgF/GImE4QeNSykpi8hmAyVidHVqOrhKWUrFYjDjEo+x4t4vh2JSvJH5VFBXJAUu4Sg0hbJaVT6jKhsQgXL/zwibPC6dxgb/OJQtbaflT///9aAW8AaA2JifgtZDYFzEZB+MiAm03nglTnBg5OEeUg1XwljOkpUMror40/gBzFWT/OMSzMz0gNt4CNZmUMipoMukGOfo8MLhwNjwDM92RNqEONt6IMhjpPuDcOG43OtlvN53sM2TUNkwuMbn/NfQvNc1VMNDKNEw9Mni3BRvmAIYBULDEQQjBUtjBoPDFwNjCYDTFYBzFkREnDeKTEpDTAwgKOhzEhypmGSJl6IjMGfNlvSAibEmgsc1KQjQioTTwIbLtDowkDK2AI6liQLE20iAcDFAIGLlUSgNQlCQcKg0xlXLMQAsEUzDDwgDIDGtF6SUInAuabVoJQKrkdVboS3JsyWpe6fUiEB4ipmq5lrUGHphtybkXmdRgalKSRcFh6y000j1h2dscYW3jJF3pypmNTa2meyEvo0FlCajrF+XAa+nmuZpzTkrmqqqoLMmSGg9w3zftZLhPxL1sy4hExJYNlkvTScZWBVJ34cpkuEdy0Sx0iyyKQL/ByBuBeBnalkYi17X//////4yowAICoPo6PKW8EMU0AKYyh/N9CwMMwzE1nphZCVyi6a61FhCEQNPKgEBmLTmKGsZfiDp/D+dfQqDCOJ2Orl+t3/2m0zFwXebMv1AOX4+ny5/4V1Hkikii/AQJOicRvULwrf///uSAPIAcQi4X8QwAPFqMNMCsxEWTjyLIxOksMkx5u0jVFNHOGeVczsDiTFlPtMTZcs1bwrzD6IBMWI6kzZBQzDbEaDEzDMXEEMSMVgywAkzCOKjMIoQoxNj1TC2IcNJoqUwImqTEUC5Mcw5swWBCRJd8xLg2DGhBUMYY2wDERmNCGn/++JkOg/8fWNGg9zNoHRrCEADEdgzIY0eFe8ACgUsn8KBEAAYcAnBicg8GEQHqamGJjZBmDS0aWMxjVPmAS0BoCZ8iJlkDGwSGRFUSNRglDGNRQaDLhiFIGKQmZEGREXzO4gJhCYEEpYB5jESmKisSCYzcDSwLURQwTglYylCDtVcetWGKpIUVi6xAVcZpRkkKfCgZvhg0QzkQQ6aRo4CWqLaKsBQqEszBFrpRRcDKGkMQJChJlkO2XXBwSqQs0X+SGJqAuyz4vSXbEQTqILoCHfQ2XI2Fk6NECtEiC7HlBoQ4UpNdyoUyZlPVIEDAM/f9YNrqlpfIRgIpBxympiloVJkNzXarbKkdkJzdVY5cwZlDyqoluyzkZdZ7i2rLGHvhGZYzZJZssy6Da3rEQLkz8uWK+SqqYyKJfGLs5gu5///////3SzR2+YFDdztMQ3EyAZwESndzH07ytZ8OBheWqBDwOk02NsR950OhOul0j08z8KuyOCBLX///klOHPA7a///9/2qKDgppjMIjqwFmme83///+xhShV5bFJweGYioTFP/W3///oiVhuwMEEKAvgspMJwKAxRw0TmOK1PIw6k7MLEjCwHaN+JDs0CRsjRPASMYQtkzow7TElFiMUo3YxHwrzCxEHMeAK4yhAWTDNDPMeIJMwYiDTG3BCMEscAwdBsjFjDtMJ5OkyJxATIHJGMUsT8wwQbDBVHqMKENowWylzA1ELMNkGQwExAjCUByMI0BsYBgMCsE8Eg8mA2CSYIIHBgNAxGCkBkYKQERgHAWAIGkCAChAO5gdgPpBmCUA8YFgKRgAAMGAMB4YAIDAOCgIAEysBsAAAGAwAkYLQDIhAUBQMJgGAWNqAgUgwANYAwBACErFMEBAkAyTAAoNl2hIBeGi4pfsHAQO419RZh80rApWouuVdawKdTWmtpgqdILLwIgKhCAOKgEkwBCv0Uy85VADeFNMQgAsGV6DgAC3MLV+/wkAOXfdhIxfC7WtXkP6FLuQJCLstPAx5Xk5NI4qUNgXrdm5c1t/oAwjawLoPcplRsIgVfLjrB1Y6v6Cogx5NuAX/5A8ka08kOsqmqVkjXGXsqgLlRizW38aYy+EN2ftp0xLILp6////////RSE8gY4gwWoMRgaYZUGx0ZUgQX9GytIP1DJQwgILh8oWii8ANQASDbw2cLeQv6GKQNUP0GNEFgb2C2JolZzxWDkQaEMYCDkVanOCkhSwhYgIgsTxcDIxaNm7oB+w4B7OjhDZQuFD6jNG6bJf//9jofqNsRyFooWijoIkuolAhxpuOSQwqEvjDuDTMb8loxxzrTAHGVMiodgxww3zAWESMoUtYw6APjGoBjMLsS0iG5MKECYwxA5zCqDhMdEI8wYQEjT//viZCMAC4hlzB57gACHDfWlwVAAL+GVKFnugAAAADSDAAAABgNWJQxiODKq2MJsM1KjzOx6N5CQzsPD2mHBRUMous4yFjRzaMvHgw0BwENDGwlMFAM0ARAwYgQCrlNFAQwUCwCCxIFmIAYDQEBg03QDABRcwsBTA4MSECoHBQvMNhsxuB2uAUFhUFJwq6TsYUxJCFWFiTKlpsASDAQYLuJeAIAJgTA8K1kuoxuuoCAQSYHARggCiwhdcvnFQgAkAFU+zEuPOzDQJEvVXsHM9s6X6z9oE+wdVikg4ANs4yPrXptMhoCkU11jsFUwYEmqgOT4QqoIg09kjnPlYZOyJyli0r7LoeGYQRvdRuMEAOgQUWggSgR6G4Q6kNEmhuGrSqNEekWqyVZ2XzUci655Smk2VxltPaPAV4Gz2PX9D7tyhgLYVXoDFkJJIzKz0lkASQAAD8EF8SnmpNeQI4v8pGJMkF/1suc/8gRMBZEAsTAxiEBAL/8CCcAwCHeAIRgYg6DcANRf/+DckMDACKQMAVBYQLeYni9//+OkWSFlwX+GXD/EVKRGlElv///HOJALDgCDIXxECiyjIpkRPkiRYpEl////+UFk6ZKrSRSRWYE0dMDIolQEAEGmYxbSLTuFI1MeI+k03wgTDyRQMSpjY0aiYTIvBZMIYl0zOgjTXLKUMCwGQw7QFjDYIRMFMLcwww4DGsDOMEsTVV5hobJsmkZigzRlgtZjURRoPLxiyY5jAm52EhByOOZlghxm3AphuDpgAcpqYZJg2FRgKPBkCExpsVhlSJ5iSBY8J5qwD5g4BwXCAxRAYQBCYPAAYBh4YRBeuUwIAYRASRBdFXaMCQJMAgnKAgZUi8EAwYUAaJByKBSj6GAqWeAAFPQgGSaW4gIQGrBJgMCCABBIAiMCEWQMASwy/ZEmmn4hKepfUHQYRAHDysAGBV1C6ysjkzif6hzKoZTCQiaImm7MDzmTG37bFDyaq7HdijsvxFEkn/XgCQIKoEQyRAAn88buqKKbLPAgCuRTRdEx+owpqXpY9FrbpqGPSkCxFFJuzpr0ZnAjI25LGXG6zSi87TWGpuqVRj/a21Vj1umirhq3MFZwyJY0ze9oS+2wqSZ7BLAXWfeaZYuKCgAWcwAQbDHBGrM3E6E1bD6jWrTENZYT0zMChjCaB4MnEHkcFGMc0A8w5Q5AYQiYkAhJheBWmDaEaYLQxhhBhyGPD8InIZVXpz9YmFiadMC5qZxH020b//5pR4ApVGJ5SZOAhl6XAliGESyYeiYAG5pAcmIxKIwiYrHAGPxgwRo8GFwYCAAnSYXEQICYQIUvA4JDgNMCAdTgwAGyzA0Kk/RQFqUGAQkyEwEC0J5EMF4AEDDQeLyr0T6RzTCSicFppf/74mRgDvsDY8mXe4AAAAANIOAAASrljSJPd0fAAAA0gAAABLJd5QAINYgNBGRL2V8zN2UrBIFLleVtVcsoXc0durUY03Z9FooJG7SRu0APy/yaa1WlNustkjDoi76ulD2us8L3RVgDBkjUxFrOZPsshp/mxrizjSHJ/mIqkWCYlHHedOcmJ2Go1jSvw5zswPAbww9LIbsQhlkRao5jM3VnW6sdcuAmutaeZoqPy9VirwU5hb4s4TDTugJbbQFMpPIocpOAMNBjmRAHeaWikBmnNWmuWnkcHAIpmmhfGMqKaa7r8MYwJRMZKLuZSYga0m2ZFASZpgyaWrqYbBeaiEcYqrIY5BEZyG4YkIAaRBiZr1kaFisa1dwaniob9jqCT/M8QQMA2VMaRiNkQVMSCyMiwlMswZNyzAqs4JM3xUFHzxBSgkYAkNDjbOQhkEQDIjBAMRKBQUeMGOFGNCmCCEIsoEF/UrA5EYMKZwKZcEYAKxIRjS1iPahCKlZEVdShqFCdsiTcUPLkoZCoFJxlbYnnDDCrx4MUAXaXSvpR1ZSi6mg4EjrTYOU7axcluFx3qNQ9srC3ViDuRbKUuxeaVVbGylxfdp/4ffGBmcTUtgqEP+xeXu1BMMLBP61tq7DW/Y6/zkObKodiDToo37doRAz+v+0BhkGOwydPRCmLKpJbIJ2IMdlb4Oi6ciZXiyu3LMLDHmyw5LpVH6K8mkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqABpxEEQYs6CBtaqRnc6h2IiJTrkE9MmRLMyaBYjMMBVFEXjEg3DIdzjGnwzSUeDCEQDMEVjcpODM8bzKcRzHk8jJ5MjjspzB0qjWEwTGuvDG4YD/31zUVDzn8LDLpgDFwDTCRVDK0uzhs2DLWqjFMSjMAQDTMzBFQInLRCoozJwIOFYR5jaxCaOFUIkuMEGByAIYMLMQEEJkChRkOZYMLKExULhZGFwIXFiAMPOQsNZ+WdV8rlExyKNA9TdWxACFyJMKeYv8XGL+pEK2s6EJQGCGYjgR7nbaVxPh0UKxo7H0JRQSUwJgiKLc38QbqQwo2kgsSFNkg+CVel6lDEqEp1V2ep2srfchCJKSmDpe6DqKpqaOAxFAapw/DMsmfMmXRA7SCsI3j+M2VnVRh+MvBKUfkK17RtZ6asER5+XAXO5CTzdJZ6WyeKo3hC7/++Jkpg77JWNHk93SYAAADSAAAAE7GY8KD/NWiAAANIAAAAQKZaSuCcEgKpmPCgoeDMOIAELh99+OI3bZgMoi6Y62ffmt/GRRsGilscadPBnF8CThhAaf4ZDeGvmMHjnZgdh8EYUAAbmDJjXJhXxLAYuYFVGAsCzBhzIHgY3mGLmFkAJZiAoKuYIaF5GGDBoBi+gHGYSSFtmPCgIRggAb0YmkETGc4DtRiFxICYIqP/GDZEFRg/QCYYbAMMmDPB/phuIlAYQWF1GJvAxhiCYTeb3cx55LGKS8a9HhjYWGTxIYVBZjFNiI+lI8MUjI2WHDJB5MmEEx0RjCQQAwCMTCAx2XDCYXMrGM0gIjEg+McjoxgTBASDIgwMOAswCJSoizEqDJ7DYnjCDjHiDFQjQOlwB0k0UEssBB5f04sM4KYaDgRabJAZN0YmebJKZhoY0UbEiBkLO0EwJLmoRmgMGzEFvDYn0UgwKOogioaRA84FGxUxBkogJPkpsHbVMyQcIB4RIWEMiADCcbRsBRcyKVuoQlFnwOAMwEkRiRBcZQMwA0rEIzFBoBITAgRIqHJjBpEOZbIDCUHAEyRnS6DMSHhM/YWZBWDDhhACSbnCwZM8HCC57zmaLBxxJYKniI6CjZdwLDoEAxo1g4CFEFwKBLNlyxwGwUcBggUKhBU0Bj4NHjgAIBQMBRphACK6EZccxId46TQfVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUwKgHDOmCcNo9KU64AWDVI6/Nk4asy1UkTIuKiNJcKwwFEmDLcDwMUQK4yJw6zIkDfMFolIwqwpTJ0BxMI0HAII2MB4ScwmBCjFBBGMBQVcwBwbDBVGLMTAHQz7wDTAEFrNKgQwwnw7DDcCfNSWKMYY3NIAiNGa9DjlNGFUDABEmMEQbCMERkBC76V4kDhpGhcc7ITQbMwsDAApRXZNIIVAw4CmICQUcbxLjDRJZ4vkySNGKkgLAsilphrS+AhAK3ohBEhRACRCl90GGasZRmbmo0qGEJTr3ed9nhlDcX8bEhlD67WpMiTPa4u2HFO2vT65G0zh9hSxmzp92n/ftfjTHRkUIcR3GCq9j8FsFed+KRPZc005ECxyMwuadJurqpuvv2n7I6VKNz1LGHONAq5WSPPC3yi//viZJsP+uhjRwPdzRAAAA0gAAABOUWRDA/7S8AAADSAAAAEb8xrq+5O5iwKwcDPc0ZeLlyloD7vrWi7gJWRt7n2urdcdqNl9ovbMHvCnjJCS9A0dBbGOHpAhzVc5z8wbIV3MsSCajFHSqsxKwaUMEHHADMIAVcw1MJVOQwuAzsRgzE6ZIMVsb02KUtDFaNYMKQJYx2CtTCADkNOAukxUxoTOeCgMcJVUxhRfTfKDHNMY3o/SlGzGNiTAT6pmDL+mIYL2a3hV5kCvemiGHCZPbDJhQBfGWoEmYV4fZiFBImB6HqYNwEZh1AvGB4A4YJAHhgXBHGFGFqYR4JhhgBhGA8EKYhoPJgqgXGC4A0YJIEBjCxhSx3dYVOG8gGcuiglCQfkYYQcYBQnydmWbtUXCJnwPPoJQSPaaISZgyhmD5asANBIYYYAmwX8MmNDCZZwz4UzowRiiAOY4cUJCIMmKaFWbo4OjTflzOBjUkWIgQQZoeJPzCAgcUSTQrpDJgho4CBzfGHNJ+GGEL1Q8HSZKAQWTWMQfQ5JBFQijUFgBZNcQYPR0ByiXLkMWVBo8VREAEDIxIkBjAsVMaXMaEIjIhCkT0BHUlUG0bjCijDEDLDUHEjyqOMCERwUdZG/UFLjGhSp2Cs+QRGMEhYQaAy/SggkEC4MtUTBS96ZpbIqBBCOQBBDNUTeJ3rvYlArnt3gdsqXcJ4qTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAAcdDbMQFV00LXozTVRCN3+DcebaMeUnYwJSvDLyDBMJcb49WBA02HU8nCwzLC4wdKAzsF8zAVcwLFs1KDwwrIEx/B4wxA4wmN4yYB4x4JAyhGIrn8wq742dbEzYdcHFmbEncCjHNTAYM/lMM6S0M7y2MPwoAzGmAwBhwhExHlsRoDBCATTUzj2c6vEnHEogajM+5b1ygg4yEsLUXErhDx0KK00sOypOdYeA1bwyaRD/2nVgNdCcretZf2u0SUooTTjq8YrXQdYHD0NtdZY6i6I9jDckVOtFfal0ug+JvG3yssTh2UvE/8ap4VD2D7OMpNpUWl1E6U067OZW0B5WdSmAVAsnbiSuVPNClbuwqegCKLTkawCTz6wf/74GSNDvpuZEgT3cJwAAANIAAAATehjRAv7zhIAAA0gAAABBH4NcFlmOFKu1ncOL7VCSEdREduaQ8QftXgkZuBMB01Su7KFgWbsHS8e91+NYhiBKjZLPFGCOhERlNhEAY9MjvG0MGOJh3ppaZvyFUmGJFBJhHQmSYwqCfmDwBZZkMQLGYTSE+GRcB7JgEYLAYKeCvmGAAURgWAeIYbeFdmA/gmZgwAQIYAgFFmFGA4pYB3DBagHkwLYJyMIBAYTE+gG4ww0CQM6BDKjD9BgAwtUFYMR2AqTAdgsQxH4CaMFXFWjBEQD8wtATXMFuCJjAoALswTIF0MCGALDA2AEVdRgIwCKYCcAShUlM/KQoJGag5nEmZ02mKL5NWAY9MTGDKSowI+LzukGJ5gQ+ZMaGTLJmpUYKYGXhpZIlYC5RprDDazzYAAuyWhgiAEUCmCF5DUdLEIkeHj2OJfojgQgcIUydwexMJAONa6kCtQBqgWImGFgzEHAopqAC1BiiCUhkILbX2AYVJqSLntcA14MINUAuS7hjBGSIoagRBCBA6jMXIMwRTKFhUpVhgAmGYLGEQKJYcFUUqUxaeBBSUowhCUQLTgegpSNAIFFDzBmElwGjgU0aZh0ZNKEjENL+p3ARgzCBgBTkeIh1aIQmq1TqEgZFSxyDCDBwpe5eUFkxoJDIBkBjvQy0yGDHLGC1anUQUahAsCTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAExLRDTQbU6Muwd0zGnpzZWNJNckHwxlimDMtHeMf0X4xCSdTNYANMNob0zixijEQBYMCMKcwJQLzAtC9MGYMczVMUxJHgyYP8xbAwwYGIwdAMw/LYxAHUyzMcxtt04hKw1p64ziOI2XD0z5YA1GIsy7P0yaB45XdAwaSwyiD0xrAIxYBoaCAIFMiBkwADEIDEeCsEAIjUYEAsFAOLZIhJFseXtKQUBpddI5SpA8UA0qAEiEmGr16HHiq7WGoDlRwG+pf9m8HwI8i4n9cWH7kOT7XY+3aBmTO7GIYfVuVDBDLUeUBCsLzQVArIaSYi7DXXjznMAdCBHbfuBHzfaNJhRumfODr62X7bZ3V3Ozm5cGTb1Zv0/qmEtnmZsQelccDvK0t/X9nH6lkIZzBFho1HjHpu1FJYw+MqRl7rLSWGUc24jhMhZzEv/74mSkAArGY0eNe6AAAAANIKAAATwplxpZ/wAAAAA0gwAAAGUqCNZkcPMzT3SlVwwB8Y7wRCVYQAxKgDyMozCrjBeDwI1nspgMXdIdTEAitMwF4MnMdiDLTHDQ2YwysHSMHhDEDFPxI4w2IDdMD6AJTFXAB0wM4D9MMGCzTAQAFoxoxjQuM4YUoa5h+g9GNSI4YIAuJjiAAGkEd4aZRDRkgiRGHcISYUwKBjRDDGsKLAbBR7RgmjnGQcRgY0wPBgZgOGYaegZWAsIMDaMCUAwxwSOzTAEOHjGhoMwwDAAzBhAtHgCzASAUXKYNYKJglAAGAMB2YIoCqIBgFAOQghAihAqAOnmYEgCBgHATNeMBEBEOBvX8PAPlxTAKA3MAMAgIBqHAAnQQlMkTqBoBpgLgIGAOASYCQCAQBuNAJgYBMwAQBTALAGMAIC1VMuSW7CACgoBUmaYA4CAIALCwAJdiBQUAmYAACRYACXYRAFqLv0CgEGKq3DIBYiApag5ClpgEAEsHWEUAEgFg4BpJpL1RRtQSAOLAADQCxgEgAsRHgBBCAE3MaAFakpBTYeACUyBoCZgIABjQIim8DKKL7Q5qnDAB07UKJSjGj+CgCxgAKCYEflK5HReydCijqF00VIyzAmAJb1bCaNrH0o1OaISACWOpYofAKXbssmV1D2XskWWhzYkRADJTCwDUiDgAKQOAHd1tcUxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqABgzB0DBM7JQ4xX2+zNCasMVAyM11wvDISF9M5MggyMh8TDJJVMGUIIw5QuTGXFcMFEE0EBOmG+E8YIgE5gshhGGYqGJpGmLRFjS/GBpcmco1GI5/mR5cGoKGmfy9naSBGqHnmlKfmL79mGQhGZ50mSAtGKIDnIcFmKpHGNYhmGY2GBQQGMgREIOEw2FABhcFRCABgSCJgqCKYoOAMQAEoOBAEakX5IgTQSIhgwEggFVByYHQUBiFY6AyrE12WA0AyQAB0BXpTyCgDID1lPeo0/kQVjKoAIKteWapdRJftyU/Ekr10K+WM0tq8Fv+quig0CTwNFNKNRKLVEfWHJwrjjzB406UpaU/NmkbxubX4KfhlUeYm8iroHXdA61qeH/++Jkj4z7OmPIF3ugAAAADSDgAAE1NZMWb3dUQAAANIAAAAS3boafFpTXfbd17Fecd1T1BesQVRt9DvX7eFU8vgRrjpWYIm0W0t0+FDEaGnKqJDtjL0LAMuZSmgWda4+Djt3SqnYLV5KaScwAATJUMH4W436WRDOcyCPy41s4tUxjyZFKMLNrY0FB3jW3EPMC1bUxJQLDKkEyMWQ+UwPRWjEMBlMasAMwLw2DEGEcMoQAMwbh8zEoDsMB0G0wiBfTBqCkML4a8xpwnjB0LyMFQfI2xBVTV4CHM3crMyVg4zZeo59Go5PwY3ekIz63IxrgwMeYyrGgwiDwVFUw3FoMIQwHAQCHwUXLPCESZdkBlCLppwphCRtaYsfDARmEBgwZtWJE7MokM0AAgghEBQWZMeGLyyhgIQXBmBHmiAGbchkprRihyyR0ikWq0FNwcxGBSDKU7lCJMYwqAg4IAKQFRpiBJgACGgOUAo8kOyFL5qJCQEgiBpMCV4gQGiaeaHBNxMgKjWaGQGDyQQAEvEiwMHgUUFBAAtXBamih8rMeSYAghQBphIguEwdeSJ68y3jhJMPKBRxf8taZUUuNXBVEgwGPKgCtSwMOUVon2aEwhoQYDXOYUWYcqhIDA7TwQEAxiGASDAAYUngggHNkgi0UvA21NMlAlwxUIWdQTFnUA4CYAoCMAw4CNIzGkQKHVeDhDIXdkeFMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAWlzAJC1MYqNEwfS8TknadM7lm421xNTEFO/MYcl8xiRejAkKrMQcHUxoQNjCAE0MTgKwRCwGHSBOYbglJhyhvmHgBWYLAD4XBeMRMCowhAHTD0C0MIwaYwZRHDHUIRME8G4zWA7jE3TqMKkMU3SDQz0UA0nDEyKbkwFBA8AR8xnXoyDFMxYGEQhCZShmYMBIDRSEYArkL3G0BqCMhQ5OkiiZskiS6YZUdEETaQXnbwnEYEpDIbmSCEBQkvgzxj4/dazfPy/6NSd7LXVAg4rASNyagQAuWJLbsw9+1XvCiWhRPw/EHISJYwx9+i4j3NBRrY0l7ZcAZEUIpGmVHTb99lpsJdtrb7JIrIka3H9lLPINUMWU28Gsvhly3dhS1w4a/mJNaYY8itlRa6YKGytzT33sv5BsRbZrL3sPfl4HOZWCQ0inLklrBli//viZKUM+2VkR5PdxRAAAA0gAAABOemVDC/vOIAAADSAAAAEQ0qYIFiFlUFnAYaxEbEsPFVqwMiywdTJnShJmOmIgISSt5ACYaCD4GcXKuBlkIG2bemKNGXmQ/RkHIOQYikVRGByClpilQZOYUEGaGAYgNxinQLiYhGSTmF0ASRib4I2YMcCiGIigKBhXQJYYNsEcmFdgsgGAnzBOwjYw6IJ1MOqDFDCEAoEw/MJ6MXlA/jFCiyMw/0bhMeKEsTF4wagwoYKIMPNFxDCzgcUwp8HBMQuBrzDEhKYwZ0JRMEVAJjAnQT0wD0FCMClAXTAuAIkwMQFPMEoAUTkNATHwi5MzTDcV42UwAoaammGHjhryOY8imwM4BgzVFkwhPOEEjMHUzqDMPPjcyYzc+EpMwkkMjPjNRAxkkMxPjEF8ygXApSnyACMx4FMBFTFgcdCzZKJ1wAoY5jEAEGYbAXKHSJek+FV0GCzabidK6BEAOHF8hEIbgIQSbxC7jFRUDGCX+EYZECKirtGgKkUTPcpgMHoEhU0wi4QEKrCAIwgCERKKQVEKisBEoSE04IQyAvCrgzlQCCOICEESDAwiIK8UdS56tSqKTALRAEQ0St5hpjIGY4XFfxHw5Dw6cval8GmFxxGUX2lTFEtQQGiA9ZpllUYw4wAGlMlegnGlEFyVYxAwckaF4OUEAy7R48BWr9T2WvA1Na4TEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAVVjEDAcNsNKUyANMzQnCIM2FLQ1ChxjUsInMcpE0xNxezEgL1N0ZFMwEDOYp8M9zVNfw8NI00MsiyEQTmkCkGIY+mm4UGM4VGNglGlSnmP7omBblm2EXGT/XmHy1mBitGJTVGZpXGnoEGIaVmcBpnIhiGGSBmcwkGOQNGHgwCR1mAQANEEIeg4CQasDQ0xy6BkImWeDYi5SYg1q15VA3TQMKYR7aggoDHDpYGmDiUkUgiIMRjARokCLjCEIHRoYkRqdC6ZILFNjGhiyy2UckK2nOqsMSDv4QBo2hCawCl6VlRWtsSejJ0dWLuSl46kJS5ZQ5rsMPaysC+7Ok+3oWZHGI074pUrCvo8D6ooumg+4D/NmXs+8HOkyNo5flp79t1WO3ijkPv/74mSTjPtpY8aT3cpwAAANIAAAATVhlxhvd0nAAAA0gAAABOK67TQuc7yw7mw+jOWA1TMAawhyZZDTWlBmVLjT0etuaODAlDFB5BAysiCKyXSa6pAveJAFgVu6VKc6e0AJkhc1YeBoZwWAU3G8YQghBvlGYGaLeKbmSyx1BXDmV0nIZhQuphIJlGNGYqYg4Wxw4b5j8zhpM/Jl0rhpG/ZtoT5ueVhlWJI0gpnCeRnq0ZqcfZkiSJhOS5hpNB5piZ2wih1bxBh6QJvIshh+qI0Zpq+I5ngk5niSxn0FhyM85r2GhiEDJiAixgaCY8ChEKAgBUBAuWFRnAJrOA9TVRDL5pDJAFCqo0I5EA2J4369B6oYB4YIqYMOTZTHGAcPEZAnDmUKjRoCkTtjBo25QIAoTwMcMgNjxoDQkAViGRRjhIGgusKDwcdZMxou6PJgYLMqZBrYMOJyqJmBQgYeOmg4KBgwNKGADqBiMuYZUZQ+GDwCELfEgEWRhAcWNjIky48zQsiKK8MGTUrTYMEQBh5YpEUZKSBy7zrqOBUeFx5nBCvAwCjeIiEsVMtoUDImCEOSCUHhlsWsTlXuoMRCTGBVBwaCDhgYxJpRjQqeRUBGHIJFloBaMHEYfCoALhTFMAccUGNKrAQMwsUafKGNYBSUHExWizAyJAuEZ8KFlxwwA0BAooAiiaUnWc20YNBLnIc2vM3uVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUDZSMGnBdDJDw7kxBxG/MYyEZTPTRqgxhEIEMToBFjFZAuEwfAOjMB2C9BoGfMFHCZTNBZDJROjeo8zHJdzFskzItEDBeJzHpsScjTgQ6jHszz71Wz9OVDb0OD8Saz1ERTKVVDWwpzSgVzFtdwYq5iWGRmHBBl4URr6UxmmcBi8RBm+DxiGCJgwDICFUwUC0wKChFIIBIsBuDQxCoTlmVmkoFgoIiggQYiVGDoCA/S9DMWKnhnMhd9BwbGLA6t5nABUooUecMBStLhghgVMGlm3WDQ9OgQSGJDGIkS8NMPHqCoKmiuwIMQsJm0z1wFnHGWEEnzNOFhxItmbMGrGIGwIlDCoANXBJSNCAkaKAggcUuseXcSTmACj1BJe9joNCZIvtOBG0cCXUoCUMjAamSQ4YjGGJl7QqETEyGcQnkg7c3ZUGXM8rUVjSpLwHDsSEQrdEN2AtkC5Qs2r9rbcUbQdEQwmSmxwiQFj1ep1oXoWq+ZCQFg5AWUAoAOeB1goKz/++JkwAz8Y2PFE/3K8gAADSAAAAE8qZECD/tLyAAANIAAAARZTZcsFr1KxWPN0ttGP0EtxtszpkbrwZymWur3ZrQhKQZLIpWmUxLtBohxoMYTKWDGDxkmhgVAJGY1WI1m97biZ1qUBhbjqmgmZAYXgn5pVLjGAkdMYZakJplLUEI1pklq/GYBUqauzUJ7zS4mdqHCbiqnZoMCmGXWKYZfA/Rofk9mSYBAYexA5oABCmA4H0YRhzJhxDGGPUKKYNoc5hHitmICC+YR4DhhxAFGB4EqYAIERhPgqgkEIwfwbDBMDlMBwBMUADAoMJhaA1hAa5lABqoRroxj9Brhxw0gGzHN9GdXGS4GOlChwdegJuZJKaYQIJZtfxjUBnDBpDQCYAaMbJicZqYFo0k3z00J4OThiEwCM2pkx5Qa3rOCBRiTpl1xgwxySJpR5jXBaoKFjAFzbkxpYbpqIGUpOIqCgwtEgyDjJjUZqDgWatZIoRCQCp4QIBRWYYiaEGFyhlAhiQwCXHHTgq4QAgWeKxY4PMYeGSCGplBZhiJtQAYVWYOARUEYgqw42g0DcBEWOWZOk0MAPLbmVIGGRAUga0AGOQuDARw17pK4OTmAKGgwHBNmQCmEAAJcYIoISAXSBwsqngFwBgYxBcORhRcWQM2SVyZJxRRE1DgYCGOOI+FyzCAhSKYxiYw6l+TCDKAgEBEIRBuXbFJMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMc+aGjmjmCg06jhbMqGMRjMaBVsxsEi4M0bCGzDcU68xGwRTMEKDhTBeQK8wLwMHMqaIADA/wL4wCQG3MGVAsTCFQAQxDYIhMFdCPjBkQV4wfgDnMKqBGzAVgxYwQ8J6MUoC8TA2Q04wZEI+BQGqYE2B1GCkgnpghwEWYRf5zBUG5UIcwZZxfTHSC0b5QZo8XGVkiSLoxmAjAwjMnE8xeDzChbMQDcw8JzTItAIECoFMHklJIoQiXLCjPMgw6lWGYDLxAj8p2AXpIoRjMcYMEJHkhiwZrS5ZUvoDggQuRBCohYcZDpzmCOIiBUABDhkx5awlHAb8h4s1m7GjBAzAigaCMmXFRzsonjAAKpwqKJQJMVCoEwwkzCoBUAULJnN4FZxJE7a9A4AzAyYltxKeF4YWFCQswAUEFTCLwxQJNXPCHTrAYChlDgwGAAEEAS1iRy2IQSgAFSBhgVKhwUBECsyIlIgHJFiI//viZLQP/gZjwgP81SAAAA0gAAABMyGTCg/zL0AAADSAAAAEMKFgCTJlxc4oQGICkopsAVHAQ2WAKK0CtRMKcEQkADg4ealSYEaYQeCSiLZhhRlHaYRkzKFixy7pVAEJ9HgCEgIuDFYAHGFBjwtR0UGQIgCCBm3E0a//7aDGaWvQ2DddFNoT/HDFEzs4y+AI9Mb+F3TI/QDsxmEgKMKSBdTB2wV0wFQECMBuEIDDqh+kwg0HiMD+A2DAXQT8wIED+MQ1Brza1QNZm03nbTJ+wMoiQyO3jLpBMr1czYIzsxiNmpI6ywjZpGBifNZIMwiIzUqyNApoCpg0sXTQA5MDIUy8TyQRGYCISh8x4WhoCAwhmIwCAhMBn0h4CAiIxAYJEwkJFfopl8zDFbwIZDkkl1zmwEDZy3QWLFVywuwUmMIRDDRWWAikOohGBCTbg1YKgyxp6JQeqxkz3FdwGFRxIQxFzLXNMwu4BiDInJi0T2BpnBiZ4rqkDMSzwoggjB0BFfLU4RZAAqGgGX0Eii9Y4W+Q1CQzpgMSLBS9AGQrwOiWqFknQMIN+RxAuhPN3RYQ+WYCDUMjAAYkJGqZghUtmCiU4k9RGoYr0QFogMADnokMEgrkKSFDS8XrSMi4GPBThYgiRpIGKIJBIABRVo5CgGRmFCGMJ1AUYDDtjXe7qKQ5KHVBVZOsdDaCCRZE/uHLYPv9X+ymTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoxQkX1OwFKlDYYuSExI1UXMX+G9TEMhQ0wDME8MGnEHzA/BIAwSUBeMCvBQjAGAd0zS0OyMB/BrzA6ga4wI8DpMChBUzBTg14xY4jUgzFSKawEZl1rmI4EbfVZloQmVlyDtoY9V5q4FGTB6YSexusjGvy+a8IRgUamFRSLGUDBAxoTDDQHMOksChkxOYzCo4BwuEZXMFhcw0BhkqmBQyCA+X4AwYbUEApbDU5hUAItzW5qTCpoUQE2FyBAA4Yt8OVAVAtYhJGoxACmMXmC4pf00xQMoiUy5Ccucs8QAgYkRAAYtItWUq7JqgxcxBUKC31wzhFFSB8cSSTlScJAQYJA7sGLMPLkM/BoYAdBRSN8LIQQQIAgEbVuudIE5i9rqsnLwFYggTQ9ZUXKXyqtAz2KiS9a0XUBAIXBDgRoJioKpIUkxjFGEYIgNTPYohCajv/74mSnj/ydZcMD/MvQAAANIAAAATWZmQoP907AAAA0gAAABDrK9WDQeVMASxEABFkfFVjBUGhV6AEUtommqkBClgCYUcSKDETB4F51dlw3PkAGeHlUy1HGuoyoqGGNUdzChryh/P//QYOwoTmY0IABxz/LIZZESGmR8iwph1waGZXEEWGOGBTRgL4dGYCsAymBPgiRgQoA2ZvYK7GGlAdRgmoFmYJUAumC8AzhiXQUKaBkGaYD2YPDsY1EWaACQYjiGYJFwDjWMUD7NMSXMMhZSPMEizBorHLpzmPQmGAgRGEg0GGRDH9YgI2InpbEz+I4J83LQSbmxLGSxmMcFojJgjCHDJvQc0N0FEIUxqUu0GKjJAzCizBkTEE13BZEFio1pMOOEIoREGLlQ4X1BIwwJEORAEYRDF8ixoyx4oFA6WgiBQEBEDHlAaAeIRlxUm8BgBDfAAFTlBYcDyMMBiogwRBLgBCTgHxELVrBINigKcmNBjAooBqZJJmWIDoVlIBAjw0DNDMgAMHZwgHCxtDMHAjBimTA5K/aZAqQLwhw9SkQgjBGgKEmk+U+Ui1VUyyoQUfGgCHhcMILmKEhAMIFlUcpYjEGLkUy+KwgGMGBGuWAQ6KxmQoCIN3WHMQMMcrC4JCVLTDAzEqxQQY0YZwwn0ZMGPAEyXzQHuZBabwqeaiWuZqyZuMBsUld/i3GusRn//6t9UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTFfArI854QZPNa+TzDsHSgwpoVVMHuGBjI+gNIxLEUZMIYC2TBRgPowg0A0MNBEojHxzKkwrcHdMCFAGBkF/MHmAlzHSwaEzLOjuQqNyIg18Cz+1INLLo1YzjUCDORQA/SHTLTpMcHMSR5o2LmVnIY1LZlNamSDWZTTpnENGkhsVnExWNzAQIMgDsSHZhcVDQbJCSZyFph4DmGDWWCKWAmYAAiAowCATZtSsA0ZekukY4THRYUwRwqubtpIEXSHEAMYCaUxBHaaQazDIWEnU2BLkwhh08xBRZUDVGaIdAbxiugt0HEg6IzB2BAcwQUhzw0wLZPMmaFWx2A3j2RD0YQYBrzJTMRIIVEDhoHmMYg2IxSYoKHFUMxpwuAHKxgEBtgNCciiGQSwcMAGSSArFUzRMBAg4ebwabxhTIKkh7cmKmM8MCmSeoIxAaXMlhS0LkkQJkkJEl/C3YlgQpAMESqC4wjFMA8CMIHgZNN0L0phF8iUJMwadC7/++JkvAz9T2ZCA/zL0AAADSAAAAE3+ZsKT/NOwAAANIAAAAQbaAY0VeMMEFPrHEJIhkSRAQBaVriRAQ4j+YKo8cbyAAASqgyB7LvRdr7ju2uie//r3AigZh76nkY2qmnnfy67xmzZPaZTIJ7mFdiiBixIUeYNoK/GBoiKxgroDEYGwDOmCphd5jIpUkYLmCymAUgxJgYIF2YCMCrmEtBwBrOFnijgZ5ghspCGBmScNExjIsmliKa+XRwKmGTAsZWEhq0FmejifcGBiIAAgZmCzsYvDBuBxhDoGcmGFh0UBbTOQjQS0PTEIzLRwEDNwKIs51JrvFQEWB5f0IYiMS0Eu0IBAkVVMY4Ea4ODqAsAMMjMWFBjw4yBD0wR0FrDHAS1AkDMCPX4IT5UIhCsIJFQ2AlCWKSYyENKBB0wwJo4AkVEmFdGOFmHBDwQVBLXBQ0aPEAE0ZkMMA4IgCRvFgioQSCEAwWBCMAnOYcA2hbIVBAlOAigoDFiSLDHE5gAJLJGUR5J5JNA4CCRCL5jxhgyZUEiyYRgw4QTEjHjjCGRQeYYchzDhrYnbBBtL8wJArCputhaOXzV4BTSMZfMyqEAFA4kDgQMJGNEE3ccKI2LAmSImoLkIU2AcCKjChzbFTPGTDtQAvMk/DApEzMIWMiOMpmGrIIemNVCIwdviZw0a0aYYIt4oUKTFiYcFIj6DIsPktH//0pMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjGGQzY7wEfsP043ozHAGK8xZUjTMHBA1zNLwi8w5ca3MNvDsTBuQHowRMETMKyBjDQVBnswdAHKMG0A0zA4QCYwe4HSMYyDTzBYhTS8TDKQKjQJAzUs8DVxLDXR0zKUqzEtNziRETIoaTP0ZDEAKDGcpjJAuTLUXTApAjBUSDJI6yYfTBAXjAEHQKBZkEBACAJPcBB0YGOa+0D7paw058y4gWVnAFCQsLDQYVMqEUCJRA0NNmgNTbKwJILIo5c9moNBGACGlgGRMuAJLxQOZpQDiwY+FRaxTNGggQCkivV6DxYaFmELvGBQgUDF1AuBVAFjBigplQwOBq6R8KiQQEQuLEagxJU0YUSHhxpOALAQ4SNP0NkwHQGAQ8wFhKmjrmQAKeMAVRTEQ5T0RLIhUMPAbKFBjQxZkmXkQYrIIVKJtxUBACMMIg6Ea0QnmIQYiJFugcBMsGEoxohE0gHSIBIAzQIwgQkDtSEBMDaVeGNFmdCk//viZLmP/cFmQgP908AAAA0gAAABNZmXCg/3TsAAADSAAAAEpYwQowig045REDRQcVIhb3kxQCgV2CohAWDlBacwhgDAUc2hBUCKjwwGHAkEoswNMpSHHhohB0i021kEieBqdGzb/+vOGG6JUpiuqDofeDUXGZzInBjhYrOYAgMVmIKh/BgL4x4YTcC5mD6BFQGEiDCVgh40F0MzMIlCkzA/gL4wN8FCMFiANjF9QIQwgEgzBXMx7Ek2vB048HA0hFExaPc2HNg1oJQ2vA0xsLYCESYGC2ZajGAwaMYjgNEhvMdQXNVhxP2pFa5dMyeQzAMx5BGUwwswYw1NoWKmoIrtMu5MMuN0TDCoGUCCrAJf9hC5AgCYEau80qARkAYua+IhZhyxj0IFSK3goWYQqPHEhguJXOBSkhHgqE0AjQcSMEHAxILAEuyFQYEBAgyRDC4kYBocSUAoiVQo8HGTqARQNL4ZaIiAaGZ4MniBiIWHDw6iMUGQSGGEmIFFp1zAkKqgnWMgi6IjEBiEDAgi2YQG1YgHgaKHJwEyHCo4gAIUHBEmn0IhyGYJUGqJApcWULXkTaGQoQVwBghnAoBEDT8aIIGEyYWGEQcwSIKAS+jMESE6TIHjTkRERHhqVokYKHaViyiICNHGTGHCg40jWz8sAQsaYqssLAyJ2DghpU0sBT0abFtiEaX+bnHIEhFe9ZzD3//XTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTFsAeU5BwPmPmIe5zHDT3oxowZjMNtDwwMZ+mE5Cx5ga4IAYHUD/GCBgaRheAK2ZZYQjGD4BARgToLgSgsBKBFmJOBoxnqepgWs5maMZzSLRq2iZrvdppXERx6nxqIH5uGORsmi5k+jZjWYJnaopx2OhoaV5iy3phmchn8I4ORYwZDUaF8QBKDQ2MLQCQkkgJmAYTGDQeK7MGAyMKBCAoiGCQHrDxwaFcwPneEIKCoGKHBTONDrjodU4B65cwAEFojVOZAzJTQLng64xwS6iUhxBp5iGFVMDAF4K5IQkG4sZlDD26GAAlsTVGCkFCwsSPPBBiwbQzlHC74IDM5A0UxCGYqgNGLYEKhbM2TiaNTBDaEpHJDoSwuGNMIgCR4NEJkHYEAKIxrFF4jcDSXEKAtoayL2JkJPgf/74GScD/yiY8MD/cvQAAANIAAAATKBjwwP9y8AAAA0gAAABIoCgBw6JJpmoNq0LNDh0ihxAmSHhSIwo3QzMIcmdCgpZBtEQWxVFAgzcOMZSuEwQDMWCp4VEQmCFZTJ/0UA4xBWLqoEJqXCerqh0hFwwxgiXA1UmIXJSBhFh9LCDA4zuAx1hBbPoTaXjJgW/MwsgrfMRbAyzGWgbkw6scYMBDBDDBRwUIwxwECMBwB+jFiSrkwPsEYMHYBfDB2gkgwPIFmMCOEITLwwAuB5tSqZvaR5nOTRrh1RljpRqf4RjqBJ10eRmwIhjGqpqSr5rGjpnQG5sQwxsU+RggKhigVphUOZkkHBhgCxgMKJg8EAGAsWFsAgIZnwcKL9mmiBwDKjPR4zlDQULdGTcNLK3BQFLo0xQSApcZRIrGRHA4ItSAgS5Y8mLVlpTJbOwYQDj26AgzjEjmvLrJhzBNURRZMtYWVAg6yUx0fxiIADGWcgMbKX/VSDkjGMMQkiyG6xl0QErpdslBOFcDFOkJIBQRLgEDowiS6ry88EmCGRUgQpS4whiIIuoQCkTRCOoWYBQ0Yw1ASrYAVwggiBLoqLAaReIPATrFTkzVXqrCMcsmAQEiG9HS0A5EanMg+YZS9obZEmMCtS/LDQs2IAJCKyGWWhPKprQ4SMEEySdCmCdjX3AR9fxuBAG/K7nGS2iCMrwqTk0mxVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTDvRGY4Y8KTPoSM8TObh10zK8nvMdBC2DA9AAkx2gUvMDdACDCFQHswgIDyMLdDizGPSX4wKIJHIQGcwNIC2MALArTEoQvwwFEA6MA4B4jBVQQcwSEDIMG+AHDBHQiUwU8SGMAoDsDFfQmcwhYKVMBIAqjArQ7owH8D5MxwsONB0Mm0JM9XaNonUMnQOM3BxNVTBMfg0MJgdMWwbMkBAMChVMFgAIgCMAgQMVQJMEheMVgxMMRbC4eEgKigKjgSC4JE8gPM4UAljUZUHHkRoJeoJRHj1Z1ekTBgvlGZ0SEgoZK3UuqLOCIdmpROOCjSpmIEzCY6Vpc4hBZ4REmAOaZAxMZCA8a2sqMEotMwGHzCHBxiqKlbDy+QywFhGHvsUOGcKKHtdGEwCYgyIBHBARiow4d9gy8OdRWM5ECqgwsRvi1jQgoIv0tMbFZojmQOXDMEYRjlUuSiRbRiYQGDhVcRAGACxxSseEBwABSTvf/74mS3D/2JY8MD/c0gAAANIAAAATXZiwwP+yvAAAA0gAAABHMXWaYXiUaRtM4Us+iGiYGDAY8STXKXsJxoeJiWeUYAJUMEgTBHYsl0bAAsynEDhwYEu9OeIs7ZggnFg4EeboP///UYTAc7mKDnYR/towMYPzFFGE4EJ5mZIQwYEqD3mS7igRhBIe2YG8GWmGKALZhpoPYd3kgZgeIrGKKQGYNo4hkCgQGycC4YjwTJgEDRGFCMWYDwSph3hvmRcLUZCYTJigA/G6aQOcaJpJjMCcGJSSQYSYmZhgg0GPiIuYfYtBhdlnmHYK0YNgrRgkDCmCSDIYEQOpgCgeiwcAjAvMF0FSHAUBOYPgBxIAiNAihAMoFAfBACxgOgFmAaAKYA4DAlMcxQ2AdiwWoJimIAUcueCBDAdZaPIgUkLFEEpboqHQOigNMJQAyUeYEYwkcSiixJnEmWKlSXXMJdNUijhJryrOItSLEvarcpuieIgyYFM8KAhcUDCAQoGhgpQWGSJFBFnnEqBWDAcV2CBQMMECiFgChl1AcMtEKjAIxBKKFqOlpi3JjglqSKQcKHgzDBGbEDFA5HVL5K/L1pPNfiCaxkICTKIAOKBw4ZWBgCqYSCqANxSTQxkqYRflDReJCQBAxRMiiDqQUFHQNSID1BDFULYlQRWxUir12FozGGGSkaTADVPDQCdcFEIIRLZP0TCP//1kxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowyoIfOAgA+j+1gYY0+VGPM1+HmzQqw3IwjcCEMxUFAzCmBCYwkYRhMFkDVTDvwDgzpkJ4MFHC4TBsgs0wXsAWML1AWDEow+0wKkLWMD1ALTAOghMwVQB+MChAZTCiwPkwOENbMD5C6TB5wlQw7oSEMFEBdTEQREswskIjN/UtNWSgNIkdM2jeEXLHn4XGASvmM5XpvmB40mGByGGJcGVQVGCQ2mHgJGFwomDgRmOI6mBgXGCpEA0NjCoOw4UzCwFjSzOE0QzCdAayBMTX/O+IFjgb8KDGXsJ4IcTnVOFUAKAncpCCEDsAEK5kMi3YWAHoDKGA0pfY1njvNjCOBwju+yM1gQQuNPmWWCVQUcXvBpptqoIkGBZtXZdcvW8iFINhUNXUZqJeYeLNsUQAE1gcEPoISVDWaNJLoixiZjsowBh4jPWYmyCXiMQvka5QOcBChVVGQ1gAUGJDlqWoo0qzCE1FoiQXq7Jd0FONYFFTRDehDqUKM7lBYQBxhnlpDgatzioRLlwGaMTQCET/++Jkxg/9q2LDA/3NIAAADSAAAAE5CY8MD/tLwAAANIAAAAQZAU4dAwxTXENckIRirgCFBqyzBGEXnXe4QAAInWhN0AUIkm/IXH///UYUuaUGGWF359lZgGY9BJ6mThiKBn/IGCYyiEZme5g0ZiX4UUYYOMomEEhXphEYA8eGRwRllBkmIcMWY5YhpoYiImWKgMZVQiphlC4mB+LKZLgbZk5A+mgEBuZzwhpg5l3md6NybbyE5zYBAmY8d8YGYmpl2j9mfOOGar4KRm+nTGL+ZkaHYJZooiVmVqIGYr4Bpg3g/GAaAsYJ4MxhXBCmB8AYYPAGxhGAEmHIEuYUIIwcKsYI4LRQCQYTwApgcATGCwHmcKuaEsbWsJeyFSZSuYoscdkJzTVDDVxDMuAEwNEHNQHHYho2BnTJnyxfQ0ZEwwWCQg8Z8KpaZQ8UDQEEKyBdQtSBQgYNAw1DskeBAJfcZDjwsDAwCTRWWYPKAaaMikZWAoAyTAzIMFGAMJVKwgYSsLCTDgRq+Ai6dYkzZKGBYFXOjIXhFA40WFQ5c9MlBEPEhCFQMAwuWmQGlvCEE96NYGEq1jIZOR2ED0agUOLLvOEAi85MxCBYEHkJIMQWBYcFgAVGp5rVUtMaSL5IUxZTFtAsXEAkAgBGDBwRFIqImkAQ0XzJRrXoFFRLGjOCCqFS3M0KFjxAMXKUFRkClcwi1xH//10w7cTiN3zC1z6Elyw1dKymMhVSYDSARisxckPANHOHtjBqB58wsoN/MLtEIzDeAaI3uZFzDpI+MLo5oyFQzzRbFiNVYqkylyjjAnCeMIgA8yABODDaFZMrUQYxaFHjABCSM+lJUyoT0TpJRYNMOuY0IiwDPJLxM4kdw2jBFhA36YmKU5oulRmsiFOYRRWBgLBxA4J4wpgPTCnCsMUsOswig4AEIGYMAMBgzg3ggDIwPgsTCLDxMAQBIw1AEDAUBcMBIDwRTjCUjmvTTlTY3hVEZHUJejmDDqBzTyQ0EQFTFEjcOTuJzStzLkTRkjMGjHkVak0zThQagM2MWHKjAkCHAUGbBjgUCkDYEhZAYYUYoMYw8YUSadCFiRhgTuFpggQXhRWGTat4KkA0WYAaYwGBAABFA0OCggEBCMwEElFy7hrRBZ5fpnyhhxoBFmJDmABM9GSzVkcBIUFQgshcwzBFUYkNVuMAHQDtyBg1LwRiwcKKxqHYwYomOg0ILLDjCSgOIzJmR4KGLVL/mMHrJMiIMsACCEsQaEjwKDmCC5t6yQvgDQA4KAQUWOpICEMFAQoBBIolChBBIkRGVJqlCp0CCi46S5e4qDS6o8FGCZQVWpIC3//7L9BFKaBM4vKLHI6/y2B6qZb+Iaq15oHrQ8sEzPjOpbO1Qxt0VnTja5q9//viZP+PzqpjQoP+0vEBEFSQAw9mekmPCg/zVoGVLhpIEOq5seuasa4zI3ulfCZG9zTilTaFpxfWlZBV7U4MD1RrhYT8KaeeIxwnB/aJDiN7tOMKjPxWrbOrFOzHQ1qNcLCslfyKg/2ZYjxnBD1wsqOzAwoQc7Mhj060QrVWn0QfJzIScw+Q6gXgXApY/BcxHCMkuK01z7LwQsuiGo95Eb3FRqxTogzSDDFFUImFwJmWw/1I1vq5xBc0MRaHJVVu2g0zcUKFvKViubJD3dSKVLHGckV+zqRlW4kTdXNWLtiWVtnZH7A2uThfEOEoFO7ePGt2q3lcv2pwf7nMQAM3zAxD7Y+PlsdNwDdLjVjFoY0MkHfMP8DuDOhz2Ew9gdMMKkAyDIZQbQxg4MDMOMI0DA9Qf8wRsKyMDKDPTDTwQYwwcKNMAbDqTAKgVIwagB0MBNAXzC5QO0w3wBkMJ3CGjCyAy8xY8F6MNPBJDK2hJkxMsr9MWkFqDD1wn8xSYCPMW5DJzEBAyYwRUX/MQLF3THI4POX8863ACczXAyNwqA2ObgSnRG4zHQwKygZfBJjtNGCAqY/CJqw5mMSCYJBJhEnBYbGqRmAAAYoFphwbEpaMWkUxEaxIBhw0C5rNMMMSccEqtDCGwNpGqYu8C9c1ewCpzRhhcSY5aNKwKkMM0NOTAz0x500poInsuMgTNaDMw2DkinBqFKN5hghhTrSrJjQiujjDjBqDMmX4YSCqpb0xgICITDuBKyasSIDCuGQMUABCSmrFDgQiVt1EAAzwVE580Ul3GQFiRMDCho0nwkUARrooYIJzHiRGeQzC4drK8CoNWCMsIRMV8HBWTIJ1RNjDlxEkNoCBgYKARAqCpFFJsRkCymqfRgxQKcExUSEGZBRBFEBJwsoJkYXMkIoCEwAFSjAgMmBmTCvqvBIwucAiUMofNoyF2ovgb//+sBqgy8//////////HzGpSTxzeSdlg1/+SXzaktlg+NrN/vW6k2wgYBmfOmwdHEaA5YOgzNqzVozLhVlDJMmmmtWiNAaYIWrUeIAJjRJlUpuiDUzNMjTBH0LOGEHGSFF8GPwc79ypAZqzB3AIoIgADdUEAww6Vv/MV0KvDFbwYQxOQERMTWI9jCtQSAwGMPYMRcU4x4hADOgRVMUYfQwYhFjAOFhMDgFMwfBGDBYFYMR8AQw1ADzC8ClMB4HIx5wgjDSKbMLQQoyTRSjChAfNPcikycDMzBIOoMH0XQzVhBzHeIiMg0MwwgjoTH6HZMigFcxiwTjAZD9EQDJgOgthgWxgCgFFUCMENQ7QBiIFLmmJgVQYYUNEBGVL0BUgtgDETDDTBqBYQYcYZEmARZhQZEDBKsROkJAATmTFGUGGPVgwyYMCYZCamf/74mRxDP2tY8UT/tJycwumwAA72HoRjwgP+0vJma2ggARjYMbJ+LPDMpQYXSAVXBzkBKxYykAY0IDhiA9DIxRdCAQjTFFGvlnRYMghJRKjYs2GjBkhaHgVOJPpSFugAaS1ASwONkQ0LBgN5EJtQV0mvJaFuXZMoFh4qih4wZQG/5EARwDBaxDBgC6RaamSaX0BQIQhGRBdVCaWudiBiIj0KAQAAaAZpOmU/pikCeCebfDIFMkww4eJpmyRgrIRoiIyYyFXaYcMVAohEGPDFrTCFG2AoB4xGGFsxjCxlDxa0dNkJgtaLEk4i1Rd9ExDqYcKoI31JIB39sB4DaLr2A2AxJtDAZLYP2wfTGA/NsBkZJpPmQXnhXuTMSd1CsKxp+nAaK5mXBTAzgoAz2POPJyQ4OyDDEH8wIgNXcDli82d1OBBBDGmXvx4Reesynb0JtL4b4JmGhhgBgaxjGzFh0jkcKDggCbDEqXIWYXeaDGENGZp+B9EObuINWGozuPBj2hGcZEoArmE+KG5iIxLqYZYRgGJPgnBg6gNmft6txlYppmJ6iKZExk5piDdGOwOWZUp8JhCIKmP8JaYhQGBnVClGh8LyZeQXZkegnAqvM30AMjyEhKMPrlQwmJVDN+YeMkwdEy9j6TNmWNMEJyM0YDazbYItMjgqAxbA0AsNASglGKOCiYAYR5h2gQAUEwwCANzBOAoMEsAgwyQPTAZAUMGQFkAALGCoB2YGYSY8bEiYZlCrZOAxF5JQ9RYy58wJ0HJjTszGkTlCzVhDEmB0Ka0qQRjUiSyQJim7AmZBgIWYFQCBAK4BYiYkMICAY+AxxkqCwIHoCAaHTqUeMCjRTFgIVKGDKGTAGigGTCG3ZrvKICIEAgoSgyNGFEDNFQqIIh4CMlgQNHSzzCjHuwu1IjqPQGKhQKHJEGAEkiYjKBcCOgCIgPJQIaIFC8hoCoIPKEAJQHek2At9UrTMDCaAVT8jCg4dAmiOFlzFhgcLMSHMWdFSRKeCB5MkNAQdshKggPKQFACwELAjFAiUsqdJ4QGDQB0LTEkhpEWAoQUcBLUxxoxQg1B9TUwqkoGIGgAgo6iqKhA4iy5qMhH//8ilf+QAoBMQDCx9PcmPGQZ8g0VhSn/kXdw7BufkABw/vIBoOtHF7/yDHF7+b3m5sUMrIt2+17ffxUPBhxpSYBdSSIekXzQpBtXqGYywWLYQqStIQCN4xFFyVISUASLLdkjWLvn1TA6w+4zX8GYNXCSGjHmXRIxoRBmMcQEPjFKwuExlkk8MPYDFDBiAsAwq4GoMHnAkTFXgSgwc4FMMBTBax0ETMI0AJzBDgJQxYA+DBWFLMRsDMw+BRCqIOZCoCBg5FtGACMcZbowZj7CdmmSq2Z9Z/ZkxFr/++JkOYANJWPFBX/AAHrraGCgLAAr9ZMrWe4ACq8xIgMBgABGTwVIZdoj5mPisGCIbwYqQwBmGBtGZkDsYiwpphpgWmA0B0SgFjQoRgHgDGCgA2YEQFgCAOfIwIwEAMDgIgLwEBqDgDjAkAdBABgVAmbQGgFBwCQKALMAcAsRgJJDioA6CcwBAFAoAMRANgoCJHgEADICVBFaiYBEIAoCAFEEqjA0AKhsCQBWHKbiIAta4WADi5AAC/sNuESgDL6e1PuRRNmrYH5CoFD4AQBJo4cAW+LOHWQRhwAgWAEc510sGQEoASoXEf9n6YMIiaE1M5FRHNxXjREhCgjc2bOsigxKXLJhbBWIwAnM9GaQqF7AYeh4CgAP6nyj5aeVMAvEXmgtnpAAWr5lyVlFWSRlrVOK5DgB4KWej8uKAn+a2wleKVLJYuX0zdNpZdtGdirjwxBkuvf/////////////7GE+vfcEwE4ax3j6TAICED4O4pLSABMNCgyknjvJACA+F49k9/plSpMKSovsocP3CBWOwdZ/IAnM/HccNyUytM2ciOhp04byi8+bko6Vnx3m2GoIw8jyTB3AjAiiAJwJBHG02JR+0qeIFsl7SxIeV6AAQxAAKMbcSUjKKMFpm414B1TLPZbMklK8x4YNzVVOyMVIYEwCARDP9FKMc8WwxciQzA8CpMCMAkKBYmB6BuYVINpjfglGDEC8amGAQHSJtBlQMFGMHNcywFjURjAAaOtys3H/T34jM3JEYfRqMZmXxMBQ6hQpI7o3jfp+MpA4HC8x4ojWxdAwgFgEFAc0J7B4CuiJBcmMqqiSLUAUJ1jSdNyOyQHCZdReJMQQAICAVay/1MUJBfdMFta5QDUDlVHIbyBGWucrFIV6FAIVSQoMDBAoAKGcMPMxpkDqLrbi0xkq6l/t+y6GXZS9gS6zZYRSuzF4PrI2AYELHUdFgSuZLZNFfLAoqtJAWVAHMOisLDj6N0W9AK0mgv2+sYTLcBL1f9KqJkbzLTkcon4cgtlupbBsEwA78/fkq/kA0S3/5t7KqzT5NnJKrQF50mHfa4rIs9frNWgMGdWC2TLxeyJ////////////////////+///3///ypSCVaOQigke+paotsWSY0gGoKLGGX3uJflnVxKUjCU7H4T6g1yQYONNgL3fzkrp9fJUFJhr7GFqpwyWRMNh2CFKVqzKwSgxbqtTUlSmu5fVdOAkIGQqaILpat0VEECWopSoK6EdmYzAUpZjcgLL43rG/vUYoLMBlyVtMEY81iTf////8qtsqUCcFXMm/////5jWNDvG8AEDA2nDAm2eC1PRpFQ/m5msMa2BAJhRgEGw6MoYdxM5hgBcmH8BuYLYf5gcENGCKHuYCQoBhBhFG//viZByP2tRjx497oACFyzfQ4DwALLWPHBXugAIALFrGgMABJ8DWYRYBRkgFpAnxgYERlsD4iLYyrGslT8yTQg1LIQ3TV40Hycyw4YxCAE2CQk0DRY1rPM0sGszHbA0vWwxCK0y8HIx9CgRBmECULA8IAEMDAHMEwCMBwFAwTEACrJEgDLgqaBUC3zbu97fNIGgAZsqu01+U+1O3mmmyy8mAhFJMpB97GtTDhrnaU05yKilCexgAADRlgE30fHFROX2u6SOzSp4ODUiaTy3Uf3Ar07WazjMfcuJs6izjteQDugs9YSEMVg1a9M47/l4WQO440NtPaZKFBJBYflyICzdNvXIiLK1iPg1+A2NNNgtgrytLm5ly4dgOONwZG7EjaVHIBfZfzuz6ij+MXk0RpXVjk6whsEnh9b8fYm2FSxNtmNFy9Z////////////////////+LPtpkXFTH6fyJMJDzxbHNTG62F9SC3JC02qRzwX1YPcvTg7boylZFerGRClbKqbvcKZ05KFiTsWa7azQEKVrE9TyRVDAjlCrla+YU6syR4u6WncdtbYqp4sJiOaO9wxXUz+SErm1UsMBmUrxIpVeRy6SzLGexTA8PQMQUiE4Z6/TP+6cNs0qQ3VBADV2KcOGwVIxlirDA7HzMQQMMwpBJjK+HBMH0TYwlReDB4EeCA9DEEDMMzT+MTzMMzAZNHgiNAhpM6CkNKD4MSTwMNV0MlSvNcfcNjzVN7D3NflnNPgQMnVwMv3cNJRANkXqNmxpMRS5MBhfLAtgYOgUb4KCMwxD8DAeYCgeEBWTBcMA2YBgyYDgCGA6GAkJAAw4eAJWpRYum2FQ8qgDG1gUQBoBEx0Q3kRiQlsrBoAPkyiRRKDKZ50H2dsef+BVIsgSMb5e48Aam7L2Xo7x9kq+lrKdopscRvg6ZfWYhKlDDHHWvBbS06YdWWsLEEqGbrjWWw950QYVOv81iSKzQ+qZNVqOQGALFt3+jENsTdJ3m/l6lrLJe3sOQawpx3gXesFAUcgBxGXPdMPpG0A1XCdaXTPc/slZgX2Z87k0qdFVotZn6+y4S04ZZA6rGVw6puCmZmZmZmZmZmZmZmZmZmZmZmZmZnrM0eafdXMpjs1BsCwrHQXCSmZOh5IJUOzxGtYJwSg6IAvD0SjlMhoSZDQk6x+l4M2zLSGsVLWaXpelqtZtqrjkvJzhiGBOeGxiSh5E8mGxiw9CpJRWOzxXE8pMhxE8mGxidQwMpi8nWPuerBBFWVAMKV3w7EYezTOpQO188g0s2YjN6q2MPcdUwYBgjQwHoMPsWsztVlzCRGYMfULEwmQIDIzCGMIAJkxlQdTFYEJMKwHswfxIjEkDYMJAGQwOglzC8DhMksVAyDFATHgGvMP/74mQyAAzmZciWe8AAAAANIMAAADSNkxx9/oAAAAA0g4AABD4OcxGxhDD/DTMLIZQzrCWTENJEMWof0x8RKjCRBAMEEBMwxAtDBgCFMFQC8wMQATGHFrMMsFQABBgUFQwPgDQYAkDgLCYDkwAQDTASAFMAoAQWAmQ7K5MBABMwMAFBABgpwnoKAKDQEw8BghxUbauwVb5boMAKftYAoAJMBMAp6y1iIaZIwACmGXeCAJAsAQvkaALechADbCCQCFIKLM2lwKASWsgusdCMFABrLUGZ0scWAJhxOVeIsAA0FEtl0HMGScZnCIs1AeAEDgBhoAllLKRkAJezUF1pMQ4li5TCGVT6mbZEqFcq1I3L6ZtLG8Ughm1dR5W+YdpykQYCWMwBVR2U52zrJcJTWKKpx585DiwZnWH+zyHHJbExaZa1BKCdkLmuHJv9tHufN23Xe+AnUZ2vGAZZCMwASknDA4Ar8wB4XWMZHP9zDZkn8wwkWnMcwCADAUhRExV4aIEgOswfYGjMA7ANDB1gQ8wn4HIMEiBQjAbQNcwCQEAMBaAyTBUQFgwkFoxmAgIR4IfQwEJEzgSwz3Tcx9dAxSZE3QTM/hQ425pgy8Iw0GagywDMBU8aOE4Y8iqYmHoamh0ZilWYykaBQDMXgXKwHMJgYR3EgKMAgcMAQhHgQLciQJmCgXjgPhgcA0GH8GhWX5KAgAlopVhQEwuAyPRMASKSAowNABPQSB8lAN0oAFgGUKFQEBoBA4GgEBRKACTIcBpQDohAtDoPBEiNNAIAiUBwUDrAUHESUVg4BUzkEQQDI4C65mVgkHgaAKSCHpbtUBMDagEDugj4iG9i/dsyIQAvzzpBAKrTSJTEh5ejZ2ctKQ6LmiT3wC/QEABQWOLeVkdZY6lS5mForPZMJbCQTsSLOptggCjAoFW5JRhYEVUWQOuosreisj0ydW9m4OBEHAUleYJAQW7KAVAQZIqu2IgPqggBi7JWAql4BAJPNqxgaA6XwYBEoDAAULnUQ4fl1q0qMFvIXDaGB08ybDHYN3WiVjZU17c2WoK9NVHCnjB0mcUwtouKMHhBVTmBTKNRgkwwlY1TSfEwMipikxv0MDKhM/M1IpwwbEvTHUIgMXkU40MhCDDaJqNLkgEyKD9zJNYcMPYwM1s1iz7CISNgNl0xjR/TbNI/NJkvE1+CkjT3HZM6oCE2UBZjTfMaMToIowmRTDClH8MZ4TswdAhDDdEIAwShkyKZvIGEO5qTiYhSAlFDFU4VvOiYDFCs1NwCBwzoRGj4yddMGDAMEGZhhg4oCgAZNAKBAEkHsgzstOKNgQEpBKZAIqMHCFUzFwFGAgLwxFIgoFAAqAhCIzMw8TGQcxUAAwsMi5kZGMDIyMGKkRhAaaP/++JkiY7+62RCA/7acgAADSAAAAE6zZEKL/tLyAAANIAAAAQWESsEHS3xCJmDHRgpeQChh4gYoGkgYY2RgUOFh0SAWmo3GaBC7wwCBwIFgYHEQ8KC0sYULGUBhkAKmYJGCnYAAQsGBQaMVEiIQT6CwiCBwyMaBoeLCKWhQGBxSYIElYeYSMspGSAIJAE5wCZ+JGSiKZJg4SEF4CTkkjD00BADykwaYgOwONBC0jCQkBFYcZhgbfFgQUCQsQF7WxGQnJedHIx4ZLmrAiEQbuYiJiQEY6DCIGWch8mICitWwvGYAAhicXRVM2BksUmRgTCEyvQzVEdXMZSmezVgc9gytBSNNDkIGTHfReQzbdTOMXnBxzAbhbYwfELYMSBEOTcpiMNBxccxtCwzGjDeNR03gyYi+TIaJIMBQ/IxdD/DNGENMnwWEzmgxTHkM+MelYgyQxTjhlOgPwMkExJXszZbEvMOUHo02xLzL1HhMNpQUyKApjTaTRMyMQQxdR1AgEswaQ2THzEMMIcFUw5AMDC3DaMG0FMwAAaDApBMMIcKAwLg0TByAnHg4jBzBUMDEA8MAvOg8EBk1BgKoREkMEHNOrKAwAVhKIcGGOPFJQ0y8OpHJHBYeiqYZoQixoKt0xIo1wUOslgEX3kYCZkTQErg5QjSZwIacuZYYIUCA5n5mC61jKCjBCSqAGshiiJjghy3IKHBcyFFQXJBUQCh5lRAY2a2kqmoBkiiw1YR6MkgBQgzR8zwwuoTGi2jeKcmCPAIOUOAYWBCAOEQwYggW8fwz51U46FLKDxoMUGORA4eMCjAA2LPMhKMMEJB5jA5kEqGwsnIjCA2yOkTPJQwWYoEieYMYHEzDBDDhmuqOhYAZUaFTZKRVxJhZSa48kyW7MOtA0YAkTCFi14ZOKAThBhowIoyhQEFzBAUMgMbNcqHlTqqMUYiMJwCSTRsRcozM9kQMYv0HTe0XEUzAAZvMs6DQzM5D08xUYWdMM9C4jCyA1QxmcQVMnxK4TFWg24wMcEMMGDBdTCXxWYwYkCGMLvALTA9QOAwtcS5MLgCEjBPwEIwccD7ME3DiDBeAsQwz0G+MT4AxBpIkML4F2jDdwKYxS8KPMJ9AojBDQ7oweIIQMGJCzDFLgr0xhoEpMJAAujAiAA8wG4DfMDcAYzAlAEkwL0DLMClAnTLgvNfus2yPzYZGMGto1wyjV7vOIqEyqKzG51M4pcyiQS5ZppYGnCoYyI5i1emtTaZIIhn9AmcUyNGIx8bDOguDDIYzEpms5mVBMZ1Hpms3mEwAYWDRi4vGKBIKjMyeRwOyDYTrzGvzOAOA55DGFB1ZtDg180SzblFhQAEYj6O4FVCNh4cCCgwEGBEIIqWZtyAg1RlAR7UIQENgEDA//viZKgO/ytkwwP8ziAAAA0gAAABOwmTDk/7S8gAADSAAAAES5AKXOALYATCTwigcKAUyFwUAAAQNNA46MgmgiAJbjoaqwFcNE07Rwt0YRR2MCEcQNjCZhEAZc62TeMKghjHJUlV01T0TgUeSlqZMGBwBbU1xxlU0gUwBCeXIMRlK2Hi/xdMYKMQYUPHlBa4QAjgIiEBwgWCBxKxaISFZG/4KGUNLhF2jTgHjAsKDGy6YQaFlAMZjYuCGYKYHUmTXBShhT4K2cH7OlnB+jSZgaATAY6oDFmS6lwxgqQaAYVCX4mTUAaZhFoHQbsDwxjIjymEcdkYSgtZhbtbmHIJyYGQEhhyjhmVo4mZEYuJgnh+GFUEkYtpWZjmH5GHiFSZWg7ps+g/GGctEZIAXJplg0GUgLAYwQ+phVj5GPYSMZkQ2RmzBNmM+G6YFwchiHCmhAoxgwg7GAkBWYGwO5g4hiGAiAYYK4GZg7BjmA0A2YDAPRgwgdmGWACYCAIJgfgKnBOjvcxvEyUEyDIDcxueQJj2hzulQIjHXYCyCRMyM40shTEDMinGAtYodMsPMdABrQ1bQECguJOWkaWWDJKXMYKCBgG5EQMDRiAgFh4cPMoEaAkQWtZuX8MwBTXDjoEOiEGY0nAwVFjAkzIFO8wwYOrIoAYRCFkA5ugAJCoCTjox5hABZEKECEC5JjA4iABx4iLgoiFBKNANLmGDhEVN57BGKXkBCpggI0JBx0xiUwwcBG1GQcTKwRmAbWFfLoLYQlDBxEmDCFQcMQmyoAAR5MxMOKEQ5BYxJAaOg0EIx4MMGmEgZOYMSJBzDEiKkEGTRCDFgBCZMgCSDBzgM6GBTmjAIcSAqFJZtB4GYlqV1O9hLQAIcwRAMkMjCA9zIHktc1IRuUNWIC2zCCQrowacASMtoIDSECqMHTKbTDzgq0wWAKlMa9BwTCogBAwhMLUMBhA8zBuhOwwKwDlMC5BSDA2gakwYACPMPDAEjBJgIUqgsRgZwPmYFkCUGCXgXJh8IAcYrIECmCIhwJgMQHIYNOAaGC/ARBg6YM4YIWCHmBXA1hg4AQkeH25qUXmlSiIRQYwYphsTmTwCaDOpiR7GNAqGKExOjzSxUMjC4xUQwSSTJJfMSEMxcFgyKDoRMaAEyMBzDQKMAhcLg0xATQEbyIGDSBGohsxpgmgEEGbFmKGmHFGaGgUFHyFKpwWFBa4AtzEFQYRLlAEiY82Dj5UNoHF3SUQYIaakKWlGmaAYRizDgwqkMOGMePJNyEgeHGEUAwUkUHIFgzKGzIEAddSRSHY6LMQxc6qTagClT4KON7LUEZgwAhEpgg0OrEMAigCz5cplwJEKCgMRFQEXBwoVDJvig0aAmEBJruwIiwXGhUKIwokUYf/74GTBjv6kZEST/NWiAAANIAAAATjNjRAv+2nIAAA0gAAABIy4ZGqJpnDoEZUCMGJDAUCROMG0CC6Ad0iIE10ChjMhTNlBruBhgJTJ3GEICUECCUI0ZUPRoGQggaFMCbGSwsLXKHBTMtgEcQ9CFpADVTfujbCYHeMiGMXjIJjUaJAaSoIJnQBFfJjTIRqY2qETmfzhYhgxQh2YLAadmLwSGaDwaR9tA5mDqXQY7JHhgCgHmUOiqZK4eBiXEFhASBjSoHGgeCIYigS5ihClmGYPqYU43BlLhAmIMAsa65vhlYHjmT6C2YQgXhhYiJmDcN6Y1A05g0kUGKkNCZl4hBhvAhGCOCEYToDhgaAsmDsEUYTYGRgaAMmgqQAIDWlcwd4PhXDFD8Rj5migcLYGRjQJJTIJEzQZMgGwSfGLJpwAyaSxExMBmMxMIC5+bgLmguQjUTTj8aNDHi0z4fNTPAEWr0MAAwwaMFEzRjMAmYMCA4nMGCAuAgJFRZ9MAqhA4LOgjsZKBExNPiAGEQOPDoWDTKAZ/hIKFBQOEhoCVpXBLgKTgYWLooqQSqNHtM5jIMATFwQtuJFwEIQwdEYUCQweDkiyAXYoZKAjJGqUYAguAKKKxBAqvgMZyYDIQYDDKTphgEYqJLQLdpOFlgUBILKnVIXxMEBk03fHhZ+VPg0NUofFX610kkmQcTIMJARwwQIKwlG9YklAoEoUIQUxURVw5RioKlAShqTpKAIPryHhBWxggJACYLHAJm4aTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgABYwNsCpMp1DhDJWC3k4TViFM1yRkzIoQmUwjsIQNHmE8jD9Au4wrownMTjASTBVAgE05kK5MGlDATBVgPYyniJjUySKMNgTwyQRHjAGGkMi9HIw3xmTBMCsMIsDgw9h3DFNASMrcIoz3A2zYsI1MjpJAxPw5DB9G3MFcZ0xBwDDAcCKMGgmgxsytTE1E8MNAOYwKguDDiAdMFMJMwBAEDCeA4MC0Fg+Ns8XM0BwjEGCGmktmCsmVWmabG7ynZEnDQHBBmPIhdUYHmZmOaWWDgIZTEAADCjdEDTDDPEA5ybIaZRAZAcY9ILIBhSKggKQGATMEVwqSNIAR8BS8mWu2YoGpiGAxZM9pbcHABCUERhS4KCDJDS2aa5oSmyIkYUeRDCy6+J8GByqXJAbrsJBolfqKCg6VLIgqHDhc4AoIKFGVGluFYAEhQ6hYoHCE/DLgXRTceF2TIEUb2LjAhC0IXpLEROVGNImIRF8ysEKiYGMqJMELBIwui/5KKMEERNTEM4BMAFTibim8YIUSAiqBJgaJRcYyo0mAKrmBEJqBQAwgBOUJqQijBlSYoHRAGhRlBhVAGDIkgJP/74mTcjv4bZEQT/tNSAAANIAAAATzhkwoP81aAAAA0gAAABJ4GgAaHUKX9jPqGFyj65jmAx4Z+yL7mq7Zeh4QbEeaPSA1GThATBoPJhCYsuAmGJ/lxplioVoYOAF7m4/BdRiFANqYWiDEGCdBABjFYQWYNiDZmHwgWpgOYEqYIkMtGBKghhg4gUWYXyDlGDyhvRgbAPcYs+BUmD7grBiuofsYOCKTGEThB5hBAQaYAOCLmCcgc5g/gKoYNYDiGDVAz5hqqGgjSY0TBv6An5GgY2cBlqimESAcDHJndtGgR8bPRhh9EGBjyJZowwuBw7G7H6ZcJZjVxAoimXwkZHKJmg9maw6YUEBhk5msD+YsGoIPJ0CxlQ4W5mQWGHwm/bAXDLzJBTGLTiuDGhRUyF1Z32BxShmBYWUmsXh0U0oEwIgDBRogblQZcQOwjKgDRFAECJsQQtMELEQcyKk0gMzQsyjM0o42IoyBM7Sc2R8LAhRiAAxnk5rGZnBpADMqGAgdNI0IsiQGeJhhADeAwGZAgUHgqDNG+RdMGWRYUuByIgdBw5FAWHCyIBITOgjFgKUOgHJAIyCw0gBpLEBRsw0MBS1NUs8pcKETNiAARM6VTTDJ7Exk8JI0wjPhgsJAAtBcssSgzCCwEfAQkRFkmQgAY8yBhCMhIDGnqPyeoXOA1CvwRlzEmBY2AUSdJgTYZAL7OtL6+NUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAFBzBGgB8x5QAhMqaAFjQ0jPQ0rcLEMlfCUjFfAZMxZQdiMCoCDzAgBcUxh0B1MIbAXjLIQbswTsGaMB9CAzSExDzh+TSk/zUQKDEgKjL9WzYwZDIkkzOUiDM8SzTAjTF9jjh9yj/qrTs9BzbYajdldjU5LjO0EDKJPTG2aDSFJDhApTRUyjGwPTEk3DJAgzEYYjFEIRYlRQGQULZgABwkDphCDIwERiwAwhBAw7AwOCMAkD5BqmIznUQZ5YlcFiUigdARdDt4HpEkDbEWQzMxigtWIhgCEXdDnjPYexEUMojCBRiDtIIEkuFNVHwoO3QxCQaglYVV0Vy7av11KgAxbrFUVHEQDo3CINrBCW1ogADCFMy2BhAEADKC8dguQnNAL8K9kLUTHBjcbBoLepPKhdaJIjrsFhWrpvJIjosUR4S3DBkHR4ZdxdAvSHFJ6Bclnb+s4TKFjESJ5wkwlkoKD/++JksIz8/2ZFk/3LYgAADSAAAAE2YZ0eb282yAAANIAAAASEFK4RlpAJ7p9AogGmj9Zjfx94QOGNZFxgTAFDhlRpoCnGsiKcRuLpM0FgJpEjRoBHA1JhmoxLXgyQQ/asDxIBTSShhtjAGIiN6aqKqB7f9jmO6c4amY0BiygcGKamaYjw4QNEbNH8LIwVghzQIArMCIdswlgDzDJDCMb8c4WJJMKEK0wKByTE9D/MEIFcwZAADBAAIMCQIcwYwlDC/CIMG8FgykwmTEmFHMFkQgwowhDEgANMIwIAwUw0ACDeYKIVB6hkJihkoAYikmTjQQTGcC4FshASHBiAKQDZhUzhMNHODWmc1g0A42KuCZQETTGEE0siMlGzJD0ydSV8UYZqpaYYZmAJhiLYaYIm/FhqqoWE8ypkA2aaQRBdCEIeZwEmOixlY2CQ0FOA6wtkrsYNGujTRRtVsX4WBBlFPQebaUF2Vlm+eDgguqPIGq2iYh6XdCogCVY+jKvJDiBgxAOXSDmy+INHGGyg8uUIVWKAkgWBL2p7mYcAgCzBQyDBG7CrqdA1KIRnap0rRCMrgwgjAYSLFplRoQkRCjyqicDYkOC6UuluiSA8GvRuzD3EChCAgBSNwVjWWpSOjiVBgBEIoZoWDDFJLIjwCGg0QDBlegpwEnKPIupPHGQYjQWSbKNEFUABFs4TXgCVQPK7Maznbi5MQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoATDlBjNdEOY07HezMseDOzRN40JwqjOrG7MZlfox1xHjCoAyNUcK8wSQIDSrA2MMgVYwBxODFEdDbmbzVtDTWwiTBUdzIGnTFUJzHEljRg5jBRBjGMoTI0RBsQT3pqDLTnhDARiYkBn2W5qOrJoSXZm+npn+vxhUPJiCaoXIkwpBcx7BIxRDADDuYPg2ZV0YnUbmUEjwVdJXJiEZikvTGHzJDxQeYY6FgRlTRsYBt2SFzCUDhKUDixecaWGiMmgQmkLmLFM+GAJhEJnDJkhphgojBqfMMBAgdROUCMCkcuUHAhCAS4T6LImOKpa5DgYwYgRgC4IQVL6CAWHGm0Ug3JSh+GkoJUhWUM+LNFolTqasSS3CoIAihoUrc4LB3dAwZYdXao0vV8gIasRUsVXA/CtjAmvPu1pPpgxcZLZhK5aeDlAWJITlxO+p5oy+483dTJpy5mPqGgwKYASjy11xl1rAhYWnCkqy1EF44lCHTQVeh//viZLkO/D1jxovd01IAAA0gAAABO3GbEk/3VMgAADSAAAAEPFWB8mVqxpUNLTklqZL2t/LJ00KO6C5gkgnWYH6LwGRcjLhu9jfIatwM/GQLhmpi5IY4ZA4WymFLBiZhfA2cZIGCKmBQBN5h+wluYPGDUmAxA/BgR4CQYB0E5GE2hEhgUYLQYEmBWGAHhsZgE4DiYAgBSmCygJpgsQR8YBwDWGFrgTZgqwLuYs+E4mGXgAJhEwb4IkUO0x0NBZsM6kTMPMHMNHyO/V5BYbmG6hGagcGPJPmTIimKRVGNwmmOwYmGIhmUJEGEwsGGoQmFofgoWAYCK8wEFxhMGA8HphKHJh2LBi0ABhOOJg6HxjgIgBF4OPAxDIEwPEI9j4xeM/Zc3lYyBE0hoz680aQ3SYwp8w6Mx445SwwJk1RQ07Mxpw2BpM5lwjAItKBo2gomlQZ4MISJEbUJMEPBSoIFmbJmGDCwwwiNphIJBoEOCmMEhcGHB4g/AVNpyQ4VSphCqD5fBDUrMmJFGqDBVyCiZmw5YKF1h6GShBYYSNEzgAOCEchCpkMSjhZDWFvSSm02VDRIEKCky1Yy8mYKHoemjKlvC2pggJEpYE70uXXDcuAAsZIlAdWRM0hBgp2iiPLAUTMkKBIYSHrKMwFNARMmNamb4YOhQEmMIWAx0yY4ABQyeAmAEhJVsrAwhCN/3vdydl9TG3JVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMTgR02nBSDY2LWP19sAzVDIDQ9HFMpwN40dULDCFIuMDxGY0PQVDECCiM2OkMrhbEYtGThtm9JNm+wWmDRlmFR/GPizmyoWhUYSIbDFcdzEISDR0fTeczzuqLDRjxTJOPDKY9TFEGDP44zKJyjLBRzNAOTi8DzJQcDCIbwqC4CD4mQQwiAEwrCgyiTlCNiEzDVbwQEISjjFLILjAAa8xp5nwPCAUoUbCjweQZYAwAYoIwoHLgL0v6iEYRilas7T0nk0jCJDkkGSYUaODDTHKVsXu1kFBImMAeIeBKgDATHFCDRJYujAjA21QuJkk6kzXeYa2dmCSqaT3o5O+2iMrLKVYqRyMUSTML7KUs/EATrwDTN0VRSWXS4z+rOT1YfJH+UYd6GWRPotBnUHuFUfVvZtK9rkkk8vedZT9tJgZoyZMXgpOROeM0sTgSP/74mSljvs3Y0aD3criAAANIAAAATqpjQ5P91TIAAA0gAAABEwW5S4XwfSxDT/XZDbbE2NtEMG7tbb5ubv3sYohFUVYMW8DXTOTSv006VdtN61KgjGERGIy3QNpM30GazECwMkwSI0wMeDCEDBZAaExtMpDMG1BJjAfQJswJsEFMNiBajEhQK0wEULYMG3BAjCNgq0wm8BfMEZAjTBNQn0wNkNTMF9CJDBkwSQws8EEMYNGkzDwhHYwxkSOOxFpPriSOxZuNs3VNhjpOmN/OY00NUTzMzkFMtmQMABINECxMDx7MmxlBwWmBg+GSAWmDoDGH4YmCoPAQGyI1CIcDDsTTF8azBwMDBAJjBQTjH4NDFIAh4KzEsbzIYLDAgOAMMEkNe1NmzAiEGygGcBDE2MUIDlU0ZYMYQIY0cCsgybAAQmCoByYcENSZcDRpacGnhJesIImKA8GCDHLmrJDCMuDnYBYg5Kca6ZM8ZgyYIiFgYOtDS5wgEwMEfMGLAzACtEmAdMJCCYIsaIhoXCAoKDAKgSG4MTGPQFtmWw4hWZM6BRA0LLlmTAhQeJGjJAGNmBCoGgkQLOgENM0CEgJfAWRq7RDFR5cdMUsq2NvX3MEhIAQEBgYsl4kG04taRErZMeLOL8QfBoNBIZGGLBjDCU0Qs4NG6a5efsgCGKCCw00csKFjEjDJjzQkggQX6EQQwIB/dbFKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAKSUMJ0GI0Gw7TNGDeO+QJw4zWPjDOIoMRAGUzzQjjA2H7MFJCAxPwtAMFQZRx8RgQBdmBWE6LGI1/KjbSkMPlUxKIzE5GNhmkz0HzfBWMqHQxsqDQpyOMDo8V+DrNOM4Loe9JzIjG4B+AvAQmQ2tSzTwmMBDAqC4AjAxEDTDgzIiqWsMiUcDY0F5LrhDi5QeINEr41oPKgyywamqDIA6lAhiAyluQYU0NTIOokyk1hpxfwUAkc5TIVlM1GQumKRDutIaeYDqoCrkFh5TJ20CxASZmaoYg8UFBcqmwOeiY6xaOYBAHdJBM1SlXBIGZpXs4Cg5avtK50GuPo/L+rMLmNXZGw1TV2E6E6oLaWnGy4qiQDo5QwCmsCSCa/LXhRMizEkH2spEEzossdymyPG+ToqjZ815rdLEFgWMsLFGNc8BnL6Cl1BKJTZhowOcQlpJL/++JkqQ77EGLIG9zDUgAADSAAAAE8NZMMT/tLwAAANIAAAARliMDhPyXmIlDRVU0L4/lDRowfsZ9Mc3DDjQbzj41X87YNiuaHjIlAywyaMNjMr+C7jBmh8Qweg+gMLMBUjD9w409FfAzHuLYMI8f0xSyazCIShNShFMwui0DEaChMPAhIxPxVDFKDWMVshUxYzRDB3PiMxEJMDWSmJa/aZA865jlD/mpgSIYY4KJpJmSmOydYYnSURh5FdmmcKcZRhA5jljCmNaGmYkwIoGC+MDEFZtTCbA9MEYDowKgFDAjAYMDEA8BAzGAqCqYJQKRgmATGBmAiAqAWQjWUnyGigJ3m1FmQiqYGxDmCQi5o0twyqY6pY1lwKIg5oY1IZgWYVSagSYkOUATMBSJwYQoDBYwLOIkBQgaemGPGjbGNKnaFGfHmcIiAOZo4YQcY8MEGWJmpFF0xGIMCEMWZbmzww5YEATRAwM7DAZhUQQfIAyk1DRgkYFYCCxihpi0pKhAhYFbwCBFnAdFFAgqLT5MEMQXMCkeQFIQCkGgZCcN+SUwHphhhZhRwBTBCgwS0LCDMDzJoAiMELjGh1pGRNGvEDQhfxiywqSChoEnlylvTCATCjDZIVoGHCmJLEzQzpYv0FVYO0CNSAwBj6iv0sCs+XWAx0kKixYwp8xAkxQQ1owmIgUeagIlEYIMTFQElUGQzHgdHUsUMTBAAcsxtQH8MZcDgTPRyoM0dAVYMa0AZzFOwUIw+0HDMM5APzB3xfgwvIBCMJTAjTFrhs4wLEDAMDSArDIMtTYiYjmktjDsoTDQMBAyxgoDBqeahnwlhny45owuxkiwJhygp0z6x5cfhm+UZzcPRq+OZp8shmU0ZoLNhliZ5wgEJkeHZkwUBiyXIwFxIBJYBctwbSYGmBSZHWfHyDQFiMyU4nDGeMh06RCdUojCUDbLLaGa6/IxQYoIjENy002B7QJCE0AAoB6zMSeIzEgCuCKg5kdaNl4FghxxhIqvChJphIkgE8mTMwwwDyFoxGwoMmgtJAwFMixwKMHhjYQfotIHNgg5QdUi8JpkQ8oCjk6FY2BXqOAEvQUJAMdaY5qtiYqc6bD75uk4r7J2FqYApkGWUsuW9SzUJc5K5914JotwdducIUDcZkiblI6i7WJP8oYrE6LsAYJQUeFjSVK/ysdc6O0dQNZ1F3RQ1LnFyUIwcZEaZFVizntKYgjrFMRRg/RDAZ3MJYmfAmZp8RiSuYf6P6GxmDZ5hmwcQZiYQmGG5FLZgZhN8ZUsDzmI4htxlCKd6YqUFbmCyiKBiPjZGZKfyawxcxkPBHmFudgYc6xhm8AZGROOWaV4h5kiFemdacsZigQRxBibnRVR+cSY1xiJBkGeALYYkJMpigBom//viZP+M+/9jRgv9y1IAAA0gAAABPF2RCA/7TYMhrtcAWGPAC2NUZTAeRqWiHmZMEUYeYW5gqhBGGOC4YRYJphmAmmECEUYL4FJgLBsmGWBUYD4DZhaAPBcJIwYQnzBsATMKMCowhwHjChBbNLSNA9OcBOkbRKLeG6XHRRmxPmKeEoQzgQKJQKkNgRNkRNWUMmoB0AG+zLIjXswhobMwBD4tPOCSirHUUokEUzAlBZAYFeYtocIAZh6QqQRhBIxLs2jA0aQGxErDPIzNNDBtQYIHSRwBoYRC5c1hUwZwxpMx5kDNTERAYdMYnQZJSKAZF4Z1CJOFgBlMZkzxYCCQkyAIicGLYmlDoDDGAwcVVCZcqYMIVChskAIRAUiOEAaEMCDEIcuOVGJq0BlVxWHMkLNGHWWLH0mAsxAqEBZQEOcQqEjTCTOKDGoy7ae0CqWq7WAEIACFB5oFBYQvAKEwpAgPGdLlUoNC0uiQgXZFiBmSSgLU0G0ji1woVT7McZL7pcRDG27//6qNEAQiKRrH/9KkI+jWn+ykZTnOd6n8hPSQmQjTnPVBDrTemmpMuE2HQBBjSgGcAISNViU4SvLmFVoRID7MwoDaYkWuQvOg0JILYNJYuBACsTGYTwd6oFGUoXAUML1rCNYSdFhBkC1he9nSABBtHpGlKNJBWAvGMAKAAEalSSCGatw0dMBeCXJtaKSDIhk0AjYoOctuDcVUkJIdNBRYNDYIYgHT0T9SDBBkBoOwX/bFDta7WABc+GG1BhMThYMHAsCEH+s/kPrLyiowPkL2Md3DNTFoCL4w1xZoMz5BcDJSAB4xhIHuMHHDCTBBAyAwUEG0ML0AxxEBNmBDiZBgdYSkYDMDQGXBVHcjBmNRmmjoLAUMzE07DZ4MzMoJTXQ1jSSoABPhmI3BqmfB7rFRlg15mae4RvpkGCgEK4xhSYy5MU1ZPYz4E4wNEMyECYxrA0AiqNCeFgDMHgyMMOMqMMGWCkMxrkDWQKbAR8hZGOCKgBQRUid5VCLhMAEUATkUqf4x5FuIXFsPQkg4GLABQAnWAQ6KKsj8N2AwBGVP0u+NFB44x5Dq1UsBkpVAWMl5EbJmigpn1pQZjKagCBN696aavIJTobRCS46ma634SZn1esEfgkBLAM3HhjTlpMjXRKVpNTg62+jcVpu3Bia7gPypUwKC6VsE4zheCijyrDs/cZwlUEyHNL3t4kIuFkyzn5WByXmmOxBNNP9bqYbyNJVizXzGE17uUNvTDMYjzKJ5l8NNq61O9G//+cFLI+iu37sLbLjqpF8HALLlv2iNMkqc4BSCppfg4i+2T08ccRh+UjL3lty06P7SgAJMxmCggFGZwp1s7TnQBv1CEe1WP3Hy/697UMOQpghXJFMG0f/74mTiDPtuY0YD/dNQeGtXkABY8G4Nkx5PdynSOi3fwAPnwMB+GYGAxfiB8p1laJ6a7cETFLIaRMaDAyPBbRfit6EtCgkAKrGBwOSaHZDhnOljnwCg0bB4GBqcBrGdMO6YEBERkPhNmDGJoczHuZbEwawGSKMOZBkqZNHgZOncZZlMNNgAUbHGfNPAZMCxqMMRfNdQ/FWkMnE8NEjOPnCxNeGmMfTxMLinMRx7MAQaMtB8MBDlMQFcMuhKMKAxfUEhiIRJMcB2DgsZudxxjHG0UYzBoDCiQFYQFK3g4FNIxAAMgqkZQJVDBLYhpMIwMAmS8YtEYeJ8sg9cAHGDOYb5IWXrniwgVEhlBHsaAIjA4BYimqtbO0Oat8REkgSeLFsxd2GWvv3SuVL33pWrz7ZHwdYCoihq+6qGqPRKJCIrcZKndLwUExIiEVCstI56SgR0kbF0qyRV2Ygmow9nSkn7VUYUoenOqdlw8Cj6XscBLuEV3+QAAYJ1mzExThr6DAlbU61ot0W4XyY2YoM0tVX5oCw2MlFAalAqEXWIDX4CyIJAQ0QhUml6W4BSSeifCRz5OXIvtc//5oL2yAIduiCRyTBdN1kajXOFgjLRKCgQoApEhAMAYghsNIiw6rauOAQKGY4IjBNUscCMs8WLeR+lKEhy+5iimSKaBxrKJ4M7a3GC1ZigxNMViQAKNYh9XeR4LKIKOUXXTCDCAKiaJIBHN9su20wYAM5o5IgVI9Zmum+OyNjqQRnDMUXW5bOC4jMRoSTdABBjCUhBUybgVcMdcDUzSRJCsxysmXMs+GajDsQiswLgNXMKMDbzBiQXweIWDB5gbIwnUPFMDvCTDAiQcEwSQJeMIICMTASAEYwUkBkHgf4wJsKZMFOBCwwKPMAsCYjAIQrswT4H+MJYBhjC1AeYxlMYjMUNDgDC2AVYxHMPPMOUCoDA5gX0wWUIqMCEACTBng4A6VMTspSA4oMekcyYhR0cmdEgYbDxkAamNREZIEJnkpmPzIQi4weHDD4KNAkwySH0CQAAgYQjAo2Mki4xKSjGoOKyGNGgweGDCYwMUigDBoQgMUB5jQDmGBCTENGpFsSBjpkQDEYWCwKcEwJCDCDRRdHAQ5M+j00LLOdDrqPDI0AAdFLhLh3gMUkAXoRTL6qGlWrXSIK0BlSVq5UApNAHEEAmnsVNRkzZeNFLyoZpSABAVensDAhUSxUAD+F0jGUBXEjCt09kPFhQAkVWjqFxkqQTtbpkoDHJpIlDjGNKjLbAYYCupM1wRcElLsb1iyAJSRAQ1kbcsJBCxTKV7ovEY3JpLOa0yRzge0n2GJEtmjIEOLkITSkLmLgkQQsYDFUUdqfq9BD//ljjOQw02QNDipqGcigaMyOI7QNULcX/++Jk6A7ttmTEk/zFsIDraFEAOPCw1ZEWL2sYidetn4AC48GtESzw61LBiK9IPuIAUB7BFCy5yaqEppaQjM0fYsFhsiHQEAS6K6FBlZ3skStaj5AAMEvlQVVR52EFoRgKPCPycRyiOiITgQRF5CsFADVIOiB4tQxTMOi8JZEQCAI0sJ1U0cUPDiNQ0EwfTUDj4PDNCtAw+dGjjIIelA4Tg192ZZpcRhfpqGQGHeZRQxhi8ETmearYYaIcJhNCUmIGOIYAhJhhuAsmIcHyYLQphgXigmGABqYo4E5iTixmEQLMYbw3xiuDTmMYMmZYCQxhpMImCERsZLITRoCA1mMmKwYgJjZiHFZGHgQ0ZNYY5i9B3GDqE4YCgDpgFgkJVmBwBiYAIDZSKN+mOUGNEAOfBAU0mUsFQ2HoJi0YBBmaLAIAn0ac+muX0zToGihigZqQZkQ5tDgCFwKDCIKLMBYcl4IQIyDaQPHJS4Km6hq/2mIRkIRVSx1Zx0QYBTsIuMgMkhsIIIjoulCp+wwyyQVN/yQZE4AsUyaaX/V03ZAlBCAfFfC1WQMUQTEokc0TAMtwYOEJlNYos5uz+NYtRMiSqqUPTxgiB1poWsDLlI4hQJEVd6qj+rxQefdLtncaqQXGmDNYcZvoylGpSKlTNRPS0bK4ari66EpHpORSStD9o9PIPIKgF0NWRDhDvomOXJqbCf//YwRqPqxGlLyoDWkoOxR0m1BpBYUedZaKuWZLGnWlOswowkSSUqXtBjOYKYkuZpzSWIyFpSVJeFtewzFYCi5e1TZQJ53FuZuDCY+jcXGdZjL+pEp8MGdBUrpO8laDBwkt8W9EakJBMZY8vaM7zXhUalUtzo3VAABjBZBGwxZUOdMHvCCDQK0KgylwdjMT+BHzCGwqIwpAIxMI7CpzBSQR8wi4GcMICAkDGBg+kwM4FpMArAnjAXwRowXcGPGgO4zpJgy7HAzcKMwjDEzcBAyMVIyxXY1pHgzsXE4jSgxI586IXQ37po2BX40eRM5AJUz4Ywz5qAyXMY4NLkxxV0xNKcxeA8xPEwwpBExMEUwzBowWG4xtHowyE8w+FcQBUu9wDAUFyINBGBJgYEYhAYVAZKgwUDMBBQYXhsm+Ybg8gRKoamCgKmBgLGKonCMKzFIOSwEhgkFK4QYABheDRgWAphQEYiAYwXBQlAVAcg7AgoBpcJAkNACIwKSPnVFBIBgABJg4B4jAYwDAZjxgABoCCoGAOJACgMMCQQbqYPASHASYIgoXlSakrZazZlLmbrZa40BS2KqrLBKIEoAKJgkAImgJRNftB5ixd1QQYAcOBRLQIBJJcOA1pqm0afJHJb7BXLHgDVXEIHJniMDgcB4yAMEO9cSNf5+0bgIALurpKAma//vgZMYADfxkRhV/oAKHjAbhoFQA/tGXFhn/AAOrPlaDF2AAK8an3mCoFrqL9jgBopEACJQg4AC7aaKPSA+FIRqGJCqolx2sPmyB3zBIBWALfgWZi9LloEP///////////v/9S1LUtSnZX/spaSloOzomR1aDs//ZSKnLoncDKZuAz8ewRGIDGBxA24NANDsoDNy4A0+7gMCMcDPB5A0+mgNTl4DDYJAxEjwNYHIDJhpAxoGwMGjoDLJuDVoGSAuICBzQMHB4DCQVAwADgMAgIG5IYlEfCZDkjwRp4yCVTGLSc41sRINMb0B1jOgRe4yaMu5NSNI8zCBQe0w2YVeMVcBejAHhDUxcoM4ML+E6TGBQT4wi8MwMhDAwDApAK0xXkSeMIrB/zF0HFMFgCsxlCBjFlAxMWMAIxGiazK0PlM1mhYzyTCDIHHqMY8r0yzAEjAaP0NYeAI3hjgTHHDCM702oxHQ+DBHABMhcCYwYgXDAGAGBQYZoNg1GvCKiYyQJhhQgWGAODqYGoA5gCgfjQHZgLgSGE+BaJAOGB0ACYAAAxgNgIlgGIHBFg0CYwMAHSgAcwAwLVBQ4FcQgFpUgUAwiAYMCcBYveYAwCpgBgCgUBIhAiEADAwAmnIYHIDhgGgOoyiQJhgWADqJvoYHAAC3SQAAKAFmAqBWYDAAxa5E5locAsYAwDcMBAAZMBA08aAaDgHS8BAA8GAMNARXTEEYELOgMBmYCQAqXICAXGgAk9S4ZgHgVkICKZIhASLPGBAAMAAAxgA5IERgLs2EgEQMAWNALkoCYcAc0ERgDLhStQPd9Ktc6D6xhCAC2qYk2YBAAYiAUQcCAJhYAMwLgCBgANiLWoDEIATBUzkzH/CoA6qagLT1oKLAoCRqBMBCjsXOfXvo4jwAynTK39GABCsA5HRrapW2Lqu5R+YAoBLWWlpehgAbdCAAJJldTQ0vi4READLwRhWT/zUpH+OSDJsnKkpGqksosU1JGq8ipq5OrQPofNSZMXd7I0Uc1JIWEapOjJoF02UpH8TQrjYIGRUbQ8pLMnrQ/k8MyZnCHjsIkNki6aCdaCZgf/7DvHMHENEfZ8fZJAEC7AxuBqWswROG8mS4AQBcDA8An/4GbdzAGfdnQGUs9IGsxZoGhxyIGqwQ4GbMsQGFsIwGB0FQBoIwwiI1KxQPACgcASBIDBiEIDB+DIWoMRgYHAZhfEQ0rIpmrmC1tot/mpEhyS0ouk4OkrnjhUTICdKpeLhT/5FlOjl5BM8kYFYuplxIR/161QAiUlDBaF9MjwTIwxguTX4RHNSc60xgRHjIOBVMNAGIwChfjCLBPMM4G0wMwwzJyEMMEMHUwEwfjBIBhHhegUEwAB4AASYNMxkAImZRiZuRgAU5//viZCmM+29kyZ97gAAAAA0g4AABOJWTGlX/AAAAADSCgAAEpE7G3CIbmSxg7zmz8SbyURpJGmywuaeXxitVmIQabhW5kFEGTgwBBeYADwQBB4FpTNaLeI27aUo0g6PCoRAooCqtDWTBYXX6XLBxEGAyHCMxMJDBYaDg4MhFVBuYhAiIgND6mwYGhICP28zDGLr8UXfZV6FCgbvJmKTWglqk0FQKhQkqi0hAvsUAD2DQTT9jioGVvJB6xqFHtaK71qXH6UHgZeCR7oL7zcdqyE1vmIR8v6vZSCRbIlcMTSAQEvy39mWRZrSjavnqcp7GnpdL4lTptQjbutPWEaS0OHlj10dmJM4cOQMRk2FhwAMG1/OklsrMFwGxYtYm6JBAAgNAYkjRDoISrGgsAAUmUCAAWvUyYC/pdhVVHOev5AArRgyQPkY9wElmBBBiRiYqf0YrKLMmGeiFhgxgXSYLyC8mE6hCJg1oPGYM0AiGB1hABg8oUKBgFwwQsC5MEYA6TABAFQwDkBRFQ2TC4B/MQsMAxRABjADDKMKcN0w5ADDD1ALMS4TUxRCNzKDSqMvQucx3xsjCeGfMMwXQw7ROTD+DCMUEXMyVRfTJeAwMQkHUwuASzB/AKMAgCtJowCgHA4CEKADiEBwYAfAwIpeRCEDAJGAIAGYHoETPC5SqZgAgCpYNZEYAQWARIgMXREgAVlFzi8ZMAZAo0AEYBgEaFQKAEIgFmjNPiTojIBxbJJEBAOpJJWAoAYiAZCoAE+KAGgoBN2E7CgABaBgAAAtMDgBmkpyteWI1tH8kAHYS76oGLInK8VGgqFQBHzBoBgCASTaIgCm+cRxzAHAHVSYK+UqL7pwLXUpR9UDHgDEtioAIWph2VAUAUBAEBAAKwCKpgEgCFQAIcAFKwC2xt44EtWoiCXcL2kQB6ZqXiFQGAVaakgnkNALoJH7ZUgwwtoSawkAU8ZCACiCucCAEJ2FuREAGW+QxCADR4A0u+owgjBwBSZzKZEnWYB4ACb4YAIXGtzt7JTHrRVox7oKdMDTFhDepR4YxSZB1MgNBSzGSQXsxjYJRMUjCZzDlgosx0cFAMEpBLTFXQLswgoIkMEJAoTA0AHMwgQDhMExAHzD3HUMhQV8wYQVzEgA0Mb4PgxnB4jRXOtM/Yys04VcTIeNJMk9twz8xDDFkCMMh8RgySDXDLFHdMBwesxiwMTAVBQMfxNMyKx0DDdA+MGwF0zRAhTHWF0MSwKgwLwajADA6MCgBowNwATAwASKoA4KAJMDMBwZBCHgFAsBCRARwyGAcr0BAGRgBgNDQBqvhCA+iAjkYAgDwMAhHQGRwAEwLwDigCAwCgATAeAkBwCCDhgRAUGAEAACAAHFCAD0BogAPBQAQ6AGoQP/74mSIgA9iZkYGf8AAAAANIMAAADpRlx5Z/wAAAAA0gwAAAAQAh4CZh46AcIABQsAIFwDi8IYBUDgMDAlAFAgAogAKT9BQBKXrK2ENjQoZWlwiK0hViaKGLUBCAYYAoCJagwIQDy+630jSEAtgSVSYgKALTQKoD7eiIAJsKHEQACgIBdjQ8AMgHQrKgArKUpyyAsBsr1t3tBwCiVYCAkW645gMAGBQBAEACgAAZly2RUAFrpWAGmkgcVQAU+UASY7LBCAVFyUAZOCcz8WAAS8QOAwBZf0hACCACVYWwqqAAAZZrXpP4kAQgCjTGCIBZSwQgAJJlvl9EoAaMTJ5RwUEFYVUxB8L0NTCFJjFaB5ow8IVnMaLA2DOZy1cwtcPwMH2C6TCwwxYwWUC+MJXBgjDIQoIwloF1MGoB6TCPgM4wGsBfMHYCRTBPAYAw4QfjCpEoMEkAwGgvmCARkYNIo5hdEKmVu0oYEIQJijhDmEeFOYuAjxkYE0GJOgUadAJBjdHqmMeGOYVAW5gWA+mBoLmYRYPBg5ghmACAKZlZQJhSD+mJGDYYIQEYMAIMBcCYGgJhUAoGANGAsAyIgTwwCAQAGBwERglAbmAyA4w0SBFBwEYEAxCwCJcowLALzAMATDgI0/mpgwBMvUIAAi6BeEEgDlUARAeXaFQDzAUACGQBXrDgFgKACDAIDAtADZqsdiTKWkl+i+ZfZjhbxCavslADi5KBGCQGh4CNBCGAHLAKPgIBVXSgaFoVAEc9eL8qhQ2robkgAoGAQQvFgD1cLGIAABGAOluHAWqDhUCMSAMSYCgALNVOmIJrCMAFTlSgeANCwAabZgJAFqQWcv5UI8AGXxgQdAKTepQIAA7zqO2zp/QSAEKgFKHioATYS+y4kQS2Rf19WIxX1BSIAIuGghdlTdgr1JyOiFABlYG5X/XS76q9I6KfaDaZbdnLL0pUwP1AgA5W6mpVMeBLs0k3fDJ8c9M8QXUxxV+jveWNMm0DwkD2NKoOMxfBgDKOH5MG8eYwHwbTBgCZMKYGExPwEDCcHBMC0DMxOFsxUEUzSP00FOkwcGg2TGIytMYxZmE04IEw1Ek4ISo0mCA2FSQwx/s5ugExohsypMQsBKYLgkY2E6ZbDYYlA8m+a0TeaFmYYzi0YCgIAQFEYohxHGDoCLwCBBMSwYAAamEIWgoEDBQHDCQAAqC7MnacZDEDBsDAIMHwACAUSdXkucGgWJBY/YBBwwmBMwKBIwFCsQAGDgpIQBMEAFCAUBoOAII0cgaBiJiaiZyoxIEgsCwVAoHAKmWGAERAQnqghCgKJahYEyUACEAQwAXVc1m4hAJdYqAESEICpJoT35T1eQuCFALYJVZgmkDgXDAIMAQEJAHLVsMbUYAEmD/++JkoYANQmVINnugAgAADSDAAAA4uY8QHf6ACAAANIOAAAQku/aUqRpFgDcgwCAlK1gSPMpMCQCL/wEknFX2IgEcpMCmSPVAnuz9dasDRVLEGkMlUUDFhWJyVNd4hoAlx5ewdcqZzZ01igCECn+FABezAty52HHzfppSXysC7+NJfhIilcdmgow1gGeMcMEMjBukKs1RWt+MseLjzEZQY4xJIIrMHMEXzBKg/cw5oW4MnTCdDA6AFoyFse2MDIBVTAGgPMwc8H6MOKDazBEAVgwPFQw0bswdmo9rfY0kP0yPaQ0wiMwBVY2IcE0ErM/q5g5Mik35ng4Uf82ZRQ0Mnk1agY02tszmmU3hOowUKcwbFwzyFUwxEgwgDJc4AEcwEIAwOCUwLAgSCYwOBIw+DUxBBIwgBsOD4QA2JCsGAQYCgUYMA4YVhSFgaLdmCwDGB4ZKRC4BDgAoIaYwYBIwLAkuEBhBC4AKYEoGOyYOgIqsDgDS/C4BDQCCwFUKuQsDCNhgOBiIwsBDIy9ZgeBCXAIAIAASIQAc1BtlxeVJQwCAYAAiiqNAqmkAgEJQDL+AkA1iPGvAwAAEIAFrZCACuGVlgEEvhAALEXuRhSwTRMAgACAblcMtSQvFgKVUKgAvuUAWhwVC7wqAxgsAjXlC1CQSAoEAIWCUrAMKAKEAgUBAl+kqkOv+CUe3IQktYEQCQ6RAcn4psJAGnCYGAYwYt0YCgQVgArEstAd1YxAAABA6B1Bh4GFVQcAJIBBEBY0ALQVQkQIhcARYGHte3RRMQU1FMy4xMDBVVVUC97MC+CwDAWhQsx/E78NQaKfzQPRAUyk8NSMJmCpzEexQYwYUKCMA7IhjE5wWQwrcCnMemI4TASgBIwGwBQMdV0NG9KMFjLMPTrEIzmHF0GlIKmBYAmfyEmHpwGa5/GYASnA6BHBf6nAFLGk70HBgLGlgfGLL6GNYrGcShmNwnm+BIGUIwmLowixamH4qAkegICJgyFJv0wUgmSiBKM1wExr00Y4WPDIc168EmjUCzngTOSngMGWMITMkTNTzCjAxUswAMQAznnTGjxaQCQYUKjR0IqF4DPrkaDAgzIFjhmjIgAMYBRkQoiQqCrQcJxMWWGRRtxQGAGPAIihUIEGDFgg4EZEUZQWDBINBGNAwEAAg6CRQIgpnhCkizJYLgkM1ct+FggjBkzAwrEAjjIEUXBYiuhzQqGX4UHzDFyR6kmyJJ0ElxQuYoQHFDEDi96gxjxZihKVY0lDDiElTdFQFNQAEICBli6S5CFWI5bNg45VVAjeNDwgUFgqegcGGmoNEl6CYgYNoWxGBy7zAITRBENUbEXUWjNDzIK0kgaBLsDQQGghAdh40YEGD09S7bMQU1R8sc7TGD1AU//viZN0M/bNkxRP901AAAA0gAAABPrGRCA/zWEAAADSAAAAEJoFoYobvEvDmcK7nZ9O6qIZw+K1GT0gzpnxBJSYVaDImDkrFhlKISaYt+IWmsypfxgSwJgYIyEcGG0hdxi/ZHeYHGHiGC4gOpgEYIUYLiNsGBPgQAoGaGCOhrxgVoYcYAuGXGC4hzBhGwWoYogY+GHdjgxhpATUYUsHYGIzA0ZgowyyYGoKZmBUCIZhIQJEYqEBJGGqAiJgZoK6YMuCOmAngFZgmoGSYK+BbmBKgL5kIpGRnebBjZqdamUhEI1sYeIpiwxAE0muDcaUJhjMIGhEYaQHpnUdmLTybLXZocogBEm20OZpTJjEMmCIHaVHgSHFMmLAhgwxSIWYGzbmdqnDZGrMG01G2nHdSA4+CQZnKxvHRgSok1BVs2OMyg8QnTezzSjxKurIZoiRQjMITNtQMDM2QAzM4T8VFiR4iLCZ0wZQyJ4DOQSOAC4yqEMRDiUKBGPsuBwomQmIGFmxoCWUIVjThEsNmXNMJYSAhxAKDm405MgzNiBVtMg+CoYOcplhcGLQhkUGDDJIUCBm1AsGRmEAcusSoxYyj4aQwbRAFhYZLFSJRLM4SHTZExCGIcbMWiAx5yDChSJOZQC8aJRiAymAVQBYoyEVIgoYQkgwPAZhgJjgaKZoRYCmhYQY0EtMyAYOAEwhdTmXKgf9f///UTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgAACLGCFi/5gGwJGa9WlMGlTs8hhh6XQYweNCmKVg05lFYDcYDIKSmA8niBhl4T4YAoGUH9hkGYNAIZiLnZGJCKcYBKSxkKBfGA4H6ZWwS5hRC/GZEHaYKACRiajhgwUow2iGDDIIPMl4RIzyVezN9NPMXA8AzegLDPxKvMbcoow9B8jGpQPMsgVQw+yATElBIMKAQ4DBlmEmByYGgKxgbBSmA6AaYJYQBgVgBgUFAwGQrTARAmMGAHYwVQOzBVAmMA8EomAlN9CAAU1ZQz7wDYzk3zIuTSRzfjjjnAQVAiso6hmRBAHhwSWAgJLcHAjNkBqstUxQMDIRCeEJ00CM0SQNSI2GHTBo4Qjl3mPMGDLMPBJkRhQgaChJMUMALKqaIPmYk2YswIFLNAUlMwHJgxe4IEgpoFUAgBToIDEhMCDEdVLRosHEwwiEDEFlXGRDmiGHBBBxZQw1psv2YQ+TFTKAzWiRCJEnYoEFjoBAlEoFRysMMpCoMMgBAJURDkWAuQBQB7AcPCII87HSwKxmfdmEDgUKVBoBBF/0HAEQY2YQYy54DBhS2hcVf/74mTVhP7EY0Oz/tLyAAANIAAAATiJjRJP+0nIAAA0gAAABHKwpWTEYMxgUaLq2CyxAgFG4GEF9DIEAKLLCMxA4QkCEK5JqB4OMCW4DAXVaVAalzA8AO4x8APWNRaPmzTfBkw4DgxqMYLDOTDeAwIyNIEYMCNCwDB8C2I0QA1TPQCCOn1+IwtgizDEBEMIQDAz/w5jAlDrMGgP0wdw9jA2IHMrwIUSE7MRIPQQDImLMJYZAIIpjigFGCseMYNSXZh/FiGOcEGYrY8BjZDUmGOSwYPxD5klBkmZKGeYRwRhhPhumAQCmYYIGxg6AAiAA4wGwDC8J9iyP4sjDH4E4BTeFFhhDRmi46FLIGaVERhFA3lEOzHSNmnPGIThUOYwEHIyJyBTQSOMwiNnMMQENuXCGBnV5C2UtbQHEhUWZdKBrhqrEMsOFRJhQCKJhjBhEJvRIBQmEDuULKBIsEYjCwzDgjIJjTgjnFRRukkChyLpENNENBKMaOAA8PDQgIKizOFw6aBmymRhARoAxkiqRKPcNphEy4DEkqwYSMqgCghAYPMRGGKgwFAS5wCCGZDDAVHABIxU6l4VBZiBBQXQdYGo0EHER2OEQgHFR5EmW1olCA0MQEg4AFgr9BgN/0MZfHzWLwQMKH7flumBAQKPEDGChEIA1AwAESNBCABJUzDChzAFBZCCgZhk4MKGBEmRIGBFs17wFkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqowDkeuMTSKgTmqW3owZXdfOoOIOjCbxKIyqQF2M/LH6RIueMQNU5jruCZNyIEY/Dq6zL5GgMpUJQxzCrTbWNpMt0NQxWxrjD+OlMKpgczyCczBhH2MBwlkzmF4zJPI+AgeBr9lZmg3O+byilBkTm8GhwVuZdA2pp1mFGKUa6ZVAexrKFwm2SOwYLQJ5jnAimDSC4YWIWJghg0mCIBUYYwbBk3oe8uA6lBViYCxnkwp2LyQ0IG2hRWNxKTdQ0y9qMmLB7oM/RhzDHlMgEzYRoDEpmJiYIAmCHx1gOauTm1nIBXBAQmRBBlrWDCYGA4iB32ECaUAZhigYekGXAIhCzISMwwIMeMgwUGCAwIRCAAuAZ0AjQuYyLmAAgAFzBCwyAVMPJjKgARhBiwuZaYGjh4sSiRSgsMDoUEBoyKBgQgpUFzHCEoAF5oTQuGjxSoqZUHjwoYCDIci/Ra0FLZhwGY6DImmHAIhB4qZkPBiKSEaPpgYIpsRFhgowYSPK9M5D0uh4BCBsrBC/SOIssgoJJB4wQYFmkLCYgByslSWj5jIUmqMiggDB4CAAKOCIKZUJ48IGLiZhouEByNgcQmOh66CUMQQKOGLCqVBfYyYiBQSBjj/++Jk6I//G2NCA/7acAAADSAAAAE76Y8ID/NWyAAANIAAAARJJOpTEHDSqMBKJu5YOO////1GA1g+4Gcjjk0HAU3P3FqOG9KtjDOC/AwIob/NBgHuDCqxisxfJDMNEKGVjFMxOQwDIxeMHCGbTCIwoMwIoI7MAoHcDAjAhIwPgSdME+CgzCgyB8wTYBAMIuBuDBZAsAwLoLCMAfABDCNQ7QxUIFKMZkKXjB2w1oxWQG3MOYCVDEWApkwTwFlMHfA/DCEwt4wpQJdMc5w3CWTnryNeu88l/TBb6O5mQzU8zZMGMpWMyqYzPhhM1zk5A/RVgGKWUZxFJoI0mOBgZfJxncFAkSycycgxGCjIpeMeDsiRBhgBo/GMUsZxBRkhVmLl+YlJhiYGmLA2YyJJn4QmIwYxVggjCZZIHbhp2JiAmaYISagkbHIdsibimm0ZcIF4wwONUTMQdMuIWkwEAnzBhgKuMqMM3XL6DTIWfpYB5EwI8hBm6OJaJrGEFGGFMKMCaDFwjBgoY2YwaU2AUDEQUmOK1TiBwpBIPGSAyJAXBIgBiF5giZggQ8VWqBgoQLNQpMctDBIXJqZCwQmamfRSERhAVYEi5UEAkKZkOgmAzVBKGTlsJ/EQwaEDogoIGGJvAkoWuNURApYCHRhECg6AlgQJBpBFxiIiZY6soxAQrCiQuIJvmKCo4prkpMWSF6EuGs2NDtVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQKqswJQLjMOPDCDNyRbYzJ5VSM9BHnDBnAZwwtkAQMS5DLTA2gw4wGEP+MaEBajBiQW8xFUPlMGUAMDA7wN0wxOsGWSAgtM1EEMi0nMiMFMVQGMJShGumHV6BKBG4Zsgb1DS2vzWXJzUwRjSQuTEEbDNkkDIJljN5TDUY7TXoGzG0czB0OjEQXACEhhqHJMO4sIooKQjEoBEMYaiCYQBgYAgoXxg8RAyMAkGTi04kewQ2+ARU0UWwEAxgoGEsRNmiIZKhgkmoow4lXFm1VSTZBYz1xJdAQKjKxgYkMJT6iYMRNF9dQGrDHQFU7aOCnLPzJRNENr44S5y1gIalEgKaCX5ZMHajyxad+kqhCECmDMAgFfq/Y+NFhcEdKL7BDJkGgpBoTMxEC4piItUSrXO6Rgml3ZxVjIU5kQbIKLTIGBGVgYtBdB0dFUyLvtLCHV3rrGRS4C8brQhIVnqAtOALBMvZ2RCGA2eSreg7oSIUBDgVCC7ZUHMAksiYCTDRwMQnGeO4qV6Q7gAodD//viZMWM/IxixhP9y2IAAA0gAAABPWGNCA/vWEAAADSAAAAEovoiMe89UwrQRHM9yHbTrviG0xsv0xMxLXgDG+B8Uyk8J4MhCOeDHvQQYwbkXoNHEEkTDWRJg04QdCMS7FGjCfgW4DEQxieQpsYKGBuGIPgDxhuALoYRaJ+mEXgfRgKIAKYOYAIGDqhk5hrQgsYKuEVmGUhsJhTRIYYU8CEGB/g2Bg2YbwYbiF5mH1AkpghYG0YJmHCAQGXMQ4CCDBHAC0wVcDRMCFANjAYAHwwOwBcMH/BdzBqgK43vWPgwTZys6TNEPQdponmhpwUkdahm6HRjzsY2Pm1FBLBmjpRvg8GFgYfGCE4qBGhoBlBUYGSMugOMNWJAAA8zc7b80jI2+MKRh0+RBzBQzcSj5lg06BVKuRgsCzBjRJxAZsBIChlhmZsWIGBkQZiRZh4QeoNe/OASM24M4MMRFCPIjkmuTKXPWYoAZEOFzTdGkGQGK3rwRaEgxlAxIRDH4MHg4iYwAGJDJAQErcAOLF4AMZMeiMkxBhgElxlKaNKDgKzwEMASYQHBCdDggwcHjxmixrwIAFhioArjZgjLEAsEMEXEYdVcQBEaQoTCwAwA8QhAowL2CEIFTBgYpjhQAFhcGTKAKKIkRiAxhAhhgrWzGlE1SzQBIg4gwEGiWkqPlwIfFgwCDBAJnxIBSYBwZLi2Hk////6lTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUBFDMDknQzLB9z4TC6OMHFc0xlqjW+HHMQ4Vgxb0VzBXH1MK8J80sgnTFbCVN0krkxPhNzCeF+MVUcNLxfMSAmNMhCMH0EMHxDNCRrMdw6MlwdBKzmGiEGe5QHB4tmbMamFtTGmANGNyDgJXDJsIzKYKxVAjEVIDJ4RjJchzGEFTFAADHIFTCcZgEQ5KD4SqGQB7xgDg6QwyBwUuCGXoDi/QK5HjDFECoYONZgnKxMLCJEoPv87KbyRLZS7qzkVIyKhJsL4agIAGdqLJDrSQsVcgKWDjA4Ii2mClHLiYYMBfoZDS2f9piBokwsAyQePVWVvX8uxyUV1z0DNE9HAUiyho7rv6pWyxlS6KRSDhpyQK/a9kO6gif7mtYi7BXMUBaQifDiTz3w6VAZSxCfp1gleVGOu/DjprSfRu6sEca9XdJjbspGJXI2qgChRdNXQ8KTIvoGBjSCWq/wcahLjCCBNlVy/mGNFYkgDlL05v/74mS2jPtjYsaT3ctSAAANIAAAAT5VkwYP91aAAAA0gAAABBc4s8aHySDncnJnp2M31gdK0ITmugA/5mqgNyYBWpFGLXEaxhXJvyaL8EjmBjCC5sCgm4YQ2DqGAbBvxgkohcY44QDmFoBB5hZ4NoYCUBbmETBihhsoHIYdsB+mGEAmhggYUUYFoJ3GH7gdRhDgUEZGmL9GHElFJh1wTaYYaAFmAVAdxgHgKAYiOCIGClgxpix4vcf6ECcUJcY2pgZjFiYdAeY3ImZaDuZDGYY+kEZ1BGZBloZ/EoZnJEZYEkZII8Z7HQY2EYZVhYYphiIx+AgOGSAzGNw4GYA+GQB3GUAfGOYqmOIUGNpZ5gFeqgekCrWbkqTJwYXFrZpcIzCO/pMVMPCrGYgAUGzPh4wycAxkcwBgxuc2bAAwzQmTUBzQgwqZPOVMcnMPgB8wAMjosjDtzpgDFEQEROu5RPZUPRCRmZdqaueZc6Y1KmpLzHCCqzdII4miQmLegkyBU4CJm5QhUmSETEkzGJTSNSIyZQkZpUX2MHbAikxrMHshwCWH5ik51yIUg6MOoQwCpJL4WOtjByYxK845gxrkoai0kxAQzbBBwwA8xc9BKaAJECoXM+UIhZQTM9JElwhShydlBkyqYokBHEEsFiQVHGhDpXGQBhhlVheUgBGTAGuCiQ1CWJGCI4nISHjJhlVMfsVf//3/7UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQApswJRnzJ7CGN6sagxvSHDQYK9MwQb4xcAXTGYL5MLUC4wLx9w4xkwaAoDMfDFDAKhoI8wOvjEsMMji0Lk81uTTAk+MQhAGjESz5glLGBEgZPJZz42HvpqbMdptWEmQACb2B5vInmNHKYphZrU3GxUiCmWZBCxgIIGGQIYhERhcMGGwwGACMh1yJxRMFEepIdSSM6yQO0sqSDaQylWBcjlQwzlaIEOCqluQ6IsGmXdHHJcZmEnY07hfBmKIxfZaJA9gzXU1HgMgXTjKmqqCXcCS9mBedSqERh+hCd2yEKpRwQiAtFqDdUKmol7U04OXtH0wlmwAsDDsDz7nMqYGvdShDVhbD2tOo+0MtBV9EE5c19rBPdtfD+NTg9S9W1Ddfjkx1ksLtsbXssp/lkQAsJL3rbd4l0O6rpA9RpNlebB0lkTmDRhB7BYYrDPw4tVUqSTCFCmS2eFhowM0ZXRlR6rZFsjIyo1SnRnTOjL+c5zvE3OjftQhCEV+4c33//n59/9cz73Dn4cz7+fcLG+4bz3Uq0EzBTWWPL8a6qYmAazgigUeCvE5AV8BPCgGGqXpUIFoJhYIs8MOoI4AqUQsBXQm5wEXbW8NALtsAiNBdubw5//++Jk6QzKtWLIE9zDUKRuFUAXA/ZpaY8mb3NlwfQnmcgA7yH//780L+FoTn6U3iJ8SoXEInYXE3dCzQOLiYc0jsDPkD4E5Zw+T+vAJwE20nTAODtMdwJQio4NN9RE0/yhzH0EsOVsM9v0DHkfMWbs6MADKQTPRCYMNgyRTDg4MuqEyWKjC5cMOAMwCxDEQAMUgky0ADF5TMTHwwanTKhVO/nIxRXDMaZB18cwLgNSNKVDFcsEmB8IWZ8ELZLPJLgZ3UwdpJEMDVgx4gMGCW6pglYWoIEACXSNYjDG0RlQClrU7FiqMuooNAbeK1vsglh0twGB65H0UyRRYUvxMkSC1K2OOilDUVWXy3WyyZnMPtJXYstnKtzTGM13CmXhUzV26LPWhOI5Eff10myLMRzlz+q1v81xpCd7+NwYuy2WNegFpUTbrZaVF1bIy0lkTlPbFrk45ECJJLWVavFU6wsugJxI7JFhnTd6BWzvaX2XjMPGz5kCdiyQwXZG4rGmVwE5zzIWscWBnXEWrOJVsQBACAhFLBcstt8C7w/K/nKmmcFgBJSXKZAMZKRS7Kbmy+BDgIfM6krfQRgZVHjdX01EBEggqDBoyIBWESnzC3E4k3NTnTjUsKgBiLadrmnZsZij4b8bBcHMoSAFGGOg5ljsdtuHmRxqAwmEaU1HBn40DSaIUoT3//4REIn7+aSohnIP7/hk5BVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQIVswNApjJgDTNoMwU2YE6jdtIHMdAJ0x7QojLkH1MQgbQwYCGzNg7FpweJbRicfGJ12YKKRgZhG2AIY4I5h0IBV4A5gmRgoYbI5ngQmIQ8YsJZrkJn8ica/IIwlTW4+MKCs04qjQpjMMJUz8OThouMTEsxELAuAjBQVMSjwsyPCdCowFLpGw7zwIiO3KomEzJjJesMyJGacCSiACEgMmhANCZ+8McXy0pcjc1pPflIEomsL0vqmRxbtLe3mFpCEUSZy/JRD8pZo0tiDyRd1kLFsy+KPtNtzcpubNHnijA2/VteVE6gUDaMtF4ImsHFHgfr2RvVQTzo7U0ldBDzjQhr8IqyVgUHIIk3UVVetMIRuAiu5jrNxYlyZjz/LmSRgFwoeQwiJevGJpbsPeEtvAsHyhcqakoZa/iPyszDIFahGHUcSVTmNQBVCTkv////////r/rRcuvX1sv1601p19FuNfooWgAMAwLMFhQMLgVNUkMNDS/MNECMdjRN40rNnJyNCB8M+YHMIzwMv0tN+w8CANMGCZMCGtO/UPNIoMNuxUNBgoMdBUARqnUBwnBrPnOMYmhaenKUvGgBTmoosGz5HmAIlGBwPkwdsVgadvhBvJXCOJh7//vgZOsMyjpjSJPcwnCcyhZyBF2eK3WNGC93KcIcJ1rMAXdZltAh8VeLLNLbaK66/+0ATELMYM+k+s8sKPDSsVsNJYzszTi2TF5G2NfsIgxSwnzCFMlMjkyMQyQOOsbMPGNMjSZNCxoOPR7Mp0JM2TiMayWMmTiNvh4M7gaNLAkMwF8MRlsFS8OGSmP5WpNgNhNOwfOOTcNxTRNAULMwmLMIiUNMoBFl2A0rGHpCmFpEmCoGAgTzBEIjFcKAhlaplrnCWNajTaXgXAXoYjDaMsYoWqCqKlKZbMEBZb10VfusWYo0qmvkxitqBjl2BEMthZrQE0kiHvZTMO8j29SaCigc8ni8rfTStyhiRLirsLTAZcHDryWlTKmijXcH24yxDu8LiI+teR5TpboyJryp7DproWkSgMSc19lvsfTNbs2VaMVkE7TQ2vh2l9t3pXFj0dbdOWC0Or9tAcRx7zkCIJjjkrrkFh6IdiLTVcqfhlTalLgTLyN1U1Xm4io2vJXKFuK0pJ6lbdYVsDawqWgCWUDX/9N7nk1Kl/v7a5oNGoutnqpJN4Z0TjCQAJoGcY5HMiHnKpXnEj1mIJwGsOMGzAGmNfJnbsLGt4lGfoFSswGGw2Oc0yTZw5d0w3mk0xmTE5C6E4PjQwQikXv0xZbMyT8481Gs5qHwFl0aKgOlCLA03oS////ODnN2PhthjFwkTV7voHpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMG0V80+xcDp5bdPdnz07UGtzHwEvDmPDTmBMMZ4x0w4hrTFdAjR0gTHfLDKAbiypriW5lGfpqGgRkYiZiSNZhucpjoFJoGTJpmGZlaXxlUnRjEhBn8MB4kyRrBbBkWUhuuU5u6EBmCrAAgQySiAzGYcFYCZWFAZcCIYMhaIxVlAWBswSFAGnnJONCmQEfKRQOjc3AeRMsBCUuJQdCAKLGEMBEmNFBK75sHDAwIDkBCBMgmuhSoOXETsR8WEEQ7cV0PuoG5AKEQctzityQigQ4czJpj4tbfwoEh9FBYRZikQw5sDLIoienhEmfvo5q1GCKXv/NMWTkDIZ/2frOdaAEvlWtiSvghPdfEua0rxTGIMeXwkc02MMsd9sbT1h5xwqe0y1fb5taZpDLlJfq/TJbqnXDr2dhharKLj4tqzl1VNr1BC4KbBbUrlElcqGI0zNcsTm3Dd9g1IPMp7lzMvKpvuM/0eOABFP+bGwp3qOTMmMBAXEQPGGo2GUSAmfBKmAQiGGYrmdymmxS/mdwumi1HnxHBm1JWGFAKmBYGGFpZGmqOGJYjmFpPGJZCmoUlnJc3AbGjKQZDYNrAiLzRROzDo8DO8DzRpaTLUSAKAiI7FG+is9eC7O//viZOuMysFixoPdynCKihaBAD3Wp6GNLG7vCcKjtJcIE2PIxQ9VQubohe1V9Vd4DmstoUMkzeN48aaI9EH01UukYEIIiQ1xOcQFwYImCbiMm2uRgX+ZaimJtRbM2MkOQHzBDowcdIDECBoOYgggMNXzGIIeEBdYPfszhVQ4qgNxSzFAw1w7MNRTKrQAlJ1gwYUDmGihcRLpvIq4yILqNVYKCOo+A6qkoix0aSnuI4pArRgAvInEiDFlwF1QUEsgEECZDqCha/U31ABV4kZXSBakVIQC2VALaU8kKl866tLclMoARVUsS4YYpc3Na46Jlol1/09FltuzaMI9rC4J7TDcoGaJJlglKWPp7LtjzKVblBVgl7KXKLJvrclDKMWkNfn3qTig5ZD2KaOmqqjnxTGLShD2NvI4Y0pDhLHLTxT6spIOjQNNcCsttmkoYAu9/180lE6TWBrrSEwZevplDhu45T/sSX8vCJRR5eAAoX/wowhX+VOxCwvhCEOJ4Q/ELMIhOYQ+QhChDR1VppGZqqOJJU80cSJEq///rmkSJE4K1Ry2XO6zpVVYNMwMMYAhciL6UwgOFZCHAXiADA55NgDeMRxUgjKXrBYTbYY2aEDbjUNMpb6RSqrCG3hEjnc+a7rLLL945ZU1NTd3jj/6pst0tLS1qampu0tLS0uX6rU2X41a1NksFQVBoGgaPcFdT53BUFaqTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqoATBoD+NKoRU31V2Te4/iMl1vsy2RFjC9EHMrA1wxJQazCnD7MNk9M6xwMoeCMIgPMQTOMuETEY3mmqXmVZWmJokmGZtmQoFmfgaGooumhBPmGaoGjBOmYxOmyk9GHXXmID3GX49mrQzm8Z9mcBHmXbhGtJnHCQNmXIcGB4HmDg8AwCDCAHRYSi4AIFMM4EwICTHUFBwd0kORTwQxEEmlkAQaDih0FMJTyeCZyBjpooKAr8VVFgphGlHJJSBMG1YnCajyM4b5uzEGxKOuNC37LrsaUHTkQTsPpW6PcxhCVAsrhppEnhuILrfDONU7Nm5u9J26K+YBKHVg+HmGva9yuIi2B93bfdsjKorSP8u9Ix00+nqZwreFSmCtalDrpXodGJrRZGp+ENu4E2211kMYn47QNxpmKO8711v2uK+bnB6HkBOnAzPUClKnjWq+DJ29RKXw3Vr0s4owEkfwMa9IAzUNmno5isdhMl7SFTQzQMkytMGYMLjMaTEAhQMwUINxNCcyUxbiIDRAj/MCAg4xWyjzImI1MlIwgy2ylDMeBOMDczIxchdDFDD4MdARUzWBPTFITkMpc0AxqBPTZBFrMpOdc1PF+DPNYCMgwWY12CTzSeUYMmFQQx2xXzUzSWNAIaEy7g//74mTyjkrCY0cL3cpwAAANIAAAATiFjQwP+0nC6jPWHFG9uMDDIFMMKcMgwXgETCiBzMAIHgwYgogJLF8x3YIJHnkUn6UHHoGPQi7UGkzRgTTjzCjAuAOgGNZGR5NkMCgofwGKjApQAuCHI0QYRBT8nzHNjPIBtgFBxsCLXGFtOByMABDCRihKIgoGVmAMmFMmZrkxoKPS6Q0uBxY1oUdKgoGYgoBiKH4BFGkHmGNhC0HAEJhe4xI4WDiwNS4VBrSCFAWUIrAkIm6LLgAAMEIBJdSCRAIIoawaAggGaBiAUDqWgwCCigqZeIQEDChzACTBCTFlzCkwFDMSAKqZL4wwE0ZYCj0UywBBScBbAMfBxVN8HB31MGCQCGFBqkCAYQKLziRRciwY8VKgIwpAmVlUKIAgUFMDAQVnCaYoAT0LOJiloQwg2NMiiRIHgZsCzvGABiQcHIVKVuwhQgKTUlg8Z1CgypCCDyTKvCsdjBf0lOlYTwv+EHZKivCOVhwAGBLCHphUo9zdObJ6s7BLEzHgRJY8DTzMeBEY4T1VIMuBvpJQo9WbmcJ6x4ERjSSEjwHrLoZpPiWkPFgLfFb3zamDlNYxDzS6MVbI/YFOpkqlUKQKDOAnZ+RYCkVqXOgt45BZQ6g3APghaKcVeuEShRYDoU8KC+cXJ0q1fApndLyVZGNzprw4UzJDxm00OzwCf41/5DTjXwAAMwLEEJMfhCXDIAzo8w4RMlMcLFJzG2weEw/sB5MQ3E7jAJA0AwWUFhN2UfNkguNpd8MulVBDzmXCqmsysmzw6GxoXGeJTECuGK4qmm5lgqfzVEtDIBFDZZrDmUFDfPrD9vEDL5sjFBrDVoRTKFvTPOmzRnJzLOOAuShiuOZkiN5gwKphUHRj0CBgsGBhGF6kwiI5yCjsRnGa8aGhwnErJjpnSKNLmeqPdhw41ESimJLDA0E4AMCCphAOaA4EdNoEQEiQKaq6lorlLaoKgkQkDQ6pgx8cFSFjpikBHSdJbUEChQOUptCpw8cqQSCLcpcJLKLLwRrnE9lnu+WmTWBIiNSZM60tT6IRhhLGqp0oyvLDIwQypVjMb5cRVNAxNRio6CmiiqqiWBRgNW11yzI0KnBFU6oswNOpDYDMt2ZUsJDrGFoNpQMCZ7IIDfVm6831QXM8wzTguAARAVCqiBRFhFnKDNJa+BgEEUYQzTgBwKK7eg5EOdUxl4CHrQnVP////cas1BJYGOjg7mDQeOJB1ZQIzzhZRjor/O//////////3Yk1yrITBlPnUMzhzxUEzUTVVNoB45rHtSSwE0kyEDUaNgZDA1pA6U0T0axAEbJ6QxjFA4QCEByhgpg58GFGyOYJZqlopmSqRJGYsHKAUs8EbRnEEsvub1vHKdD/++Jk/4z7+2PGE/3KcqZLdrADONgsgY0eT3cpylgtnMAKZ1BKQFd7pxpayjaEQMFqGFoQtna74HwpgsQ3GKiTq9C9rCb5lCHAougCLQgKlMTIXQzXoIjnUYgMocag0+SrTHGF+M04kUw8xbxUK02XEg26Gk0Uh0xMM4xEPsxVD02iUowxPcywBIxREUxGOwxPFsxNEgzmEowKaMxfFQ1cD8y8Ko4Kr8zb68wtGw1ILw3tQMytWYzSFQzxe01sMoy7HUzBDIwcDgBBGVAdAAEBgDmFYNIEhw0HVmQQCDTNtMhAFaI6lkC6wEFRlbgRILcJAxCeEDlZbCG9EAjilEbPDIAEICeCgpdlTN1UOaXJflYJQCMNbtK3ua9bPUzlJu0m4mtGmsU1VfrI3NEYzO2rNUdJQtrCmcXbgpxHZO7b7MaVImI1NoUPJiKLUspYGsxQODE12mXIChxeSp5S0GMzSlrcFcRtkb4QxTt6OAumgW3VJtpcCDQ6XTWwwRvnRRatOorIXYLqqUpHNNuJHupLl1LWLhNEfFkLoqPxtYVma+bqaLKXRbdoy94dsPU1X/qOlgVkDXgQMMLAcqBiQqEcF6QMUOIuktTW//ppjmUshCuIhAInnUht0DIuMgUeVikrpocksjjlKY7JiWD0jyBy4GZNoxuZCEBgpoChp4lUgbAJURrcqoD36LpAA/4OARqRiIgSE8a4pU2iLiUb/+cysiN8iPpsa0wAIAowJQnDSTLki6iOWNVD5KlLWEFFcbeA1hIf6gARIwaxNjkcJDNX/DM7jfnDu6MyOMsBA10iETU1SoMRA2Uxui1jBwEsMY8TUw1xVDFNGWMewIkwwxsDA2MjMOQO4wnA6jGtA1MIwDQwCRfDAEEXMA8PYxeRXTJsHoMXEJQynRfjOQZ6NTc70yqhijC7CXMbgLgxIR0TEQB8Mb8NwyIxUDFAEuMPMBkwiBLzBdBYMHQKcZBSCATwaBiBCNkxEUwZ4cDDzkwqsAIDBhRU6LEho2ZJuUCibQLHzRCgRNMWvBJozxkGAzEBANHkxlBZhTIXOsILboXIOl2y0iq4QAJArvIsmXElUcAAI0iEgiK6KYAQAESZ8cJSQqNMcOEI81yElDyFrjxGcoDiIj/uYypCyWxRhTzK+bqluTHbgsksIaaXrLcA4xapl6TCHNNEteMkW2mslgs8LAgslCHPLdIouoDgMSZwwVt2WPwsRvi0ayV7o8I+MfhdENNJiMcL6L4cV5FlrdYc/i0nRUgbwJxiMTpAsxijEADAIFmu5VUEuRTZ8keACKuVvHhNKWZDC1JQ/cERN/IbikW/+CWJErWc6xBo4VGXTkf0K52/Z28TBGZq7n4gpgkQmu3RvFb2btIdRkaYbLF0NcRXf5ur//viZOgMzOJnRZPaxjCRa0hAAFjQbpGXGE93KcnlrSOMA79AQnsroaQW77/srWPDV52GRwOkO4TTdyZchfwtOlfDdE1trecbZesI6jyOgXsSIZIoAtRYd72AMAUEdTn//3U90AaK6Rbrvuyxrk5SJHgoaa8/ci60FhIEgRxKSkh+OAStmJWbQZXaIJuKX4Gj+2OdRh0ZlMm2GduGwY2wg5jyBLmCmSsZYJyaiHaZuheaOg0atoyYsJGabEqaXoQaGAEZOGAZNjkYaCuZZC+BlZMeTaMtTQMEFFOIRyMfYDORjEOBW8NH1LNNIFMcB7OVzGNgXzNKyIMzhpMgB9VeHA8MBkYdAMYdAKDgrQpAzylcgNZtEIBAl7l6gxAyDDcEVTKgRAWrOXxX6XWcIlAEgDOIAxKmrPFeIbAU113JQTg0VlKcqAdCJTJmhZ1QVdz8r0fJU5MO8Y4QRCuYHLjxQkSrA1RLhdUbUVgFjrqL8aehgXxlK7muNeftZL+r+bowAWDpF9JOrxeNY7cVpNNZ4HAP6XnQ5FlESGNr4TDDBpSFSxgZypkSHTxg5fBbRAJC0Sl6FzXlboXfU0WavwHLqWKZJcI5iTBfccFXe0pTgetUHGmAMegIlrE2/cVyWxpkoshQJDCKIaoLnEMFzSYp+5TTTN76zQA7pAP/xAPo+zpEeHUbIF0QFmd/nSph0hfFvDlL47PYYyiMAMIgItJvD+MUctVhmF1VaeO0sj5MlctqrUiEJEvQ/HNXoadDE9TrxD2ZaQ5irM3KqDRhVOoVn0bdXyiVUbxf//3r169lYYz1TQzlePt4bHalRuoTEzRqBmUjKNUnPhdpozc99zmENDM6A8s0Vh+zIAKlMVM0kyGBFTGROYMEQSowZQJjL9uDFgsDMkOjLUwwcjYceJgkmhjoBhgEoJoqXhmiThoSQRvyjZ1SXxurfhuAShgupBsEg5hv+pmlaZm/ZJrxlIVLwzTOw0QRcwACkwlBAwcFUaG0KEYYOkIYABIYag6FwlMIwhIgWBgGg4FjAcTSAKTCoIYaGQSNV0wjQY+DDjujBhwhQIkUHjtTQBgeAAhnamwASWIGTdAHDxDAYQaVBjVgI1PMmIBtyY6lKJAEXNUAwz11mA0DCzdIFbjcCASpgvOklstFX6eRfJBc0VwqSXFUSpkowxUMDRKU5JgnVWGHRWwMpB1CA0SQMEBSoWaXqaIgOHCj0CIvp3oSl6sVdwWEQxRMfkzCkyk05QsOXbCphlAIrswYo1lNNDk7ikFAmSRUFHJQJNpGBwJZxER2FB3KTpayC0yAtiErEAIsUFGiyaFUHBYotOj+y8qHjyaaLXUJoXDLmGMkag4gJScZrVn/UcF4Yk0iMMtctqKpoP+ghbDY25zut//74mTSiPx+ZEST3cryd2r4EAMP5DQRkwzPazZBy6weAAO/QNDViae7sBOK6UCspbyMvU3MGgLZFrmdtdTBb2B3mm2AlqQNF+H1LwyxQYLDARRSTALkP5aPQR0v6FpBRQUUT0nOso3rub//J0tWZFv//yJv9vZEiqjTQlWUJU5un4spir5iwAIATFAsDO15bg0qVuDHfNpMtEUgxhwpjBaAFMb0oAwqgXTEhGEMQQGsw7QeDDUFNMBUK0CiQmKOD+Y6wmJjQiNGEYCSYIAGZieg5mMAJ4LApGQGYEYZ4xJgNiQmjUduZIRGZptipGQQh8ZbZa5golxGD6HmYNwqRjLBLmNMKeYnYjQ1mOXMNc7M6tP8jODOPcuA/cU7nCXBC4KmjDsjfzB1eY4SoeaUUaAhEoaopmqhgBFMIwUuQ782Ki8xm/Atc9ojsPPCIDgCZZtFmAACWTNFHvzMLDgAsszUAKgZUHELyAyQNYAJZvFl1xJoZYKGR4MKFpNPUZyppiz6yUUTqcC5CNYqqrocARTNQAAFDBIAPJiC1YYCBkwaAYY4k940oBCRZQwAAcgTJkwU44A6GjmiUgKRcLSl2xQMEiJ4GuADhE8TFATKDjC3ggEAoAoizRCYao5b4DJNZHA0fwgolRSUTIL5p7gaOGV6o3s0VQGCgViaZ5piImigQNeQfNxwBDApUUFGZ0BUMCSZFUKjMVQWC4BKWbRwUJLWoPu099zX/wsXI2QkKACHEJElGKfyisxKKPHLa4L5OXA5kOZpHZyqQ0kOOq7DPqCpSCnCpmctsdOstW1Gm8mx8lyY0JRQ9SFNY3TJfHaQlsUSeQqWuaRmFl18WxKhszEzZ/+Lbr1KaJoqJEnS1FuRylZRgiFHkpVTijCPDFkyPob7M4wT2DNhBjozRdF1NHLKITB5hxIw0ATvMbHFvTCbAakwlQAeMDGBLzBkRbQxr4eCMXMBEjrVUxA+hthBxlYM5hIMhj2PhynEpyv95ma3JhstxgA95r2YZh3OxjHNZl8j5mxJhu+DZjMQZjCIJgQO5j4opmaaRi2KoYsRi8HBguABg+JYyF5hwEZgGCJ0ERl0ZvXptah45hzb5nhgGIGdMFzzfNRFENWwFBYADGJSA5UYhCBYJMPL2jrI1KgCkQyiaEKXHN2jNeMMKdMcKB58FUjEhDBGwcaAQo3D8FHDQhkE5VTGfIGegmZHMnBRgQPgEBIBZigQAJGaEBDQ1ApJI0jwRlTTrCIkalQOCTZqTRyTHFTNhzWDhGYNWMNSVMYVCqMHSx4QZQuaKaGQFrGoMmmAhCczb00JM5IF1hFIM9KRdMKcDAhoRxihhYGBQ0/ghCiCYYYsZsiJLTNSjIijUkzQHDBDSqICgccfGO6GyEGOAkD/++JkvY/+WGRBA/3TUHFLNfMALNA6LZMID/NUgAAANIAAAARgGGUdDEEiJaYQCKgU7VzEyJMkcOiq0GCRECBzhBKalUa0Yc2sZQosoLJjPvjYMzEI09jVEwzUogZRgtsIdIGRhLcCEzAADGCxw+liFQLr1QAWg5P8Rl91cSR6E4rnj7is9EocSqXDs8VqXmWoH4n4lRNBIeRPLBaMWrytJQ9FcsD8JJePyySi8fhCJSGpOk7kX1nnjElDyXSovWL3FRiVi8duP9fL9W2zSMmhMCoOhwJZYQVP9aInEkvFc8VuBf/6zCOQz0x9M8vPtVVAzZchkk9XYQ4MT7GkDFnz3YxyYlfMNbMwjCRQxYw5IFGMq6CRDFJyUo1HUpBMdbC5zCqwvswmUL+MNwAjTCDApgwioH6MMfApzBzhcExGwNUJhMIwBMF4MCoBCzAsAfUwFgEgMD5AoDCNwc4wWYRaMwJcwW9DPQuNPqMVRh68fmAmIZeCxNLzAQHMlDE46ETEJ0NJF4yQWDLQlMKkUz44AUkTLpbAgNMaC4yGGzFgZOGUNRqOEAKgENGmHVnL0gVYgsOigqBFpZklhARMC9GDinzaAiIgaE2ZBYRCmaCggwRMBBi0YGGCBAawQpUUQAMLMOGNYyNSOOEPMEnACY0goDJQMXADQihjCoFIwq0MYAM0bEYkMFmNGgpsYUuQAQxIEV3eEhJqwSRRoGgNHM9Jo5VDg0GHEDDhjRAiEuVAJhBRwDRaBcqHoOQGsHgYQKmx5ikAIRZhnhnjIFXoeAokYQUXPIB4ZQL7lgKZJWZQmZ4kTCygCBACKLWV4jAgzgAyRoQgjJGmtERtFAvmIAhiAQ0LfqUuvMmNPkwQwohVEAHUcwsHFnIOHhwktaZlIAqxiAY8BEZALkTHBS0KKxaRNJd2vsDPZTAqRI4wPiM1Ndl0QzBMisc+oVYhMOdCaDHvVqcxk4AqNksLJTB/gdYIHETNthGwwg4uxNXFSOjLUwAEwVsRaMDAA2DBGwaowugFkMBuBiTBowckwGIXXMbSBUjAbQJYwZ0C6MCbAlD+fKNuF0VXhuY5G3xaVnA1aZjXARNaqU0oBjXxwODIVuJmhEmXxWZZH5rEkmJCGAjOVSQYgPwKPxgaSgJPGFQYYbFRm0rGNwoYANRgjgWXGRTiCScg6ZKWbMoPvjgTzBIjOzjKlDrExGXMhjFAgSCIvIBKmRjhVAadMZUWIRZgAIGIiw9ZqjK+TEGhUcZscXNMX1BmQhDAaaHOTTjRpiZcOCVgGVGHNESZOMwhUAqQyQDQAMBhYuhUUSzIADajzLFTCAwYPYKZEMmwF3T6ocxatDZhGL2j25ChoQO1JMBmdsI0NTTEkRxEgXGvqv4yIo1R4oQmKBgA//viZK8P/kFjwYP81LAAAA0gAAABOIGPCA/3UoAAADSAAAAECBkAcGIQ5mgBjww8ENgIDKZpSRgQYAImDFChwxAgSAGCHkIJuQJILEAwUwpUABQgUuICixQ+CQgVIKyqAs1Hr7MlPEQBLcOFDgAMkuUBRpgCQWLGUKF1Rk0aQUHCgYAHQpmCqx2IyYDL9pihYqEYeoo8n8uF4JqnpT2cN5OVGG1Ax5mSQ/0YRCBRGoNkTpiBAXWYB6JfGTjBV5iOA/Oa+UZxGEMgm5gVgYWYb0C2GDeguZgaoJ+YK8EBGBMhaZg9wOwZAkBmmBhgbhgMoaiYsKIjnv6bmY5VmdFTGj9RmRqwG0j+mnbImI5qizXGD4amGROmFA+GJhomLhaGYCWmGwfGFgPmHISBUPzFoz+iQViPo4NU/PEQNQxCLA8vMaTN4KMqvL4GhNi2A1oUwEg1Is6a81xQqpAxIF0pwGRUlmwEAEWCS4kdNnNInhYMAYQIhq4SJcIhgwHEiwCWvGNSFSApOOpgcHNNFMEEMgPNmQDkoqDKHAhHgUkZBSDSRkp5wV4qPpTcMUBaoC/S1iQChYNEAwZTBD0xAQwq0y7RiA0IS0BKpB82xwSaAwaYYCEBDFFGRolAkKmABDKZZcEKjwENApcwgUmMAZYIRyPDvL4AAAz49J8wxEqgTAnU+zFBQEbBAtcKGRhwav0WSsdCFCh4YNY5OyAABSgiliqJXggMmMIkzkSGhBVqKLRdEoEhiIQsDRkQUKLkryMQzGhKJwKumABpJNYU/FQC///1KkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoBUbMFGFXzEblTQ2hpdgM71HFjENFh0wSIFKMdZKljAqQ1EwzYkQMGGB1DD1BMoxKAD/MGRDbDIOgIMwiMBsMT5qNEHGNhB6NLyHMUitNVjIMFXwO/ljNgvIM+93O/wuPsjgNWClNBkPM0lqNJg/MvmNiZjgbZkOdpmgUpm0KRYAUwJA8IH4Ck0IRiMHADAgXiEAQMBZgwDhgCA5kWE4sFgVAkKA4IAEMHAeLaCWQ3RoGBDAlxGNJTZiAwMdAJmYsI4YKMAYUZQkNHzRlQYfYWak6NYzFgh6Cb4oYREGMDRkSUOjeWAIsLC4Iww4FGAILBzIxw0IEIrDpEmJPSYxiNCR0GOhR4GYwIbIaDlZEDWqWeEAADDUtAcGHBQWBBwALgQwEAlICBgAGnSYhMjMlcGCF5mJCNYesUGmQCoIUE65yAUo4Zg8leZkeWSAzJcqUBQ4MOSgRNUyA5GsQGzNCwU3QlGXDhgFaYgOCwVFYWVp0ChRPNKJnhgAJVTgoiDiMMgkCQBzTEDHkSASrcrOZ9AY8WpcRF1BR5sY9yZf/74mTOjP3UY8QT/dNiAAANIAAAATqJkwgP71ZAAAA0gAAABBSYUio6CPIjHGJLKVDypDZepx0IyUGhRMALfQ63oxN4d1MbLLTDq1ZbAzN9PMM3wlsjMhjoQwPI3xMS/GADNhj2UwfkQWMKEJxjFvAUswgAM4NPBDljBcQIYwIkYFMI5EaTB+QjcwmIATMHyBWTCOg+Ewv8MMMQhA3jGXRAcwXcb3MKWEXzN+QY4w6QlcMSPCfDE5Aq0wtILzAQHSYp+A3mAtgORgcIPOYMCBGmBygCgthnQiQ1hmKlR4Zeac0mQrxu6sYg8GEhx6ZGBX81wrMcOjPhsxQuCwGY0pmcxHCdGCeAoSDyxhCBkjh2hAtXNA4N0DMjWB2wVdEVAyJcxIsz6YxZI1S47RAx7IxwAAjDDRQxMpyCQ5AdMsde0xRBZIkAMqCFRReGAzQmjGEwxS0ADVAsAi5kEB0yR0NoXfFgALKAyAtMcGAIiKmTRlRCDNOFMoAMMAWsCwQXGI+DzYGoAEFB4oLCgUMT5ZGu0FByU8ZAILAw4guc0TQxYFrBlSZhDBuwpgghlSJAVMqoJCRmZRIOEQxEhBQLFDDIwsDDpYGjg4uDUgsmBQhTMGCQw2moq8wAUrAsBUMBwFA0CgzDBltCoMxI8xYQwIR0TDEX0MmFMiWAIYxAMGjQYOCBA8RbuWAqG6G4ygY2DhalUY1UwkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqBZZzBpQjkwlkEwNUzA+zDnAnowh099MaPCfTEfB3Iwj8IAMrVCYDCPAZ8wIoJyMKNAtTBpwbcwn8ZgMFNAgzAfwm4wC8CGME/A/zAFAHEwTUB7MA5AzDBcwN4wG0EAMLQCuzB8RXEwOYE7MTGA+DBxQkYwlUDUMJhB8jAqwaAwScIeMGdBdDCVwPEwVMDaMEGA1DAIARA4EgTfrlMdnI3AYjNbhMykA0MOjIo9Jh4YRCYUGRkYiAoLGM0yY7GRqIhGRT2ZwJ5ncthZCGbhuaRN5ig5GOgAZ1FJgkuGFQSYKCiDZgwIgomCBYKEmvWgRkbcEbRkIZpwTJlJRqn58Y4VZGQAmCRBWWYcAbA0VQIGFiyBc5QANEWCxcMdGqUGAQgJeDBxIHM2LKqkGggoIALU2BAwwchJDSBH8wIVjAkMNWHCoQxRJTdrRMNFSAkNMWbEBAyx0sEzOhSUCXIQKVtAQMFGjBBk2wsQEpBjVq6RoEIQiQxeMQEgADIgZIESpJAyEDSqrLFwprrYHpS8GcqYPoyBc64E5XaBwxT6ILs2Ue0kgwgDgJjBIJIP4LGjMhjGJkv1qriMOLC48GASzJALESYOEJwiMKCnD/++Jk5Qz+xmPFk/zVogAADSAAAAE8WZMQL/tpwAAANIAAAARCFMeDMAOAQQhQrlXBcDwHMDOCajK6kJMzXg8PMCOMOTjyTBA0JYyxMorMtDG3A+0zUYiiMNwD2TACdkNc9C007BNjsiZmNMAf0wbxlzFdHwMAcQU0RxVzIkKhMhE3gwyRuTEOJaMnlj4z1KNzGOQqMmlTUyZSlTK4CCMi8eYwACaTGOTANH0JEzwCCjF7F7MXILMx+ghzEoIoMLoTswyASzEZDzMGMCswoQs2kmDiAqbbLghTPVgTOAk4XKNycQbZGbFhsg0XvM/AzA0ooUDDIAwY/NaGDaTY1xzMsbzPkg0UmMsHyUqJQ0yoOJUowU1AJSb0VGQuBqhiYYBGrgAjHwUDiU+DiAGH5hAQaSljKKaeCGEC5pyEIR4zUfEYygAJB4wwFMwNAMyESiTCRj4sYYKig8Ai4woNTOL9GMlJhoQKhxhICYEIAAgCoCFxYGBowOo2AYoSeBgaAAcx8FGAUykIQQjAMssysPCwOTFwgHkrjBE54QUiFtmvvgNBST5MHlpR4fBwqFz4u2iWXJAweOhoCE44YICGIBkbDAAFCBgACFgNqMYRCMAEzFRMQi44FK4X0WAkSISACMAIQaGFv1GDBBIdATJhwZHisCTsBo0DBwmPQcQiEbJgl+ygkBgCHJCXbRAEEGGi4sPprMd1nepMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMGPBfDIgQPw4kQZzMcnPGzmMDjAzF1lOMOWB4jK9A3AwUYyNMErGsAYACmVYg8ZgwIhQYN0CnmLHAN5hEwLMYb6EBmChhJwGG9zEJQBkwd8XkME1BujFhwlUxLUbRMKOPtzFjg0kwQMVuMKpGTzCrwlcw6oC2MN0DUjAdBSYxecAIMFDDlzAYAwMwKQHlMB7BaTQNdPpXU8FITtjfMAis2SWDTKoMwqI0w9zKhlCIgbRBpoN5GyQMYaJxmcymoAsYfKhoMCGXy0aBNAjK5iYgmri6ZiCxkgdGUDKmIY5GhgEQBkEz6UwB02AkwhE0pYx6kRBj3ZTmDTQFTBKGAGNNGyGmIfhDEx5IGzDLvBWQARhiUIWYGlbGJLAUMo1eM4XCpk2hMwQBVFPMyo8xZBEZSA0ICg4AgHkLcDQsLBx0qaYC8TETFBVXlw2jkylI4GDQ4ECkSCo0ZT3HgxlVQwOHERlypoACPBaMtMs4viEIR4KvEQFEfkGxARBIcirJkjBYuuSBDNmwccQrMgDUreiLJ9qyF+TGHSZ4IwBkARjQilghAmGMBC57gckLnGBAl3FUQYGBRFDmXhYeZEWkKBjKdaegcFaOUAU//vgZOQP/qtlQ4P81aAAAA0gAAABPHGXEA/zVogAADSAAAAEigQBL4jS8tjEoThX+wYI8HCmRXJOxkhhVwY0KS/GPjIF5klzQ2YY4ZvGMkAaxmqY+4Yd6IAGGPA1JktYJUYVoDXmZ3gXRiXwEoYnqBQmATgLxgWYHCYeqD1mHbAqZgkYHyYYED3mOOgsBi7gMwYOOcUmKRBQxjbwgGYgsFnmDJgZRhpgLKYkCFTmEpC6hhSIZWYgaD0GEhAUBgcYNaYDUCQHGGKarb5mBoGKAwbRDZhZUmMQIZeE5mgImZx4akMxoUUg0uGBhEZESRhdrmiRYLMYygNjKyaMlAUoY5kQ/DxbMZCk16MzW6vMGHgxGNRASBEZMTIM8BOWcAWkKgDFnDAFDZgSwGARM0BAQmzMRjDljQITKjjIEwicapqTQwMwOmvQbL0LPNEkNi3MWBMoGEAgGOwEtMSUZABgARDDjZrABgVapiwAIBpjARdULrCqZMECEAMvUFw6GACLQQCrggGplggobNGYQOY0oZYWgeWqIigkZBBkBVTOBwxGkwChawCihlQpMLHCy4A4iYYEgDYA0cDGBZeITAYDGBpghAiFmRSggA2YAhRUIpsre2NOIkBl/B0uWRJm5i0YAKK0lswc/L3PeaMGDhAoCEYUcBBDgwZRHMRAjGAQuUGg0CIcHVCCaKIYUBIVWNmbbxyP1I9MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMNAzAyfxGz45amM+paA58mpDLV2iMktP43iicDgqEKMac5EwFDgTKfDCMhclEwthIjOaDDMbAbgw2RijEYAHMZsN8x/RGTF9F3MHApcwUBgDPDDWMRticyjhojP7EVMMkpIw8gzjIaCQMVwNIGlDGJAGaYxQpRibhYGJME+YBwg5hQBYmC+DMYhYK5gLhSmBQAqYRIBRg3hAmDCDaYVQIBgzBiGDcEYYRAIBgcA4DgJRg0AlmDIAkYKITRgjAJGCSEQRAlmFIAqYCgNxgXgjGDIByGCCGCCD0mGYL4CRgjgwmAcBuJAXg4CcCgRoGiwMYhAMfYEAHhgABEAOIwCy+6m6rUbgcAQuVl8NF2zABAHGAETABADFgPQIA0YE4BBgCATmA4AGYAYAwcCMIgHSgA0BAWgQAgEAPBwCpgHADGAUAg1gwFACjAGACLXmAGAIMAFoNlllqkQBo4ANPO8jexWRInsNRKLol7Ud2mF4UEyTYoALEUBRbkwCwCFBUtUanvXKGAEvQwMutTAQA8EACCMAxE8WAhCAFAYAQ6AcAEX1RxQlCQAS4VNGMICx4AdAss/FRoAJReZXUnYQAAK9gVyigAJjYUADR6eRbDxKXMpanIJ9MZtW//viZOuAD0VlxoV7wAIAAA0goAABO/2XIDnvAAgAADSDAAAAXUCZLT3aDgAZenM6lBLbWRtIAAJlSOEHCDVaYFhgxx+JNGqaw2cA33pxEFTmJOGqYQ6lpmwIHGjKB+Y2hNZjnF2mEcE8ZWpIRhigbmX4EwFQsjEIBwMdgwkxAQ5TILGXMRgf8x5hGTWUGCMAAIcyUQQjHZDVMV0NMwmxGzNrQsMYUD0xNCbjH0HRMJUOQw3QPjAZBPMIQD8xEwvw4VIwBwLjGpBAMOkLwwqQjjBhC+MAcBYRgnGCeEoFATzBUAzMBsC0wCQYzBJAHMHQE4DA0GB4EOYNwEJgMALmBYBOYFgBpgfAsmAaAATAGmBAA7A6OoAAQR0IgSFBTAiAmMCABQwLgKTAHAaMAUA0wIgRwKA4CAJxAAMBgAVyg4BkKAEGAiA4YB4FQcBIXUFAAFgDAbAPCoAYYAcYFAGIVAMC4BBgGgMAIAFYhAAECAB0tAaAUw0DAQiQBLH2ir4MAIAQWADUVFgBAgAFWJmSXKXohABYql6EAEqYtBbuYAgCIOAFRca8RAIJPFsn2R7MAMAAwAQBn9TsgJlBfl0X+k6gsBqGrKak7D/Fm1ZnRZUi6WlTSWYWhWQ6aEDG2qF7lDk8EvW4w8zKcpLTftGay/UefyQtuwNxkc26xe9iFwDi4KAGLJEOIIAAWlIzFxgwBJM9U3VVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAILkmEILRlVEbmdgXqYmpHJsJkkGbcm8YUY3BiGBdmPSLQYTAnRhFB8mHQCUYSoVBhikTmAsAKYEYEYQEQYDYSBQXRlWPpEXpiyUBokK5mAhBgfNooWQqnpj+Ypg+FoQvRjcJZiqlxm8NplmKBgqDpgeDBgyAhg2EZgcAgCEZFYwBAIuCQgEGA8yoAAiAQWVtEQBAYCxoEAMDQqAaxiEBFNwAAJMAQiA0dAJTUSACHR0DBICUPiIA1+IxEAClUBk6BYHy/pcpeaii73XBwHkAEBQGUWC1afIVAgiClOZTdOIFASQgJDqOgVAVc6FSpSwCawCEtrg0CSDqICANnQYCDKYGYOhKLqICEJ0eQEPKz1St+12pUqWqwt9it8ZAIuStQvZDWBMA0NozqiV6hIWW9EPOEDABLaRRqrQlTK0JNlxnyFQAeFfCz2YvcmSmiqi1pbgVASblEDysLgOiYzNCUHAIWVSWStTkIQCKAHlqK5cN/gaAwyA6AUtkv/74mS9jPxnZcofe6ACAAANIOAAATvpnw4P81aAAAA0gAAABJUWyZeXdU1L9KleKkqyun0AZmBLhDJl8on0bYwRbmUinV5kywlSa9am8mMNmaZlegLeZ8oFYGLZiapiPgkOZGEDLGE6AM5kzYX2YnuD5mIjhLxgwoSIYDyF1BUFkMNcFODAEBCAwNERiMABCLTD9x7MwK86lMAcDLzKLRBYxBoJlMDvA5TC9QUYw60LUMLfCADFgAvUxFYDAMCGBljASAWQwdMEBDlcYyogNaBh4ZGPTOYeUpkAvGZjcaHT4oix5WmUIEauHxhoWGL5aabnZ0NYmTEGY/c5r98mvz+YXLRmaTGmJUacERnpWmKmcZwShrgNGnBCYmqCw5oxZrYRyaB3op3H5E7OqKPqVA240C0faGuSGHznQbnyWGIdGzXA7kAi4JHmVMmoNGOIGJrmLkmvYtDAiw0lY0iwzIYQKDTNjpGDVASYKDRoACgoaY1COixqgOFDBnDAlDOixluY0e5REHAAEOAjAYQAAweX1DiQCAGQLCzo15NNMBJVokIYRgmYDApmwkGSvLmuS0FFuJBCMUUyYwhIhBDg4IMkp0wgh5RGlAKUSFolqbAIoLQCQ2oSkIYQw0BUjO3WbiAhylzPzKBSEqFEK7U8UAETa4MBjFC1V0YVzF7EBoBCgEDFHQbmACRdghDMlsvDI6atYvXtKkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwYQRpMVSNeDI8zl4xP8xjMrPE9jUWClwwsE/TMNaCdjDzxe8wlAPnMIrA2DGxgaAwhkNdMSkB+DDTQT0wlgCYMBWBJwYDcGAhA8xgwwRmYLCGEGDwA/hiiIFAYuMI3GFbGGJhuYTGYwcE1GA3ByRgVIUaYBsBYGGvA45gvIhCYcABpGEjAqJgVIKuYCyAImA5gJpvRWqoBCxNbmEwrGjATJMJDE0IHDSglMXtU4wjjHp5M0qgYBBWrzQxeMbPM1iDDN6INHJUw2bQkUmEkqYXXw0HjYLIMZlE0YDDJoFMCIo3cc4No4BMHlzGHDEtAKzM6kGIo4AP8jMDlM1qMsNN8zZ2awmaEGaJ0DqZkYAGOjWo34UGKDOiQoYCi0MBm4LoBwYEdEmYjQsQBDZgise4Q8CeEEgmCKArkaWqkBgA0DMcDIQCWoUCGMKoil6QyWFiS81omlIDw0WDpeCoklBAwyTGjJlQEEQDoQDoMVIEA0xY8zxJ4RQWFiwwHAQJzRJOioSjQwqVkTHiEQwsiAh0aFv6LDwQHElhghaj/++JkzoD/IGfEi/zVpAAADSAAAAE1RZMhT3NNCAAANIAAAAQgcNSDTEMWBZg14OGGREmTCgYAYJSYhKQkzGEBYEWbAJQqiCACYsc0khEgZWLUhYCZM6DAgoABwhIElBBgNrMFyGC7Mpv4WgICAAKktuMBUTwwjipziVWKM3Y9s7ij/jShE0MewQQwLQLDJ/HIMNIYIwThEDJWATMP4LAy9gjjBpC2MViI1MOzWE8M1qM4qBDE5VNFvU3vZj9ujNLKo5+WzCCtMiwAEkk2UYhLxGuOqaHPRscjmNAmZDMhggTHbUGkOgbwYswqYxztWwaNm3hGrInYqmRgB3syi9DscFwQvQM6M9XNEECIxZYygcwwoWHGMShQGXQS+ScdowokviYoMY0srCHETAkzUnCg0iqABplywGNg4eYhGigZcEQBTGAzMmAcONA1HSacIBHF9QwaYkQGDjBGwYkOI3BiorimgEkxAGjDBjRYKzYBKR4wEIIiyMwRQFJQqALsqLiwABFggyX8TtJDwBDggQLCVJtlJgCBQqCFghlC4kOGB4gDGfGmoQkhIEiw7ikUZ42InhkQBiEIwcR5EQkApi/RWNCCJgRYUIF9iUYkWh+iusZPByTAEkAI4CXYVAQkMLTCQMSHGGHluDFliqPHEFdPeNkyFXA6BB0UyoUwgJr5mJ4GPmOGgkckyOHlbgUFa+qSUWqTslVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAllzBBgmIyeUrRMrXSkTI6CpMzM5D7Ml4DITGOSoMwVAAaMpyEBzCyweIwOEVgMRCA0TC4RLwxDcAYMJ9CsjBfQIcwsMHAMImDxjAKQWYxPQIsMSUBCTETA/cwiUFqMQTDDDADwYAwdcEQPDWSB1Ym/YGnfyWm4ShmlQZme48GIqWGVZGGIoBmEQJGRhVgoQBkEzB0KQaFwoJJhAHJiECYUAC48dSjXA06o54I99QCkgdmEa8/v5H85a4QQRGEAgQxbkz65UhkxBxjIqUEkzCwYAMIdApUyA8wIACADajzCrnFdEaugY4WjaSMhxAMAIcIEAJmPCDNFRoCGCxIoVAiOA6NBwQHkgheZs0SHjWpjUDxkYpIFTEBpZk2YULjAMELYhhYxC4wYZMM1hUKqENRwW12cbOzJrQGBAJWIx4iHMyBCBf5kEgEhBj0LlwEAMUMEkDsGVLAZ8LCyIUAAocYQxGCKEseZGQEhB9iAqNbdhYCSEwAxgcZLGABrvKBQYLNYYMOHMaIAJdKsYIiIEbo4LVyq+EYQxaUx1UxR8DNX+QDAEgZMiYYQHESAgISQy//viZNgM/l9mw5P91KAAAA0gAAABOq2bBA/3UsAAADSAAAAEQESwygcyCYxotx1+mUJmSHrMcaiqtfa20hckHGCPhWxqEQ++fp1Dmma4oWJj+T18ZZqHhGZAEmpkDIaEZ/2NEmADBoJhSJMoYJEHYg4OCNUbI2jDNwh8FFxRiKQNcY3OLPGGShrpjGQJaYRGLMGEKimxjEoNMYgsJDmCABexgiwT2YQsccthUa2tYa0oqbNzMZxIwGC2YZoGYPC0GGEZdD8QEQY1gkYfF4YfEIYiA8AQ/MKhVMJBPMBAsMGg+MIgEM7wOGjCMTw5MBQXMBwXBowIpmvQBVwaleZkOgAMgHNWPAx80ZMBQjJyAavHrxhKhgERiqpvihfA3ZMKoTVVBA1A+w1QcdDFuzAozSLDPhG7mHCBUYstnAMIL1RHCIBQSM2cAJAKHDtgwxCMgjKATDnRZGdgsYYKh+FiRqSwlMM0OJSpgiwhMgoMBBYYXR9MOTJBpjWCIBpR4sDjoCUApA0kPHjRwtIQGAEWMaqNkSByMrLBQmKAzKhFfkLNCWFwBiSxiCJQqMgeOSbMkKR9MtCIEZeAMKGPIglcPDDQjmyDiQMSINhB8sobcWaEKaFubsMAjyG4XPhgQypYorlvTIpjKDUFBkVdMiqLrigYzoIxoQmDmPHorqAkIoDMhptFUJLhhgtwKnNsBU7W1I53//qVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUlRBMCwAcjA3TXg2AR2WMnpMrjaRFT0w+wDaMNDOoDEbQv0weseKMGKBcDBfBPAxEkGEMGlI7zDMxnIwe8EzMF5BdDBwwMIwIsFFMGXAqDBIAiERAChgz4IoYemA/GAxAKBg1YD0YF0AxnAD5tzEYC2HrOZhZMewKmbhZgTucKZGHsJO4DBOa8NnGsQVkzAyY5pKHoMiEjISU0NdMQLjjC8x0WMQDzB1IwQBBImUDwsuGQYGfmRRGYSGQHGULmFPiYADCjZJTOKTIrjEHkEhELB1oBXTtIjaGDJkzMEIAMgjNrMOaUMqLGgZghBmgACShi5aSXQKJBUyumbNEKMaHeONFAYx7MxSpBEKgTR9jTuzMETFqgvCGCJlD5mBppQYOGgkUYw4CC5tBZkgBCqITpf0FAjNgwssAyBO5JgkLmlDA5UhsasoAToOZF1QczEQJrRkQYBRp3A4OOJAUVamMAUOBlw5nySkmkip0ebIJgMNSYMMKDiI0FAQgxI8xQQOBMfZACCBl2iCdOlQQkCgA0DTQOHnHBA4cawSBjLCzOHk/TGP/74mTRjP5hZsIT+9SwAAANIAAAATkBnQpP902AAAA0gAAABIDGjiIwLGDHJTErQY9A04Ljk4yEODkaAMECEqTDGkSafDB0n2WuOgVvjDKRgqwkSZHulvG5Zq2hlXwwkbiSMIGDrg3BhFJaSYX2CxGXIB65hRINEYGQILGJSgNBhzwGUZmgIUGCxAchh8EJlkx5nAs5tqHZi4Nxiqgpi85h4qDoUIAwxNQwmDkwlEQx6F8xjF0wQFgxrXkxYAEwfHkw0HwwDCwwyCsRCOUC0YLhckaIhyd4wbDkwIGQYCAwEDcICdYAy1B5ggFBIeAUwDCAIDocBhEZQ0wI4w4VG0IxApiIVJiz5giI8zM+MNImOa4Bh4mbGWMmKaBWqDBBnhphhIUbmfMslDCRMDMVODEotmKySHcOKAqmZUwYOkIC4gPiJeNDwczUOGtZpVJhiZmBSFhxAZFNFDBrzIMQkB80xQxoAyZEwgYsoYgOasmHJAMNThEAMYGM/NkRAQIQHQUaBDozIkKCwEnMMPMGVMcKMYMLggwEYUiakoCTyDic4sbOAbMoFMIKEQJi5cocEqDMbSZZyguPFBoaoguVP4EBCyYgKrUFjapwszMWMGmaGaiQyELNGgVGdKGUCGZDmtdhxMzQscMkhUaVl7gdMKgszYQxDA/74FEDIli+iaIUQAIUISRpwoRbHAL+W6kefxhyNy3tqkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqooZCMIqEHjL5igE3y1DpMw2HGzT3iZIw4ARPMYcFQDD9QzQyrET3MEpBBTBYwmYxScDrMLjEEjFAhRkw1YGWMFaALTA1gYgwJsC8MBUA6jAWAeMwBkETMBGBQhIfqMAAAIDATAL0wBwAlBwQcsHmtM4RFHgPZghCbM7mWC400GLs5v4UBBYy49SYMzCjVGIBFRkDCIwg1kUTrMrBzRjA4U1MqJwchGQgpgoqBAEINwAOA4oTwXYFgwCBZhAOZKFBUTS6DA9CIu2AQI2MRMZHaQaOgUNmSB7YCyCQCQwOCgACmrPqcIdJIRgoaMdDjDyIy0bMnEgsIFmhGAGRmQ4KmRooqhjouTB5hwsFwwDBBo4oBgcFAZgQSYQEIGg4HGA0eSRoXHiFYqnyyxZQkHRZAUbcgtgbrYBKFQDgJSCEgxCIGQgFU29wImW1NAoeXTxjgVRGjC4o+mzsDTvoGKFHYyOPKGOEO0P0jWlmuYmHaQrCBrEO5ruixYYIW0EYxgnGAeZYBZgSKPQUAqBOJe0JKDnh7EGyHAGchg44b/++JkzYj+EmdCk/vM8AAADSAAAAE5VZsKz+9SwAAANIAAAASopoLhyRjBntecggUMSbCgQJSAgoiJLBQc6MCgYNYjatMQXUBUVsdINSDGKNi4hmSaX6ZgI1lmNHiZZoVZn+YEEK4GKHi8Bgr4VOYCSMtGD0BXpgKoK0YZOCcGEaCYxkuorqYJWC0mHlg+phGIG8IwUAwHUAvMBPAljBaQH4wSkBgMPvAMjAegQgwDwBeMAiAFjWAgzg4FXwwdsNQDTizgA6BkCKkGglB3mDDgIPgcdGqlxrY8Y8xgr8NnLRRNICExZDODK0RzSS8wEsMOPzDSwwcZOkIPOWNkPJihm8Bql4YsAyIxsgy6E4bc9x41FszqoxlEHqTVBjBsAdaMq0ETUww0z+gmyGROm/Oj1846WgNgCOEMDgRhQCQaFBhyBUIg1KMjCAGkeCgxgkpQTLkGRUDqo1LUSZBcWOhCAQn+Z0WgKEQ4kHrHZwCqZAARjMArShQoEKJOdkI0cEtAhJmUdwIIBQBDgYwLUjJQlTGKFCTZMFagkjYkj+YEACjpUGBBAofio5D4y4wyYlJY1J8xA4qhiwbDDaJxkQxlm5nAoiDmRNqAtPMkSYcYsch+CnABCjSkRLziBS+AJaFEIAFUcCb2aaMcdUAUBmVhoSQVKmpsmrFB1ULDjOhgSDmX8NAGMAYBU5AovdHEYV+w8hKUHkdMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUX5WMBFDyTK2iVo3BwYEM57ExTI/EVwwFMTpMHcGxTCjQPMyXYCvMLxBBTCsQFkwkYLSMD7E+THjQWgwcME/NdtqNzkvMOg8M2igMOjVMHCEMYS/OSR0MPxyMmAwNTyhCpDAQCTEsHjEwEDGwzDdwjq0DYsDOtzHjxP+IpgZ/aGOuWjlnAcHMBQMAvBToywA7igxqc2Yc0pUv6pkVWhqUhghJx6p3NxlHRm6xjywKfHLZmARmMlnX8GFCmgFGMLlDszTUAGi94qqMCWMAnNH7AZAEMQerVOZoYAhpp2BkxJnlhhQhlWIXfhQCZ48QDHoMEUMWBMoDAIkSJA4wZISDTQ0wFF8CizVEEOHGdGjiQyw4kKjgUDFwqACqQx40t8Y1gZESaAOYgOimFWD3kIkIMhhExokyglHgUEmMIgAojQBDrHANKJBig7qmDFEz0tAVA5owIXVAwCABgGGiFOABCETZBATKqYwgQIXAUQAGL+mPclBkxgMygFhxhzSl6SSXwcaJnBjKQkeL6GPBmaJmHIiIGYooIBplDJgApmSoGNGUOrZTdUqOEBUPIgiTxZkzw//viZNiM/f1mwxP90zAAAA0gAAABPGWbBk/3bMAAADSAAAAE4ywmCl9LGTBSonVbGdUaLIMYL+GgmAomyJjgEn8Zo6WeGp3MzZi9wp6YrOHNGRdgkxnj4GoYrGDeGVRgn5lNJLSYS8WNmH5CDpiJYGEY2iWc9NEa8CAaEmIZcAQaDJoZ7ImcVsgY8kQYCuWYOK6aCgGAB/MDBjMJh5MZxUIwUwC4OHBTLm1vDHFIBF5tpuZejGEEzTTMx4aDCsSNsGAAVEzSbKSgk6MvJDBj4QCRjxMYEfiFEHhgxhaOiUTnFIu+cUemipBs4aaAGCxya4KmboRZQwAZCCox86MvTxEOmwBBjBuDAcQqxvgKFyUanhw1Gi4w0EQABisSgw8JhC2VhxkQsY6DiRYMCAhSyU0M4UTIgM0EYMNAysaMYMzJDQ2EmVlGikv+YQRGEoAGHAUAGSB4IEjKicwsfFDEy4CCoIYoAtzMCRTHwMDTwBNxoPMCBw4YC4oEBxgQi/yT4QLGDFQQUigSDiY0QKBzIYiepDhDCZwHmQCYADQzaMNJAqBGaKZMjo/qakA2IBpPEKsIFDDDgM0ESMFJDCDYwwkFiMw8HHgMRBZh4UuglLRICTRJjs144MrYzJy8yMZCC8mM0jzdTM5gZQPMBSTGDaXqZKJF3yyBp5UYaHDQgHBhlgkIEsxwUJjKIDQYuBC1GgZBE+aNTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMGNBtDE5Z/Q2SGEWMEBCUTghVnQxBscdNOLHdTPoi1QwtAn/MIPFEzGlyuAwx8WBMl1C6zNKBA8wf8M5OgHsMdo/MwZaNPi6ORHBM4zWNEizORQtMcVROaQoMVmIBLCmSAoGTZZGAg/mUAomNQXAAJTGELzBsGDFYJjFQHjAMaQQQhjABhgcDBhWAQGGkmLgWCUBIIYmgUSBcYYCoAhRMGg2MPAzBwaGN4UhgLmnVmiTiqg3C4QiDUDhgGIQoMAGWDgV0VYpojy9SICOAwKZNIQNMIJE5thhkToUUBWSac4DpBiAgCqGYQmmXmFFrsTfEjAXGFEg2ZM3B4GqwIbFLpgiRhJ5k0xhSBnwZmiB8jYCriAOWmFARiFhrBRnApQlBI80JIyRUITmGgGGbhcIaYAX4MYeO2NFjRljBmkgsKFgxiT6UJgwA4KNoCAo87jIxrEDBwMGAa42JIa6mURBwoaFmFcGWOmWHCTMHHQAdMcmNeJMKHMKhU6BXk0DAyCkFJzQHRpeYQsRRy3DRiY6DkZkjICChDwQmTFgU7QCNGkBtGRoj5tQQ1OAQ8yA8Bbk1TKFRYyXPMGFAxYDXDOgif/74mTgD/7JZsED/dNgAAANIAAAATsVmwIP902AAAA0gAAABBWQDQIGAIMyqwxY8maprv+r10muQWo8pdkYF0PwGDldEZpL8U8cUaoAm97QKJl4JjqbkaSEmqMn8ZmdTWaY6SbWmb+I55iyoO0ZcuDJGJtgaJiJQEof1GIYRAscTjceiHEcLyYb3nuaB1CYrZqbIF0ZGksckF+bqFAZTIAZqGcYnAiYioMYIEOZKlOYWj8YsisYWjMYwB8FBzAxUGCQhmLwZmCIUkgimGAKGLYqGJYXlQMy+hjmBxkEI5hoQBhmFYgCExcAIwYCcw6sxx8SBAgAPmzPdjKkjYFQpGMEaNm9DRhv0YFJnDChUqKticIENDgkjRsxk8fNyYACYeqJEDmrQGrDv5qsIRWNCBFAhkR4cSNuKOTELfIcTLuQ7McEKNJSbwYYiYAaCg544ZkmxjD4WhHLSiwMlFCp0100xeAykk0B8xIswYc1IsPHgxUawOakicVShUY0GZ9KPBVRG+HgcKJNRSOWrb0wDky4wOMDyY0BgCAziGxJyGRS2AMEGlinFMoSREHNERMomFDpnUgcFBokwQIUflVabFaWHBuJotZMEBMCXMeVN2hM2NOOPZARWTLiBrmYoSNDhGFCOBlRCsAlCQOOu3RzNIGBiplwOZijdE0cig6GMPgVCQTGYNGRWkzQyAMuFKZC9LuMGjTs8UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVaZXMJDCgDGpGOoxe0rENxxJgjAj0dox9UjbMTFJKjHwjjcw/MW1M4LB/DBbg4Aw3sB9MRIDEDAvQGswdYDmMBjBggqDomGEgp5z9XmuIEcZTxmlOgFrHVEAZUgpg0kGew8c9jJj5GDyRABXCrk5AAODBsw0K0EBDGCzN8wMDQXDpRoMwjAndGJHlRkaYKZWGfIObZYa8qHbAoTHmJvW5hXIcNMCQMKBHriPgGeGsSiyU0DU5hheA4HMYHW+GTA4wHIgISAh8JDmcbtPEIExyICmkvjLtxJgadCPJzGxTClwupHo5MxGmYIHBhsrFpBF/hgAl0gOMAZCpcFqGGnLEmIBhYWKpzGDhJuZYAqA1iwMDiQyGwADHRZoAQEIJGlQAIyaxlriJCvwIKBA4GAwUxBosQGzLkTELiYaRDgUoQHtxedYURkAsYSlTjYouQgBpLGCYCEQQik2yIACmCO4BHEwFqEBGbHCxg2RcBagyUKgjBg6cw6k70MGoQu7MwDBAsvqDA5mT5mVxgHRhXpt3psgBgTZshxvjplQ4OJmL/++Jkzwz9i2RDE/zTogAADSAAAAE71Y8GD/NUwAAANIAAAARAmdPmDJAgEl+Iha3l1I4PJXRgxg1gt2ZkywfmREwT5/kJtUZtwownqeXChlkAkKYrUXaGVHilJjdJHuYjmH6GJAgzBi4I+GYwMQQGLyAupg8xg0ZX4ePmdtgtRgMAeyYPQBDmDuAtxgBAD4YmKFomBfAyoyCVmAjgyhgBgU4YQAKDGCZhUJgSoA+YFMEUH5r4bynxjwzmqkebrLZowrmsC6JRE623THQ9Mvj8yyujfASAxoMuh1MAx0cjGwOBSINoF4yUCjHIRBJPMyAIxESiQMmRxaYhG4CNYkGjGSeM3CoxuOwEllFDDwXGIRkBQQRN+7NGGMUGCrQYBiGabcabNUXUHDJmCSm5hwoQVFTwkgHKy5QKlMemFSRmDiGRj2RmxYoVMSeNwJBVQ04ExBdAcGiQmqGKASyGIBAsApM0rUyaIRlQodNWaAjIwAYWamPJmBOmBaAJoDQ5mixkiYKhucBTQFFGMRAUoZcccJWDjiAg2QI6IQyoI2A9nYOLJBDK0INmLAmgIGhVCAcYgFAYFJhBoINIeGZKmPACwoQiTgCivQAn5edKw2hYaDCgMQBBI6YM8HLxGORFIAphApjzIWBDo4dCsZUsCgUwCAKKgcPMCEBT0wwcuLGH3NTBMeFMmKLmqAtzZUsRibehxH///+5MQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTB9g9YzZQ1YMFtaeTIeUTA5rMF5OiZN0TL9gKMxhMisMAfGCjI7j/wxA0G0ME6EFDBJRwg1oAGfMD7B6zELxe0xtpWWMHnAnzBSwLQwtoITMDiAozBiAjUxM8BbMDvASzBbQf4wa0IMKwbMwX0VWMFECKjB+QK4wG8B5OdIs181za1RN6OEAIozUeTNCdNqMMrdoVLZlVJGzSsY6GAUFBlUOGSQcYbJRg84AgTgpCmPhyZgJZigYmQx+ZMEJh4ImJBKAASYBGRisOApTGIguQjgx2FjGpkIQcWAzoZPAUAGgZI1hDmBFVQhMiXAx4oGn83oCsQDA5s86mPw2WdCgpHAI2ShgzDQtuGZHCgasxIkI0QY0acxkgE1hjwrVEEQXdKGCZMydFjm0Wr80zhGAZphipHFiBGDHAM0sCAICSwKb5pximzChmlYMCAg8QwAvtL5LUi2Mpot6wljQVlSgEA4WLJpzIYIpQuSYgYEMJgBUBIYBPInoMqMkcxi2orIxIMFzAuOMgm0ikQoia4BYCBUzD1ExAmChAxY6TDCKMBBWM1BgSkRKGwaaZLAH0WS//vgZNeM/gBkQoP8zTAAAA0gAAABO+WPCk/3VIAAADSAAAAEPTh15EoGKqQLeQA4LXFVp3IBlBMTABNjSXSI8w7uGPNnbR1TsslYw6y5GbM2DDuTFMw1cwIcUdMneLYDK4QsoxboCLMJ3J6jBdyNswJEHpMZUCUzMOQtkx64ItMGgDeDCyQJowDMAOMBJF7zEvQTAwo8CDMBJAvTA7wJowEoDCMF/AUjEdAKYwL0DlMCiAhDigGSoFqZhlqPhiGMpjeW4cURkcPxrGMZicQxhMGBjkXZocIxhcEAoJRhcDYGGExBIkw6FcwBJUwgHQwOB8lBwxDAUMygI4DOIGwGIdnNuklQ3YoFOgdjNYgIzBnAxgjJuhocRDO53RBgRJi8pkURjCgs6JAwyFMGrMkTM4NMgVME5MUuMAFHQ5jQZmEYJSmLijJBQwwTgLGjPpyN2YoEUJTYIzZljsLTWmywVOC2B48ECT1qVAhCaMkcQgCArbgUYz8SeGAOiSkgCp6wyYJSXfFXCJgJEF1x0YYIUVQygRmwRkghmAJplLiuOQAEOBKPMQUGQBmCAKMGGCqPhVOGF0BpoXpeoILCwUwYAoGFY8WRiEWLIk3y6qyhABMiKAx0EDURRoUQBzDMhGXBLALEzBhTBnTAOQoaMQqFgwGRg0MEOjAEgaFTDTWMM3B0IRLTHDDKPhYKkoDQb0Ru8D6m9ipMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAEwlARRMqeCdjHxHNU2IBreOThW5TbB3LAxx0ZmMNaINTBgRo8znEzeMIfHajARRcMwtwTYNP5EvjCVAl0wt8iwMhGOwzC3AhwwBIE/MPfERzBBQUAwUgY/Ok5iNCjrNIToMNDUMJGsMlLPO8ofM7VDMazjNPhoMAwsM3CyNEADMwieMcSBMNQHBgWmjoLmJo4mQIemKBdGTQ1iAiAMPBCAxYB4zqD0xxBAmAsHB+ZCAcYGAyTBaZZUaZIZYcGVQcQMISMgUBVAFOgU/DgAOkFUUas+BSJm2LfgVMCjJiTwOSBAAEKhYangFB7QhaEAAxgwxgzoCAjodQd6TDIxMWW1MCBRpFAIqMC5EwZMCLgohAzNKpoBgUogGy9P0LJ1Kw4CqFiyMqWY6MIYBgBhjxiSRMWHAi6QaMMwPEQowgct2wwtOWiApJEJ1gc8TDTjXkz0ZFJLq7EgiJReYy4EwIQmiAQUaIAkCYoGosSiSwbLCEKjCAWXGh8wwsssBhIjBCoJF0abgYOZwKEP1//viZMYO/kFmQwv91EAAAA0gAAABNrWZEA/3UQAAADSAAAAEYQAASADDAJTKLFUGY8yPCx00YQWTDl9GMCpcgpOZEWHCwQPTQEIBBUgCIDk9B4ujU1lPjTpyOA58///0mA7A3JlI4+cYtEMDH36C5JpoxksZG04smIAANpgvQIyYamALmQ4FjBgq4h0YGWBrmGOhsphjgx4YQ0G5mLDhxZhPApAYuGCdmAFBupga4DAYAkGYGAeCVZkcDZqdvB28G5tCkpmooBtbI510nBi0V5z6JJUNoyTPM1rGMyNCcwkJ0ynD8xhHQyvE8y7F0x9BgxQHgxNIAx5KceQowMDAwABAgCQwHKQxoBMwfDURg2YVCOYUC6YbhkY+IbnIYUgICZmoIYcVCBGZkRxIWMWFYaBBwCynMGv0DA5WDL/JWDgYt2CiYYlEmjZgYiEYkskBgRAQMAIEAcvuAiSBwoPMGJAwMeIq5SNQhMcEQLEhpgDBKLKxRIbEiTQhQIsGBjrPWkiRRQxJMu8Z0KDg7Y1AR4COg0F1cDARlqg40GZoGALZlAgMGBw1ngQQNAEIgwQXEizJFTo6O2ywkEJUAkQgaieWtS7JlIsJZOnMkOGFHhedX73qpEQJuYBFjwtVMmHR1AeYEoCi6Ty82PsDRYVwgGUAVwwtnDTAAGjRcVurLWRpqJzs1IgjhXV1v67MBunJHYZ///+mTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqABZTUMC2BljD9B4kwahKoMdAM7zBwg68w15K2MPECETAIQTAwmUBXMM1ERjBkAugwToHFMGuBhDGDgWEwO0BXOblbMZ/gM4USNCm8MLSGM1CZMZUXNUg3ML1tMQy1ND1mNG8pMmizNgCAOGH6MO0sNKBPNWiMMdU2MkD/MehGDA2NERIMNwFMPgkMLg0MQBKFAJMNQqBQQnCKGMSBlQS2HKdDqgxqQcFlnUvTFElgBhQIEo4NNKRBx5FUKgwNPHX6JZEHNCCA64ziA0UYtKFiY9KBw40CczR0xwAONtzDiDBGEhYEwIBAVVkLjOkwuCC5y2BlqCIMBkQwLEzBAyYcBERCVFRhg07Gkkl8sULAFCMHARZkgJCBQWCAo8GCAw6BSocLRFRRMeYUKYqacGYwGa4UUHhYEloFTAyUU7MeTU3BQhaDPxEJHkyuisSBAb+p7KBFUSjmvxQgxxIBCQEbSiIhzxgriq5EkQCA4AGMkNGVGOSRNGsvwgIa8Y9IpshxC4BDUWNgP/74mTDjP2uZsWb/dNQAAANIAAAAThlmxRP901AAAA0gAAABJ2g4DS5kVp0QoBPg48Z5CQsQSdB28WmIJnBUEL0O2ZQiFALLGBLoR1h10Wmr2g4AnvMAkCPjAGh6wwJg9+NuLAtzR0yDQyYdGtMECB/TCHQ4wwSsMAMANJgjGkBAEwigH1MBtB5DFAQ9kwLEHCOL+MPMYANFGgMMGnOEi4McVBNDFaNjhhM5y2MKSjNJVOOGFANip8OgurPTZTMmoECDYMOnMMWSLOiwpNDMeMmj4ExYNCUTMRxUMvANBoomQA4mEI0mJAbmnCHTdF7iAiYJCY4qY6qZguZ0WZkWYkWkuYoEZoYYoUn6Y9QYMYCnAyDBJc3JMwr4wNY3E4DSzjhBATFngGWAkOCqRjx5jzBmjhmC5jiwOiKyjJ8RGTMLRANDAoYoGQpMCAAgBDQsHCxcwQMxAcqqjXhA4iQrjYLyC8XSIoyW5iwCEAMFmZJG5AGEKGjGGSKGJFgb8CjSxUMC+Y6FRrasIRoQqL6GMGmNChQyYxmsww4MWDBYGNDDAhh4ImaoAj0gWmGZEYaIoQGoqUKhQOEAgoIKzYeAMEmBIkZCxUt0mkDRwWlGYFmrIGfIAQiY4AZksCQhMWASoUJGBAhYbGk3zKn7JgAMkKhQ1w0wztmCy0pCQokoIwQiAv0SoxoGjWGGwYeYVTPQ8lrHC/Vs0xBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMFkByDCNT6UxFVBsNalDLDqAGac2CZIIM27DvTFYRMUwi0RrMuiGdjvGQNMRMpQw2FhTr5cuMIYXozqKJTQa9jM/EaEGlEmMaEmZJoXpiolbGJIJeY4Quhj9G4GEAUsaIJWJhrQ1GFmDCcaylBlCG7GCGKMYzSOJjpnWmdyIcZ9Yj5jWngGIEVaYpBA5jSg2mQWCEYTwEYBDzMDsG4wwwXjAOQ5IoOiUDbL4zZwMaVDEy02xvBRoaYumPhhIdGpCJmQkdEpGKOxucEbgYm7hplZKYCfmFDBpasMExqR2YAVGuuQwsGIlAUF1qBhoY8OGPgZiRKYcMiIdImkx5KMhUDSycwQ9MgBiqGFYq4JlBAnKDkUQlQk9GHlJhyaBisSfAUECAeBSUCh0Ag7jkUEYeMhcKMSJhAIKHGBC8TJgZLUIVhIGFAauqmZuDmBj4YRqNoTjABtUpgIKYEAsMGi4wkfDkcoDgcG3zDAMxUABwsGCY6ElplSCwmIAoChQJBQENtLBxkX5C4IGFqgRg4VC2mr9TDEidDVko4L/++JkzQz+zGPDA/7acAAADSAAAAE2QY0Wb/dNSAAANIAAAATR1gRiocBg8gA1KBCADIOYqCNogIFBpOIGgTDSgFMJBR5FRSAwmiOIA8LhTPmhzCOLnGBBYjCDEhONw26E7f7AAQUXDA4wHYw4Qe8MQTFETcDSEc0ds1IM9ZCPTCOwXYwWYNZMCnAjTJYwzIxDYI9MGpAojBkgjsxkgLcME4AdzXzxD2bwDrMYTgk1jMcpTFEtDSaYDYsKDGIFzXVVjG8LTS1pDFzNDcSRz6POTFpnjec1jEm6jP9VTGUvjLqITSUlzj8TjIAaDN8HzPYcTDQazAQlSILDEgHjJLjRFDNKTMjQiSc3KaAibIeZgGMIDAMBE0DvwCRh4IyLgwiogNI2GIFCAAZcOY0UZtAY9EZcgHKiKKGFWSp1IyPAyQMHmPLBcSrMMlVLl2miiFwkDjDgCYa3EuitYIeMdLXiokSJmDDqPJCGGbG2MJ2AViZcSXAMGCAwszCYAGkdkq18KHGYBmBSBco7oIAIGqTSCcRVESCuMYwE08BAjDjQuBARxJESHEhYDCwqZSifdAaUAkNTJkjPNBIkXlQ4FnQYhBBN+FuoogEEBQrYxQCIk6gwQdYUGEACDSFYkJIFrlkhYgZM0zEy5QtEAnYsJAAFZpeYVDptI6kxUMBDAsRhiU8DBhWJBwNshjSJlEBpQIkOaay4LmVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBAYwIEK/MdbI4TECYac64E1UNAqJjTYlEGsxMoFaMHyD0DDsRJAyJYfWMlIBWzE3w6kwcgT8MjmCpzA3ARAwYsDmMWJJjDCbABcws4BEMJUBjjBpgJgwloSqMWzAazDHwmEwRkIkMLsBSjBQAY0wDwasMQ2AOzGKg4AwAcJcMTpBvDCQwUcwcYB/MSiBsjAdAeow3YCWPUfw78ujpJINOk403XzOSNAAOMzGE4OHjHhTMLDczG0BU7DVsU0MLkUOPYkeDAgcMWhswaSgEqyqGQQFjGgmMECYwcDDEoTKogMcJIxMTDBhvAIjMtigwkSyIXGAwGYRTIY7zNwKMfCgdBgqDESTOFjREwgAY4Kh8AE5cM1aBvCamZEGYACARyEIGQg6WBRgqJIQykx0aYUKKkU1TIijLNgdAXCDmIXIiRUusgcxlLsueOCAsjIh4CfgQKCppjB9GQFVsISwoaMSWQ7ssBAUuwTBbCF48CEAQDAF4hYOUCgEzHURcwGBTVjzIGTFBDItDJHTHDFkwovrJ3IW2VgS7qxYiY0qgPCCoXOERAdGIczADxlkUYDOjDGkyGIBBh//viZNqM/tBkQ5P81bIAAA0gAAABOZWZEE/7ScAAADSAAAAECdBwImCJ9DSQVDzpZwLCkTi+YWMsHVYuwvkLCCwpCwJV7u0/VAAAcwagIDMcyHkDG3HHE24ov2MEhQyzR+UnIxtwDUMIMExDAYA0kwQkfPOMwpwwIiQTHyOqN+0HUxOgNjDwPJMEGoMwthfzEQAHMGEIQwyAJDEJPWM9kLgxGBFDANJJMSgB0x6xnzF9F8MmYC02BSjzDcBKMqcOMy8hOTHKGSMugAUyAS7jCwBHM3wAowzwOTBnBIMGcB8wkhFzAUCbMOIF8KAYnrFHYlnB3mGFiJQYfoYNwIAw/MNQkN+IM8VMqOBJUxwBEcMaAq2dc2aQiYkYYRKbXwYRuZGQYUiaAOIhxCcNsrCGRxI5iyxhhoXbAJGVDZokRowZigw8HMIZBys0BckRAEUMnywWMCjMECDp5lAhqzScooDSxLzmGEhw8wRkFCzOGQcuIgYKMwElWDAwYaa6DBoUMggESEC/osLYEEBoYGg7cVOAKDHR6fRnwSDAOUiMEoOAhaVwkEkQsGXQXEJgpiDYkGBJAoUizFCQqk/xvwZesKDysWwl1RgOaEoYAwJDJAlMDg6syEkvcXHQRptr5DuqAIFIRREBXZtCpkTY01M29MYeQmiwAHHgCOLWiQpG9XQiCGRKI8lni2wFClDCWFAuxjbp2sUSTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqMGKA0TPexGky1JGzPuANLzFMrk4yzh4rMVpHKzErQxcx1oLFNG1CazJXBjAwVEEHM69xs7J2tjAxDZMloyQ2FmZjORJdMkUckxagJzBsHvMWk0kznRBDHMF7MbRCcwDApTPCQcMTtG05blPDaobiMJsgc4GxczO3PSMMMswwqyWzFjirMLwpYwTjzzCnG/GgMjGWFkME0QkwywWBYNAwDgsTBuCXMDACowbwEzDEBKMFwB8wcQsjAlBLJQFAEDeYKYERqSRpEx6fQ1VHjI3PALFLkwkwyIgLJQxSaEIZziTETJkDKKzZGAq/MXUh01QdoRlD5l4Byxg+LBAQ1SYzTBFQ1DExVAIbmVOGIHkCozJsIHMIAyEvyVASHAlOBiExq4QowzMJDVgjWnjOITbFQUlYiaAOCQAwBCwIcHIRiR4yAUcLhyZuIhAgpyFk5MlMiFABZCUGtiqTEYE0YBDAwYwxY0iQmIAhYmDjhgnRnlsgNSKBQ8DUxp6sGmEPCSEWEKFKQsCHjwkQNCMMW0MsWRHjwv/74mTJjP7nZcID/tLwAAANIAAAATT1lxpvdy2IAAA0gAAABMTag6oQAKBw0KAz1EozY8kBoCAYoMEXrmNAjIYzZMx4E1YgDBBqGjixwGBQhivYxwAw7RcA0gWm9AYDEQdbEQfiU94nc0X////eAm23KYFQaBpwDQmJIT4dLxCBmxbTmiJc0aMYZJAYuIhYDWwH/M84OowhAkDFcDLNCQV4xFAszLcajVXKjTorjGo8THQSjGUgDFdtyZvjNkDzAENzK0ajLZgTDKYzchJj3GkzHwgjhElzNQwzCUoDXVHzP4OAc5hwuP5hOR5hIERkiJYMAYwvAJA0GAOPDwYghQYNCSBQPLsiwHgEDhGB4MBYaGQDBAmgwJS34UBf9DI2R05yd0CPhGJiMmoMBKSi4LChxhlHAmYUDOQRGUERDYylwNHOAEGRGAUic0YZtCKAqqYI+zFKGtjGVEnEZQBAHKgaw5X0UBgo3BwEsaERghoOFUBRUBKBYsyySjwBFApROsxzwQYSllvhAWbIIiOMM0ABCgDIBVIywjHgAJYCTGlgUugiDNCUICLF4gSaGSqUGKiFyzFsJugQIXFUyQVQ+BzhkMhQEIqMBEDAjSTuJOjgZhqiQwGCYsQIpfA5MyUDZCA1pUlaQmcYcwwaYEINNPxMwkxGccaIkWnEmKWsYcAsUQQsy14EqBj6WoQyOhLGjHaBcqmQikxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAFApQwDsFUMnjGWjFQEpw4VIZQMh1HSjPl19swiYKKMJ+D1jChxEkwwk4xMs4WsWLsMLYgo3tjETNiEQMuwx8zUTFzPYEHMR4VowQgKjHLDAMKYhUyOQ8TF3F2MGwUww5RXzGJImMYZdEyzAhThEUiMeMhMy/xCzEkI6MK0GMz6w8jDxSmMNkucxXBPDFIB2MX0Ecw7QuDBBBcMEgBxMYGADmxZm9Mg5MaQeQhzbLhbqaU6asWcMuZsm4YVdGWoET0yI00a8GkQYGAx8iDBQgBqAIHm7kmPMhYma1Kl6quao0ZIYIx5lSKeJkFRjS5eoyA4zg4HAAwksOCoaMhYGjTMyRgqknZCE4NBmEDGMBGNIg5sYIgchkpSYFabEMqqArAGLBigUIByQx5kBKzFggYaDDAUBpAGbKGRCGOMG/MA4sZQuSB2/DBsvDjSEQhAmcEmaECMSBgUPDAAaVCS0xRkw6EzBs1IhXxWRirYTEkRJ8Y4CIAYOKMHMAfB0hC0xxoxJcMZjQICATNCTCjkglGzBjyzyoVBjcFDXlRAVOojAo5nCUZgTZkwgNDl5zMhzDRDb/++Jk2Yz+ymbEG/7ScAAADSAAAAE5eZsWb/c0wAAANIAAAAREEEgAIhhAGETPn4GMSAOQNKoAz8ULIRY+FBBZlKalQbKC7MB4RwAElN0wBYDUMWMHjTAi0r4zawtzMn8MxjKOiR4w8wFkMBBDuDByAJ8xccOhMHzBuzAuAAgwV0PCMOhCTzBKALYwcUNIMGSC1TAVQS8wEUCvMBqAZzAKgJQwAICHAAAwYUYCeGApgpBgTABwYUwAtjIYeYLkCbGEdiJZgK4F6czlka0q6ZTMKaqkYZFyOYtiqdrBOYpQAYXg0ZFCcYXhAYGgUYRAAVQYGg7MGwlGBPAQtgYDAEKZcAxAB4UA0wzCMxVAkwVCstkYQgELCmYPgAOgmYIBGAQECwAhUBxkAxUs31TJHOVUEnmUwAuAhRHkcATlL6joJWEYyRiInAEYdQgcCgy+BYltyQsHWIyg6QhULhCAwGAgQKHJWFQS3iHoUSL7LDrEM+UQBhHaAMmifgajAVYsaFhwhIsoAjlpIpoSRYkDPKkFnTAaLqhDpjOF5AqCW+O6kAhoKKLJ8AqQrCBAyl4oOYSYsmuhuhjCA6scDCpZdlEc1xASeIGCsUHFhyYMDElwCGATjkRWcLSjJAaIQBA8I+DzMhMoMxXzjMNLIjWZuKpDg4CGAyZuzkwAq6K5mCQUOJaGOSoECRgiwgSLhPoyGkTtaHA6tttMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgApG3TBbDUMW9Gox8Zaj9vOFOUuhk20SYzOGAnMVMKoxWBYjS0JrNiW3MXQ7MkFrPkSYNGA3MDWrMxucMaAnMNiTMix1MWimMGUjGR8MyizLJGVAmGhKVmPUNmLZ9nO1fGQzFmvIrmng5mShSmnwrGoi7mURpGmpVmQJeGQwqGPoOmHIRBgVGBoJJhg7gJNhVURBzNpjRngMaMikCFwsBSkMQFIRRkRQ0HC4VJhcYAHiIaYoCZAaFD5nBoLCGaPkIAwgI2AMwQsyQUIHAgCYUeYMKlWGEjCAgCwNCPBAY0YIzoRTBS9M9n5pQhUHGHIQOOEVUgwcWRQAhQAYswYEYTEUbmmgFMLPExS1pfB2i7rXjOETAi0OIkQL6JWrpJAYAHmIDpqv2rckYpzGDBAAUHUbRJTXLhgUY2sIGQwGNAokjTAYVNCEYs0mJNTgNkzhgwEyBSkFCUtndXUjjpJ0IBBYCNCERFLQ4MkwUCx0oPDi/Bih4ILLzBzE0YMKABRIaMiZUAG//viZMKM/TlmRxvd0nAAAA0gAAABOembCA/7ScAAADSAAAAEHDEIDBk0AQQHA1AWSMFJDwYFAxIEEi1ZeArA7rqPwqkEgBgJQLMYA6rJmOyhkZ8k5zIbXgpbGmFCvhmP43CYQKb3mBqjCZkFZlyb7okpqLiGmjy2+aqy9RsmBhGkQmUcQ8x5l0BumC+lgZTpdRllEpmLEaaYcg1xnUi6GFSMYZcgPBrlIEGWXieZfijJ16momOw+uYig0xiaqlGKgacbUgU5ohITGeIkuaRZvRhjgiGJ0MUYsgmhhChcGBYFSYZIVIjD3BiIiCAJgemsZOOaacdYsQsDHvjEoDEq0CjiiTiHzSjRhiY0+WnBokPHoTzAsTXqDMIwQkBTYieBlIywBC8xIUxIsIlGkSGFWBhsGgDUhAEKcUrEgpQFEYXKLbIuA4nMSTBwsDdh6Kus4JoZTIhGLYxckMEJsEkDFCCIaZEUPJgFQbAGLjCqy2g1HcoFHVLASCAhRkZQlSeTTXq0wu64ZkSQdhFTgoCEg5hhqfA6RMCVEApN00CsTGhjk4J0DBQgWbU4wIwYkCmRQQHUlsmXEAwbOIYCQMyJcxQBNQzLQGoEnhoGj+Yw2ZIUJPDZHkbQYdM8FHt7MBpcY0MqVfQCXJtgAQAAZqAAOSGLJFUyCRw6DMSLC50CHTEAy94UOkR1CcRE3W52I6j0bvf///3VTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTCmwjwzUBsiMHrYuTmKQUoxSlSCNV5NNjSAxGgwp4ZFMJvBuTKgRooyt0GPMUjABDiIB1Pe4xE2vAZDdzXXOfZUc3SSszHPRZMaIRkzDw4jCpCmMmQOQy+imjD8WBMc4EwzGXEzK8xHNU1Jc/pkCDL8atN+I54yB4kTGvWQMS8uczJYnDUhMNN94xIxKh9TIyDRMPcRMxORcDEiANMFUMgwVwjQICUYFQNgCBaKBSjBoA/MIEC4wjAEzAjAaMFIAYIB5MEhBQ8yhgySY0Zg4poLjTRk0Qz1LzTHDVNzItDRojcuTRpCwQNWaJV4OUGmIqyGbDGFOmuMlg8WASVgQMITppBhiw5jlQKHDpcaXAkqBEYIGGiImOABZUbMCLAiACOpwxWDwQffMMIYcUMG6qWmnBITDGhTFChwCZJqGVA7WQFBCDCAZEoMgkMGkMMHUHDhgOkDR9u4BJpwCI+DRy8yoTMuZMJTNmDHhoWEAwCaMCZokiaCDg0iLqv6FwZaYv+YEOY9MZcMz1QIxg8yhkzAgDHDNPQOBLpKVA4M8QqNUzKywJAiE4EMxJlJUJQCIqwB0ONSwRHAy4GQUGw4yv/74mTfj/7WZUGD/tLyAAANIAAAATq5lQgP+0vAAAA0gAAABHqYQMYoINMwAcFgKvBQKAQZmUAUJJjt/Vwlm5TAywiEzqVTfMLbjuTsfR3M4R1iXNWucXTDHh7QxWQq6MF9GMjOYA6Ix20OuMJTA5TRlUEMlpiszBg2zTeA0NVu+I1wwfDJuJrMI8EIzOQwTDfCqMl43Awbh7zFHTNMBwKExNlkjIQodMUEcU8JXCDHEMoOPQU00oA7DHnGkOZMRk0hTNTL7PiMudasw0SWTAYFFMHAaAwORODBzBdMJETUDB9mCiBuYUoXZgigQllzBSBWMBQDcwRQFzBaAfMAsDowLQFQSaUiYY2aKAbM2HHTSKQHHNG2ZeZJ8YQMKChfSEWzGEAgaADJtQDojq0AlDFAIQBSqRoWXg0YbUKYImBikGmcEA5OXWMOfM2gSpBgo0xExBozI4zxUGAlDRkQTFjnJRrgGTR50ZYqYoQjuODi64VOmMGAgYEUjJATCEkCRmXIGRmdlGEMjBImemKCGKCGkPEQsxggyZBioJAvUzNvzgAw6EZdIrkKBXcMihCC6XxZstwY0OCDRM9FFQVIoJjZjQw6BlQ6FDDZYLEgFGw4ohAIFiKE9COGhgABp5lTJjQ5ZgySMsql0AADF072UJ+Okz0gISYcJhYiFApgwBhyYwPM2OddvAoGBQIsDDAM2COPJqK31UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAEAjB4AFszQIvYMJ1g7TKIDb43SQZlMyxTPjMlgrMwZYc6MLwENTDzxK42W3QDJoCdMYg5Q4gxezJGJnMjlIYwGVxzG/D8MDMuoxHgujCUDFMIseEzKBBzJ7HoMEBd0ykw4zPkNfMrF90zaiNTXyihMIxEo0wAmTBIcmMis9kwVy2jHxhPMFYIg0mUOjBWGzMK0KowaRbzBiCGMEEEAwcxJjAxAHCgyYdJmpPwRYGjmRsgiYUaCZ6YFGhxUEACsZlIUZYZGxxoJdgAgmMmwGPA4RMDETVSQYfxqKMGEDP2wwUYMmQzJBMzdpMKHiIlBSYYqKmMi5qIcQngcuGGlQAATKxswAXCCweTiItEAsZCGlrDAQ8DAZh4oOBZhR4BRkGgokZCg+CDIz0RQTmNhSChdoAgxg4iYwVI8g4cMRGTCwQw8LfJQIlHkfDCQgMDCJGEBWXPhgKjSsxho+is9Y4AhwAhMTjMVAhgBLbBg+BABQ8mBQSHGCDBYBB0BLypEhQ1cQs2mIFgMFEpfhJ4xgTLOhxqBhQwILMIBRIPEAYYcVEIeYiHAoMByiHFQkGJEgY5AgmYYKCMPAI+UAJjAM4y6BUYJg6BFugwvAS6z/++Jk5oz/JmTDE/7acgAADSAAAAE7OZUKD+84wAAANIAAAAQUEBhjJwNAppgyFwhY8DFFOFwUthnT2aDAlAQE1GUTNMmUYuT0aiZI2NVsOMakLNzFEhH0xKcpPMOUBDTF3SFoxAUaEMS6BxDDLxdExDsEIMPyBOTDOBPEwSgNFMC9ATTBRwdEwQYBvMO8ABTAdg+cwzwHBMSGCvDC3gWAw0kI0MJ1GIjBqyqUwu0LzMfLK1AAM0GHjAAJhUItiYG+FNmNgAEBi4wE6YjECDmOgAWxg8QJeYJWBfmCygQBgUoBQBgA8wKIETIQBgxFzM2WAoaGmHphKabK8BmEHFBlSKcQ7miCBmyMbmDmOPYtmHHtRfk4I9FSs2ZPBJIaSiCM/ByiAW4BFRnjGaiRGQopmAuOKwBTjAV0wpvBCANX5i4gZ2PIagQ5MdABYChoDRphYgZsYGNjxggABh0eMTMxQHH5iwyZwAC4N1w42wZUdjwQcbjBgCJXtaN5UZ6j6aIYyTJJ8qrozGGETerVMA4HJk0oyea64BMiBIsgucppddeJtrpjG0MwNAUBRiaEMbMtwDFLACcQ2Uy01xCtshfXmcDg40Y4YGjLvGcYAhgFWh2OgIWPChgs0OgD1ZkKiEwrRRNNw0aIBxIGnckRtmlYGRCVr7oDgzxG5BVCWkEccQCUMcQxmUTQw5ZIiHIQFBHgZXPcs8VMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVAExB8JANQUFAQCU4HjHGNphhMACYgQcOGnZiP5gURmuYsKElmO9DhRgOQLkYsgCeGEYVMcMwnhrGA2GEi5cZVRgxqMCJEqBZkPhrmUycGZfpgZiPh5GJKOuZRDfhi0IpG0MlaY1MqZnqBqmlJmqZrCCBwCj+md0KeZZoPhmAF8mNlHcaTxShnimOmSAB2YyoS5hfh/mAQAmYEIQZgMgrmBQBaAg8TANAWMFYAsHBpmCWAeYKABhhIgUBQJQwLgNzBXAcOkGHDpoLBggxh8yEILMGOXiJ6HwTMk0QDUEkDTYOgC3HgDTzdCzJAjJKDMDzJNzLFDCGjQHjBpxgaZxEMmhLE/JZQiOmEDFhcjuCTprw5pEjlmOECoIuAY9UXBNRDGTIeDAgcwRYAAA4caEqHCFKTIBgYGLrOuYIINO6MEIDEpSUKADZlywODFCAHD1+kg0sAUKRGhNijMUKCwZQQUHoBISnI2Ewgks8QiyIClUwZB0VMukY8QYYaY0KwksETCkR5gJIWlhcOkoBAjmmMJM2EJJo4IGjJpiCtoKGmTCo0jqYw4sOBmeBAVWJVSwW//vgZNgM/rtkwov+0vQAAA0gAAABOTWfFm/3UoAAADSAAAAEMqMNmYGg5nmBuiEBmq2gsQBkhCMLJAwmAjRk1hEoMCLHhjTYPllxYAKJJhgowUcY/GMsGBwFPhjmQviY1Mp5mhEkeZhhg24IQksxaECvMRvCsTAWALgxCwHyAIPiBAIkwdIGBMBZAeTB2gVowDAJLMAaATjBpQOowJQJwMIuDoDC+wFsw/UMGMNbE0jBZwc0gjs6pXM45ggzMo415SgyFXAzTGgbHI1xQIyZGYw+FYwQGoDG+ZJh2YVjYZSEgYGjuZqieAR6PigM44N2FNMiNUXOz/M8+NkZOXNMWxSIMYKOzNBGQy1M4rcqMDqHjcZjfUTVwQqoNogOmbMxMNQBOazEE89oA3Fgocm1UjRYMtmLZHqYGMOGaImzGg1AaAEYs2liZISFTZhCJEPAgRMgMVp2GWEqOLNBpIQAwqVMQUDkhmSJUEGCGI/GHGmNJFlEQUszOAkOpQaXgXPSNEAgcHjRth6d48JBgsADgIBMWLAwNYBWtMNaZeNgstXIOB04xEMSdMmPHRQGTsyJhAKDF/CsEtIwQQDAV4RdNGHV9AYQgqTDgUEQFLhQ1iwcEL3ofwAwkwCgBSy9qapiz5jxo8cAJEKtDFkgwmXPBDcEmjHDhVWDF6dRjBgCZNELVAECZxyaEqtwt48DTIDkcosU9/BMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMHLDMzEtDqUwVspKNFHEnTDNEH43tkGmMsyLRzCcwbQyskG1Mc8HUjBvAwgwpwJtMDPCzzEewMkxkEINMC3HITAcBlcxCUYYMTeIhDJawQ0xJQJNMHlFKDEiQsYwMoGnMDgBtTDZQRUxP000GJQ3WUg00Zo8gOA3uiAw0Pc1SMszENkz7GQw5FAzXKEx3OMx3XMxPCo3PFoyOT8yEJw0BJY1vSYznIEzGRELlYY+gwZzCSZEA4Km4YdhMZfi0Y5keZwE6ZXncYIjmYpA+YwjwYai6IgiMXALMJAfQBg0BIgCsJp5BgRh6jpod5mFYClGOHGYMGcJGohGOIG6DBHYmOChQcIGmBi0kGpB0cYAySFDUDTHNjekjKTzCIDZnjARRIoaISFkyuxKCbAuDSgaTM0nCioogmzoEIUNAEigOIC1AAEDIgywuECwwy1MAMlGNGgg2WiMKbGARiBIJGsOAwcBIzIiwEhLXKTMyDAQda0bHAgIFl+QCGHDxcJ0jOGh40ZdCrcIiRbmFjAMZBg5MUVjKAQcOMWBM0BLCsLA//viZM8M/wBlxAP91MIAAA0gAAABNemRHG/zTwAAADSAAAAEgaHMmBBI4FETIEGEsddcOAF7gCBCFI8MGkZc8vABlIBGsOHQAUBo5EQQxAYCjAhGNLkEphCTdy6BWEXu+92zlnelABaScMBTAOjCAhTAwmsJlMdNDKDBMCUg0U0CIMRnIPDB5g0MxMsFjMGtEFDCigIUxS0EKMFUA3zE+QkMwoYOOMMYD1zClgBEwKAEPNwFw2CdzXR9MzkI0YrDVA1OzhkxqDBrRmkYOYCUhCQDbjcNpJ8zyZDNCFM/h0zoISoOjQIEMcFgoJ5kgEmDDGClKZSJIcpDLYiBGBrxrHJuSpsCxrDAGAEzsyRc5CMwT0zSkHMTLEBQUUJQhORH2PqBGUBBR6DhwVUjBg4wAw4NBkyzU6Bc4jEx4c5y47pM5EIzBwwA8BAEvTKmBwAZNQVGhtyQKOKCBcquNrYoKMUDCgUteLE0+zHDISquDAzSzAjDAiAhCECE011GIBDwcINGPKI6EhBUZkUDHzEhlDU2UsCEKOgGhjJtNJIgdAq5GQysrxI9iIHABeRBdP0t6xQSGLqLA5FshZgJUkElQBmpgGRjRZCqLSmTGGEVlzE6yoDHnw8lGQ4WBGUGgYwFkaVCI4ARtZaIWSXqj0YMkY0uyAUIBgAtwwoSJBgIwYkyxFp5lAydIlJMONVSh0ILRZK6X4pVAExW4CiMajGKTC2BVEya4c+MITX2jiQRSQxcqHVMPTGATKJCtwxm8lpNB8HWzNAkOwxDETkMgTCvTCbCJ4xAQIaMO8HCzBJg50xF4GVMAzEYTB3QJ8wq0AdMC7BJjDuAK0wqgEDMKhBBjDLQc4wMoM7MITAyjEOQigmD/TGZEOI2U0O3jeSoMpOg44YgAggoLzUYPMTGM08vDGYsMrDs1svTN4+M8BQ1oiQVzjisYMWpwFQU1k7TJ4/BKHMCIcKiQxIchpGmNSWY9DphYLGTCgYfB5igZGDjoYtBw55M1TJLBkcRiXJp8hnjAwnMUlKpoElEA5gHbIzKBlNBU2cUALHzCthCvECcBBTCtSorOUiBE41JEx5UlOmsZGOcAIoCFAsBBpk0TYlFApkCRY8hBz6YMAFKyhmAJgkhiThhwqao0mBIB1AMUCpwAgTAmQQTMmGGSJIQMgmAAgwYBJgGDESGGmAFBA0RBgMnBgAwIVM9fYBFmRBIbtJEQUChTRwhgKFloYILJAoOVBDTTIDrZf9I4IEOQjODCzjBwoOIgk2m0ZkEbIgkWAnYcNSRAwExJQqE1A1JA48piYAeYMA7aHyeQlBW8mAGFRLYYUOY8sHCKd3FvkTDNApExJ4QBMSjFiDQEAbMxRx0COCLJJjRmopAxnMhONWWH6zJn2hcz//74mT/js6uY8OL/NUyAAANIAAAATqpjwwP81TLvbqOzAlmlbQp3M0hO9zBrg50wcsLAML/EbDFPATIwNEqAMCNEQTBzwMkwh4FiMIxCYjEggcUwsANkMI+BZTDoBcYwkcHIMYoAdzBvQxMwNgCdMCZDsTB8AZ89G1DSLzOqK0xzSjBoXM9u0woOTf56MUukUJ5kdcmJQOZFL5lxRBi4OIikycezMpaNIy01sFTqL+EJHMUrwwAgjWoZMFFMIO5o87kzXMwk0w2YTHI/NDGgyQODFgsBIgAyEWUGX4n6Wn9MG/fBEA3T4YPHASkIyuasmFwJpAZmARhiBpl5MGAxhC92SByW6NYJNa8MoFAGJkZ0DozIAJIyqEAPDXqjlOAiwWqIqhgBxkAIOhmPImUCFtUGRYsXKBysoeIMBQASgTDAwKLLBkDBhARMIOAwYGhQUBMOeMKACF6hQ8HMeUGAZkyRlgJULEhsEAjShAIhAQ8wQxJQgAsFRvMyIRQgElVmPCmkKsxEsCaAKlBwFRoEoi1YVMkQowIoaGkooiKCQ8RjyAyqEAhELYiKg09jIiC88MFw0fBUmTBW2XgDhBkUCViLyWRCDLxIOCwJQUIFsXaEFhQM8iYpAMqHCAJsMoEbDK+Svzw55XwYIKYhYBKAvC4AYCVrFa5WYYIJYGGAzBA81zAy/zBBBBgXNBIAQCNXlZi4G3aY/8ogHJ+L1O30m/5LJGxsMRubq2dHBiLSnNaut1dj/RSJtkksWilDf////u91zOIVZHOUdJU/dbnbl/V65WvX/t0t+NQc+ckdN+JbJ71J///71QwdRvw6ccfVynJh6H1qL3a4/b7QdB6noM67k3R0Mvdxqrur/UETTUWUBSSRpJgiIoaMi8Yj81LZ6inJfGJXJJTLpNI5+cl9JXuWb9iCkquokqBlVgyMLIKMLrA4jFNDqYwbM5qM5UNHzCKIio2zUB0NpNOaTJfheQ0UcWBMK7hjTFxQpcz6QiCMRXDRTDtg8QwKcUnMPkAnDCjydEwWoGZMNLBPDCNwsQwZICIMXbCezALBFwwcsC7MHbGujDMAKwxocKLMDcDgzBvgWwwOIOnME5BITDXgVowGQBfMFOATzAoQTMwDMAlMAgAyDDx1GqkYfR5msmGtgOTEozMHTDIgMahgyUfAaWTNY6MThU0upDJ6SM8n4GJg0cLDCRXAUNETPMXiY3UUhRemji8BImaeDpuEjmFFMZLF528RjJxx2xhag9vNsFNsTCrUyCc56k1BoYXmcXAAOcJABR4OkhY6YwYcIiZwIao6QjzF1DxDDvnzIIjSmzWtDnBj3sTaHDUEDFPQcYNogMLpS+OU/AxU1x8z6YCiDPpVhjADQAAQGo1GkEAxgaMuY8gIgL/++Jkqo//J2TDA/zVoIBs51AArNB7sZ8OD/NUwjWz4EACv0HVw5APFkljDiwwRJEKV1CzAxIEqhhGZMEPAW4z9wEiA5UZE4JIgaoMOEDiys4ksGgwQmFCQ1PNMmMjVMKCWYDCwgLmoCJmGIAGQBAgYoul6Y8cEN2hI9qGiEgLFQCiGrAVGiAMHBE3UZUohYQ+qEkaLjh4tXG0SzBgwM9AweKCogsACoJYAo6YYMngt95rttP/qA7QgCIcqgbqjAuj+AgOQ+BgWAPpCmVjUAcomDzsbgTlosesYIYV2TiWqAQHhwcGDL6cnoSJaT0jhULB2qUCQ6S1R42kLpHHcqRfMtn8B/8ynP8pXiWr6+r7c5QqFg7fptyuI78wLKMOMKL5C8YJVb6w7XHh20s7scbXsQmadYwlcBOMfXHyzBEggg2y8H+MRFhyDS3xPc01RQlMjrIkTLPyiIwRJsVMv7DCjNIRaQxT4FDMIiByTCPAyswawEaMVyGtDCDwTUwq0AjMGOALTDlAU4w7oFQMIvBSjFFwmcwHMHNMQYBnjFCgOAwagFpMScAyjBcAb4w5cDOPzpcykGDsxINAEk2WNzN6lNFjU0sDDCgsMcigxiGwETgcuAuWzGBHMRhMVPZlMjGDoYZPGhksSmYBQaeBJngrGnhaaQFYNR5tE0BVIGgAGbiPocazVgxKotHl8ZjKBpFZujpky4CGGaUCqYLUQMGFDgJHFhwbcyYGKAjJFHJX4l1AV0EhAcuEiplG5mVoUCmGnmYCmEfGnVGNRiucxC8L9jDKQacM6eCOwlnJRoGXItqEE1ZnBsBgVEGNLBxoLjgUNHkpjyACWhQcBQ4IBZjw4VRrsMiJEIswBQLJBa8ISYdLMSQYWggL5mDFIghBcODIIhgGZ4yn6CjpQFMapMuAIhYQFM0ZMyJMSzMObEIwVFlxTIgTDgDIFn6S3GQIYNSAL/gImqZD8uYZwQ04w4chIppluCg4DhpVOmEMmHBLrQxJABIFS1BgEeMpwqGtKQ3TUCARKIKA6msUcN+pZKMMKnP/QLW2c7DE2Z46+1CaORcSnCBiMnn7sAwxvi1pyOn9tRcAWBEpc/DKJoPhKs8VRk7IOuUexyMmUmHOr00uNSk7fJRsoqjgRZlk7jsyMRCFoXj/83FBPf/LZrXkOirkaEGGq29NKtseEIYUfVcMQ9DAsIfbXRA64n/lR50VVDGpzjNN+zq/f7UhGvITh1JVAEoAhzELA6EwrMUNMjKKMDBilXYxi8LcMS9TyjAkgrMytwLaMDQOhzLEQg0yFQflGUQBAamPNRmNAFHxq4mXbFGPyTGU64lBWnPoamDB+nq4NGJeQmlAkHmJfmSDNG2QomPdNGLAIGexYGKoBByyGBhHGIoR//viZDqO3JtnRYv90tB87OjQAeziLn2fHE93K0H6M+JEAL9AmFQhGEunSFApMGgTGvDCJghAKEAy0LTzBsxoKZ8kLBCRYFTRwBAimorHRJmYJnRQm+7mdhHNYmQIB2A6KYcVjIodAs2KpVN8qoxgGFgi6TFCAMJRALsEQUVAgpeGBxABFSpEHgQuGl6FQQJMAwSYhUWbNEWMiQJjhoCiCcSbocWbjwxAG4CkmIryQbXEBi5aswoBAWwNDNNZWQDDi06W6tZUBpxGFFlpRYQv1K0GGC2QsFVUWikQvtGpMifQyTkSwboIASgaAMiBllxCBmxUGIABQHe4eIw/Fky0JAoFdwWPJjIYr+dldDyslDgT5qHMeXMRCBYIiLfWUBRiSg8GDgq0FbVDFKlRo+t6lIvQgAiQaNjgKjxvRhkm6tx2JW8NNVzfu/4yQgR2fJ1qtsORrYk4f7pFqtcIQSNLIYSzEEwkAwIZLDsdwUNxwQz4sVHMK0iDhLP2JTGDZocktcJBdeJhyaRzMzMBXUNmZ/ZFMzK84REtMYfrJbKQsK8bJmdsiG0YHZ0ematuZmZqnP54loyQcqzg8sYGF5mWwGMD0CQwh1XDCqNqN4hdExPOJjKnKRNRe2Ew5BGjJQOZMHxqE6IybDHVamFk8Ohw0MYEvNHQCNkhxM6xvNODHMWVfMmhiNvCbMZU1NZC2IIDM8RQN+jMMcC8MOSHMUyUM4gzMgyhMLg0MGADBArA4OTBYFwAINoGXmnaQDlUoeLCqyRREwkKzkVPLetGABgALORwMHBrB0lnCwdWQPnOOoGnGo2DZzoANYtDdAYo2uoQgIorRQkq3NoyoMFAxaOgCeZ0DgxEU9CE0YHZQDB1ExMYgYMMcFZFvA4sADDIa2YGEQBalkbkP6wJ9JQKCqGImjJZZRMFYdaiHkkYlBTer5a8jixcLDtZL8rLaCo+kZGUH5apU7imRYIdNDdgE4qEt8iYsOnFFEImlPi2qFSxWbugrFDSMjrKZt1SMYsjxAK5WyMyQSxqCWBN3QGsEDwRw2IEUxdZfC9lgFBgsArhrpbFLFPpkyt6ElpD1t7JpdTWtY1ui/+RzO1a4+Aqv07MplehrMwmiZLiuVbRjNI8jRMk/idLl1d8nVkfRLnJcltMlrdM1VMczOT0sNtZUrLqLtTPFc5q15GYXieeM3//bo7Eop2FDXv/y98kfVLwX0GKpkKfWlZWKr1iZq2uyvt//sUNOu2x2wxLKV4nlbFhPv/C2gABIxFxCTKJTPGCED0vAlMUP3Az/BIjsadkM50fs4BxczGmDIOtsQMxc41TIU6QsuRjkHhh0VJpfCxgSc5nEDZksdZjCDJyGRBl4K528LBowtBqaQhxWcZg8pRs6TJkCw5ioP/74mQxhPwQZkaT3dLQdszYEAGJ1m5RnSDPcytB4zOhQAe3WYphIaxhQKxgaDJhqEYwCwQIYBCBGQDgTIiDKhF0iwIwM1FwHCzDhx4AHOVAhJuASI1AIxwUKhowxzIxIY258ZegcAY2wBpY6aJCgoJBQ1eTvlqVSMFTTS0UoSCJBY6JJARIWQWBAwQgBAHfyJzqKxkxIIJI5igslMoZA0IiIZQSXiGjClKDyRYoFZajM0JXIyGFAYgDpSppEA6cGAIKHLNfRKZwkFkbUxV1IIC56bxEeVhrBQAFQIUAskLcuwldCGSobgISBhTR0A7DmJEQlQhj6UbxKYOSzpMpIeGVyPIsO5F9gjAEsoddIoFvMlySBV0pcryC4Iu0FAJiBiORcloquE7lbxoUNEwEPFirJ5Mw1Du0lgy7nsFhCnqS9UscmZmdbEMDhBADAmAsczlDgHdUJBMVxiGAclrFxkZGT0yy9KY+SmLtWD96ExIo+iSOLp/eFse1ZYEE5eTFCIFCR5t+SRS2UpS////tZEiRIpf/3HPS0rl1UKFDFChkiauPtCy/fCKPkg6fOJVCb7PjjKE6KyMVhm4BDeswEQ4zLoEDMQsn0y2ERDBRoiNJYRc2g0xDHuNlMF8twxiEWjcXGKM+ZQQ5OVjyBzNFPw36cDWFtM2Ak4yDzE5WNWjg54uzCFCPFLkzF6jN48OWOoxKdTqoMMcK8HHYCmkw8ABpHDoPKBOIAEYxQO5AAAQMIEzWCSZARquRoIyT2DKX00Ua6AAwsqAFAq2a0BurAeQRzHkeakSJRjjoDUVkm9t6OEwwtd6xESvUBlGYqCEDQJNC5NEVFaTKGtL7LSNDUsAxhngGMKQDAgUtIYJAcAITlOUZwc0OrrAIiAQtPqWNhExjFNLxFiUaoN9JWeLthKD33yYMngXmQGt9Ar7gIFWZ/0dGDKCrQfhrCc6ao6gXNGAFHTSAh9BcGFofLXStIjm1i8Ulswr9rrrwhuzTpUorEUS0/Gsr/W4xxOFFIRCPEgeTgCAA4hFUGpgE8kSZUODgERhZcVl5eNR0DPqvalkrtwVDoEhU5GpLWsV7f/6N5gEFJ6JOIQqkJE6FgIIXA/CXnEKEu5ejEAqC3moy4z/////8aXk86Zy6LCJRZ5jcL2Xo4EuOcUpXD0KFAEPHeMOMMG64xBkIN////////TOMOAd5OEsJERsJICQDDkUlx7kkOQT0hkiQRKBPxgyw1Bbw5A7LiAACABRTKUBgYGLafGGBHHGydiLFDhwDDUThzCopTfgBzEeeA0GjXNBQMRBgqCZUIgwa42/I1bo1J4KQAEKOiYFLRxTJsZRxAhr5pVFnDCGEfDy40ZCICQJPZZxALFMFEW7L3YOISJ4M2SNVhR5fhnH/++JkOAjp7WdMU7rDSJGs6MIDDNi2MZ8UT/ctycczIsAHp1hzORiTRmDkEex3S6BoaPCib5hwo0/0ajTrQezRh6xGav+xNO5ZRd5FJkS8S8D4qBrXTkKhUbxJqWxRMtEX0Hvr6aElvDzbv2zKLs4YI/zvPi+q0kEy7l/NEW1Ac/lAWUteVh9ZlagsQjayFb3KYY/UcaSp3LpMxqAl1M+tvvDb7SJLN81Knnh93l9OpEW2X4oa8bWXlmF4L+glVRpi3khIS7mlXDIE1kt2JCEKFzkrudqWum1NzWDqBuI19/HUbks5nbUpW7zg005k2dyIUAAYf///wQztjLpNyQQsYb5sjHVTw23Vm1AxVuxddgy1GUxe3395Ybsc/Dn6wmICfWAJO6LDnBUwYm+jT3gUNXwzgu+09oDM2yDHQiRhUbmg5ZbcrBQa3////EIcqQxOf/yj5mlO396Znf35mabfNv8zMzN5oZjYKh1bMlQ6mCkKQJKC2QQKJzMD4+QCUBUejs1AEQjBMAGkwoUeHMDrC4jQmRJ0xBtE4Io4AxexdmMBbFwjEmxk0wUpOGMidCmDLQgKIwbMD1MIlA0jBmwvY4QQIwXQMwYX43SI4w/qQzWOw74dMyaJ4/lDg0xl01qL01GmAx7ckqEQY1yQZZDIaQAeYyCWY/jiCQgCglGQ4tGJZTBgmmAASioJhApCANjBoIzCAPQACBhUAsOBgRgoR1DzDUCjDcLQIG5h2KZgGL4hCQwXDIxUEIxaEEwMBsyBBEwZEcCgkYEg+YQgaYDAAa0goUWWMd8xsSrWI9Q5EW+QXOMUS1NhocoLPjJT1teGSEHAc6+IPCNK43WiGEajOUEACgBB1C8IlIZBpfUz3AE0YqoEeSVaUkWABEJSWiGgFMVtT9MUQWQBizembKYIpFeZZxhAuUSnhwpfFliZyDa9hawdKAoqbyJySyJAORcdGprYJRLov/QBwSYgyMwZDqlsW3V4ZygGAVGSKu8hyWctCS0Sc5iAOyZYalwWQMCtm6nKMhDJw1DhIQsqFLgreydioO/CgQIBMpoRnmigrwSCSnNAkOPlbSY1J39mpesK+kDbm//+GJnUSlZDSOezAzMr5zLqXVgG8axbTlkVyo/lXDY0P89sddqcGKkz+Mu1bEmZkk7cWGU0jzSJwv2FdMSvWGWa////Szt//pN22+Ds2Gf/Nzf7R3RO6b///0H1DDES4pJSwJOaiRIwqMAaVEJ5EieyqjBdgRwxkIIgMHREszCFCzIwr0msNX8A9jNqT80w2QBVM4lC2AKm9GKMCiBkr5DsYZ8CmmCTAqhgvYLIeoK4YMnsYZEIctASYbmUb2BEdyuwZwJWfWj4ZAbeZukeYr8CaEJObPCYZRwiamACbThy//viZDcO/P1lRQP9y3B5C1jwAezULNmTIE9zLUoVraNAB7NgOAOZmimYqjqYMgoZkBUYVCEHEALBMDgGMNwDMCBcL9GEQ1BwtmIoziQ3GKIbggDQgTjBYJDDwQygeDBYRBwOzIYSjBoJzIYIDFsGETDG8LjA4aRoHTAsMCQKwwSQqCHOgkQzk0B4pUGHJpC0wK7RJB1wRKKlA0ELNjx48i4ZaBCWXhOEAyVhCKabgsMCAgYeRkAkZmwMBEKQXTAYiaICUFRS7jTBAayAVNFRKJ/l8sjFRVuIBpYtZJtsZAaLMpziMJdixoPR6LZjwI6CUEF6AuWLEkpLQVYjFCa5BaYaEphS0S8KPoGRUOUTTPVlZSlcPMKnAhZECY57uCwpWAraDimZukCicFdFAysTHnbS1TlMUYiDEI4QyzNFERDsCSPl7F5al2VAEI4+m8iVB0irzVnv///Uh5rtCyRkLUw+A1AmBpquj+zMiDIN86HikJwmiVk7J2LmUnxZcmmtzqB3K4Nzc4cPFixomKOYSFSpLUkszJYNykWCuIZExZ04YKGC2ZvFhZ17mYNAaCATKXJYjj/FMwiWI5++dxJyWJZLAWDNc2edrRg4cCIaehZgqhwGP2gwY9gxBtyEPmCkX0cZAdZvEFqmSmJmZIROhhqvFGQAICY1bwZg8DLGcwTMYPAv5gMLmKDGZCKJtEMmPAibEIZrqCmJFOcGNhlpWm4TKY6sQgDB8oOBS3ioVN8E4yCUzGo0CC6YJBplEQjQ2HgyFAEy0Lh0UKBgYAGHQKCCy3AcEbZg6sDpkvkJJhEllggpG8uADvQq+zwPQIXQzUyQzAKGUTRIMg4Qrp9BECLxMCzN3IcnW6tDZS9Cn4aWIq8RkNfh8uQIAG7JrMSe9Mp8hoNFRZDuN+MEIWlxyAAiABIKuUI1sMpZ+9Vl/4CwVw571TKKaeimCX7+rqfaVpfOu57Jm+a7AaYDgseSEhh5mzSxYVAGqoyxwYWx12HNVepFfbIk6FH2boWIqNYXKqZ0Fju2+bvIcXEeRQBAipuRCoGoTyoDDUOsVaA+6KRfBWJEV0y6cvaSydcj+pXuzivwsBrf//1PYWE+ToLkTpJIaZINkOIHMJMBiAvAJQOYWJ2kksp1Qfx/RygEKFtaKIcokeZJCVCdzkhpyo3LCgSUmkXIuRfjSOZDoWz+T2TdJCQVGJZRNDi5U1uJCjIk6UJVMSJNHYkZ+Yg1AFD1hMPzNZp5JJo9Dk6kTLS6nD0my15TLqA0YsuvWgAEsxCw4TE7MnMPYZw03SLTIVGFNrwRgzz4RDJkImM5QMUwkz4DKeBsMm4m0wowQTOFWbMUElEyNw4TAxClKAQjlxo1N5M4MzT1oSLjwE0wo8OnUzb5sGQhpP/74mQtAAtKaEkVe2AAj6tY8KA8ACzlmTu5zYACirCiAwEQAOODfk40EOXiDghI/hIMIcjQy8zx6M0LDDBcw89MxHS/QjHhUbIBUKB5gAiJEZdtOpB6wpYtIQiKLbL1CAgYKBF0DFQ0GkojAQshormSiyGosmEgIAjMEh7XFDS1aANYNchdSlY49KgbYEyFYGUMDTzeZynuljUYeaxLVliIAWWuQLgCPxEIhYEWMpimqnKvVlzlKseZ63vgKCmuRB225tlgJrizGzrnjiezaMUhiBqGLfAUhiDvL7Z7TuumIyth6uHTC4C1dukRZRK0j2kp3MqS5aYly7CukE8A5rsYYnw9aGFAsAIgCQK/C4Crtb6prBeleSsatUKgB9FGo3HXDa+vt1F4O3ONAhh9GZyOasd//////////////////////keP07EYbVVBtuba2NeLM0ztcG7Y308Szl3FLOUTMoDUMEXNiGAYqMT9USaZoGQT9FMSpPOdweJM7jwYFYpTzQg+DVci4G4OBtQtnL4rSDravQ8naqDUG6JmrnURvJ+li4MrcXBdmQf52MqcN9nkYJ7wHp/vlAwQGDFbRnuoD/YAAAArNQCO6letln12pnhBnH4mbNWZvqPGiGeZXpx4pPmMAAeHxJr1oHmyoakPRig5GoRiYj35p82GJnKSF00kKM2BD21wzAtBCaYEEm/NZoIKYsTGsPwRCmqsCsRloeiEDBgwQKX+qcRNYNJzRhEHExQKmOjaaQcEGGhSK5CJAIzbscCVByyYyGGFmgGL0I1hF0mJAjIW5jwwQgIkJBxG6IVJzDyEFPJkZAYmaGAhJbcBFCcDjIDHEQ5zCfMfZC+s8BAZ5S/SzAoFo7F/2UmFAxdluqu0j9KYP81R2m+dZ5p9R0OBgQBqPCgGwxPtFJnLJyzaEtQNEdv4zGGGOY8Ze0MBmuQ2DgJQCBUATCIHBQESjZhAMkKyZ/Kd0VaGWq3QUXwlSmyhkHRl5WWQ7KGiOGxGDFEH4Uyxc1/4GiWLiYK3K4cZQVWNS0QgTIWXtKaM/cO2YSlG0Blao28oIvWjs5DcxBz7Vf//////1GKmRMer+sZUNuD3gvSLERMgpDguiLNBuIPWGdFJmaiKEBFlh8w0iKDMCPBKw/URwHdEtBsaD2Q7IcmOeKoQoHwhlwXGNQdxPDPkwK4LPGbFLBegTcENEJBQwgKLID6Ba8RYTMAhhf0LOERGuK1C6QhGNgRiICCCghcRmKAE/DoFkEMHgZcc8WSWQyyXFO3+KDIsH/HILqX/GmigboUAACRRBs1LSWvW/UziDjRWlMaFU5wCjAK+MTUgxA/jDSBA5oN5oU1QlzAwSNEP81VAjOKvMFqExwhSkWHIgZlzsftTGbBR3jX/++BkJAAK6WZP1nNgAK4sGCDAUAAp5Zk6+c2AAoYwHM8BYACa0egaPMPMjJxxTcBEKlBkhKDSIyMCDgswMkMtEDAQt8jDgwxwWBQgDgp2zBA0xobMdKC7YCAR0TMeFTFQtIt+zBQMwkNFQADAQhBgsDmCAIcUGDBoODTAhtBYcDQ4HBQgyyOVXYTgXKvpIaacIIMQAAgIBKgAsKlMAQpKwIE065O7jW1/M3bBKZY/rgwyu0cAAKAQ/UdFd0DLAqeU3a6wdYSBFg1bo4+CApAEw2uwF0kvnnlTS0iUQkkhQDTGuszdlkrO3pTDLaIcIm1+KRFs00+bd3Ao4xHYir1uLvRJ6EeVIonJiq5dBxXFEgXDOAYbrQxKHhupCMAjsOSeAWIy9v923Yg1pkMtjcVhy5U+Wg01+mpt//////////jtAXDANAhXQDQwIjwNqjlBl0MfAcBDLgXPk4YkOJ4hopIeh0g3RC0ALqxyw7AWvBbkDEAwECRMg+QRcckVoIWLQewK6XTiZiTozw5IoEPhC2QdABiTYCgABBMJCwM+AJ4MRCvA2aDJxKANqBnowQNQiA7I8AgABYoIHGyQ4OKAARAbRaAEdAQdAzx0DLCwxiZF4G/EBD1Rli6a/8aBLigjQ3/82OlVgAEAQiY02q5bRQikDZBkkMkDky2DgkVnhU6dEBx5tXGmQQdMqBrlbGk2ycpQhh8dnALeZMcILQx/1kZYKHUFBy4MAaE9FHMJBzVjQHCgNFjKxwz0aMINDIzoSaTCRUwAPMpNzNQtI8ZEDAwqdCBsHIRmR4JCoKUEnx4DLWNJJhAaCkGQaAA4iDlQHCa0AgPAAYCiMx4AaWudgMQAQVBTfOVCqVVg0OO2sI9FChIGgdBIjgkGhXB7CXdThfrJrLHXwXculjzxIS5+quRPAwsBZUgMRLXJLmkoKlyZtlryzcMvLDz0qDtZgp216NfU3YeXjR4YO3NsTMmCOyio1iu3V2cobfmMQZD1Tq22iLUaQ/sYVZI4cf+faWwxuqckKdhWBlFLK0uHAbm6mDWWFYLDO2tWLt61hvobYc6zg3liNtpaTM3tVRXmkNTKKTrWpiUgUgAAAAAAf/////1rdv1f/nTIc4jR1BiIT9//jlCthxFkiIxxdJQXF/r/4JgCAwDhbA0koLA2sI2AwhEJAzzitAx0BkAweAcAJAOAwCwTeQ4LJQNgyJAMiZmwMfIrgNXD+ANOo+wQAmAJAIJ2EEgaABAcHYDSOIMDHkf4DI+G0DUCyQDHSVoAURYAwPgUBkF1AYXIKQNSbs/8mziZj/8myq7cABBBGE1Sy222uw1UeDe/HNDmMgsRtJ+nZcMduMZogJGUZqYrGJzcOBh6MPkEz9fzOR5NDpwyGbwRUTD/++JkHgAKnmZP1nOAAKCLBrnA2AArFZdDuc2AApgwXA8BYAGIxMIjY5OLDSQoMelMWShgMCGCwWvIiF5jsQGLAOXICBpEhIBiEPoMAURBcBIWA4nGJAIkEYAARggPhAaCAAPDIlA4IBLaBwtEgEm6IgCYBBgKAaP7SHOQ0C4oMKAREoIByG7ECzJggCzULYlFhgBBgQWOX/aBI0rIEZ+1eUpppIgIEBgVFgU20wxptXCV0EANU6VdM6kkvMtorzJ05k0k5XYVkAwPYkVQSAAEFwIQgdVzzK2MtcVyH1cVe9M465aZibpv9GpfBcWliOS70bG9a+9vIDoFtKbtbfWUu06kVdKlytw/UiOVSN3KsTj8PPxIq/etcZ04qpEtGZw2/zsMZZctVm8D0kWcRpj7RCGoZmMoywSIUN7EAAAAQgSCDAAD/n//92/6Kl/9n/7LZSk2//Wjd02+v61UVUlOtvt/RnTcGgJAMHpVwMYyWANsodQM9ZSQMTp8QMWgagMJ4CgMIYaQGA2AiBYG9gYOgggaaE+gaNkRgY9BjgarDlAbDjSgYwA5gYLAAhaCQULogAhgAyClGAwqhSAwOhwAyto8CQIAMHYBhbSXUKEJM3//HNLwddmaPb//5oApEAABOhFNOS3XT/b4xaJzG0PMaDk1QBDDJqMAIo4PUDSBfOZA0ySlTwzjMkkoxQBTMLSMcl8wmkzG4kMlxw5eKMvMzex8HQYklmklxlhaFR8BPpkoGYQBgEXOThjbtM3AjbclATGAkEhwGCy/higUAgxeJhY4ZeMAEDeIAgSF4JEAqBmTipgoKr4VAwMJgECSaC4Ukaq0HDBgwG1rBwXBGhcuIgEWpGWHmGkQMB1uqpsqkoWAgYDtmbAyRTaMxdTSEUiZkQijLmCyAEAbCpW3BmSeTOVcqAyAs6h4oGrlQd+2xsmdItwYIBMNet6ASBKAshQkwPAK6Uhom/rK21m4auNdQ9cQvQ7rsK0NiZi4qiiZqu21bo/1WIWWtQTGXhZkqaHWZqY8iETZWmMneoDK1HZZM8o0JDKXWZazpdax5yXt3ajA+uvnDMJdl4qzXoKLXInP7FpVTgAARoAAAAf/////////2bfq2bt/1FkjP2LwGAgBn6Y5AGAUJAWQAmAcDAKAUBQD4b6HvgYRwKh8ApcA4I4XMAYnxFAZRAPAZLQ4gYbQ5AYTgegYBwoAYdBVAYqRxgHEWAxkhGAwJA5AwcgnA0RoZAcGICQyQMFgEAMDwLwM+YJgMLhRwABTBQx4NmhQYj8sGh7b+A4DQXqDC4jQZkixii34/lYroAdQBAAwRtyO2632/4wATzLBdMALYx4jDBIdNNncyWHTThaOenoxaEjAJUNTi4yEVTT6bDBMYgiQQ1DW//viZB0ACotmUNZzYACpzKewwFQAacWZP7nNgAKcsiBDAVABZPNkTjMAo0RnNSITzHAsiUCJjIWJAYUNDGC8zwhCD8LkIcVqCJrBYMEhgIBDAhExYRMGDy7gGCAaKmKg5mYexdXKEsCgqXyqoACZovkXBAoAAgQFARigQYuBmJACQEThEDGEiSlsyyCibRL0FFDE3oYQzF+0VwcBp1pmTrOETXXeNAK3JG5TYDCama8GsMYW0zhfyeyyHykDhlwAEIMdelyiy1EwxSpgTjw8wNymCIXtMSHLotLiq03Xh9WB23nmEMHMRrfSnmWeqZJJRqVy+VM5ZbB/+5D8xjURZ26sjWgzVYj8s7ViYe/Kx32a+NA6u380pSsDLdOE6TuiwEpJa7LUkJFqmso+L0qshc5fTU1mSlChXOd3v//////////////lgRz+46A5b84QMGgxAyiIQMrJoDYwyAzqPw3oBcDACG0DLqHCiQAz2NQMQgUDDA1BZQha0BAEgYgC4GIhSBjkpAYJGAGKgqBjMEgCAkDjoHA7hWgNuFYDJhyAyYBwMvlkDWp/AwSTQbbAclTINTsHvkBEFxkxwGn/AwEBxHwhMTROJJN/A0YRAMPiQDHASCxsBQYBYmGCx8jTIoSZcYQAAAQCBQGAyYjpY5tvcYaHhJCTMI5MAUIzIIzVaYOpFUIahxY9mrFyUa402VTBAuMhQ4w0hjjL3Dj2Z4FhxjkbKIH/KoC2zRgVnRk0eLAwKqQEYGaCIY3rzCDemMYAiwMGbihhA6YMAjpSIiwQB4kIoDwgAFAIEBCPwWEC1KwBjgeIQIcATBAcMEgMKP2rpa7FTDS5WIv0tpdC6jEAIiABYCZSnKwBWxnDvz0bgcsypFHFHpVipZWQgaq6vEi1rsoiDUk14Wrlx4jXd1sL2K2LAOsiY7zHZlfiI7K10xNiyNCu2dt86b0Owrhfj9xaGal9FB94fdqFLxTSefkca601LlhchuqYF5myqDs4bi377tvE6NU0FwqA0UmPO016BEyVltaQagdB598c5GkrH36ygqkaomO/CMy/IvPXr7esIqxxRd9mnPtCFPLHcOI2v/////////////+xuAAKP1oAJHH9AEgcBhMNAYrKYERwI6BtkBggSAYfRAGFQsBg46gYmAoGEgaAEQQJDsDDwHBtqKSAFGgBATAwSQgMRggMijPAEioPTBvQMtEyEIQBACgBgiK0IkYhfgWQLgDNCxjLDtEaEXNHZ8oggBAWxAkFwWC4ggDZkFhqI3Ig3mYIQEBgwGgiDQFhsDegGEgABhYChgoiJqBqAAAA8gjVT1lstmtMihkxw5zHAnM2AwwuRDCpBO2pwwKTjCwUM5Cw8ofTFYkMpoQ4WzTIAeNOGsy+Wv/74mQdAAqNZdBWc2AAmKzYMMBQACq9mTS53gACr7MfQwFAADbpnNXIDagAz1dCDA6e0MtIRVYMoODdxIxYsEloGCg4DmKmgshBhCYOaGci4dGg4AQfMJDxYHSkAASPBph5Aakjl7TAxQAlhioWjMCQUtOAAZKUwANTBVAFAswQJFl0xopFhUQhjNVsLiLeQJZsTQWBAACl4WW5o3EIEKhgYFZtOSsFgthSolL2/QUXY34sBLff9lQcAtYctk0OMujRaouCFg9CBY0bjFIuRESCHTag6E80lW2Muw4a7k+n/YdB8MM5Z5Joy+zLIRIq0CRx0YImG6S2fquHyPQxC68jpYrBL9PVDjpJSoONdla/kjmnqsQCq0qZVItF6KHIW/zwSxd7j9fxYNw5znL0uvR6D3IeOHaqGKKrzZf/////////////+oL9f5Nf8VALqw1SYmAbgIBgLMhlQyKMokicRMhbgMK5A4KcApWI0JXWWh1ipgYSGBhyQGbRACAQJARticwMkLAwAwLRgbNAAhA+ogsQ8vF05caYSGi5gDlAGtGg2fA0oEDVEA7IuMGxwToVKBIAULhc4BteoGVjAacIBnsgGWcgaQiBIKOSOaMqZG3/+iAAAX/8ykPk10CkRpQQWEYakqa7uObJBKYwnMdpkoY1DSc9hyaFl6aOIwbSGyYMEMbXmIY1JIbsAifVnZt0ZnMSgbXLhvEDGmCcZDF5ngtGRBYOBkRiYwmAB4mmKjoZOAQCEBjYTGTicY4BwFBpgcWGCwYYZBhikUmHSuCj8ZGExkUKsYU2BQLGgO1tS0wMFzA4KMFgwyiCTBAATMMEAwFAhK5UKABMBujWDBoKRNSRcSKWQ4DmGAEl+womASYiACnT4YYkOgHfVAc6Lixd75bPsHHgAut1lRujAblwS46miAiDkI2XuVD9MhKcNoidTKWGoSWfKwJzlABL7iwDR7S7f+brQRA24THa15+nfmq81SympyNNKjL8s7humnozNsrjbqQNDlJbgaCp3P5Q6Uyzdr8Wx3Wg1XsOxyT45Wa0BvTGf7LaVd/Nbx/Gpi1uX09/////zn/////////////////8siC4LMRXAGGgGDRgZ8OAEIACNiCVANhA1l4L/gMvgNzbFLhRWAcmAJCywGKwDpIAgYDSKQP0CA4NEBeKAqYAJagEhwFNIHFbgLGQMoJAgAAooABFABEAvYO4cwkDdQDRkDnEACi4GDFi3gBBgNLIBh0AYgH6LGweZgMq0AyWoGjsDlnQbGQMSDBAbA0QMAkOI+D5yLDmFsuO//kv/5gAAADBCoxvS2TXe4wkXjFFJMjlsAwgysHTO5YB3NKhBPdFY00dzHxNM4g8KCw1/RDQpsB3JLBcMpyg10dNUJT/++JkH4AKmWXP1nNgAJ+OmDDAUAAqmZU/Wc4AAq+yXgMBUADiloQDpijEBqIyc6MDAgqGAICM3FAcoBQFJhRdokFigSYcKmHB7ShCQGQDJmYGi0jmDhIMBR4tBxYYWPMdMFFAclg4QMNDSqKhAMHFEvaOmetswUOWxLl0tISuCDQoBX2aSXJTGWMuJZWdO2isTGF1goFTUVtWFWKoCpU0UOBVB1jsoQ8UvV0xx4k9rLSFnIrM/QZg53S4L8ohiICU2fGDEUlWrXcKTPs3kcpUh4v6gT/ug3VfKdMCLBr0pHDeOHHWfnTT3ciTmrdWIyS0u+QuJB7YXuWDlShqQibigKAFvXbgV83SVvXyoKsWX0rSYbaQ198oArK5WenQ0ZO+CJqXvFAbKoNSsd1pjOLLLlK3VhVz//R/////////////////+sjBkQpFAiDACXAoiAaNBnAuYEAywGFKgAbQBDwGzEAbkaAlsByDAOIgCxFEeAYhAxYYCg0DUCwM0nA4DMArSLJAS8BoAAzCAAoQF+xxiegcdDp0BjxxmiKcDXLQOshBNCAgYGpBlsBSEBqUQGGFg3mC34V8ZQwK4GtVAYNIBa0MibMBrBYN6jmFltX////z3/9SAAwHoiYbcjkdjtpksemkliTKkQlUxWGjGUbP3okza2DUJWGkodkowquQxRGgEOYWLZp1ZG4FubWjB1BBmOyMPRQKE06YbzABCMOFMwWQTRwVMdBcxCLTAwcFkOVQkY7GgkQgYDzCIyEYxLIGCQapUhQWAW3hgsPGEwiWBKNCgVABgEFGAQWYdBZg4FAwCAAGJUGGxUPAdCFynfMHAgviDQEqunVKnoSQUHUzZI7YcDQQEUWEvl2uCkiXVawk4x1oahEjWAYKnU7UOS23DaAFtGdNFToQafl/y7QoAVDkrS0yyX3bjNumpm7yl7v1HVa+wxSlkCgzDmTS5p7BZ9hzE5RGVLIHflDhD8ZeyG6HGkgCQuRBqtzSn4uOt/NL5i7BWdtRdCEs5jTX4LQhbO8OsZ32/0qldX49kvo7biLDv3D1Pm9jWmbuYn0oa0yGWHL2h52neV/////////////////+gWwMLC0CDEAw4GwOhHwAwOABCEDFZEAoHgMlk5Y/AJAoGCgcEhoBgMYAYtDAAQaAwsMgKhMAgsqTCQPAiBQsaDB4LAADF4WAwYAxcQGABGBq45AVCAGTxYBg8Dh/AahQDYo1AXOgnUFgYKbPqgUEQAgDByBC1kwAqDQMaBwCgVDfRySaNlYBgMABBIBQxGyobIBALDLlZcNHK//q//qqbYIBQArZChNlsstsv/NGAc8o7jJ68MYxozgGjimSN6Jk0sjD0ExB1NMvu4wmEjLgwKo6MligCk4x2NzN//viZB4ACttmUG5zYACfzIgjwEwAam2ZQ7nNgAKmMaLDAUABpqORZTMQw3vwMxJDFnEAkJhCsZuPgUsNJZTCzww1EFhczoEBQWjwYWApblwzCwtDZRUQihdsyIKMcBErAcCGBlpmpCZALSAxAvMoExUACwC00xMZMrExYT46axgMGR530UJ0AAoMATAAdC1E1UpEBqwAACRMl2bLC/87LgUBpjsibKnU+xeZIlfSjsdaGrYkIyiENAXgrhpkTciAFA4kywBAyWqSLXlBrIjEAcNJ6uc7KtbXJvacidD2oZsXclYdkb9SB73jemTIZJzNea02OKSlYrcbKwwJAVh2bsTduQQJKm8nYSoZEGxJ3q0uO8LL2trxa5AFSX9GQVr5fl5S7zrr0Xa/CE5heoxTX2QDwGtN6y7C5IZW82OZSopIneqQEAAAAAAAf////1/9c3Ugbl8wK6yHl4jCUBsWILi5g2QUw3NMuGkydTDIEqkA0ABQYncQnABuAdMijZotNab5mOYYGZOEWOClyfOgYiAYgC2hdEG3xD03LqBoXHOuxZNkkRPhFBoHjhMLIOA0gDGUAYYEshlgZUWgTaAFcCXB0EytBJnNnSS+O5UzRWZv/JYghoXRfAEAC+gBwxO5EycEFIAJggQIkomyS2SWX/mAzsZbVxkoMGVIIZNRRoFeBXImRCQZmcw8JDF/FNBF4ziSjYLGBQ8MsDIzKFDJ6EOq9zLQoBW5uouZtqmqqRgDIc0hmuJ5goEYwDF70ARnyqYELmSB6gtIIwgHDZigkDgBHxMECB4QMlqQAEgUAMXGC1KJqAcFAbvmEgIGBy3RjY0YOKKUsOL+xoRBJggSmUYCBDw2whhMPpCL0MNHi7qAVOBcqOKAJbMmAgCnsXahtvGTSxdzfuXRp2oShUEDCNcSuWGzLMVoJ6w7pI6Ft1ciD4s2Fx3XaRDkZaqulkCYs6+l9rryqBOUYCBLCy2GalA7L7QfOPlGKWDogrvJ2G0nIMcFQFhzAmzw1Ro8xlL113jWBjL/PO/DbdkzWVNaKpm/abDQIdWY4ESmmCRp9HgbyH7iGrDWguS1l3mH0rwyGH2lQLEKP//////6ywbmLkWHMSFLlckSuiUA34TeDj4GmKAooImlOCdS8Vy2J0KhmKAHYbAoJFakRHSKcIQBzc6QyakFWfIIaMJ0IqXCDj0UyZPIhckBAEOWAeLC18TgP5EDITAnhwGRDRjBlSfFzl0oDOCXEIR5AyLlUY8TgRxXC4IIABAQvuIzcIgwt2mvNjMol5JL4xRzDQoGhNuLjN7+J7NTUhgYwDVAhMM0QZqJgCBEBgFEgJORyyybc4QaDNz6MmoYwiEjURBMgk8z4zjlwwOOHc8wozVeoNTks2wCDVh7M//74mQagAqPZk/uc2AAnuxI4sBIAG0RmT9ZzYACQzBghwEwADG0xwlTKJaMzB47YiMiLDQ9o7iTAr4a6aGMCpmDcAkgy4PMHFjRBsHHYVFwAAgUFMcDgaAhw+MixgamEYpEBgYtMECkEb8mBBgkCN4YYEKIRwLAIKRUawAKrTp2Ut1XQv8t46D8TjphgwKhbLl0ggHhBc9aBQAtYZQvyB20UHTrR8ZI7kBJ1gYBQCJft6k7ijBFqZBfOJsOBgA1h/ZQ/E3ZiAGCgcBBAC4RfJ3GTNwZc57NZJFoGXXF5M/8jRUgSC5VDDrsgmIbmFBn+cR9FzNFSGVMvNIaLwS4bRYDg1dssnJ2khpnCp1CpFKHhsxZyITSxGgkEsTkkigymj8q6cRkEAvvIGXSvllHpQ13nVSGTkRlZeqaNO4t1e1JO4AAAAAf////1er4ngCBA1UCcBiQUoOUXRrD7DIQfnNyOG4VC8I0VH2DeMP2DjBKKKJAC4I+DELvH0VSNU8UmF+wuQFlwzwnIiakRjRSQoMokBFtLSdbDdRPjtUCYm6IYqEfmosockVYpEji0RMzJIdoiB8cBJlUvuSRZNB1FI0IccPnSgT6i+QUdpDycb8i5FkyNNhzhfnzX8606yRRUZAsAYoJLjtm11v/Mrgoz8wyZcmYCENL8z8qCDrH/08YxdJo83Gzf+fQLZwk+GBWGZBEoCRogOhk0nmg8x7CmIWoBiRp68f1TGpiRIempkC8gqimCBwNEVwGkBhgRqNK5swOZGCGBgRACmLhKPiGJg4mZgTAUNMIGTBhABF5iIsSDI4GL7STsKamAhRhAmChIFFQ4ImfCBiwmX+a2AQhDiYQHstRVEAO/KQw8lgYGSsd5L5AwAAhQBGLAAKMmTIlqPpDMiaQjaxpaCwiF6XSh5fxDRQtBsEiRZcSBEwYmhsjgxael5gYGYEAI4rRXauaKA4CMADSoEDILALdZfAhblOJh6Ghc5W4aIkeXQQNRvAQCoNguFyUmXwZvADYnFhiAE+EqWpy9oKKcPKWtKXdDN0v68w8CNQaegoh2gCGG7O2syU2EIGMJyPhIJLEH9i1qNtidWTfYFQVFZiL5RmmCABTdWCfd5klL2AAD////+r1fE8B7QY8DliAYHwIrwjkQRE9EaOznS0TYb2M0wW6AyBAXUAd8roolEY4UESRv+JSLos8BwQ2APzDihjxSRiiK6LOImOQQUixZ16lYX1E5jKilQyCCcBYQwiKiTRLiOhpGRDTQgRdICMyRxJfV8QqJRNBWS+LiBvUi48pfKSnIafIqQFFv2MRzzcAAlS0HBsLMk2mjzrZjMAGMBOYz0WzP6ZN1YYwiHzORtKHEYqBBYHAQaTGYdFkCFR8aCLGlCxkpibE2HD/++JkHg7oyWPPH3NgAIzrBrLgWAAjlY04dd2AAkesGwKBYABMpQBCxKYeCp9CgCrUYIFGFnbFAYCjQWHBhfMRgIKDDASlNIuyncwUoDkNGCp9okrRlLTgwAGQVJQtcxst02qfbIIm+rPX3l0Cw+5kPrElbxQ8+sah2D2sP3XjcjgizDjxwVFaeGIcldB2BY3UgdgjAGRvFD7Cp1qcC9g+pNyPOze5hqnpoZkU84VirEn8a9OtLijc4EZi7MFOLA0gnn4o7rutfmom0h03efnczKcZRL2yw7CXJinzbuu0/rV3KkU7VmIcjGNurVp4W3WFu5Ryxr7qx6Lv5BMxauYRbgAFh//////+gVydHSJADe4DgHALg7AwRC0AxMiLAwkA1AxQDoAyoDsAxqDFAwmhKAFByBguG8BrUSgAEKUCQNg2wVoJ5HUIAN/+v9vU3X+tBl9fr+tl/+tR0sHSaAqAUAYDYGAIKAGPE2wGu4SgGIEYwGhIzAGoBXgGbJDwGNAAgAwMwbOBlwQHE2C2HwWoYKC8ZiK8YmtCZuokIgDCw1igmGT5HHKiymELKmF5KhjFGN4HEIrlBumGweGEozAIHRMLONQzCuEwx8PZMTBYEOLwU5FQRC40gWLGhhR08oYUDyIFihegsFgoTEASPEwhFTBxdWseDwqBtaW4tNISHy/QwLugUCTRACBNiDg0uwFQADAIYCI9LfYmy9y7b7Pu7rfzFq9LH4hh1XYdaGo3FYhanH4nHAkUrh+vB9XKjkcadmWVsI7m0584Cf1tIavasZ8hiGqFzWVQC6kUaNCYe5GZx55mA4ZpZuMxmkszUagSNwPE4nGovANHjUnY3nJZTi/8UfmpuVR2YqW8/ibgxu1BM69k27UufWIw/Ru/Stef9rz+xmKQxEY5l//////9R0c8g4swG5AaQBgLByBh1GOBlPRuB1jEmB24+QB20uyBv4QMBqcssBjSteB/nzmBkTtwB1sFmBi+DcBgwA0AoBgG8gWGA3YK8b/////+r/////YwNCbIGGzAYAAHAYEA9AYOhNAYz3IgadSqAYUAjAaazxgbeHPAYkVbgYNwrgYOQLhZsQjCwsRuIGN6AEqqprM3UUMwSCojSmJiEYKxlWpDGC0FeZo7Khooh+GIgTCZmxFxgUMrmXoDGY1goIUDHMe4YIxHAmDFPDsCwR5gzJpg9IRtnCprcWpj+n58WxxmGHBhubxgYMJkMSwku5laJZj0DJkwj5imORhcDJg4PoQIAQYZiWB5gaFIsMQ0IZlyHhgwJph2HRhaEgBAQLggYviYYGhUYXgggMMCQ7MAQpMQAWQmAgRzEgJzEgRjAoTTDADFJgUAjAsEkH3acoMD1FcwYAZEWsmCYbA2FxCUXAQCkAHk//viZGwADUZmSxZ7oACS7DbywFgAIjmPOH3NgAonq9mDgVAAQAAIBgaApgICJhAAJUAEvyQAGyRIgAAEYGAACgAAwCF5TBMDTA8CBYAwYFICAtdywgqAjOyEBnpGQBAQCrldNmaD631HGtM1XSEAWztH4wCAkMA5XLXkckKEphCBABAJSldgVAhJVOVG5SmlLkplOEw5n7sjwGV40TAM466kZVU3WZzIy5he2Ko5A4DoJloiAclARincVmoaPqvoCgUDgScWxId+pIu47iw4KBRBRvVbFNJcwNS+3YwYAIwda6FgTd8swYIAWiYggianSt0NznKAAEgAP////7er8EQMwMTyPQN2hFAMd6+gMQR04IQBgYLBxgZYESAZjDvgYGgwQtWBgcBeBmqBIBiOMEBhvKWDlenSS8BgepZQ8A4OJ09/9bf/+v/yKBif/mYfp/zMTwBgcGMBjWKqBiyFwBi9BAPxv/wCBUAYIA4AYahGABC2JQt/8DBWFoDDoK8DDoGQAoGRYPgABJOEA5NMUc1rrjhprMfiUy2TzCqSMQNc25wjPkAMDFkzYTCJZmCUuPMYxuLwEUDBJMByOamwm3EBpLKeo8Gjs5AFrGLSqSMEJTMRI0QBEYEFg0mBA4WQVBAaYeAEoGgkYilQlKsGsenWe19V7aockcEppSigDgx+lBWLtlZE3BTpmkqa66VPyjlrrO89MBRGYn4xPx2deCMxl6Y7YlcSvvjGKFn7lSyAIfnq2tW6eR1pJLX2p4MrwmpFHzqTM5bhE1DsaryyGOWe2JHL6CISOOT8oi0pimEcpIKlb6P3KXgjsVi1fUM1/jLbWIzWtdqXYxBM5EKRxZF95oVSUzd2rlLl3RmLwluvILkEth69TYTf/////r9ZiRUqkaFroGAgOAUCQIhgDIpyA1K1AN+xQDib+A0EOQMao4DYbeA3S5ANssIDU6GAzCOgcJgMBA0A4BC7DVJEW/9/qf166urevr9T1aKnsqv1VUDY0IGMQPjAkEAMeoUDFJYA8f8wP2v0DE4+C0MQsFjI2BjgbrCCJoXjY8Rb1MvV/spqAAJKcEYbGITEGZY6mNxTGFIGGHpOGFKDGC5bHLSXmbo7iEBShiDHABzAoezFkLTEMCjB8IjBgTDBsCQITRg2fgiDQ00CkxwBgOD4eEMHA+OAiMguChWFiyICmQZdACoQTKUhDCTAJQrQjqm2/iNzpo+lsGwM+GjBEwScvrTF0071bS+AgUVCNAaS0hyoy1lVqVDI7ilSQH43MLyIvJxyVmEi1o+fuLm3uCwqIyWUZvwHBcuo8RsOJXsWFt6qXGApm7VVTGaVZd6frQjXjpxbZnbi1MTDdrhKxQRTHirs/US2zrmAlEY2IZBZ21piM63Ppv/74mR4jMiDY04buH0wf002MAg+rmPViTZ13YAKK6tZBoVwAAZLOKOOphXJQt8YmyWUtH79Tyt6dUrMdz1OqFmaavKOkK0w6vv9dL17z+5LMwa/crmqgICIrHu0Bf43v12HmMF3AvsZsiMenYeu896539b5Xhx310F8zAUACMGUS8wVwyjHgG9OcsQUwEQSAoAiX2Xi6Udqc7jzPLD+Z7+p/ef/Mf5rWH4/jrD+4fz8PsQDHGmP1I7UvOW/XhsY76rP0AACjGYzi6aQgYZwNScBEWY5BUZplSDU4MhQBPJytMnlTCEvMnAzMfRiHhlMiQtMVAjMCQxMAhaMoBDNpMxXAPIfje6031aCAEOkx45CwsIwUyoWM+FTMRkgAAgLBQ0rCXEDDMREAqRkwMDjAEiYiAF4ooopOKl0yQiCiUAXyGAyk0RXjUYFQEcAHcDAodAEfGUv9NO8/rwvlK+S6tFo5Vl8euMpgmizhySxOK1ZdOxOGpZDVWmcB+HDfR4Z9/H3mI3G4CaA877V36sR2URurLYjdhmnu1qbK1TcvyS5LausJylkssjris3cRkbWLD9vpC5ZDMNPov52oy+7ySqGbliXTUPRSW07/T2OqR5Yjg69j607WgCVOVdk1yn1V4JEhHgnPL/+9bqr9f9Wpafp0Ouy9NNFNJJNJVLsitVOupdT90EXrRupSaF3QupdTLZbKTs6lKdBF6K2WpS7dFbIsqYE/I4MsCtwmAGgYCeAvgEgi4GBEgnoGFSB+QKI2wGBogZ4GAygCYGADgAoFAAYL2CgCyfJwUR19QXdgravZJAq58kt17WN19TH1UxBTUUzLjEwMFVVVVUAAAtglkuQyuikTG3CZMcMnYzKQOzFoKJMzsJAwWAkjB9CEMKtdYw5QRzBFDkMDUR4xdh4jEACOMGwAswAg2DC+BjMHUEIyxCw0RGIxkPs8yL00JM8zjJswhDkxrG0zHIcgFAxaL0xJAQSaIxMMYxcA8xnB8xIDgw8Cww2AgdDAxlGyoECem4YYCUkEUAYYRBcYTCAYUBMYRgKXIMCg9MMAUMAwVQULAHtWMCQRGQsBwfmAQBqRMCQBDgLfxId8iIIAYAQQFQhAREEFASqisdRVuSDRfle8rT7eMvAixJiIAE61LRAARgMAqhpEAEZLkAYE10JNPAmisItx1AcAbJ1fylMd1nSjCh64pCqWKJ5PJGI23agdFkE0x9oK2nAeRrCVKEtdq33RgRqTsTxfaViIB34eJuUH0s8zy3DMCq3o8QBH7dHTtmb95mDr5YGnkqo6s/HoRD+HluXCL5CQDAABSUCkklAUFlZndXjSZfD6hieb8BgArDLKdqG3qk9K5MmADA8a/Oa1If3o1atv6adTWqfo2WnepdV/6b/++BkzYAMCGXMHnugAHqsFmHA2AAioY02fd4ACe0zlkuEgACf19JLuv1oWTTrZdJaOqlXVdTVp+GoAYBQa0lLQeZORELPM/dlrTHYBkuSGBrnS8AcMMBoBC03ag6a2gEikAxgC3ACE6FxmU9T7YGAUDQC4BgRACKrjXa3h7R/lmeR+u1YAKkd4ID0wScQ0EX4zTNgxvEY0dHswTKo0GMA7UZ8xhVICk4YhheZKh+BCKMKwWMrQRRzCBGaaYyEZgCViFrmNWEaHTxg4EGGQI1JA8wWMBJOmECaIgSXxBQJf0wECVxGTQICSsDhS47/ytXTfQtoLJncZUy5fCuo5Ln1gHkNLOopHRvK3lPB0PtZa61lrtyRTLY6WA4vJ5c8uEeaUu5/qeJRtsMm1TurhIYlHqtFKJbRSl44pDbwzsVmXynI9ADWuy+JSKNX6961emnano9lQxKRSm9Sv7IIBlkaf5drEXJnaaX40szapZz5m7SV6TKGn+rdiH1I40l0WEudG1LnLrMSlq6ZDRzmUhu0UWlFn7Nh9YjomADX//rQf8b//6////qqszMzXfxH///////6dtEb7xHzjpaDijmtXupVTZqYx7MVj4U4hrfqmi2belGHCxT2aSKjA+OPgzD4OlBsDwdDx9FGDnMeFlVKFhYWOZZUYccIxSS+PFhCKEYRmGBAKBT+kdlgaBoKMrBUFTxUNAAAQBDCwCfMXsckw3ESDSiDYMDwOAwaxGjAdJiMhwZg43wGTHfIDNGk2NgSbNficMKHMMcBpMvUEMAjLMZxBMgg1MzStMuG3NCWJPkAfMR2tMcgdMfQECy4bPLm5sRxZubXpBUAC4mucwUBHAEKj5+QiZ2+mcG49bmoHQqHigE4LPxIPMgADCyUaEzDgw1AQMPGwSCs1Ao0YMAjRuOhBjCgYYMkzGGDhiY2OgDHG1pMn4jsfwp5MhMT9QHv0iY3FeLOn0aYnO98zlFF2MLft63XXe3BiD6RyBYBp1t0zXIQ3UvIyxpaI8qfBeDJWbz8oXg7LNkrJ5mb7NSlb+NzZk2axnBDD6eMUj7285i7LKvbt+WWaGR35+UZzdPlSx99LNeXy+RyiQXUxFK30YWtZIQHABbiimYHn3/hh/H5Z26YVBR0GIgFp1KvBhMKoqfKxn//wfiCHGlgEOIQREYMeNEBAuyIGRwiSbBmyLODMwzlvTYrzTgzHLjTAjJMjMDzZjTKGjEyzppQoaJjqTZlVZsWJqy4jFGgTGcEJ0N418wiA1RYAAigoaN6Ar5hCAcMrqVq7ZWzowQoxABRgEgSEAZsSAFACqGbfnDcmpKjQOWBUKHIAKBZOgnQaMwmNEOWiw4IDggoVkDLrTYrTQhTAIjVHhIY6EIjdsBjAJBaMYL/++Jk/476g2TKG93aQqfrhuAA+vApXZEqT3NJSriuXcAFa8A4sxyybTC+G/MKMYYxdRDDBQECMuod8zPFVjFsF/N8ls8KWTpsmAkQOSAIzYIzWzlB23NvH44kGTEjSP0nY/VfTfiNMcnQ06bDHIIj5mUPmxyeKP8GjgPXbkYg4RAR5eHezjaRLIIcAgMG4Qg5ai+DGhujA88A1Az545IM268yTUSjiAqAGpgx5kTxuziTIt5NYOER4SCAFMAggEDFqEAihEjhqkUcjyXBZVfAOJKDjAF4lW4MoXpHH+dhpjzspa4zNubM5cq5PVoaiqaL9LqWGaEommLEAgC0F6GVJ9s3TTZHS0UPyxi7RoYk0MMZgSngR/qSZuQM6jOo4/smhd+XxFusB0i73fa1HYdYZOTEBP5VrVmwtZir8xDOXt2fp7F+wM2WJtmmsk+XMZoy94WNw7C5PO6a46zhwm/EIpH6N56luLl/9FKDMVgklQka16NAhQUYsCZwId96amCdVgD0KRpgExj4JnGR2pgQ4Ni9O2SCLAgaCDOYDUYmObBsagMeVaXnJiRiEpFPNFSIjho25oUKjMgfsCQjPEYPM+9NcyMWROmVcWLPUDBAIMGeGGpXmnImvbm/MgJUFRAUUFWOYA0byMaZIyRiZKVNQfMyHC4Na7lmrOxstKJL0hGRmVigwgaJkaIgcdSCQwZAUoisnsbqMCUGUxPzhjCEPlMmEUgwRwsjCwEtMIQDczgC+jX0UNMSpEAw5xkzA7B4MYwUMBDXmJ4E0YaYQ5gLjoKQNLgrNTwsMvp+NFQnPsy5NH08MQQ4MXxAMmQfMQB1MiR9MziWM3hdMWxjMdAWMWClMBgNDi5MJAaMLCpMLhvMcgrMVgzBgBCwQg4KxGDRgYDyA0w7AUwCB4EgfGDDwAzAIRy3ZEGSBoUCMWAZOkKACBAMBgRlw1fmBgDAwH0c0zEgiwAiRiQ6XKtz1FYAmAoBQw9CQk+zWCVBBUAUY5ZIxkAHSL+KzuQ+DU6Z6odYbDNd9VeLAwevhxlTRNbjzioBK3K+j0ee2YlMNw6w2DV+0V1/YDh+w7L+wU78PSHenYfaakTTIJjU9Wtw/LZ1/Y/GJicn3GmoxF5DD0kyu2KbCzbobNqV1Iem5Vaoa+Wn5s4wBXhm5QzMUrRaGqbn///////////////////////////////////////////////////+qRYAhWLB4YkCEkAJsmmpEFDQc8LRkxqSqLgc6dqppRAw0BNmKaYoQRYaJJyOHO2bCwqiWfMNcxEAayFFAA2pdzOfVkY4ZIpdRO0EgF9Q4YBKAwggJLBAyCAhBJ8mYEmiKEHGjSSFBc8tgjnunbuwkVAQ9JQEUVakDadHUuKL//viZP8ACsVjygV7oACz61hAoGQAcyGXKFnugAJ7MV/DATAAFmQcZrZmMGauAEEdbOlgAIQIajG7WNMP87QyXijjERIgMfUgoxcgHjC0VaNKkzs0b0/TanNoMVBvc1bikjLRIhMYsQEx3QWDDfA7Mg4WIxIxGDt7RDZi5DRegjZzmzbjLjkFCjS4bjM8hTGUOzagcRZNBK3jQkPTB0zB60zB4BzGUWTHUbQ4yjJUKjJgzRwDCIBxISjBkqTI0EDB8JjEoKDCAIDD4CDFMVzEUSzC0NjD8MjHcAjCYSTBgKzAEKTAwJzDATzB0AjCEDAwfzBoHjAwEAwBCgAi7hgKGgMAUskjeoyWrKgELKZChyVtWMugrANd6nIJACFlyiIHZE7QXAIs+mAjQOAOj0slL1VVBYOAovQW8Vw66RawaODXJwKgOwEwQAMaCYeAJ3kSBwA0qV6CIA0bWRo/K3PlEn8HAJTnXcYEABLZFBDZWGIqsgbZQtyl3oCYdX64MAyoeAJhzIUbVnrQQeYW7bDYFaEliYAgGjetVylg2pJWStnsXUug+11CcpU35c5HlvEaF5BcAFrR+TtPqe88kkckV0/iCJMlhspuuorFv//////////7BNn4Wq/EuD1Qb2ALoA5oGAoIyBfwGwSBwGH/HcGAA90EzBiINkCxYP+LABhUFv5dANYAucOmBvIDUpbAAKFw4s4TkKKEcgDBAaAFqDEQmDEQcuFkY7R/FCA3iEdCAJOCuhcMTQskb4YMIoQ4dAyQ5gYHBqwR0ITg1AYhjBN/xC5FhCUjyeGYGQLb/kDLIsoPZFjDFA10KkxBAADzA1CPMFYS0x30KDD+D7MGAIswvR2TDmHLMvAl82SFHDCBLvMkQVcx6gODEaGZMPMikwiAmzAYBCXmYAABggCw2LM8wjOI3OIE+eLA1QDoyjCIwxDwKgY9BgyCxhEK5ncBJk6AgFAIwGAVH59gYC5hMEYjL8KBYWzBICNTglNZMkuyyhZKCi/lDRUEjAUDC5pgQBadCP6xQuBDS2SonWYfkNdvYalcCyPf3M4CrNdgWK0di/+EuqRJ+s52OWqsy/sO40E87MVjLqxKRx5ls5H4zT0urz7P796gv0uGqlLjSzsappVat1JVR8h6RWpVbgK1YpZ2s/VM/V6JTymzNqrcq80/sGRvc4+tFNRH5BFrdLjduP9KXFvRGMP9uGO1N5arVIVGpRYuyAEAH//////////////////////////t//8/f/////9a1bi/CFBqjJbDSJ0aRpGkhxzFtHpIShLUhzkfpkkxABoAJBipwSYJEOJRPU6W0QkHKEhJa2IdALcdTWSkhLQSoI8S1xzBevdeQ/SCj0lxVNNsKtfSp05Scj0iahHRMf/74mTUDKlPZEqXe6ACj4t24uA8AOiRmS5u8wnCbzKaHBjmeEWCZAIQMJeTeEKBzA5iEqHUoADacxiACBrU8Rr6JBloSQsVZpsORku15r85Bs505hgr5okzEZxM4xg0Jyx5xgJTmcDoYnN4CU50YVmE42dUkBjaSmXY0Dh4GAJE0x4EASLTPYRCjCFi8YdAaC48Cg4OBgGAwYMFIcxgCg4wgoDCwJTDRbYKpcXVVMX8QZLbisgipf1mDXVTohkrhoKjiO5bhcgqUqCGIhRCGbBjARVcgIIxq2Jfv2y+IAIcZkNI7T+QlGtyGUKxwNIXVi+VIySAWrTUPyKKU8TfeBlbksZe/bC1rOJKIy5K8mG09JyloJucm4bTnWw/kMNjgCDGZpkPGuSyyiG2ULrljO7aV7EGnssqKWTLsMMXY7I0NWhxmTOrfo22T5QiYrDxf4HhCJruS8a6nuw5sAjAgBdadlcEKYKJw/Gb1p8C8hCd+meLbZ++kbsX+QgAH8/y///////////TfoN/oN//rNhwBs4b+AbwsqQgZcGAGCiGLiIAxgkTk8R0Q2jh0UBBmeyHPl/C7am8illPDC0xQ4xAzuINGEHBIGW5W3AhFNU8KGnG+DmxAcawgjHBQ5adW4MHXJHZi7rev/eq8oetuSHoYEbp5dcGlHk8ZfZwkHc0zRtRYAx1wEEaQD/GYoLAqThykldy9QRBgFZiIkHmCqZWYxgWBglgTGHGGSYCJK5gQCqm02KUYmRnxhunRkgFZjggJgeqZmaLZoKGRkmHxjIOpnuFxpKTJjbF5hYIJ5OEJi6rIBGUxjAEwoBMxHHsxWIswXDAy9GkxpMqJzBGAiUMgh0kbFuIMbgmXFmTBih8woUMBkwkBFQCWDC7WRISYpwOKA46DpQknAhkRADAEgAkMcSItAAKGRKiIW9CPTntRDhAhCNNcZYB5VuUM9HofqJgLlRkXcttebXlnO+sMkWsHAq+msIqCQRIhTNlbtzzxtZl7fKnoJBGXNeKUOBOPJOV6J7n33bn5VDdLemHSnIAjMHPvFqR9mswHPe97hU8hqxqSS7UCS2Uvc7VDDOEcvuu6bttvhRV34mXxbPGWLv+/N938oYom6QdQTkNvnVfiWe8FJGYIilvv////+YEMHYBg2oH6eAY5AQE4wpGpBxYJTXXE2cpMXGTIhgy2JOVVRBAHxXgZQmPp5sYmY4YCx2zBvJfcu2lyAEtMOFRGLmfisBTcMKZhQMKjOfk9GLEhqS4Y4JnD4Y91DTYZmHmYLxr4bBTic//////+q1+uDRM3p0ACKZiYGdFgOpDOS83N5BxkYEPG4r5ioAaFCGoAxjh0JEA8AvNOXKuVgJgxgFmK8HKYcxPpgcjEmGeGkZBAMhhGnP/++Jk/476G2PLC93SUKLspzACm/IsuY8mL3dpWsExYEAH5xgmBYP2cOSehkrhmnERKGv5EGQLbCEnTb0ZzP4rDC5twAJBsWBhr4pRoxiZrDE5jlDxq4ABj+YpiyGoODwwVJMxVMkx2GQ1eC4xtrMvAQVKGWKZpJoBQQ2qKGEs2lHMXSAxJAJ2YoIGmDA0MhcvNIEDNgExMkByAabJhDuaULGPERmh6ZmYmNCwCWTJyEzpGMwATJQUQlIcXmTD46UkAArAYSDl9FmqaDIKnuy4BGCL6OYsQBYJoAMBI1LrXC9IQJtKhlRxNNqachalUqgC00e1h42t1VVP+UKsQ6qYOfSxdSx3HbWU77lpfvRMu6sI3FEstY+6zGHv0ulaMBxNm65rqQixY1ZYozmOyCls2sLVmkdNai7moKBvouxOWlb1acSgpoETZfF4BlrOGHuUw6Ivi4iyWYPQvSWqiVI6aIEIZtWe9hDJn2cqEZSyz2X///ECrxJibocSwu4ua2rF0XBkPxCNQHlMUgTTpyLGiTNSgY4TJTN9QHkseBr/q7leleWOqsOWKTeqkUUrcc1yQceq0MMDiU0gqWZs4XWPdEwVgNQQjHAgZCUVOApD9c7v9/PVXMhDDSAQOUFY2qJlbYhDWbyh3IOwYbZjpmKSYc5b42BiJ+X1Ofrn/rDmG7de3mYYxhLGhckILGC1BigQUzgt4TAFVhfqHwUFhqKB69VMQU1FMy4xMDBVVVVVVQAASnwADhhg3BlNGhxyMJiQExmSNRipDZmGnBqViZizQoko5ouKRjYb5hsQxjOFhkEO5i8LwJE4aW4ybI0xyPc0VGEfCUxfKAwgFkwNBMsqAAyXsY5BMZRhAIh4OJGJBr1AIIAgDEszPKiMUcASAUghMkzwEgUjyQAkJMQw0SDaHN/owbRaQrKNdoLtllA04xhypQpmBjJS9LqyR3ZU/L+tm9+F3JiqJS/SwsFFnFJJ8wcks0lTBr0zSQtqzB20d9uz3MIYKpc1VynjVhdJbbKEgaR0J9tLUsd5u89DNLSvg47ixKP3rFJJrkxldaSxKKxWVMjdJj/4axlUjpuTURep2G3uR+HYfmH2g2ehpiTgxFnKQieSZKaZoFJjOuyxzn0Xe2SldNcK6lBWbuQmZGWtLDQQ0p7nFg9gtnGfV/Mcm6rvV2vcuIuxDCErIXQ3kXlsr1K8pqzapJxnfZiSy2NSx8mDyiV6r3sqkUsU/alJTUVykcSN3KSC3UpKSWZ08ricTYoZ0BAXgBxS6yqaPKI7PgcZwWLqbpcyhYJa0vtfblGqTBjfE7Jico9yhZCCFeyIgYdhyRwkNpDxMjkUvp+Z4V+/38886kxjko6tZXdRNJRhrsSh1LWBXWhygUCcCTVZ2f4A//viZPKO+e5kTBu6zRKmbJiwADjAKJ2RIE93TMq1MaIAAOMBZgkAfmUiTOYprCBi5F/GA0CCZPRgZipoemNOO+fCp1hmcCSmcKICZJYJpjZl5GD4hYZDYQ526VJqa3ho1CBgkmhrsVhvZCBy7qBzZc5tHfJjAw5haOC0g4AzBArDH91zU5ZzpxxpKZkIYMMCQBZI1uo/PQ+dg1KIKjzTMTXHzNJzNkjEmjUmAcuQZNRBO1fN4jLuGERmyVmWDqNGZUGbLCTIzJ0CEw4dBUFMhnYeZ05SmTIF1R9HlAKj6ylYVxXaiK7VtJjMubqprewiSPSPzLpPMSJ6n5pmVKmd5wYBUFdGVtZpHpcl3XFuwA7sZqTNiVQ9IPfeMRK1hZtVYxBUKxZTDOM5ay+tdpqa/Oy+YjLgu67t7GSPnKH1d2UQ9bsQOul+XRSFdV9nKcppTNrz0qAurAWp23WeNlTXo7SvzruUqs/C/NRIdk825J2y3Tex191wyUuCrmWxB3o1YkL68ob0uvSOMshYi9TjPs/UZs0sZnK2Nt2pfFXaadAz+w7EIGmZmvKX9x1elWLG0VmbOVFjAVCSlSDiggpbNMAGiLjUawysTSVBWnS6tfpn+tYKPtDgxHWkZ09ylsBqAiECfbSnRdpQVuBWNYV1qGK01vWeVBjS1cO1ZbjDM+zJdSQ0MqecZ2nOvvt8BZRF+ZRGgIKVAD3TAYQMExXYEYMPjISTNPgwkwdgAKMRFLGjDUCd8yZsFYOJSO9jEKTH4w1yGzIxGGMap1sywXRjJNBkMppCQxHlEzHgQMNOIeU2m2fzIcwsMlJNQ+LygDYyc8MJc1s0CBgjA3B/MIwCUFBXG6aXQYv5ux/cuEx6MIAdd4ECgCJhigHmEQsAAEYOAI0Em0V0sxFJgjvpgsmvlQAJKlmk+yICEALZ+GA1mBiusm5E0YLCrjmEAUBgpBetyB/nsXY6suciZtvpCYeZ43JWJDRi65ZaoIpGhfyWLqXIoY4L+tq7zQ1QqPtUliVz8NJXcyaYhT5OiypQWC3LgiWUcusSmMYvy1mpVlNNVf2xDU97/TMpoL92LsYd5/3dYjMy1prWHLfphTJmVMOduTSl6YAnn7jSwtiHrF+7jhS6v2M7L+wzZwr65hV5zOtZS///++SrdK2BNIOEFHkyY8IQL/p1c2vgmHbjhRqiXk41uNSV1X2bGpdTzstdmxGmVSO1qhsZ4Q7GbMtgt/ZazmkjUPPTA2Eqp4deGBYZS1TqLJOUoMYTJFSdkQoFbJa1kNE/rwqWsRWjCpmgnpTKbE8qqthfD+HCN0bugvSYg3jLG6eJcRpBGhIwvUsnWxmv20uLxle+uvKdLwvocosoXoiJvGUhW184WFteNrCst02AAE5dTP/74mT/jPpXYkST/uJSr6yH4AMPyizNkSp17gAK07GdAoGAAQtAZMOkbQwnBvTGbF9MGEEcwUB1TBNDJMSE1Iwr1BTDXBtMPwCMw7gcDBwHEMDsUweEtMZ4DEwjAQjAOBSMjlEw1cji+oPiQMzgWjpaSNJHEHhwxECkhDAZhNPoAaHJjUAmFw6XzQXMBgkwQGDFwgMSDAw0GjEgKMBBAIBhbSCy+hfAAAQEAAOBC8FpqnVSSHMCgFOdaVpJkqiszUAAEGCz5etAOmOgu3y7GGS1qZchAI1hZjMHcTERMAwHAoDLRpjrnVO66p61OxPOhoJa/juNYR/TDiBexBIBgIBAIpYuiGIYnH8l8JZE5qCRQMuOYDAZf9BdCWudbyVhddB9vpThPPW46w5chXDEC9iahcAuAXodBYZta0gWO4ccUUEgInOvNAeDQOWTMEgMwOB3PZkYHAJe8BA9AGthdjSVhyy6VkOqZuvm3RQRdFDRRt/4bk776h+Py2neh1HIjjiOxOW94f/////////////////////6yypY81qBmQqavzJGdShnUi1nGaXkqjNSGp6ls8uv7Qv7La1NnKb1NymzpZTLZVa7Eqd/bEatfVjOeOVaNTdFbXLD67ZQ1VB2cdO256Lw7AtAQrDljNT2lTZLc0CdsCEcVrbQ1DU2UBqJp3SZhAWJOJHdMNx2R4QLDsmfZrSgTfODFqXVN3HCVS7HW8ddszUasu1DapX4Z0/V2W7uS6U0WVLerEkAAAlMAoyMwoyzzL1EWIiUDHXJ2MT0NwyDxoDCZeoMYce0xEiHDB3C8Mrd3MwGiBjAYARMC0OwwnQhRkFUxJRqDFxGoMKTJPimDMHTeMu25MroNPlEANDBVMdDnMnxENCxZMbBcEAhEThGRI+GixAmDAWmH5UCRTDACmCwEmNQzGNQvGFQCGLghmHo+GF4rmEQDCAATDIBjHcbiwDYWBowrDsxBEUwhAkwgAoYAIEBGYTBCYRjsYDB6YrC6YJBKgKGgOBQEgQDAEDwCFYw4CQmAhWdUyJhjIDJgMB5gAAIwAZgKCQYAzDlDlzIBiQCwwCWtDwADQHsnh1tFdwKXOlSapgeBgYA4cEJgWAAoAigYCBVkLcR0AC4MSUHZezth7uIqI+BwByd0VbmkA4CldRZMkusyZaTEljNxaEx9kM40liijqmpIAZbdH9bjfQ+k2rA0R3odCwAo+J9szBwCrpcKAhEAYVAJAcw4CgEWfHAJFgmaIPAO3jNqVYyKTfxrMwOAAOBJW5CeDQHpHOL4GAADCQAJJpFqXzkvT3FABCARRfZ0v9H9BFA6+1Bn+Z1SzX////vmkRygMPmW+f/ec1//++f/Mf///9b/Wt444c//x3rL9a7zeP6////++Jk7QANoGZLHnugAP0MNmDA+AA6/Zkm2e8AA26sGgcD4ADfN87j+X1ccf/X9/mu73/cd5d3uz8qHADQEEZ+v//to2AYLHW/7j2SiICoDAamHUj0YlxAxECkY6iLhhUgRmGoCUZFKTRjTDnGGOAeYRQCCYZhTqBGGeOgapJtJrFHRGHCFcZPYLx2HTMGjgQIYQgexhZgngQEoxLQPjQDZ6OAFMk5k1pjD0GdOMxsEx4l3DTXP0MfkU0xFxSDBlAhTjit38v3vH/7vHEwJgADAIAAX5nLP7/f1/98wTAOUeS0LqQzwfaWkWhtIKnSJVX1LE//w7HD2QYeBAAIAAAAAZjL6N4MdUaEyMTyjCmFRMeg0wxagzTKsWhM4IX02onljXMRpM3eMwzLxDTBJHhMDULsxwBeTCjHKMDwVgwAQujEwEXMKQmMyCD7zMQQwMXgWMy0COzDFAyMF0B0wRgIDGbAzMIgZ0xLQujCUB8MJYBswTAKjA7AaBQYZgSBMAoFkwlwWQKKMYIoRZhAAwmD2AcYKYDhgjgSBcB4wLAXDBGBmEgQDBaA+MDYBIwPQkDAjAiMNIG8wNAHzCGCVKoJZgEgSjIJhgMAXICzBHABMEACQwFAAAUAkDQEDAQAOMHQBYGAklAQBgCgaGBCAAHAplAKxgGgTo0IBWquKYBgAIwASAgF2ehgDCQSWhgMAJlgA8gAeQljgAgYAuXGAQBKDLiq6XG/atoQAGge3MwGQB1CgwARJKG2iIIgCAQXMWoYA4AiEtJJ3gsAOxFKuKuG0JHkoAFgBSsWAGU0qK0O647R36lz4pViQBQFADasjrDLX35liSUeL6r/YOnSmI1tqa9o0zZ01+A4BsvCj8TAAmAKAitgWAIR5CAAy8bZXopXJgcKgDI2pCoQI8p9KZN1fJOpsTjN1lllfyE+GEFmRq5JgAIuhIYwii/ruxB0P/9v/9gEAB5lOYC5f/3/////6/////e///////7+t7//1+///5/61vf//6/+/+uf/eVsd/3///5/6/n/dJAKgwBfWW987eFQGhYG////+o+YGBaFDNzSkReNcFFQ5MZXDQxUnNhQwU2SnfzCzNKMvAUYwbwMjBiAmMAUsk2KHpTW6RZMJcUM0HTETLgP6MFwmkz+FBTNQHbMDgFUwMAJwAOCYDwDJj+iXGBsLgYRwrJj1gcCEC4w7QzDCRAiUWeZGh3LH6//33//+hgBs6EyIOhZMzZ0d27/KFxrxV1bv7KFJCaccb1ltMr02NBCPMUiQMrAMMjwVMbkUOQ1POPz2NJOjMwAyNPhZOlhOMalPMkhOBQsjQqGgIRByomwtGc1ZBlhGnRkOaklZ9WkmjAGYjJQc/TNADMCBUyQAx0cGSBsY9F5gEQC//viZDMADIpmzZ53gACJavaywFQAKsmZOzneAAKRp1nDA3AAA3EArMDA4IDrUk6lymHwsYZIg8vDGYLBA5EBWMajswqDDDw3EgCheWWKwE/ZewxYIzH4DMGg4WEhgcXGBQkPAILA0qBUFAMGBNeheIulNl4TKo1SVU3GQOQA0wyBzBgaAAQBoHCwWBQCAQHaABgQoESACGFUWvQEjEAhmooRBSVgwKMLIgwtcUARd0YBgJDq1wwAjIGbqtN028nWlqGsZh0sAUskiQ1wKgEwEAkSTA4DkYYFTCIKMEAUiEJQERIDGEQAIgiFQEIQMyNLtYOxD0YemMyZStTywTumEwGVAALAZATC3SS8dh9kIUGojBK+S+qHZ/Ubl8psQGnYpvvtG5pCAlh2qt4uF4l7M6bk1SW1X5XGNA4SDoOCZb5lpg0DtCl0M1S5SHFmMHcgVQAAA/rf/p/9V1/7J6ev73bTft/+n1v01CViCCvVI0Ol/XcFDqBiQYAYPWgGPF2Bq6OAZyLQGNiWBnIKgYMDQWhmQApwA322gMojkDJwfAyMEgMroQDFYYA0mgAFhGGTCTCkhmgCQcDQJAYiFAAwRAOAoYBBsEXQ60+/y6z8/E9JfX8n////003gdAAQS////3kKomZAOGOMAgZMDFGRzPIdzLu5DA8XTA5FjddFTA6yzG8dDLkQwwjzMRPDE4STAIMwSHRhQpmHz0aSKJmVymAi0dzbBiIYhcbCR+MvhEKj0DB4xuMgIVwEXGqgIAhgEUmWUMBhwxUMlitfMFBceJhgEAAQCoAA4ImDAaOApOEw+KSEBA4JmFBUXuJQOYEE4wEQcCDAYGlgKBBIAlrq6MkBQw8BBwApbo/mCQGYpEBQGkVRYAQlYyAlTF+WN5M3fhFNNRZLrrtbVvC6qpljOEup32mtzL6wxFFKaypWz2VdBAMU3GgQ/8hQqQAKVtUTKSGeSagaSsYhpgK51hovNUtZlUWtP9HVN15p1yKq5cuikvceNtJZCxrroNdizcXKoZVZh52p23dpeYWOY5bhiVLEfdpsnsOc5jhvTB96rlDtpOZy56XZRm5D1mtO372AH1P1+296nX/tRUpL239qkn6epCtbe9SSSFb3/1JPSSUl9TV6KlUV1KUkBgA4FKBhBITyBgSYAWBgY4RWBhQYOKBgeICvTvAwAADYAxL4W6AwHcBNAwzchzAxoATmAwUYCUTTU8DAFgJcDHURt8AADkAxTYF+Ay20jtAwDQBoEkREYiYIjfl44KEW2NEQdnU1B0j+UPnAQPyB+Q9JIqIg1DrSRFWgAEAZUAULbWS3f8xRNzNsFApzNPicw8STGZgM8uM50sjTWINeHcAUo5akzMQXMojkwWQBofGpS6Z9CZwCobomAv/74mQggArPZVBWc2ACmonWlsDcACyFlz+5zYACaCjaBwNgAB6PNKzbo4xRgEmww4OAyQpiYSbAgHDq0zUbMtAwEcAYDGAIOBAqAAwdMeB1ctwCAMDC48HjQWXMBQ4ECbLAQAiQCIgV2TBAdSK/GOlk0bzIggw0DMFD1jAQOV+YACugu6WzDjBgeUAtuaaTJEz1KzAQFA9XDS2TiEAHhADCTUEAwQNJHAAEQFBQGZsVgo0Bl7k0wgDVjEIC5btI9qbyJ21F2I9bKv2CmPMBhDYEFFzrJV0jw3SPqAwzCrbyx+lglE8OAF2SuGZXCl5Ps5LMGMP69QOB2D07bNrArOVblhEB6625NqzG3TbgWAHxdyMwavOQezJ51BVmKecNGmJPtB0USvXtY9JphLLmXA4EUEZaw9g7U0xX9YJMRhBAqriBN5v8CJ+tft//b0EGWnSWi3fQZtFdaKFenqQZtGksxRam7vpIGiaaqDVLR9ffQ1rgYBeAWAY1cGpAYGQA5gYRCNjAZEWLmAYEWANqZeBgGgAaBjfoDiBgYYDeBiQpRKBl6Y2qCgPlS4GAOgA4GNfBqIGDIgTQGINFtIGWAkBQBADKYc1Bl4gMi4KnSJJtDpx11n///SwgA2AQ6LC2G3LLI5f+Y/aR4uZGOiUUNIzPAjaaBOeyk56sDPGdOEI458cT8zRNajUsC82Ial3mVj6ZUK4FsjPL00acONZjI4w9yJOAETLh0+UaPhaThoYSNzEw4wkCNGGTa3YzDdOcZ0DRENgJFCGcxcDFhQwAxFiwwkEHC4xsoNpJDEgUxwfQYBIGAisxQaRPJBMwoRGQYhBw4FMSBU/0ZFH06BoKMFD3LgZTJ336BJEibNLNkBZ5Q1DZmoEB34T6hYcATi1kP1dqOsjLqs2fJDspqzxiBfJoZECCQCowzpTFhiDKNjEH0Ug1zAvQyyOJVKCl/WFNWAQCtdH15a8kgpwWsqllDYlMq8tnJA7rWY1BD2SmMrCRN2V0vBK27USmMdUpR3VhcNthIGEgBrmiYGYIrXG1rAAHQsp/RXXe3jZ3CbxhyekMNagORr1/wMAlYaIwNYItMieDgVC/ixWBOMuHEEIaeZggslzF9tX1b+/Wk1T/WpNnVUkpL+ipa3U9SSTf1p00UlvfZ2Uy9da1MpaKSa6b2AFDYB69rgBokCcBr4nEB04q+Bk6AO7VQMHgvwOclrwMAo3wNmIWANdL9AMOYFLmrwMHYrgNPLRgMi4jgM7yUQM5yxQWHwvearDwXQwRUJIoGMB0+EiRcaDoXr91f4o+z/uB0vB1OXUATApAcMTQRww3DQDE8EqMiYeAxaClDFwM0Mb4qs130fjDDCQMnwb8xQQrjCrDvMMYCUxBwNDCwArMM0FYwKj/++BkH47LWGPKj3ugBnLp1mLg1ABuTY8mD280gfsz00QDmhkKTIMDTU45jaVJDTgtDt9CzSYwjG0CjLwIzIEEwaExhYDBjgChlyUZi0NBgSM5jsOhjKQZgqEgMAMEBEDR1MRxWMOgPMOBcFBBBQBDQXhQEBgOxIegYIbJzBEKBoyDAsASYITCoEkUjA0CRwADAUAw4ODAcAh4QAcBaIieojAwuKoEyAtyvOnMAQNLUGCYLtBXKjJBLtJDv6lvLy7MoXhBLT2UiQOL/WO/TTkaUfkmVRP07bKAaBcKZzOpUMZaChg0Vo8adReCmtRGyG42xKHbsql7Q5yCYfZm6TkPwyt+IRTz1HGZ98oZlDusac2lyynoZfR85TjHKWs7LdHLb6UwM5L9PG9kSZoipLG9VFVZm+jMWqqLPKyahet7naeV+4JTQbK8Tyy52Z92aJcAbD/89TL7f//////+v1/2qpaOtT1OcVSVrWyq6KLVJI//mI5IgKLCGQQMCBEDDgtAx8UQMvGUDMRVAx8IwUAgb0BgkdAZzVAG238BxGGAbzZQGmTQBj8OAWAwm0ZIckZk1d//v/oCtk+SitPGNZZXpl8cYgIkRjpinmk+HyY+wGpoLnRmDyoKYJJtRkTEBiatpjRpHmJ4QuYEgPRiCi4GROJkYsYfRiAhgmCaQ2YdIq5ilh3GMKMGYY5WJhsEDmdOCEY24FBgxBOmHQDqYLYE5gRBbGFUE8YSwQhhECHGHuxjygdZ4neH5zrsY0PGyC5tgiba5HfhZiruYxZmDE4tRkISYsfmYDAEhDEzwGkhj5OZRGgpLNkKT+dDxjNZVIashyGgNAI4N9kNhByBnAAl4u6HqF3mTBgKFoMCM84I6CtZrFoMIgAU9rMYICDDUTwByKe6qIdCGA0D1LnEQSSYQaYwD7qrKkMwpIKiSLRjYGgWEFmSm+5bcWEIDEuF2NLVXkzvLDK6XCyl8mErRX4XiXVB0HIwSxmFtCQpo8CBxd8Qis7lzW3ypYaaxjfa3IK05KVz432yMpZ1tkz6sEfPF0V5rslzS1itsuaGKF+HeisAtFj0iiT7MNchkVK/r/wQ41Z9qIA+p44HZckA0vq/2L1saFn49XFPD/s+PLPGNs68bMnXi5p8mi4WiSLhGi4vKfDTrUdLXhpVqSlrzKlrUSNjG2StROskagkbC5g0pZE60Trp5OLQSNQIlJokjWvJZ82atQKBEwxI2NmWeNROLhF/sViQaIsSqWf/qkqlWKqv+qrAAAAAEk5zBUWDL1FDqhrzDQAzVx2DUKCjKxIjUaFDnnDTMoTjL8iTNoiTIY2QSgBiGBxmyCxh8hAYTRjSAQwZhgwnJlqpZokketHmQ0ZkRiZcfA5PMqSmHGarZaYmJQj/++JkMAT692bMU7vMMAAADSAAAAE2EZsaL/M0wAAANIAAAATaHZALggY2GYhQARAVJGklQcGjoGZUIBYDADZb4T8AJYVKImQj4zpAuir40aBGEYIqqhpAp0hhCvwgFVcoMhoywqot8IynXRUHk0rFlwI9AseIhi7wiBgEWJaOygWPSKZ0gs66WytMte1gcCsQEYTDy2iixe4aPo66lKTKqSgiYbVmN7VxHIUre8zLV9OYo6128wZEplspiRdELhpERFfSI7+UqYNZPpsjxNBW8XkW+p0nPPuw+sLaLKIHVWoUN3QR5jStbivbHG4TDX2Sv0jIj6IyQAIJVNu7QyOXukzWYEJAFNYIRqVWQ+LUl7y3TX2Oxtt0KFIqgYG0+u+7vz4AmCjgmZgD4VmZJ6EZmGhheRjIRJGY7qNQmEuigBkHRCaaNuU8GFBFNRhswREYb0AJmAdh7RiqAH8YSACimDBAsxhVYwcYd0ApmDygKZhZok2YWcCTGK1gkhkWQGGYL0JKGDagEpgtwE+YGwAqmA0AVpglwJEJAXphTQJwZqbRiJyoXm6Raa8iZixDGHkKag7xrFWHxBkaFkAUepqQJhZcGdF+aSWw9JxkgmFCwYHKxtQemtqEZVExlkpGfQWYKTpjsZGiwCa2LpmlKGZCuYYJgOMQADZkscoInQNYQr5BDYYAf6xggkWIBUHkCE9FQ0gj0EM7sazL1hjIXDCo4gDEKIUPO4s5QS7ojBJohLownVGyas2Ok4BpAMaR6UNa+7gRC3AicEQBcgiVS8DF3aelQFDgmW1su0CCxCYiKAnHhRph4vKhoKgkI0yo6iImWrGm8ioWqGgRQRwUymnLWfAOGg8uqnsmYm+19lbuDgKZg8GYgLV1YWzOumUEBuSKDsSo0Z1+NJKCGps9ZwkqsC/y0yYNpiPQjJa5FV3s6WuGKrIflQ92kh30UFdhoWUOS6TqAAAKUMDgCgwvQVDJaHYMOsAcx4yFjI2CBMQcIMxYAFTXIBeMXscUxPASDDyA0MDYJAwTQ7zCiBuMKQJUCDDmCcBwazE5n15GjvsaVdhkpnmbWGZJGpoAWmDhqgUAjcYzApmExgASmIgKYsEZiELo1AIDhwCMIlQx0RjCgZBJPMEiFJlUDDRophxmHAAIgkEB4yaDTDIRBw8CAUAQIzUaAZbIZChCEHlaGyNezEVglFmmNdoGbF5FoQl5oBbgwp+o/eb5obfR9pbrNIeBbq/FmWHPi9tnBaB30jEmUGWUvrKYbl79wtQB7GVy1oECNjZA0tp6nTwtbXU0iNw8/kZhltGat7FKeNszftPp+nGZm4bhxWUP9E2dOhEHqhrOAra7093+VI0xt7Dxx+BZijlENPwodA6/1M6Zyad724NPlKSD//viZKCACutnTB17gAIAAA0goAABPI3VJjnvAAAAADSDAAAAUlyP46DAKaBUp4Dmm4KOunC4EtSh2HKisPV5fKAJIYMi5xsyI5GYSMuYfRuhgbHsmgshOY1RxJj0lkGcbQmb7xE5tsBEmg0NGYnYPxh/C+GQ0BIZf4DBlDiKGCeCsYaI6Bk2ibGX2YgaEw+RgSAbGI4K6QhMggCwwHg9DDJB9MK4XIyCgMjBNFmMIYNswcgRzClCcMBAFswXAKzBICRMZcREwMw1jFoAiMHsGAwOgSDBICxEAHA4EcTA9AwCsGgKmAcBaYCAC5gnBiGDiEqYOQVBgAgOGCWCyYHQApgCASmC8AIIgFzAuBRMAIBMOAqBAERgJgXFgBlG4wRgbBECcYBoJoVBIS0KAYzA2AzMAYAEwFAHQQACqwBAHJ2oqR0QAAKCF1xCAIBgIRIH0EgCLAhcAQFAWFUBJ4wwAZCkYAYMBAB0wGABUxQYAGlaEAApeoVoB0fhoAlIshAaFgBYHDgEhAAONALKDImlmEqlblfNHRRLQrZU1Yij8XwJgEEQXpL+MMRWGgB4EW0XYAwAbNRUAERAAGAIAGRAQsqRgb1iaZDX3biygqKiubrVGk0ReJRx10lEJ5cUQABqteZcDGZ5OdfsCqdqYww1ov0xFyGKq1iQAC6XDaVKnkwgR35I6cMt3dqB1hVtR/BlLVpDj/////////////////0vP/5iTEFNRTMuMTAwqqqqqqqqqqqqqqqqqgAAEJOTBhPHM/MrMx1h+DQwHPMSkmgzNSCTNUcsNYUS002U6DT/CqNklaUz/CgDCmBQMeMDIw7Q0zAaGbMQMMEwKhxDi1NjkaEDRQ3z7SGTmVvza83TbQ1jOkKTVlkTM41TSM9DZ01jNUHTBoyxkEzTsXzVUqTG44jDAPTGRATBUmzK4aTAkUDMImjUEJTGIPjFoEhgSTB8PjDQQDAUCAgHC3JiOHBgKHpgyEhgqBZhALBi0HBg2G5hEMRgADBiyHYjE0wpCYxMCQUAEHCuCg5KAlHhVHQQAQHBgZGEYEGJgjCgOmGIShA6lALmGQQGAIKBgIoPAwASgFi+iK7dhgAXDWGbI646AgXAcWAKCkeESHdBQJopPwPAUYAAZSyNKh5XqgJJJiKwQqARCAS926oADAYAFFG1SPLRgoFEnU4yymIkAaHURgAEAwoAj2YBAYBQOJgQZwhqu4uKj4XOW80d/WetMjad8iYO7btMfUeEQBJZu6AQJTtTjQoSSCAJGgKEIAggDAoA5gMAIJAF6UM2BEICKrPuwxMxRxb0Ps6V+VQGf9CmtEZErxpknagXPjOS74bSTyyjecg5/////////////////xT/////////////////+8IBkP/74mTtAA67gsoWe6AAAAANIMAAAD6RmytZ7oAAAAA0gwAAAAAgiGTpLLJUmYNInhprHhGJSp6Y85KRg8nHmDCbUaXDTpohCFmBCTgY/44JhQTWGgaF+ZjwQ5gVl/mAALIY6BAhkWEOmReOiaQTGfLEicwtyZls2ZIUef0AIaCEaY7FybUGqaKjqYMAeYICsTFIYLkoaUg4Yck6YRESZXFSYKAM0MwEC4xMHICA8wwwaGczeKUxUDUwrD4xpCIy5HYEhsYdhUVQZMLQvMJAyMMRhMlRfMRB1MgBDMlhXMEgqMHwgMkycFA6MLQ6HiGEATGIIKmP4UmRAVIvCICSgICgDzDMLjBgIVEwQCgYCYUAkLCQY0gSYchgYTiEYTByGB4DiCAwZmKxOGLA1GEQTDQMongYSjCQcQYBhhoAIGD0OK5ahIBQGBwwHBQw7BwQAQYUAsIQ4Eh7FQgBAAmJwdGEAVcMDAyAAcGFgUGGIKw2iwYFhKYcBoYphYYbBeNAaYHiUYGBmYRAqY2BqIwEGgYS8BwJIqoVKOmCgNjQOKorMFQJIQFCoDBAOJbBcAm5mBIHGAwBgoHZYDAOBwbmGQciEDzA8QUMCEBzDYJzAYAzDgNxUFlqsSXuuFr7BC/rTrTDYFLuyvtUwBAMSABFRf6SDazS+lEnwfRgEbt4M+Q1AoBjIDpRQYNAc5y+BkA4QxEFAdTWeQAAAAIAABzLaNhNV9gcwK1TjO7B8Mb5hwwA3+QUo6YaSThjM+BmlERIZXLIJn6EbmAwG0ZZgCJialNGViV0YHZGIqFiZTpwJjgnGmJIlaYk6Yxi4lzmWgMiYjIH5gtATGIaCuY94G4BFdMUYHYxCgfDCLBUMUoGEw5wSTDgCxMIEGMwfwNDBNAcMDkQcxPgIQUFyYIAP5hfAYmBCESDhHgIBkYMgQRhCA0GDWCyYGoDRhMhnGB2G4FAwTBWB8MJUGgwQQbzBfAOMGkFwwhQKTAdA4FgPzA5AvBIG4BABMBwAILgMGEiBQYAYBJgFgFgoDgwHAMTAYAqGgKEbCYBFcooAQAgCWdmAmAyUADKNhgAydKfYOA6EABA8BcYAgBxgLAFp8IICIDcwJQIzABAFWUBgH30KgBSGBgCgCphoLGAQA0VgEA0AWqXnBgBSjq6zACAQFgQ00jALAKAoAwBAMTZRyiwiAAiKgMJTHWyPADg4BtS9eEOv6ker9EdBKw1N8eAlLNUjL10Uqjy16ILgFg4ANgCykeHgeNscva2r1LtOhLEvwoREWZsNjilFdYFFGAYOsIKgYAktOBgBjABAALZDwAdiWNibhXV1ZxXcx8iAITAQoZwzxXDQVrhQABulIU////9wAQIQQf/wYv8DXEQGofwiIfwYIQMTCYDFwr/++Jk/4APK2VJRnvAARGRdELKVAA9MZskWe8AAwiw3YMBsAC/wBh4Bl0pgZLIIGLwL/4DQTAwMCgvYBgsMgYnG//4GYQ2BkI0AaEOQGQAQBo9EgaJRf/+BlUNgYpGgEmABmEega5L4FAUFjf//4G4lIBlweAY2CQGazKBnVJgaRH4DRzAxoTAMcAj///wMVkEDGYCAyEIAMfCgDEadA2GYQOzrUGgdA0SVQM1j0DCIR/////AxiEwNOn0DM5vAzWLQNvpMDIo/AyiIwMoisBYaAY+CgGs0iAEowAgwBnYhAGkf/////////ACFYGIwuBg8JgDCcLTgFAIILgY3EoDATHeBgQBBlkGxYGIQ6Bh0QgYdAIGFhMBioLCSgAAAALGaGi8YuBsRhSFHmhARsZJ5I5hsq+Gs5iwYt5eZoku9GleLcbybh5koimGaSQoZW6GBjMA5GHyMmZLQjJikF/GLMRiavJIBhJERmRQF4Y9wdpqSoimR8EeYWAjBglDumAQIMYQIDxQM8YygrRhSh0mMqIkY3wwxgvjzmGoFEYlYGwYKSYTABpgIg/mAkA2ZSwFJhDDAmCqKYYFIUphOA6g4TMxFQQDAlCaMC0GwwAAXgYB0YFAKoyBqYDoDRgcgLGEkB2YKwRxEIMYBYAYFBHMAYCAwGgRwKAUYFQBZgOAABwDQcBcDQBEpDAAAGBwEZgvAjCwC5gfgEAgDUwFAITBSAIMDUD4wGgFACCEUAJCQOQJAMQDmBiAckeXMV6pi/4KAFEgXjAbAQgEwBAAjAqAGQSGAcAMXCDAVxQA1AEPAOggAYvqMgDmAGAEj2KgBNIkiHFsKJTAS2LFS6yrU4yYAxCNAU9hfyJBABSDYJAGUzLeJvJ3sRAAA46AIoo8UDNeZ8pUjc/j/vM7BAACm4zVIRegyAHKmFtGQsSKUPMAsBwusYBgB8ym8GAAg0AcGADypOGaf2Hs0QE4UMC3yZa9XbZZE0jl/P1DuHmAmAu1EMAAhwCgFCMAdD5FZgLO1kqHNhfmtj///////////////////////////////////3f//+Y/Dnw/G5e/ZggcYgBNcCAxZbckfTEzISnzVig0drUbAA1T17cP2/1SWAcBhAGshTdK9e6GZgoCj+ZCmmQBgOHjIz0WazEws5UlMkJDDxbkri/ak5D+WGOQ8Hl6HgJgcvo6kvZPGy8IGCx6CMSBTRjAEk4Q5mQipohWpuYydm0EYOs5ZLKlj///////QDmKBCFiK9Xv/////5MCmGm5jLyGPzGKJVAAIEAEAQWno9Lrts4zO4njBtozPeKDfN2jFoojV40TWqYTMoZzaRFAgWDbl5jKcJDFIkDJkozBELzIwQjHcPDHEczFhs39mNMCDV7c//viZCaACw1lT253YACcDDiSwEAArVWVNvneAAI2sGPDASAAGsx+MkFisCBplRYaKQmXDhoxUZSLGDCBkoADTBJkwAZKgYZGpmPGpjIAJKBgIwGBxcQwYGMeGQQEmDBZexJMILQwWGjwiAYNMIFwYBDoApU9w6GJoGAgI0FGFBTN13mPg5jAsYiMgQXLbCoGutmrDGwMnMLGHSLVEgEho4aJgOBxwRChQXBLIuU3jhtq4hg4pIHvawn6FQJTZrKWLXFhYu7r+qBuuv4sqBhNFoFABeeLLSZGoqzwLALzoareUEQHQIyJTJK62woCgi6XlVvQ4JahwAWzgJaTfWkFndYi1FYZz7K3ZhMd8krIAcmUUkn1bnKv01Lnrvu4rqUQ69D6uu/FSJxV97lr6t6rq3UnLcAv9GrNKBAAAAB///////9P/51xZ4lAUAOIggqBQDVAXBh7IfiLkL45YaUGSC2B8AjwjzYviBAzqXg7QzZeDG4jwZoniWFJFgUoJzHkEKDYPDzkVE/CzwufH4XEfEkKYzBEwy6aF0TiMwJ3FGEoitxTRpB1ycE8EFDmhichgx4dIAThoQLY4CHCEo5ZbIeICDwn/5OidRGxA0P/DuB91j6OMABACUlL5LLdaZtpiaFrCYTticCDYYyPmb7uMavpaZdi6cnSaZ8FaZ4ngY3EYZaHAZoBiCkTMWSUMmCkMOhtN/GYQJcAoA6KtDbSoNwEYzyJTEIjMXjsyOPzDIGMhFUxIFDSR2MjC5FczOJwKBDAwGMqHFLwhARg0MDxcMVhNY6m6CAcA5hkJoKjoACgH2CAKWxBwBcdq8MKBphmIAIuoiBIFAIJB6DyQNMQgBe7MQYAVzKxyBwAcD0UysCRFlqES60ObW2ko8RkVB5MGh4BoJgCGAwPhgGDBIYHCZMLkJZdxtGprFZBGUw5ZDT2skU1U5S6k9unmE+0a2nhAfd9ASRANFNNguVH1BmqP2/ilz0vWuynoXFdaVMQZsifYch+ZLK+Ldi6l6Vqh5MBlaYSVQArCsKqVwxwAEIDVXUAQzBgCQqGgyq3fshRxbxkK4GrxZKdPV9IbiizcfU6R7QrbqjLpuDhyN75A1xvf///////r//KAWSAdiG+g3aJeBKzENmBEQhCJEFshn0BnCNIikkQACxgMIDmD1hlRRxpDMhmiKiEAjIV0gIWinxnjI1GOGULqiKIKIKFjwBwA3eDckQgIEGKiEGPDZR3GIdwOWJ0qizh0jtFdHOMCVJojyONj5YRKBRLpwLZDHiiL/9xuitRbV/+TBw2PABVYwaJ8RAQaZRcY8kMYwEwfFnkZsv8YshEa3kMYQGOFxIJhZMCSaDjtMCwYMhR2MDEkMEwIMWAcyqKjG6mNIog8CVzL4yMSP/74mQkDGjWY0wXd4AEicqoAuA8AKFNjSpO7e8CRyvaVBBhuBhS4ySKjEonMVDQDC8w6GUZDIYQMfiwwsBgcGTAwiQiMDgZHyAEhmeK3R93WgNcdVrqasfSltVn6lzWWzPrGX9d2ajNaHZxma2YAfmpEH1iL7osxVfcZlcumurAtdcV04BjUF1JBWuWd8jE/bm4MrV4g7LlT0Nw5Ot1zprT6RbURh2DYzBNJBlbVWmuTcm5LJyPxmBpNnCZLI3blj7PrEW8vY0laMSqOymUU1FhQStsTpxiYm4ZmnjWGp7l/CJQbLWauhllfa7J7WUpl0NTrM5XD+wAAL/////////////////////////////2Ylc5PkQDGENBhA5h/EGOMcS6LUQ0nylJ8K8JkJKsKF2ygToVpLRdgjKdITEYkOHKTgmyZMmZuMo5VyPSOGqiTCXqA+SkJCTkW4nT+U0WVufsCoVaoVWrMRfmkwTUOolSFPk8XIvxLSej9TpccjdWYiAaVzDoIzcIBTROjTHl7D5+hz+BJzBEqDVsUTMgDjA4YzDoRDBMLjDsRjPcDTD0BzGgRzPFDTCITRAFmMAxAsGFQxzYSAMUyYkAUUHIo7DjSiZqcBQrAoIhWZYAjpYFgxRUxIMLVJmwEiOv1/nlPAymBUGwEGR5vXZDrVtZlS0FxJOdzExWQ5UFXGQw8BXzCPt2zH+hr1czJ6HUzThL+TG8pVm9dpdN+3JzVx5OSdXLEi3JXKPTSyKp6osLS4dtx1MUZTIRXyGrtdNjYrEOg0iN13UdnThztDFNZctZzK1C37UkEc9uo2K7LHRi2sqdqT0CTB3pzMIsKhL6pEibrdKfkdiHoOV0eKgc7kA9r//////zvJU8LuMuaorWCggkxCVAYnFJmUqqsadudiqxk5UykX0qyIJZIYKhIHhIOtUbOzpuLoN+yVdzIWyN3eOHIeibaqZKdscR+R6TJSkQzRwIhBgQKIQLIShwBYSEloz3zKxS9yHJOdejFnVgZ1VAkJqSqgC316u9ZgZUqApJ5Y7FWdRN1XCfGGJRL7OVTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQv4IwWEo5FXkyvxIyjPM451Y+vjwwoGQ3MOgwYLkUIZAEYhhSGM8a/icGD2YHDWZ9GCYqiyYLgeYWjOYIBiYlCgdB0dB8a9ACtYCXgQacUW9AVTKjSZAocyYkD/++JkLYz4T2NKE7pkcAAADSAAAAEoVY0aL3dlwAAANIAAAARDDFgwEmLxCyRO5rtVy6ayvlirOlK11MvlKqLfuTKogoMxmRLXSZdhWF437bWQx5PWAl+u605tHVlEeeFxZG8GTawO+c2zl/YqzZXDBmiN5F5QPbSgq4GqgcxihawTykYCUB+EJ1ZCLdrxFmM2O31ZLJ1GUiYxI5SWJYbD6wqdHaB2ikpLiTjp+XlWMlYy9s+RLiTZ8eyEPd8uO7LgIF4TmxKBVLxigDsDdewOB288IBhUBvmdAq0aEzv5hBiHmuwzucEEU5lawhqraJ7KnxlKWhjYIBpeNR05U5kBSxgwW5liQxkl/xiOVIQ65koPRjyaZjgVBrmdZiafgCL0zTCQoX0yYQ4DK8YWAaUAUaAKGrnZmBEFW8xQKFQQwaNMJMTlAQOGxgOMZAUu1TI9pkFUHHhlJ1brBc4LC4EQhiOrwJ2JuOvB77lUFedtFOmuLyXVSIrOioZQtyX/IG4v3Hl0KLS1v5Upc/rWGXtAl6DyPCByYKgC9Ig5LEmhqZ24OcVfqccw8UYf5acVcuXSNFFraKrZ6CAInLHugVYaA3PXI/Kqj3RBpzBVg1Y0lYZYm0t70NHLgXUDscm2iUlGzWnbgs1ptthMMudXT4ac6EUalDbvM5SJcZFLFbjFat+B70SstAcKAqsqgKHYnAaXseZdfzVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVTJMI0YAzYFqzX/xWMMIoE480/jddxqMJYZwy+jWDP4GOMGcdEw2gnzEZCMMm0KMHUWGGYBAZUFsdo0SZKAYEWcZRjiYvN+ZJmKA8vMo4LKommYo6GSodmNq/GIQMAIIxoQDC4EDGsMjBQCzAkPTC8AjFwBjCIoDBERTKoEzAMMBkDlHAgCmUv8ucIWASCzyzK6FhywUDaTJLQ3B54OKAhGIlxk61ygCBStpaNacANnkUbVKzdy4SickA2rHH8eVgzXHtUegFuEysVQAgOUCWqshmkw5JIEOEOvFqJokwmZixGZwGsaH2sNKfdlzXZJTufgtWBHBf1IF7G6PfFVM31hLvu+pxPNhSLehnDZVztbUWdplSsC3FstsyKqgGfbJ9nKg//viZJEM+rdjxgvdw1AAAA0gAAABN5GPCA/3UoAAADSAAAAEacgZlrIGzQ+29EqoxzkkL8CIIMOzVntM8rgw+WwTXaq86KDOmhuAtdE5T6l7UHLL9ROUS7pjCpCmazaV3GbyL7pjPQMwdGoNnGNYTXJg6Ya0ZWEVVmHzjnphFAEsYZ2EvmCrgXZi2RIIYTcM2mEkAVRhhwU+YlMWpmGwgKgCJHzDKgcwwTwLVMOrETzEExQ4wzoO0MHXCCTC4wIo0kaQ5tA460EgyxK80LAsyoMYwnLY0VKIysWYxJC00SRMyNkkx5bs2+DIzOFUwECUwnDJYhgEJZsq5lyANJmZcgT2bBMJEQMvNGlM6JDDKuGQAAMW5AJkyAM0B4w5Y0o4wwZc7cB1UCRI0gUdVIDAwOQm1HB0ADASIEaMCm+QCTGnwIYMgbMeJCqQugZswIQIqCBJUMCmJWkhaKIADIhzijB4gYFsZc0ZMcAG5jxYQ1MILfAzpkwyIOACA2IxBoyZZ9DijsrJETHH2dgpkjKFgAYyTBMuIBwUzxdOIBBDJlAQHMEyVXQ9MWOLtuOATgYfRZWuHRDAmjAhyYOVgyUytVW4dBGXLDxQyoJDAiSrtBI+hMkhEkhlChAeLwmUIAQRJk9EsGUAgAXgEkxKALoGlIIUtzEgZgVNOFwabgYOYYpaYYCaEwCARbEw7NQQcGCgwIDS2U5KTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgEAIWJ8Oq4cY4gzwjLpScOIdpc1eugDFbCPMD0wwz7yBjAuHWMJAGcwigTjBFAfNhUP8wnADjCOBQMSxJIxbQ3DVMNjLVqzA42jU0Njr4OTO8qzBlmze0CxUDDDeMzDoRwgYjGg7TAINjCoMzDwSTCURAMIIcFBioahhQgKRIkMxMFhZtCEKAEok+0yIYBgMCHrBMpLutNeaWQ+n0pUgczYVGEiGHCoq9Yq+tXC28AGFmWkiQK/VeRJTNSa6HfpppbTru04LRV3OizFloYFNBA0GJWrQTzhhO5+oYSOYE/qjSVMbUGWFgdl1Vrzls0f93Hih5Mp144jconBKE5s0hBws+yarCqWxCmYPf/74mSFjPqUY0WT3cvCAAANIAAAATU1jwAP+ynAAAA0gAAABNA77qdR+PT0PQ1aYNJ45PWHuU0Zsjyj637IREC/jW1zQzlTW16l0XshbTZY7CPBZRB9GzNMloMgcpHJK1AEx9/mIDRs/TUg8yBgliN13dxTpBs1M1pse2Mx7c2jkm+dcwi8jDNtuVlTYABgwwg8HtMvEL4w6ihDFathNRMIE0fENTCQPoPMkMYxVLLDOFEaMJm340zOcjMvNuOAUvUzTTxTJHfhMnEuoxTAuDF8l1NQsRkwChAzE9CDMFIBUwRQ0DBvArMLkScxGwczCND1MkFK0xHEhzFaAQHg5TAsBxMHsJ8wQQTzANALMUE6ZziFOwE3xTzAAQYhSNBwzwTWQDCUR1QGUUYBCbwjAMwYdMSODEVIIAyZJ2GbJlESxogiggENNcEMHHlyq7Aqeg4ESipql9AYMVDwuK/bCy8gKajxoHhgBiKFgQilMtEEqm3SOlNNTdTmmDgYLqgNYMPRNBoCaAQCaRwO3SVNlc8TUH0ZnMKggoYmPQCMhH0eZGAAqgHPGaqZxg8gNPs6LRhUkWSA1zzip5ovkQSzC4iZi6GugYVbyhCKqgZmPGxckcFhzOHAyzOwqSaZpijAxSIFwjCANVlXyCZoitAsYYxhqNDpAOPBqAUHV2KApFoS3yYXEmtu3Kl1F2nPgx1YgH0//+r11UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUClbMPMOkwbHHDRlh6MfsZkzp1FTdsTyNmZTNbzWNP21MgUFMkSMM2ALM1AQPulFMbCEMohGMkOdMYDAMegiMC0vMTmwMoEhNlwAM3nmMRT9MFArM0OTcBo/EuNoQDP1sxMfMbFQaQAhbMLNg7bO8ZjUc0wcNJgkLipg4kDQ/EUAE+oAY6BgtyH8d5WpR4xYAh9mAiBSACW7A9Ar9/UwldrANCSEbRkF92UTmRKsQBoUtfC4OtZiEOuHJIBZwsGn2wVQSTPy0REwvC3JuKdCzY6jmRCjD4eTgbmSBKD86xNAdAkYVC7zbKGDQK8EKXI8iR6zpq8+btqrpZrrZQy9rzQUb3HetNdw3QYCsOg4v/++Bkhwz6s2RHE93ZYAAADSAAAAE1CY8QT/dJyAAANIAAAAQd34aZpHrNE/VHSNeW8mWsLJ6FY6EueV+GAkrZgwC0QgiFqEwOCE5oFMBB0fFJpuISGlvNVHgFr76s/fkLAjKXLlSzleQPS1+gcixg5YYsZg0agmTPCXRhzxOCZtmaLGk9gCZhWQquYoUHGmGuhqxg9Ab4aabMY6FOY4xgYCTaaGPwaKBsexZQcOwAa5HSZCRkZXuEbZbefeSkdgjMbiOmYmowYvmwaMw0dUhuZ0EaYohaY9j8YUj0Ybi2YSC6ZOkEJH2apiWYwOiYYBYCAMMjxxBQ6l42vCQQDNwqZOiLNeNHsZu6oYiMUQIAR4UICOFtjwlTEFhoyCHBgTpGFEQsFYQyuAWxqmIYUM2IGgYBPiFcCCs2UOxoWFBjhmUAnLAioAvsMiEx1sBCPyoCWamsMDgzW4w6DBogu4lDD4hBDIgKMVhwaUQTkxFJ9hY80QCoBS/7PXCZGLCTFCWnGiCggWHAQgVE1ql6jQETAAE6BIkIiY8xGAKG5YBuKyNpgUCjyEWgpAJyAIGDiYVRq3luGtGIHlBBClZqIQWAmTEMvAB81KhQAvuPLBZWAQIkiV8FwKi5QoMGCHEpqhIKkEzMyiI2Aw3JEScGCNAFIYEMYIkxMCTwcGMOLU7HGQQeABQwZIiwLTJSxrjBogzNFN7gAkxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAVljApCeNWkzwyIycjUUDVN4gU818irzdV6N61g60sjYclMRqszHLwYyT/LBFEKY6GppOSHejWZTFhr81HGzIdZmZmrinE1ObpP5r0en0qJwW0CVAhIjHmwwpkMuXDHCgKwRm5sYhKmaj4CL0VAYEmlj4qIhwcZaEAIJQ1DiUDEKchUAlFn6CoMnsytO0WG1jogImsmRQBoBFWpt4FgB0FxsxhpO1CQoA2ksQltJKAdrVGlc1lRdaLIImvlNZmam1ItZrKlLpMeXzdetgzS0BDpuS25ddNN8V2pmPqpvBTKUKmM06k28VgYc/Vp0LJeB+HaWPYj7js9gV9I2xRd7nq7BwK+UCtsw52MmwsyQQq4d1faW7uL/++Jkiwb6X2PHk9zZYgAADSAAAAE3hY8Kz3NUyAAANIAAAARjqPtzglSldzLnrd5RRpLwuy/qVb4K2oFTTWHZWSr9N7NBMlxBePyJ8FnraaxMK8TxWK/Or2QMAmSSvWfEOQR3KNAGPMlWemqP5sh8xGQ8aqbVhRhjwigmJ0OUY4grRhDB0mXAnCZcwWZlhFNmScR2ZECmppCB/mIoOYYv4lhhTBnGUkF2YNxL5nNnHGF0ECZv44hgeDGGPeIoPIOGJEJ2YP4ioNRhvOJm3zWYy7hqNPmPjybmFJnlwiSpO0AwxOcDEwlNLgUxCMU+xgaGgwSYRBJg4RJoDRwMtC0QEExORDEwJGmMYJBIGiRg8tAgDGGxaZdAQBKZhcPEwdBwcMIsMAWQ5m9g04tMMwpMEFNSIMuxgcGsCUkCso0LEIIDHwAhPAGMMONYsHuJoaBzSRlipDHPGALjmfTAEQIziKJa0CjhEADCAjUhzVVdMoGjg1WRJC5wKAsrAQxTQIFhiIUKmBAnBKoVmMNDUJdyV5hyQVALAix1nboLGRMC4JaJmywBHhVcLCzeqgULASwFKmnPCBAggDDhEzwUzIgMWAEWYUEPORJqGMkDTQgACIMMSZWj+j5ChAIRXMW0NYLrNZVVMMKDAwyFKAxojBmGiQxblMwKkBgEFCY4uOGFlTScSqAINQcCMWlImIQaA4VvIYU0kIhMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoATC+GwMDcL40cUgDJ8CLMrAJkwEEJTKqCLMoMkExNhcjFBAtMO4BAxHw1TChD0Mv4WUxJxDTLdOOhW09eZzK5TN6NIysnDUfEMnMgxnIjUY8NpGo3yfzFhzNMz8y2ljXQ4MeyE0uvDBMBBoJNaCEy8zDGJLMJisxoSAuLzBIbDAuXFAxNAzh66gJMDTiFIvA366VBwuChwTiS+VVYqClwhwFhrIQlsTZWg8FREbHrTcDOwNW3ZB4cAS7ZGhe9qA9pqOZAIFgWfAYWGhEStsvurEvZ43RUzARckTQVUSARQDs0Oxf+MlmCIBeqXq6nvcyAXJlUleWwGBO0/zKZY1pwqVx71zKXN1oH//viZISM+uFjRgvcy1YAAA0gAAABM92TEG93S8AAADSAAAAEmjsVWdOK5VvZNA087b2Rmu4qdkHQS3CHmO0awaSCKiztPLNI9M5aE2GNIFtjc1PxNKIiM8dQIRQUc+7NaVK53pOowra05k7cmUlzWk2lg7D+yISAii2qZZZRRleF3mr4miZSgbxjKkVmHGWAYWYLZkLBtGFsCCYy4z5lWDQGFIIUYrJgeJlYZcDIbKPYZekSbeqydR22bIB2b02+ZVzqdxvgdrqOfXTMaQwabtTSZ2BudtFMb9UwPTAZHU2b3JMfK0oZoz6YdKiaCLoaeiwYaA6YQg80gwdBxMIKA2YBh8YOCYZpMQHBUGBAYCgyYKAIYKhMYWhkYNgUYHBGuxuCMadwJQGxMGnhGJMmPAJSsEoAoJMspFjCyzCHjaMRpa09DZQw0JoFLjLLQxaXZQkroS3GQTATDiGpGACwyi8CgTU38WGJBpqD48FXenaZAuBZgSPDEJij5jgRMaLLMnUOLlmMLgIAWWVlfJt34YAFEIsRa09jhNle5cjRWKyyGYOgZQ1x0eQYFMwjHjBQCCAsDWUekuk+aRYaFp9oARUMRAVNjDjBYEsVQJhSYReZprEjBlgc2mWOprAkQYMQRMTBgFnuuCloFBmWEDDUewkgoRDTGE0wQKMMCTEBoBIgoBRXIhgJGI/FgEFxZmhIJFBwLOiyTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqgABYwJx2zDaEeMJs+c1KzbTJfBSMFAFYwnQNzAwJkMQwNAxlkmjQqEoBIa4FGMGLCajmiYpC+a+PQZXEsZtBEDhaM+h/Mk6BGX7MuCrNWDzNSFZMaG9MchVNTTjM41MMlzZMKk4MmRRMlgmMxBGNUz5M+xiOw6OxWMMhNqdIEhoBiI5iQ5lkBnUQRFMOLMCDX+AAhkjAOOGERAJ4YUuBk7YHAQ0UTAQtLAuuYsiY8Gy5UitgIABACAoErwWpmg+sOxNndihpGAJCNo+8ecCG3Ld9r9M/kAyN3JFeicufyIwO0hpj/uG/bcGIXq7hrvRUVxCVgC8DMU13Qc1dkMv3nNsPVOzeILHgJFRvVA1N37gxciu4HhhyKRwIc5HHbd992VtfeBYiv/74mSTDvqQY0aT3dLSAAANIAAAATjBmw4P8zbAAAA0gAAABAjeQyoG0+vEGsQxLZTZgBiFiOdicLyo5llag6g6X7buw/Gfy935LD9e9nHkMErAIzCRg0ky/ORvPMIQxDAwAeYwU0KDDA1IwTYZiMQqIfTB3U9YzCwCHME5BWDBPQZswbAd9MPNCozBtAZExtsZLMA0BnjCKgJswpURcME3A6zB5Q48wT8RNMftHrjBCwP0ChHJgvgSEYMMDkGAtgg5hKoCIYB4A0GFZA/BgbIFcYd4JamBxg8QwB8GASgZx4bcG0UaFpWZoMpptImSC0ZBTRmofmBkIZEUJmgQmag4AoSYPOBmERAaMmMAsY6KxgFAmOC2RHweGRi8OGGxyY0KYXIRigihB1McD8xuRDLJEMhiwwcUzHQ3MMAcABUxwGxGIA4fJ/gUKg5IGJgKAguFEjn6MXwCio1gQ8BkrBASJI0wSCY8HAp+lJhf4w0rghBQuBCQXLT6S6CMDJPXkxYyDEuxWYy4QhgCGtICoCcR1EGqUaIxWeKhgIm+DiR0hQcwSmJp5IOJ6G2ILBgVIFJMCRRTMhsvWpuAmwkcCiKFCJcwB1yEyLDlAKEaFFAxIICGAwRCkmGAzJVTN6KA1YnMMXEAlshiQqEkA8yL/ptjgyQbG5GuWIqxoUA081yE76YFVpbJ5CMBOBPSkbo70NzWtum/fUxBTUUzLjEwMKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqoAFbMDgN4wmRQzZUVHOGeRsyGhhDCbEpCgNRgTAYmzmSIYlqWxpaBPmDOBuYEIDph5DsmRiByZRIZ8JImvScYBQRnR3mEACcUUhkhbn6JSb7O5pY4GCu5t0EZKLmRspnLEZUjDB2aWhGUOpqHabbHGXpB96QZyDmThIVB1AwEgLRCoIAQ4iWFulQnMIDWnTqlREHsXCoEgiKoQzxgigQJAmitZTvTZaIm0garTCYbU/Rlp094k8Kw630iGSui1NLeUO0nopvEk/E6IUnypVMN2TVZ4gnikdJgl0ULGCsEZml4pYyNVdjcDq2vNLZS365I4t2gcuFP7Gq7W3LrMFZQ12Kv/++JkgQT6v2ZIE9zbIAAADSAAAAEzeZkZT/MvAAAANIAAAAQ0iTtsQfeQUa8rzSnZiCw8iRPbiqol3arrUZvH4BWFkiqiJsoi04vBBJEk5F3LTfBNqlXO7aREmbml+xmC1AgMCpErUcAaA2mJ6QhoMahF/J/Iv/y2XIYAApJqGB6ADJgj4lIYu0ihG4LkqRg3IRKYH8AzmBXgY5gIIHyZDYHGGD5hzBj7QBMYDuBCGBcAPxgUAHwYc6BtmAgAiRhvoS4YDEB6GKiCfDJRrXTGO1yY5tx2ooHBbyZPg5gQ+G2G6cQO4QhDKTbMRlszjzTRfUNiDk1IJTLB9M6FAyuDDHAxIh6ZZC4KAxEkQSAR/42Rwzg4XCgU83SyK8QCsawoCyNFw4YAQGJ/rQBySPAKdARICADqwqCe8hb4AFiyBMkDhTNPMxEILTnMthB4MHVQB5Rb9gQkqOHDQRmmChgMXYeZbA6ACiFmiQ5hKjoA0i3QbES3UDTNMQAu81sAjFUARpqolzV7hw6hgYynmNFruR7RVViRRDDjLERIcg2h3XjAJYCgZhGkIzwAYIGFjxMpBgSYa1UBbzNWXW64CKjoJWATTqlx042CFUwGBO21uADcTBQg0GpGUwwCUBEKxAACm+EGOK/CLguMaS7ADLaT4MMgQmBxAKfNgcEGGo4nkKDIiG6ESIlUMR2IiJfSCXypr29RaTVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQBacwsBDzA2HUM8mpo+dF4jBiFZMNEGQhAXMDYnAwmj6zDlCtNGQBEwUwDgMqjTn4PnkMVOJrzvmcR2a9BB7pYBhaMCBgw6ljEosMPjswwmTOIhMdNYw4UTHBPNSDQyOLzFyTMXF0xYRw4MhBJNRo0QgNOIUioMsAZAZrxp6CEdhqH5hmizZklgoNXKP6z0vIEmk41sw8vFOZWFSqJJLhw8NjhsXiTHXjWqJDJXJ1rtsF5n2aG1tM8vuvhs6q7SFE1rtOcFmUNlrxZpym+LcpDlFIcOzuGU1FM1Ny7zJmQqXiEZxoxSw65KlbbMeZ+Dh0ExNHKYysd9mCoHKtg6kblTYKdsiTCjSajjuO3jF4t1AJdisBqn//viZIsO+npjSBPcytAAAA0gAAABNxGRGlX/AAAAADSCgAAEcGBqRtH6YNAraQW77XsnFcpYd0mDt7tW1AOkQg2wVhSsbxRJL5vVL10oHIUs+bi4ikFuqK5NhtzjUXMBEAWjCYAFExpMe1NCeJmzEBAcMxu8O7MXUEjDCZRJMxvEZ8MJfDmTGbATEwUYNwMBgDOzAzBjQweMM7MB/CCDBmQnkwDMX+NYsboz5BWDOND0GlSTGfEPMeIaIwJSCzAkB4MB0UkwWgfzChBqIhEiIE4wBQrzBVByMDkHcwCACoQYMAExgGArGEGA8YBYCCF5gAgyGASDcYCwIKHABBLmBEAGRALmBIAoYCIEYFAAEgZxwBcGAChwBwBALBoBRdMeAKKgAocAsgqDgEiYAZzWKNuYAYDxgAABmAOAgYAAGYMAMCAJgKAKMACAIA4RgAIxKCohl3UZlKlUFxIvLrd1WsRgAJhhAByKDOkVy+7spsVU0UwHLDACUaFwrSf9QNGsWAGUjLl5M3hKRLvxh2xkAgAgCjAAlMo6W9R3MAAAdmoYASifYQHMVAwBJbV1WdWGAK8bOpmIQCZdAS0lGyQAKB0hH6JQAUF2e8XKjE2dYVnsyXyetxEs3dZmJABt1QaUqVUMBQAAvQuUtKy9PgIAOGQAm/FQC3JaEkQYAQA5bMAAHCwCZgEAAMESwYsjurAIABWNQizxTEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVMceWs7bSLzShwLOh3H4zatlT4DcIMuYM05GiNTXuM3MOFu01KUwjbXLsMacA8yfB7zP8B9OAVv8wJw9jRAhHMoQSQwfA6DMoPvMONCI1JhGTJ4EhMCwAYw7AizAZBlMPgjkxzC/zGDJ4MDYKMiAsMNIPkeBwMNIDYwCASQEA+YsgbpgegVmLkDwYs4hZCB4YS4Q5gngnGCaCWKAeA0AAmAcJgXBCAQYDAXZgdgTGAKCOYKoE5hdA2GAwEIYFwK5hLADmB0BmJASEwAaVhgAAIp2jwB4qAEYPoMYKAmMEQDkwJwAjArA0MAgCswJwFAAAA0wwBAGRgAAIAlGACSzjAXgHgBxYBUgAFMBUAYwQwDDAUABAgDwMBCEQLIhAmMBgAIYAdR4CoAyCQvqEAipfoI3vLjK/VEk2tBCYNAVGAmAQJAWCwEq6zAGACEQACEY8AKYAwD5akMAXIgL2RP/74mSugA9zZccGe8AAAAANIMAAACv9lSg97gAIAAA0g4AABJNqWAIBArAAWIjgRACJXNegFBtE1YyQkBgIB0wBQFjAIAJTRGACgEAGwsaAmRtL3mA8AhAI6AKBQCI5EHBSiYqYAQAKHUEAAJQr9L+r3CgAEJXWgMeMEgA06wbrxfQOAnVskacT/g4AFfxgBgDl6E1xGAESAFiQASsU6kWXtJQBrbFWbyFyVOH5kxfpeMtO//0gCYLwZZg0j+mXIPSYNKEBggnNGB2N8auAexi5jNGVuJaYdhC5jMhlGUeGUYKYShkvBsGKINuYbI1JnBkoGMWUGfXKpsOziDQmKEgXIMzJohHI6eTCRAMfGExiLxqzmGQ+aKBBionAIKhxdMklIrDBltaGNTEagI5n4SiUGNrgQwWPRZ0GQRuFhKNDgGCQaGxhUGkoHAwkMDCJIsLgIBAAaCkEFATMAgcBAfa9kOabBKBkvlbXUW06cSVVL8p9KiR9SAbOgLdILgNJVIJbSSKOJcMeBaXqSaBN/12tgTeL9NxIgOzZbqGiSiuke2WtaEgCsZGpW1rLQ2DuLDDzMfcJMGKteZu+LiWXQprjxPBVmXTg65D8sf50JbJYfhtc7tMYWIx1iCunLcCncF63LeLHJu74unWgKMvrKnKvx5wpBArNIjD0XsYNblra14lVjrhOSydm7oscZhKrsmm7NzWO1UxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUAASMUoQEybBujDWowOFooUw3F6DGoKMOTOagzCDDzVJRWMOYLs0UQsjScM3MU8z4wBR3zHyDoMwUF41wGPTF6AdNu8c0yfy1QUAWY6BhIkFwy0GNYeYOVxlFJmqWyZTUhpvHmShGZ0aoVMAdNDLJGMxCsDaUKog48WzR1qMZhQ2NRDWrRN7IMyevTAxmIrKYyRwGFJh4pAEHixZEiYDAUKD8fIDrBwYkcPsgwjxZsCRkpZQA0UmoZcnYPKiFYaVRNLhLCg4BM141aQUmCnRtE54Ao6I2gZWKdG2uBFDDHDIkw0UzBPUDJB11DpKh4GUVwbCYoQIQRAUoJC0kSAKkBQC0gUC2ZIlCWIQV2MAKFTBBIgwMe3RkY1KXcIo1iCQxkNipwiBlgGzDjkeCzyRJUAEYa9E3RImQsMRlUtdNKJlyNTWF6OSrEBR1a1K1VGWq0J0INtWZi1xa6aq84bUVSKNwVNCwVCFjF9XcaEVFU7CU0CmFlxrQKkhn/++JkvQ78ZmTHk9zMQgAADSAAAAE75Z8UD/dRQAAANIAAAAQo4Gw9CS6KwaYiKy9W03Ny0od0wHYERMEoEpjGlRzQzcMW3MNJMNjGBA9UwzRmfMKHEFzOoBNwwOkNuMdfAuzEzyE4wf0ImMlDDQTCChhQwjcFsMvbOrDDVBuQyYMZgMN0CWTELwxExcMZWN1kcNaDdM03oMvkeOkUOMKITMvlsOEjqOIVTNbVIMdFgNGS5MCjJMflDONUvEK8HKhgGGzzmRhEHkT1mK7em1g3m3iTmlA2GPZxmEpUGZAUGV40mGw7GIBTiopmSAuGDp0GHAqGbo+gwYDJYOTIkcTDopjHAEzK8STBsSTAIZDCQIDI8GQtmLBEWTGoOmbsmhLGTcRg3Z4S8GOwvWcweSPTRCzSKTTKTARTFBiyQHpDNJSIO2iGOZ5ucoEaY6Bs6MhYUgpuZWORCQFUBQkxN8LAhbgYNaGODlpDNEDCtwEYMQlIAYK4A2eZNwalOYyEaqSZ8OZYUZEKLHhGIAWMFER6EYgEKEVKzCAErxGLM8KTlCwwxJULClyhAASGhcGigpmBgL8lBlBFCkawCaGRgGIGqOgkuCiheQGgVNQxmIBynT+lY1XQGKgkOigAjI4HC5kaDFuQoAaOWnCgSpcHQhjQAAKJfmXCCRgwKsQDjRAAUUEBFAegMWSr5NJ1WnNbjkIhutOV8rBMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAHjCGAb0wH4X7MKfQvTBICfowIwdkMUuEmjK/mLYwwMTOMHMHEzB3RUQxOcESMIwHHTAqhLMwWkHuMDXGUDAxwJEyEQ+vMDNEEDIvAGYwAwKYMNNBsjARBt8zICwuSYEAcYXpUaTPWZvq4cjCUZ5wsaNkQYvGaIU2MlQUMMwQMDDqAJ0GA8OGqYlikImqQXnNrZGNr1hliiO1DJsezEYjjBkijL0ETAcHzGIDQcBoYLBh6L5jmDgPXAaaYwGBTxlUIGmhcEaQyDh4OihccRKh4MrCawS/hNCBxYChm/VyCqqCEzoIZGGeaiIYZ4uSBTNmi/ogGmtjDo4GHyUAIw4ABjgwFEhhCXwMSUCogZNAVcYNSYIGFBg6GEhQjUgZgABYKAK+bkudOkZEBwJKgicoShK2GaDKiB6EjOYYUBsRdQOVJhJ1PfDi/XvUkmCwUMFJimeGoZGNIGIFgAKYgSGDoIeozCEyJRCIQDjEGTBBAYvBo4KijDnBAVBhsUGBQ2KAUEU+XhbEOlnuWsCBrvkQEQASQSLAFu//viZMwO/hZmRZP91EIAAA0gAAABOOGbDg/7T0gAADSAAAAExBCUDSpiRgGVvW6YYRQwQfFipkwSQgCDKHkwhDIWFQ8nQ1tr0Mw3IpZYbMDoBNDGlA6wyE4+BNoiMTzChCzwzqYcGNpnSdzNrBs80pETIMF6I+jEFwfQxbgqIMLvF5TKuAo4wLcnQMHUDiDDfW/YxJgCLPqpLE0RJxjRSDRMkGBAxrBWjBaBaAARRheCFGEGMIYTgTBtADCGOINAYwgVhhdhRmAWAiYK4E5hQgphQSIw4w2TCPAjMfkNoxiBzjHKDcNioKMwfA0zA7AzMDEgEyTQpTCFCvEAghgdAEmBqBWYJQERgTAVGEwFoDhdAgGIcfHSmA5YQkyQcDwCGKCxrDhsCxiByWgcQMcQMccRmQbChlKgBGTRnyyxmzo0KNcaHWhpUoGfFUoaYgpgDgoJlmHHBwcMEmFCA5AXHAIgzA4SaG6aAwWchsdTwcZcgJNEUMYIMQqAhEyIsFMAcknxUQAhgQYTNR2Chgu0FQigoYSLfDQcwgwZBBYkAQxkCwGGAYQqVwggIuhWwWHwM2FsQomM8KCwNdSo2ktFedSgLAGmkoEueRFmUTzkGIAK2LAIcVN2dOwWkS9DAYXBqzpBKGMFMIQXo1tK2RL6axGWu1GDkAZEQDACIAhW86231Q6LEFACsMXRUYAvle8igSO9rz4iTEFNRTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqAAEjC8E4M9krYzlMLjyTbxMExfQ51ixT7sv/M41a04kFIDJidCMBERk1e0EzH6D+NQ45ky9VJDMeFpNnvn8y7luzV5OvMyNMw0MBeTDEUnOECVNSyXMWwoMAhCNZEXMOliNjEhM82vNrDFNJgNGQTMAwxHmmMNkWMLimMehSNsQyNSaiNQDcOeVNMAkoNqiKMgYTMHQgNhwKHDoBRYgIVzDIRDJ0BzEcUDJYRzC0yBr0dlSawQj6Ys4XpMYCMAzGTgJHmFSjy0HPneLsoWmFBhBAwokxBo1i02IUy1AeSHBBAgAZVIESjNhCzYCSB1AyyEOjGmWDrQ3gA0qkSVKDGdKGkXBaqYKKAwxmwgDUggOYBoBkgWWhkwM0GINDzwv2IwTQQoLU0MaDDA5MqLwGDIgkgapUaEyBgRggggcu0Pe2aiBWocXkMGFkIWDIIC6C6xZEBUQMIsRlScc6XsZ0kGgnaoGEUIU7guJYI7gBFpDgo4KgValhBCDHhSaojAAYWnoswsCV6BjJI1I0GB25DIAoIjoUiFM/LB4yBo0Ysw==";
    let bigMonkey = false;
    let smallMonkey = false;
    let zeroGravityOn = false;
    let highJumpOn = false;
    let grappleOn = false;
    let spinMonkeyOn = false;
    let noCollideOn = false;
    let asteroidGunOn = false;
    let teleportAimOn = false;
    let rocketJumpOn = false;
    let glassWallOn = false;
    let giantHandsOn = false;
    let camSpinOn = false;
    let ghostLastFire = 0;
    let astGunLastFire = 0;
    let telePrev = false;
    let rocketPrev = false;
    let glassPrev = false;
    let moonPrev = false;
    let floatOn = false;
    let drunkMonkeyOn = false;
    let bombLast = 0;
    let rpgLast = 0;
    let grenadeLast = 0;
    let snipeOn = false;
    let flatMonkey = false;
    let flatBase = null;
    let stretchMonkey = false;
    let stretchBase = null;
    let bounceOn = false;
    let moonGravityOn = false;
    let giantMonkey = false;
    let giantBase = null;
    let superJumpPrev = false;
    let blinkPrev = false;
    let launcherPrev = false;
    let ragdollSpamLast = 0;
    let monsterLast = 0;
    let gunRainLast = 0;
    let bombAllLast = 0;
    let platformTrailLast = 0;
    let slamPrev = false;
    let stickyPrev = false;
    let rocketRainLast = 0;
    let asteroidRainLast = 0;
    let platformGunLast = 0;
    let megaStretchBase = null;
    let gigaRagdollLast = 0;
    let rapidBombLast = 0;
    let rapidExplodeLast = 0;
    let glassBulletLast = 0;
    let meteorRagdollLast = 0;
    let napalmLast = 0;
    let rocketFiestaLast = 0;
    let gwAstLast = 0;
    let gwWindLast = 0;
    let gwFlareLast = 0;
    let gwLightLast = 0;
    let gwBigExplLast = 0;
    let gwRagdollLast = 0;
    let gwGlassLast = 0;
    let gwBoogieLast = 0;
    let gwExplodeLast = 0;
    let gwSpaceLast = 0;
    let gwElephantLast = 0;
    let gwMonkeyLast = 0;
    let gwBoomboxLast = 0;
    let windStormLast = 0;
    let confettiRainLast = 0;
    let flareStormLast = 0;
    let explRainLast = 0;
    let danceLast = 0;
    let spaceRainLast = 0;
    let raveLast = 0;
    let megaSoundLast = 0;
    let boomStormLast = 0;
    let boomboxRainLast = 0;
    let larryRainLast = 0;
    let meatStormLast = 0;
    let fredRainLast = 0;
    let gooStormLast = 0;
    let whiteStormLast = 0;
    let meatFastRainLast = 0;
    let slipLast = 0;
    let rainModeLast = 0;
    let meteorShowerLast = 0;
    let guardLast = 0;
    let rpgCannonLast = 0;
    let megaJumpPrev = false;
    let bounceBoostLast = 0;
    let platformBridgeLast = 0;
    let speedBurstLast = 0;
    let sonicPrev = false;
    let skyJumpPrev = false;
    let gwKickLast = 0;
    let gwBanLast = 0;
    let gwDragLast = 0;
    let gwAsteroidLast = 0;
    let gwAsteroidCallLast = 0;
    let gwStickyLast = 0;
    let kickCannonLast = 0;
    let soundLauncherLast = 0;
    let boomboxLauncherLast = 0;
    let monsterLauncherLast = 0;
    let dragGunLast = 0;
    let stickyGunLast = 0;

    function setCosmeticOn(name) {
        try {
            const PhotonVRManagerClass = AssemblyCSharp.class("Photon.VR.PhotonVRManager");
            const manager = PhotonVRManagerClass.method("get_Manager").invoke();
            try {
                manager.method("SetCosmetic").invoke(Il2Cpp.string(name), Il2Cpp.string(name));
            } catch (_) {
                PhotonVRManagerClass.method("SetCosmetic", 2).invoke(Il2Cpp.string(name), Il2Cpp.string(name));
            }
        } catch (e) {}
    }
    function setCosmeticOff(name) {
        try {
            const PhotonVRManagerClass = AssemblyCSharp.class("Photon.VR.PhotonVRManager");
            const manager = PhotonVRManagerClass.method("get_Manager").invoke();
            try {
                manager.method("SetCosmetic").invoke(Il2Cpp.string(name), Il2Cpp.string(""));
            } catch (_) {
                PhotonVRManagerClass.method("SetCosmetic", 2).invoke(Il2Cpp.string(name), Il2Cpp.string(""));
            }
        } catch (e) {}
    }

    function cosmeticTrigger(name) {
        let aPrev = false, bPrev = false;
        return () => {
            try {
                if (rightPrimary && !aPrev) {
                    setCosmeticOn(name);
                    if (name == "BanHammer" || name == "BanHammer2") setBanHammerActive(true);
                }
                if (rightSecondary && !bPrev) {
                    setCosmeticOff(name);
                    if (name == "BanHammer" || name == "BanHammer2") setBanHammerActive(false);
                }
            } catch (e) {}
            aPrev = rightPrimary;
            bPrev = rightSecondary;
        };
    }

    function forceCosmeticState(name, on) {
        try {
            const handlerClass = AssemblyCSharp.class("TemporaryCosmeticHandler");
            const localPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
            const fieldName = on ? "CosmeticEnable" : "CosmeticDisable";
            const rpcField = handlerClass.field(fieldName);
            if (rpcField && rpcField.value && !rpcField.value.isNull()) {
                rpcField.value.invoke(localPlayer, Il2Cpp.string(name));
            }
        } catch (e) {}
        try {
            const cManClass = AssemblyCSharp.class("ScaryBaboon.Features2_0.Cosmetics.CosmeticManager");
            const manager = cManClass.method("get_Manager").invoke();
            if (manager && !manager.isNull()) {
                try { manager.method("SetCosmeticOverride").invoke(Il2Cpp.string(name), on); } catch (e) {}
            }
        } catch (e) {}
        if (on) { setCosmeticOn(name); } else { setCosmeticOff(name); }
        try {
            const toggleClass = AssemblyCSharp.class("ScaryBaboon.Features2_0.Cosmetics.Behaviours.StaffCosmeticBehaviourToggle");
            const objs = Resources.method("FindObjectsOfTypeAll").inflate(toggleClass).invoke();
            if (objs != null) {
                for (let i = 0; i < objs.length; i++) {
                    try {
                        const t = objs.get(i);
                        let id = null;
                        try { id = t.field("cosmeticId").value.content; } catch (e) {}
                        if (id == null) continue;
                        if (id === name) {
                            t.method("ToggleCosmetic").invoke(on);
                            try { t.method("SyncToggle").invoke(true); } catch (e) {}
                            try { t.method("UpdateLabel").invoke(); } catch (e) {}
                        }
                    } catch (e) {}
                }
            }
        } catch (e) {}
        sendAllOutgoing();
    }

    function kickPlayerObj(player) {
        try { PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke()); } catch (e) {}
        try { PhotonNetwork.method("KickPlayer").invoke(player); } catch (e) {}
        try { PhotonNetwork.method("CloseConnection").invoke(player); } catch (e) {}
        sendAllOutgoing();
    }

    function clearAllCosmetics() {
        try {
            const PhotonVRManagerClass = AssemblyCSharp.class("Photon.VR.PhotonVRManager");
            const manager = PhotonVRManagerClass.method("get_Manager").invoke();
            const types = ["Kick", "Mod", "Admin", "ExplodeKick", "Owner", "RPG", "Booster", "Camera", "YT_100K_Plaque", "LeFart", "TopHat", "Pan", "AngyFace", "Tie", "Cone", "Banana", "Blood", "LightningHammer", "FakeExplodeKick", "BoosterTag", "PistillsBro", "Kick2", "ThorKickHammer", "RPG2", "Pee", "Fling2", "Tect", "Developer", "Management", "Tank", "JmanLauncher2", "KittyLauncher3", "YtBadge2", "TiktokBadge", "VideoStarBadge1", "VideoStarBadge2", "VideoStarBadge3", "VideoStarBadge4", "VideoStarBadge5", "VideoStarBadge6", "BanHammer", "BanHammer2"];
            if (!manager || manager.isNull()) return;
            for (const type of types) {
                try { manager.method("SetCosmetic").invoke(Il2Cpp.string(type), Il2Cpp.string("")); } catch (_) {
                    try { PhotonVRManagerClass.method("SetCosmetic", 2).invoke(Il2Cpp.string(type), Il2Cpp.string("")); } catch (e) {}
                }
            }
            sendAllOutgoing();
        } catch (e) {}
    }

    let kickBalls: any[] = [];

    function spawnKickBall() {
        try {
            const pos = rightHandTransform.method("get_position").invoke();
            const dir = rightHandTransform.method("get_forward").invoke();
            const tip = Vector3.method("op_Addition", 2).invoke(pos, Vector3.method("op_Multiply", 2).invoke(dir, 0.25));
            const ball = createObject(tip, identityQuaternion, [0.05, 0.05, 0.05], 0, [1.0, 0.3, 0.0, 1.0]);
            try { Destroy(getComponent(ball, BoxCollider)); } catch (e) {}
            try { Destroy(getComponent(ball, Collider)); } catch (e) {}
            try { Destroy(getComponent(ball, Rigidbody)); } catch (e) {}
            kickBalls.push({
                obj: ball,
                pos: [Number(tip.field("x").value), Number(tip.field("y").value), Number(tip.field("z").value)],
                dir: [Number(dir.field("x").value), Number(dir.field("y").value), Number(dir.field("z").value)],
                born: Date.now()
            });
        } catch (e) {}
    }

    function updateKickBalls() {
        if (kickBalls.length === 0) return;
        const dt = (deltaTime > 0 ? deltaTime : 0.016);
        for (let i = kickBalls.length - 1; i >= 0; i--) {
            const kb = kickBalls[i];
            try {
                if (kb.obj == null || kb.obj.isNull()) { kickBalls.splice(i, 1); continue; }
                const age = Date.now() - kb.born;
                if (age > 4000) { try { Destroy(kb.obj); } catch (e) {} kickBalls.splice(i, 1); continue; }
                kb.pos[0] += kb.dir[0] * 900 * dt;
                kb.pos[1] += kb.dir[1] * 900 * dt;
                kb.pos[2] += kb.dir[2] * 900 * dt;
                getTransform(kb.obj).method("set_position").invoke([kb.pos[0], kb.pos[1], kb.pos[2]]);
                let hit = false;
                try {
                    const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
                    for (let j = 0; j < objects.length; j++) {
                        const obj = objects.get(j);
                        if (obj == null) continue;
                        const name = obj.method("get_name").invoke().content;
                        if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                        const p = getTransform(obj).method("get_position").invoke();
                        const dx = Number(p.field("x").value) - kb.pos[0];
                        const dy = Number(p.field("y").value) - kb.pos[1];
                        const dz = Number(p.field("z").value) - kb.pos[2];
                        if (dx * dx + dy * dy + dz * dz < 0.09) {
                            const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                            const local = PhotonNetwork.method("get_LocalPlayer").invoke();
                            if (pv != null && !pv.isNull()) {
                                const owner = pv.method("get_Owner").invoke();
                                if (owner != null && local != null && !owner.handle.equals(local.handle)) {
                                    kickPlayerObj(owner);
                                }
                            }
                            hit = true;
                            break;
                        }
                    }
                } catch (e) {}
                if (hit) { try { Destroy(kb.obj); } catch (e2) {} kickBalls.splice(i, 1); }
            } catch (e) { try { Destroy(kb.obj); } catch (e2) {} kickBalls.splice(i, 1); }
        }
    }

    let banHammerActive = false;
    let banHammerObj = null;
    let banHammerTip = null;
    let banHammerPrevTrigger = false;

    function removeBanHammer() {
        if (banHammerObj != null) { try { Destroy(banHammerObj); } catch (e) {} banHammerObj = null; }
        if (banHammerTip != null) { try { Destroy(banHammerTip); } catch (e) {} banHammerTip = null; }
    }

    function spawnBanHammer() {
        if (banHammerObj != null) return;
        try {
            const handPos = rightHandTransform.method("get_position").invoke();
            const handRot = rightHandTransform.method("get_rotation").invoke();
            try {
                const cands = ["BanHammer", "KickHammer", "ThorKickHammer", "LightningHammer"];
                for (const prefab of cands) {
                    try {
                        const inst = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(prefab), handPos, handRot, 0, NULL);
                        if (inst != null && !inst.isNull()) { banHammerObj = inst; break; }
                    } catch (e) {}
                }
            } catch (e) {}
            if (banHammerObj != null) {
                try { Destroy(getComponent(banHammerObj, Rigidbody)); } catch (e) {}
                try {
                    const cols = banHammerObj.method("GetComponentsInChildren", 1).inflate(Collider).invoke();
                    if (cols != null) { for (const col of cols) { try { Destroy(col); } catch (e) {} } }
                } catch (e) {}
            } else {
                banHammerObj = createObject(zeroVector, identityQuaternion, [0.5, 0.5, 0.5], 1, [1.0, 0.2, 0.1, 1.0]);
                try { Destroy(getComponent(banHammerObj, BoxCollider)); } catch (e) {}
                const handle = createObject(zeroVector, identityQuaternion, [0.06, 0.06, 0.55], 2, [0.55, 0.3, 0.2, 1.0], getTransform(banHammerObj));
                try { Destroy(getComponent(handle, BoxCollider)); } catch (e) {}
                const head = createObject(zeroVector, identityQuaternion, [0.22, 0.28, 0.2], 2, [0.9, 0.15, 0.1, 1.0], getTransform(banHammerObj));
                try { Destroy(getComponent(head, BoxCollider)); } catch (e) {}
                const band = createObject(zeroVector, identityQuaternion, [0.24, 0.05, 0.2], 2, [1.0, 0.8, 0.2, 1.0], getTransform(banHammerObj));
                try { Destroy(getComponent(band, BoxCollider)); } catch (e) {}
            }
            banHammerTip = createObject(zeroVector, identityQuaternion, [0.05, 0.05, 0.05], 0, [1.0, 0.9, 0.2, 1.0]);
            try { Destroy(getComponent(banHammerTip, BoxCollider)); } catch (e) {}
            updateBanHammer();
        } catch (e) { console.log("[BanHammer] spawn error: " + e); }
    }

    function updateBanHammer() {
        if (banHammerObj == null) return;
        try {
            const handPos = rightHandTransform.method("get_position").invoke();
            const handRot = rightHandTransform.method("get_rotation").invoke();
            const fwd = rightHandTransform.method("get_forward").invoke();
            const pos = Vector3.method("op_Addition", 2).invoke(handPos, Vector3.method("op_Multiply", 2).invoke(fwd, 0.1));
            const t = getTransform(banHammerObj);
            t.method("set_position").invoke(pos);
            t.method("set_rotation").invoke(handRot);
            if (banHammerTip != null) {
                const tipPos = Vector3.method("op_Addition", 2).invoke(pos, Vector3.method("op_Multiply", 2).invoke(fwd, 0.35));
                getTransform(banHammerTip).method("set_position").invoke(tipPos);
            }
        } catch (e) {}
    }

    function setBanHammerActive(on) {
        banHammerActive = on;
        if (on) spawnBanHammer(); else removeBanHammer();
    }

    function fireBanHammer() {
        try {
            const gunData = renderGun();
            const target = otherFromGunRay(gunData);
            if (target != null) {
                const pv = getComponentInParent(target.obj, PhotonViewClass);
                if (pv != null && !pv.isNull()) {
                    const owner = pv.method("get_Owner").invoke();
                    try {
                        const ownerId = Number(owner.method("get_ActorNumber").invoke());
                        PhotonNetwork.method("DestroyPlayerObjects", 2).invoke(ownerId, true);
                    } catch (e) {}
                    kickPlayerObj(owner);
                }
            }
        } catch (e) {}
    }

    function updateBanHammerRig() {
        if (banHammerActive) {
            updateBanHammer();
            if (rightTrigger && !banHammerPrevTrigger) fireBanHammer();
            banHammerPrevTrigger = rightTrigger;
        } else {
            removeBanHammer();
            banHammerPrevTrigger = false;
        }
    }

    function otherFromGunRay(gunData) {
        try {
            if (gunData == null) return null;
            let hitCollider = null;
            try {
                if (gunData.ray == null || gunData.ray.isNull()) return null;
                hitCollider = gunData.ray.method("get_collider").invoke();
            } catch (e) { return null; }
            if (hitCollider == null || hitCollider.isNull()) return null;
            const hitGo = hitCollider.method("get_gameObject").invoke();
            if (hitGo == null) return null;
            let pGo = null;
            try { pGo = hitGo.method("get_transform").invoke().method("get_root").invoke().method("get_gameObject").invoke(); } catch (e) { pGo = hitGo; }
            if (pGo == null) return null;
            const nm = pGo.method("get_name").invoke().content;
            if (nm.indexOf("BaboonNetworkPlayer") === -1) return null;
            const pv = getComponentInParent(pGo, PhotonViewClass);
            if (pv == null || pv.isNull()) return null;
            const owner = pv.method("get_Owner").invoke();
            if (owner == null) return null;
            const local = PhotonNetwork.method("get_LocalPlayer").invoke();
            if (local != null && owner.handle.equals(local.handle)) return null;
            return { obj: pGo, pos: getTransform(pGo).method("get_position").invoke() };
        } catch (e) { return null; }
    }

    let monkeyBase = null;
    function applyMonkeyScale() {
        try {
            const t = GTPlayer.method("get_transform").invoke();
            if (monkeyBase == null) {
                const s = t.method("get_localScale").invoke();
                monkeyBase = [Number(s.field("x").value), Number(s.field("y").value), Number(s.field("z").value)];
            }
            let mult = (bigMonkey ? 2 : 1) * (smallMonkey ? 0.5 : 1);
            t.method("set_localScale").invoke([monkeyBase[0] * mult, monkeyBase[1] * mult, monkeyBase[2] * mult]);
        } catch (e) {}
    }

    function applyGhost() {
        try {
            const t = GTPlayer.method("get_transform").invoke();
            const renderers = t.method("GetComponentsInChildren", 1).inflate(Renderer).invoke();
            if (renderers != null) {
                for (let i = 0; i < renderers.length; i++) {
                    try { renderers.get(i).method("set_enabled").invoke(!ghostMonkeyOn); } catch (e) {}
                }
            }
        } catch (e) {}
    }

    function findChildByName(rootT, want) {
        try {
            const queue = [rootT];
            while (queue.length > 0) {
                const t = queue.shift();
                const n = t.method("get_name").invoke().toString().toLowerCase();
                if (n.indexOf(want) >= 0 && n.indexOf("collider") < 0) return t;
                const count = t.method("get_childCount").invoke();
                for (let i = count - 1; i >= 0; i--) queue.push(t.method("GetChild").invoke(i));
            }
        } catch (e) {}
        return null;
    }

    function findLocalRig() {
        try {
            const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
            const local = PhotonNetwork.method("get_LocalPlayer").invoke();
            for (let i = 0; i < objects.length; i++) {
                const obj = objects.get(i);
                if (obj == null) continue;
                const name = obj.method("get_name").invoke().content;
                if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                if (pv == null || pv.isNull()) continue;
                const owner = pv.method("get_Owner").invoke();
                if (owner != null && local != null && owner.handle.equals(local.handle)) {
                    return obj;
                }
            }
        } catch (e) { console.log("[findLocalRig] error: " + e); }
        return null;
    }

    function getBrokenNeckHead() {
        if (brokenNeckHeadT != null) return brokenNeckHeadT;
        try {
            const rig = findLocalRig();
            if (rig == null) { console.log("[Neck] no local rig"); return null; }
            const rigT = getTransform(rig);
            brokenNeckHeadT = findChildByName(rigT, "head");
            if (brokenNeckHeadT != null) {
                const r = brokenNeckHeadT.method("get_localRotation").invoke();
                const e = r.method("get_eulerAngles").invoke();
                brokenNeckBase = [Number(e.field("x").value), Number(e.field("y").value), Number(e.field("z").value)];
                console.log("[Neck] head found, base: " + brokenNeckBase.join(","));
            } else {
                console.log("[Neck] no head transform found");
            }
        } catch (e) { console.log("[Neck] find error: " + e); }
        return brokenNeckHeadT;
    }

    function applyBrokenNeck() {
        try {
            const headT = getBrokenNeckHead();
            if (headT == null) return;
            if (brokenNeckOn) {
                headT.method("set_localRotation").invoke(Quaternion.method("Euler").invoke(0, 0, 90));
            } else if (brokenNeckBase != null) {
                headT.method("set_localRotation").invoke(Quaternion.method("Euler").invoke(brokenNeckBase[0], brokenNeckBase[1], brokenNeckBase[2]));
            }
        } catch (e) {}
    }

    function rigAlive(obj) {
        try {
            if (obj == null) return false;
            obj.method("get_name").invoke();
            return true;
        } catch (e) { return false; }
    }

    function setRigHidden(rig, hide) {
        try {
            const renderers = rig.method("GetComponentsInChildren", 1).inflate(Renderer).invoke();
            if (renderers != null) {
                for (let i = 0; i < renderers.length; i++) {
                    try { renderers.get(i).method("set_enabled").invoke(!hide); } catch (e) {}
                }
            }
        } catch (e) {}
        try {
            const pv = getComponentInParent(rig, PhotonViewClass);
            if (pv != null && !pv.isNull()) {
                try { pv.method("set_enabled").invoke(!hide); } catch (e) {}
            }
        } catch (e) {}
    }

    function setScaryGhost(active) {
        try {
            if (active) {
                if (scaryGhostRig == null || !rigAlive(scaryGhostRig)) {
                    scaryGhostRig = findLocalRig();
                    if (scaryGhostRig == null) { console.log("[GhostRig] no local rig found"); return; }
                }
                if (scaryGhostFrozen == null) {
                    try {
                        scaryGhostFrozen = Object.method("Instantiate", 1).invoke(scaryGhostRig);
                        if (scaryGhostFrozen != null && !scaryGhostFrozen.isNull()) {
                            const comps = scaryGhostFrozen.method("GetComponentsInChildren", 1).inflate(Component).invoke();
                            for (let i = 0; i < comps.length; i++) {
                                try {
                                    const c = comps.get(i);
                                    const tname = c.method("GetType", 0).invoke().method("get_Name").invoke().toString();
                                    if (tname.indexOf("Renderer") !== -1) continue;
                                    if (tname.indexOf("MeshFilter") !== -1) continue;
                                    if (tname == "Transform" || tname == "RectTransform") continue;
                                    Destroy(c);
                                } catch (e) {}
                            }
                            console.log("[GhostRig] frozen self created");
                        }
                    } catch (e) { console.log("[GhostRig] clone error: " + e); }
                }
                try { setRigHidden(scaryGhostRig, true); } catch (e) {}
            } else {
                if (scaryGhostFrozen != null) {
                    try { Destroy(scaryGhostFrozen); } catch (e) {}
                    scaryGhostFrozen = null;
                }
                if (scaryGhostRig != null) {
                    try { setRigHidden(scaryGhostRig, false); } catch (e) {}
                }
            }
        } catch (e) { console.log("[GhostRig] error: " + e); }
    }

    function setInvisMonkey(active) {
        try {
            if (active) {
                if (invisMonkeyRig == null || !rigAlive(invisMonkeyRig)) {
                    invisMonkeyRig = findLocalRig();
                    if (invisMonkeyRig == null) { console.log("[Invis] no local rig found"); return; }
                }
                try { setRigHidden(invisMonkeyRig, true); } catch (e) {}
            } else {
                if (invisMonkeyRig != null) {
                    try { setRigHidden(invisMonkeyRig, false); } catch (e) {}
                }
            }
        } catch (e) { console.log("[Invis] error: " + e); }
    }

    let daisyClip = null;
    let daisyReq = null;
    let daisyWantPlay = false;
    let daisyLoaded = false;
    let daisyAudioSrc = null;
    let daisyPlaying = false;

    function getDaisyPath() {
        try {
            const AppC = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Application");
            return AppC.method("get_persistentDataPath").invoke().toString() + "/daisy09.mp3";
        } catch (e) { return "/storage/emulated/0/Android/data/com.AnotherAxiom.GorillaTag/files/daisy09.mp3"; }
    }

    function startDaisyLoad() {
        if (daisyLoaded || daisyReq != null) return;
        try {
            const ConvertC = Il2Cpp.domain.assembly("mscorlib").image.class("System.Convert");
            const FileC = Il2Cpp.domain.assembly("mscorlib").image.class("System.IO.File");
            const path = getDaisyPath();
            const bytes = ConvertC.method("FromBase64String").invoke(Il2Cpp.string(DAISY09_B64));
            FileC.method("WriteAllBytes").invoke(Il2Cpp.string(path), bytes);
            console.log("[DAISY09] wrote file, loading clip...");
            const UWMA = Il2Cpp.domain.assembly("UnityEngine.UnityWebRequestAudioModule").image.class("UnityEngine.Networking.UnityWebRequestMultimedia");
            const AudioTypeC = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.AudioType");
            const mpeg = AudioTypeC.field("MPEG").value;
            const req = UWMA.method("GetAudioClip", 2).invoke(Il2Cpp.string("file://" + path), mpeg);
            req.method("SendWebRequest").invoke();
            daisyReq = req;
        } catch (e) { console.log("[DAISY09] load start: " + e); }
    }

    function updateDaisy() {
        if (daisyReq == null) return;
        try {
            if (!daisyReq.method("get_isDone").invoke()) return;
            const req = daisyReq;
            daisyReq = null;
            let err = "";
            try { err = req.method("get_error").invoke().toString(); } catch (e2) {}
            if (err != "" && err != "null") { console.log("[DAISY09] req error: " + err); return; }
            const handler = req.method("get_downloadHandler").invoke();
            const clip = handler.method("GetContent").invoke();
            if (clip == null || clip.isNull()) { console.log("[DAISY09] null clip"); return; }
            daisyClip = clip;
            daisyLoaded = true;
            console.log("[DAISY09] clip ready");
            if (daisyWantPlay) { daisyWantPlay = false; playDaisy(); }
        } catch (e) { console.log("[DAISY09] update: " + e); daisyReq = null; }
    }

    function stopDaisy() {
        try {
            if (daisyAudioSrc != null) {
                Destroy(daisyAudioSrc);
                daisyAudioSrc = null;
            }
        } catch (e) {}
        daisyPlaying = false;
    }

    function playDaisy() {
        if (!daisyLoaded) { daisyWantPlay = true; startDaisyLoad(); return; }
        if (daisyPlaying) { stopDaisy(); console.log("[DAISY09] stopped"); return; }
        try {
            const AudioSourceC = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
            const src = createObject(getTransform(headCollider).method("get_position").invoke(), identityQuaternion, [0.04, 0.04, 0.04], 3, [0, 0, 0, 0]);
            const au = addComponent(src, AudioSourceC);
            au.method("set_clip").invoke(daisyClip);
            try { au.method("set_loop").invoke(true); } catch (e) {}
            try { au.method("set_spatialBlend").invoke(0); } catch (e) {}
            try { au.method("set_volume").invoke(1); } catch (e) {}
            au.method("Play").invoke();
            daisyAudioSrc = src;
            daisyPlaying = true;
            console.log("[DAISY09] playing");
        } catch (e) { console.log("[DAISY09] play: " + e); }
    }

    function updateScaryMods() {
        try {
            if (brokenNeckOn) applyBrokenNeck();
        } catch (e) {}
        try {
            if (scaryGhostArmed) {
                if (leftPrimary && !scaryGhostActive) {
                    scaryGhostActive = true;
                    setScaryGhost(true);
                } else if (!leftPrimary && scaryGhostActive) {
                    scaryGhostActive = false;
                    setScaryGhost(false);
                }
            } else if (scaryGhostActive) {
                scaryGhostActive = false;
                setScaryGhost(false);
            }
        } catch (e) {}
        try {
            if (invisMonkeyArmed) {
                if (rightSecondary && !invisMonkeyActive) {
                    invisMonkeyActive = true;
                    setInvisMonkey(true);
                } else if (!rightSecondary && invisMonkeyActive) {
                    invisMonkeyActive = false;
                    setInvisMonkey(false);
                }
            } else if (invisMonkeyActive) {
                invisMonkeyActive = false;
                setInvisMonkey(false);
            }
        } catch (e) {}
        try {
            if (ghostNameSpamOn) {
                const now = Date.now();
                if (now - ghostNameLast >= 600) {
                    ghostNameLast = now;
                                        const name = "N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST N3X0N GHOST \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";;
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name));
                }
            }
        } catch (e) {}
    }

    function applyGiantHands() {
        const mult = giantHandsOn ? 3 : (1 / 3);
        for (const hand of [leftHandTransform, rightHandTransform]) {
            try {
                const s = hand.method("get_localScale").invoke();
                hand.method("set_localScale").invoke([
                    Number(s.field("x").value) * mult,
                    Number(s.field("y").value) * mult,
                    Number(s.field("z").value) * mult
                ]);
            } catch (e) {}
        }
    }

    function rayTargetFromHand() {
        try {
            const start = rightHandTransform.method("get_position").invoke();
            const dir = rightHandTransform.method("get_forward").invoke();
            const hits = Physics.method("RaycastAll", 4).invoke(start, dir, 512.0, -3180559);
            let target = null;
            let bestD = Infinity;
            for (const h of hits) {
                try {
                    const d = Vector3.method("Distance").invoke(h.method("get_point").invoke(), start);
                    if (d < bestD) { bestD = d; target = h.method("get_point").invoke(); }
                } catch (e) {}
            }
            if (target == null) {
                target = Vector3.method("op_Addition", 2).invoke(start, Vector3.method("op_Multiply", 2).invoke(dir, 20));
            }
            return target;
        } catch (e) { return null; }
    }

    function killAllPlayers() {
        try {
            const locals = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localId = Number(locals.method("get_ActorNumber").invoke());
            let count = 0;
            try {
                const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
                for (let i = 0; i < objects.length; i++) {
                    try {
                        const obj = objects.get(i);
                        if (obj == null) continue;
                        const name = obj.method("get_name").invoke().content;
                        if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                        const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                        if (pv == null || pv.isNull()) continue;
                        const owner = pv.method("get_Owner").invoke();
                        if (owner == null) continue;
                        const ownerId = Number(owner.method("get_ActorNumber").invoke());
                        if (ownerId == localId) continue;
                        const pos = getTransform(obj).method("get_position").invoke();
                        const strikePos = Vector3.method("op_Addition", 2).invoke(pos, [0, 0.6, 0]);
                        try {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("LightningHammer"), strikePos, identityQuaternion, 0, NULL);
                        } catch (e) {}
                        try {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ThorKickHammer"), strikePos, identityQuaternion, 0, NULL);
                        } catch (e) {}
                        try {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("LightningHammer"), pos, identityQuaternion, 0, NULL);
                        } catch (e) {}
                        count++;
                    } catch (e) { continue; }
                }
            } catch (e) { console.log("[Kill All] scan: " + e); }
            sendAllOutgoing();
            console.log("[Kill All] killed " + count + " players");
        } catch (e) { console.log("[Kill All] error: " + e); }
    }

    function flingAllPlayers() {
        try {
            const locals = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localId = Number(locals.method("get_ActorNumber").invoke());
            let count = 0;
            try {
                const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
                for (let i = 0; i < objects.length; i++) {
                    try {
                        const obj = objects.get(i);
                        if (obj == null) continue;
                        const name = obj.method("get_name").invoke().content;
                        if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                        const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                        if (pv == null || pv.isNull()) continue;
                        const owner = pv.method("get_Owner").invoke();
                        if (owner == null) continue;
                        const ownerId = Number(owner.method("get_ActorNumber").invoke());
                        if (ownerId == localId) continue;
                        const pos = getTransform(obj).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFling"), pos, identityQuaternion, 0, NULL);
                        count++;
                    } catch (e) { continue; }
                }
            } catch (e) { console.log("[Fling All] scan: " + e); }
            sendAllOutgoing();
            console.log("[Fling All] flung " + count + " players");
        } catch (e) { console.log("[Fling All] error: " + e); }
    }

    function applyFlat() {
        try {
            const t = GTPlayer.method("get_transform").invoke();
            if (flatBase == null) {
                const s = t.method("get_localScale").invoke();
                flatBase = [Number(s.field("x").value), Number(s.field("y").value), Number(s.field("z").value)];
            }
            if (flatMonkey) {
                t.method("set_localScale").invoke([flatBase[0] * 1.2, flatBase[1] * 0.4, flatBase[2] * 1.2]);
            } else {
                t.method("set_localScale").invoke(flatBase);
            }
        } catch (e) {}
    }

    function applyStretch() {
        try {
            const t = GTPlayer.method("get_transform").invoke();
            if (stretchBase == null) {
                const s = t.method("get_localScale").invoke();
                stretchBase = [Number(s.field("x").value), Number(s.field("y").value), Number(s.field("z").value)];
            }
            if (stretchMonkey) {
                t.method("set_localScale").invoke([stretchBase[0] * 0.6, stretchBase[1] * 1.6, stretchBase[2] * 0.6]);
            } else {
                t.method("set_localScale").invoke(stretchBase);
            }
        } catch (e) {}
    }

    function applyGiant() {
        try {
            const t = GTPlayer.method("get_transform").invoke();
            if (giantBase == null) {
                const s = t.method("get_localScale").invoke();
                giantBase = [Number(s.field("x").value), Number(s.field("y").value), Number(s.field("z").value)];
            }
            t.method("set_localScale").invoke(giantMonkey ? [giantBase[0] * 4, giantBase[1] * 4, giantBase[2] * 4] : giantBase);
        } catch (e) {}
    }

    function scanOtherRigs(cb) {
        try {
            const locals = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localId = Number(locals.method("get_ActorNumber").invoke());
            const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
            for (let i = 0; i < objects.length; i++) {
                try {
                    const obj = objects.get(i);
                    if (obj == null) continue;
                    const name = obj.method("get_name").invoke().content;
                    if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                    const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                    if (pv == null || pv.isNull()) continue;
                    const owner = pv.method("get_Owner").invoke();
                    if (owner == null) continue;
                    const ownerId = Number(owner.method("get_ActorNumber").invoke());
                    if (ownerId == localId) continue;
                    cb(obj, getTransform(obj).method("get_position").invoke());
                } catch (e) { continue; }
            }
        } catch (e) {}
    }

    function clearMySpawns() {
        try {
            const locals = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localId = locals.method("get_UserId").invoke().toString();
            const views = PhotonNetwork.method("get_PhotonViewList").invoke();
            for (let i = 0; i < views.length; i++) {
                try {
                    const pv = views.get(i);
                    if (pv == null) continue;
                    const owner = pv.method("get_Owner").invoke();
                    if (owner == null) continue;
                    if (owner.method("get_UserId").invoke().toString() !== localId) continue;
                    let g = null;
                    try { g = pv.method("get_gameObject").invoke(); } catch (e) {}
                    if (g == null) continue;
                    const n = g.method("get_name").invoke().content;
                    if (n.indexOf("Baboon") !== -1) continue;
                    Destroy(g);
                } catch (e) {}
            }
        } catch (e) {}
    }

    const buttons: ButtonInfo[][] = [
        [ // Home
            new ButtonInfo({
                buttonText: "Settings",
                method: () => currentCategory = 2,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Movement",
                method: () => currentCategory = 3,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Utility",
                method: () => currentCategory = 4,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Overpowered",
                method: () => currentCategory = 5,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Guns NOT WORKING",
                method: () => currentCategory = 6,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "boomboxs",
                method: () => currentCategory = 7,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Effects",
                method: () => { currentCategory = 8, currentPage = 0 },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Monsters",
                method: () => { currentCategory = 9, currentPage = 0 },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Staff",
                method: () => { currentCategory = 10, currentPage = 0 },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Cosmetics",
                method: () => { currentCategory = 11, currentPage = 0 },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Mods",
                method: () => { currentCategory = 12, currentPage = 0 },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Scary",
                method: () => { currentCategory = 13, currentPage = 0 },
                keepOn: false,
            }),
        ],
        [ // Menu Buttons
            new ButtonInfo({
                buttonText: "Leave",
                method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Home",
                method: () => {
                    currentCategory = 0
                    currentPage = 0
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PreviousPage",
                method: () => {
                    const srcLen = searchMode ? searchResults.length : buttons[currentCategory].length;
                    const lastPage = Math.ceil(srcLen / 6) - 1;
                    if (lastPage < 0) { currentPage = 0; return; }
                    currentPage--;
                    if (currentPage < 0)
                        currentPage = lastPage;
                },
                keepOn: false
            }),
            new ButtonInfo({
                buttonText: "NextPage",
                method: () => {
                    const srcLen = searchMode ? searchResults.length : buttons[currentCategory].length;
                    const lastPage = Math.ceil(srcLen / 6) - 1;
                    if (lastPage < 0) { currentPage = 0; return; }
                    currentPage++;
                    currentPage %= lastPage + 1;
                },
                keepOn: false
            })
        ],
        [ // Settings
            new ButtonInfo({
                buttonText: `Fly Speed+`,
                method: () => {
                    flyspeed += 1;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: `Fly Speed-`,
                method: () => {
                    flyspeed -= 1;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Platform Color",
                method: () => {
                    plater = (plater + 1) % platColors.length;
                    platColor = platColors[plater];
                },
                keepOn: false
            }),
        ],
        [ // Movement Mods
            new ButtonInfo({
                buttonText: "Fly [B]",
                method: () => {
                    if (rightSecondary) {
                        const leftRightVector = rightHandTransform.method("get_forward").invoke();
                        const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, flyspeed);
                        rigidbody.method("set_velocity").invoke(leftForce);
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Platforms [G]",
                method: () => {
                    Platforms()
                },
            }),

            new ButtonInfo({
                buttonText: "No Clip",
                method: () => {
                    if (rightTrigger && !previousNoclipKey) {
                        toggleColliders(false);
                    }

                    if (!rightTrigger && previousNoclipKey) {
                        toggleColliders(true);
                    }

                    previousNoclipKey = rightTrigger;
                },
            }),

            new ButtonInfo({
                buttonText: "Long Arms",
                method: () => { toggleLongArms() },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Joystick Fly",
                method: () => {
                    try {
                        const stick = OVRInputHandler.leftThumbstick;
                        const magnitude = Math.sqrt(stick[0] * stick[0] + stick[1] * stick[1]);
                        if (magnitude > 0.1) {
                            let fwd = null;
                            let right = null;
                            const tryTransform = (t: any): boolean => {
                                if (t == null) return false;
                                const f = t.method("get_forward").invoke();
                                const r = t.method("get_right").invoke();
                                if (f == null || r == null) return false;
                                const fv = [f.field("x").value, f.field("y").value, f.field("z").value];
                                const rv = [r.field("x").value, r.field("y").value, r.field("z").value];
                                const fMag = Math.sqrt(fv[0] * fv[0] + fv[1] * fv[1] + fv[2] * fv[2]);
                                const rMag = Math.sqrt(rv[0] * rv[0] + rv[1] * rv[1] + rv[2] * rv[2]);
                                if (fMag < 0.5 || rMag < 0.5) return false;
                                fwd = f;
                                right = r;
                                return true;
                            };
                            let ok = false;
                            try {
                                const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                                if (cam != null) { ok = tryTransform(cam.method("get_transform").invoke()); }
                            } catch (e2) {}
                            if (!ok) { try { ok = tryTransform(getTransform(headCollider)); } catch (e3) {} }
                            if (!ok) { try { ok = tryTransform(getTransform(rightHandTransform)); } catch (e4) {} }
                            if (!ok) { fwd = [0, 0, 1]; right = [1, 0, 0]; }
                            const dir = Vector3.method("op_Addition", 2).invoke(
                                Vector3.method("op_Multiply", 2).invoke(fwd, stick[1]),
                                Vector3.method("op_Multiply", 2).invoke(right, stick[0])
                            );
                            const dv = [dir.field("x").value, dir.field("y").value, dir.field("z").value];
                            const dirMag = Math.sqrt(dv[0] * dv[0] + dv[1] * dv[1] + dv[2] * dv[2]);
                            const vel = Vector3.method("op_Multiply", 2).invoke(dir, dirMag > 0.001 ? flyspeed / dirMag : flyspeed);
                            rigidbody.method("set_velocity").invoke(vel);
                            const playerTransform = rigidbody.method("get_transform").invoke();
                            const pos = playerTransform.method("get_position").invoke();
                            const step = Vector3.method("op_Multiply", 2).invoke(vel, deltaTime);
                            const newPos = Vector3.method("op_Addition", 2).invoke(pos, step);
                            playerTransform.method("set_position").invoke(newPos);
                            const now = Date.now();
                            if (now - hussFlyLastLog > 1000) {
                                hussFlyLastLog = now;
                                console.log("joystick fly: stick=" + stick[0].toFixed(2) + "," + stick[1].toFixed(2) + " mag=" + magnitude.toFixed(2));
                            }
                        } else {
                            const current = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([0, current.field("y").value, 0]);
                        }
                    } catch (e) { console.log("joystick fly error: " + e); }
                },
            }),

            new ButtonInfo({
                buttonText: "Hyper Speed [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 40);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Mega Fly [B]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightSecondary) {
                        try {
                            const fwd = rightHandTransform.method("get_forward").invoke();
                            const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 30);
                            rigidbody.method("set_velocity").invoke(vel);
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Super Jump [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !superJumpPrev) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 25, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    superJumpPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Bounce",
                keepOn: true,
                enabled: false,
                enableMethod: () => { bounceOn = true; },
                disableMethod: () => { bounceOn = false; },
                method: () => {
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        if (Number(v.field("y").value) < -2) {
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 14, Number(v.field("z").value)]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Blink to Aim [LP]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (leftPrimary && !blinkPrev) {
                        try {
                            const target = rayTargetFromHand();
                            if (target != null) rigidbody.method("set_position").invoke(target);
                        } catch (e) {}
                    }
                    blinkPrev = leftPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Grapple Pull [LT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftTrigger) return;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const p = rigidbody.method("get_position").invoke();
                        const vel = [
                            (Number(target.field("x").value) - Number(p.field("x").value)) * 22,
                            (Number(target.field("y").value) - Number(p.field("y").value)) * 22 + 4,
                            (Number(target.field("z").value) - Number(p.field("z").value)) * 22
                        ];
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Giant Monkey",
                keepOn: true,
                enabled: false,
                enableMethod: () => { giantMonkey = true; applyGiant(); },
                disableMethod: () => { giantMonkey = false; applyGiant(); },
            }),

            new ButtonInfo({
                buttonText: "Boost Up [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (leftGrab) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 18, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Launcher [RG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightGrab && !launcherPrev) {
                        try {
                            const fwd = rightHandTransform.method("get_forward").invoke();
                            const v = Vector3.method("op_Multiply", 2).invoke(fwd, 14);
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 12, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    launcherPrev = rightGrab;
                },
            }),

            new ButtonInfo({
                buttonText: "Moon Gravity",
                keepOn: true,
                enabled: false,
                enableMethod: () => { moonGravityOn = true; },
                disableMethod: () => { moonGravityOn = false; },
                method: () => {
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        const vy = Number(v.field("y").value);
                        if (vy < -5) {
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -2, Number(v.field("z").value)]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Fast Dash [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 35);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Brake [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightTrigger) {
                        try { rigidbody.method("set_velocity").invoke([0, 0, 0]); } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Back Dash [B]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightSecondary) return;
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, -20);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Low Gravity",
                keepOn: true,
                enabled: false,
                method: () => {
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        const vy = Number(v.field("y").value);
                        if (vy < -4) {
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -4, Number(v.field("z").value)]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "High Gravity",
                keepOn: true,
                enabled: false,
                method: () => {
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        if (Number(v.field("y").value) > -12) {
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -12, Number(v.field("z").value)]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Jetpack [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 14, Number(v.field("z").value)]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Nitro [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    try {
                        const fwd = rightHandTransform.method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 18);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Slam Down [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !slamPrev) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -30, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    slamPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Sticky Leap [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !stickyPrev) {
                        try {
                            const fwd = rightHandTransform.method("get_forward").invoke();
                            const v = Vector3.method("op_Multiply", 2).invoke(fwd, 12);
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 12, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    stickyPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Random Teleport",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        rigidbody.method("set_position").invoke([
                            Number(p.field("x").value) + (Math.random() - 0.5) * 30,
                            Number(p.field("y").value) + 2,
                            Number(p.field("z").value) + (Math.random() - 0.5) * 30
                        ]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Platform Drop",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), [Number(p.field("x").value), Number(p.field("y").value) - 1, Number(p.field("z").value)], identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Platform Trail [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - platformTrailLast < 250) return;
                    platformTrailLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), [Number(p.field("x").value), Number(p.field("y").value) - 1, Number(p.field("z").value)], identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Boost Fling",
                method: () => {
                    try {
                        const fwd = rightHandTransform.method("get_forward").invoke();
                        const v = Vector3.method("op_Multiply", 2).invoke(fwd, 30);
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), Number(v.field("y").value) + 6, Number(v.field("z").value)]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Super Run [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 22);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Mega Jump [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !megaJumpPrev) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 20, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    megaJumpPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Sprint [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    try {
                        const fwd = rightHandTransform.method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 16);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Drift [LT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftTrigger) return;
                    try {
                        let right = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) right = cam.method("get_transform").invoke().method("get_right").invoke();
                        } catch (e) {}
                        if (right == null) right = getTransform(headCollider).method("get_right").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(right, 10);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Hover",
                keepOn: true,
                enabled: false,
                method: () => {
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        if (Number(v.field("y").value) < -1) {
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -1, Number(v.field("z").value)]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Swim Up [B]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightSecondary) return;
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 12, Number(v.field("z").value)]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Dive [A Hold]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightPrimary) return;
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -12, Number(v.field("z").value)]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Air Dodge [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    try {
                        const ang = Math.random() * Math.PI * 2;
                        rigidbody.method("set_velocity").invoke([Math.cos(ang) * 12, 4, Math.sin(ang) * 12]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Speed Fling",
                method: () => {
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 50);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Backflip",
                method: () => {
                    try {
                        getTransform(GTPlayer).method("Rotate", 2).invoke([0, 1, 0], 360);
                        const v = rigidbody.method("get_velocity").invoke();
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 8, Number(v.field("z").value)]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Roof Sniper",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const up = Vector3.method("op_Addition", 2).invoke(target, [0, 12, 0]);
                        rigidbody.method("set_position").invoke(up);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Teleport Down",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        rigidbody.method("set_position").invoke([Number(p.field("x").value), Number(p.field("y").value) - 10, Number(p.field("z").value)]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Bounce Boost [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - bounceBoostLast < 200) return;
                    bounceBoostLast = now;
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 15, Number(v.field("z").value)]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Platform Bridge [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - platformBridgeLast < 300) return;
                    platformBridgeLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Speed Burst [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    const now = Date.now();
                    if (now - speedBurstLast < 400) return;
                    speedBurstLast = now;
                    try {
                        const fwd = rightHandTransform.method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 28);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Tornado Spin [B]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightSecondary) return;
                    try {
                        getTransform(GTPlayer).method("Rotate", 2).invoke([0, 1, 0], 1080 * deltaTime);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Slingshot",
                method: () => {
                    try {
                        const fwd = rightHandTransform.method("get_forward").invoke();
                        const v = Vector3.method("op_Multiply", 2).invoke(fwd, 25);
                        rigidbody.method("set_velocity").invoke([Number(v.field("x").value), Number(v.field("y").value) + 15, Number(v.field("z").value)]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Wall Peek [B]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightSecondary) return;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, -3);
                        rigidbody.method("set_position").invoke([
                            Number(p.field("x").value) + Number(vel.field("x").value),
                            Number(p.field("y").value),
                            Number(p.field("z").value) + Number(vel.field("z").value)
                        ]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Sonic Dash [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !sonicPrev) {
                        try {
                            const fwd = rightHandTransform.method("get_forward").invoke();
                            const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 60);
                            rigidbody.method("set_velocity").invoke(vel);
                        } catch (e) {}
                    }
                    sonicPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Sky Jump [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !skyJumpPrev) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 18, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    skyJumpPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Hop Pad [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightTrigger) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            if (Number(v.field("y").value) < 5) {
                                rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 8, Number(v.field("z").value)]);
                            }
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Slow Fall [LT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (leftTrigger) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            if (Number(v.field("y").value) < -1) {
                                rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -1, Number(v.field("z").value)]);
                            }
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Dash Push [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (leftGrab) {
                        try {
                            let fwd = null;
                            try {
                                const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                                if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                            } catch (e) {}
                            if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                            const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 22);
                            rigidbody.method("set_velocity").invoke(vel);
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Speed Dive [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), -25, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Bounce Feet [B]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightSecondary) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 14, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                },
            }),
        ],
        [ // Misc Mods
            new ButtonInfo({
                buttonText: "Open Staff",
                method: () => {
                    Destroy(GameObject.method("Find").invoke(Il2Cpp.string("Staff")));
                },
                keepOn: false,
            }),

        new ButtonInfo({
            buttonText: "Force Staff Enable",
            method: () => {
                const objects = Resources.method("FindObjectsOfTypeAll")
                    .invoke(GameObject);

                for (const obj of objects) {
                    const name = obj.method("get_name").invoke().content;

                    if (
                        name.includes("Staff") ||
                        name.includes("StaffOnly") ||
                        name.includes("Staff_Items")
                    ) {
                        try {
                            obj.method("SetActive").invoke(true);
                            console.log("Enabled:", name);
                        } catch (e) {
                            console.log("Failed:", name, e);
                        }
                    }
                }
            },
            keepOn: false,
        }),

            new ButtonInfo({
                buttonText: "See Staff Items",
                method: () => {
    const ResourcesClass = UnityEngineCore.class("UnityEngine.Resources");
    const GameObjectClass = UnityEngineCore.class("UnityEngine.GameObject");

    const objects = ResourcesClass
        .method("FindObjectsOfTypeAll")
        .inflate(GameObjectClass)
        .invoke();

    for (const obj of objects) {
        if (obj == null) continue;

        const name = obj.method("get_name").invoke().content;

        if (name == "ModStuff") {
            console.log("Found:", name);

            obj.method("SetActive").invoke(true);

            const renderer = getComponent(obj, Renderer);

            if (renderer != null) {
                renderer.method("set_enabled").invoke(true);
            }

            console.log("Enabled ModStuff");
        }

        if (name == "AdminStuff") {
            console.log("Found:", name);

            obj.method("SetActive").invoke(true);

            const renderer = getComponent(obj, Renderer);

            if (renderer != null) {
                renderer.method("set_enabled").invoke(true);
            }

            console.log("Enabled AdminStuff");
        }
    }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Spawn BoogieBomb",
                method: () => {
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string('BoogieBomb'), [-182.26, 66.99, 39.19], identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "BoogieBomb Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string('BoogieBomb'), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "BoogieExplode Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string('BoogieExplode'), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Lockdown Lab",
                method: () => {
                    PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 69.99, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 69.468, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 68.946, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 68.424, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 67.902, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 67.38, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 66.858, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.99, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-192.512, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.034, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-193.556, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.078, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-194.6, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.122, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-195.644, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.166, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-196.688, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.21, 66.336, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 40.79], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 41.312], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 41.834], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 42.356], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 42.878], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 43.4], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.99, 43.89], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 40.79], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 41.312], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 41.834], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 42.356], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 42.878], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 43.4], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 69.468, 43.89], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 40.79], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 41.312], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 41.834], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 42.356], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 42.878], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 43.4], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.946, 43.89], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 40.79], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 41.312], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 41.834], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 42.356], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 42.878], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 43.4], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 68.424, 43.89], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 40.79], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 41.312], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 41.834], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 42.356], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 42.878], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 43.4], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.902, 43.89], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 40.79], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 41.312], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 41.834], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 42.356], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 42.878], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 43.4], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-197.3, 67.38, 43.89], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.45, 66.3, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.928, 66.3, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.406, 66.3, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.884, 66.3, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.16, 66.3, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.45, 66.822, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.928, 66.822, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.406, 66.822, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.884, 66.822, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.16, 66.822, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.45, 67.344, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.928, 67.344, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.406, 67.344, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.884, 67.344, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.16, 67.344, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.45, 67.866, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.928, 67.866, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.406, 67.866, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.884, 67.866, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.16, 67.866, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.45, 68.388, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.928, 68.388, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.406, 68.388, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.884, 68.388, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.16, 68.388, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.45, 68.91, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.928, 68.91, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-190.406, 68.91, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.884, 68.91, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.16, 68.91, 48.53], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.53, 66.37, 48.51], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.53, 66.892, 48.51], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.53, 67.414, 48.51], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.53, 67.936, 48.51], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-189.53, 68.458, 48.51], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-179.84, 66.59, 48.47], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-180.18, 66.61, 48.49], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-180.61, 66.61, 48.52], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-183.05, 66.80, 47.70], identityQuaternion, 0x0, NULL), sendAllOutgoing(), PhotonNetwork.method('Instantiate', 0x5).invoke(Il2Cpp.string('GlassBlock S'), [-191.67, 67.02, 39.19], identityQuaternion, 0x0, NULL), sendAllOutgoing();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Spawn Lockdown",
                method: () => {
                    startLockdown();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Stop Spawn Lockdown",
                method: () => {
                    stopLockdown();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Trap All",
                method: () => {
                    TrapAll();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Get Gun Position",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            console.log(pos);
                        };
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "discord name",
                method: () => {
                    const name = "https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz https://discord.gg/nexonmodz \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Space Name",
                method: () => {
                    const name = " "
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "FUCKED BY NEXON Name",
                method: () => {
                    const name = "FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON FUCKED BY NEXON\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "NEXON Name",
                method: () => {
                    const name = "NEXON\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "MODDED BY NEXON Name",
                method: () => {
                    const name = "MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON MODDED BY NEXON \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Fuck SOUR Name",
                method: () => {
                    const name = "FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy FUCK SOUR GET MODDED BITCH -nexon & ludemy  \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "PH Website Name",
                method: () => {
                    const name = "https://pornhub.com"
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Set Game Info Name",
                method: () => {
                    let playfabId = "Unknown";
                    let realtimeId = "Unknown";
                    let voiceId = "Unknown";
                    try {
                        let pf = Il2Cpp.domain.assembly("PlayFab").image.class("PlayFab.PlayFabSettings");
                        playfabId = pf.method("get_TitleId").invoke();
                    } catch (e) {
                        console.log("PlayFab: " + e);
                    }
                    try {
                        let serverSettings = Il2Cpp.gc.choose(Il2Cpp.domain.assembly("PhotonUnityNetworking").image.class("Photon.Pun.ServerSettings"))[0];
                        let appSettings = serverSettings.field("AppSettings").value;
                        realtimeId = appSettings.field("AppIdRealtime").value;
                        voiceId = appSettings.field("AppIdVoice").value;
                    } catch (e) {
                        console.log("Photon: " + e);
                    }
                    let name = "TitleId:" + playfabId + "\n| Photon Realtime:" + realtimeId + "\n| Photon Voice:" + voiceId + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name));
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Spam Name",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime < 500) return;
                    lastRunTime = now;
                    const glitchChars = "NXN";
                    let name = "";
                    for (let i = 0; i < 10000; i++) name += glitchChars[Math.floor(Math.random() * glitchChars.length)];
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(`<color=#${Math.floor(Math.random()*0xFFFFFF).toString(16).padStart(6,"0")}>${name}</color>`));
                },
                keepOn: true
            }),

            new ButtonInfo({
                buttonText: "Explode All",
                method: () => {
                    try {
                        scanOtherRigs((obj, pos) => {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), pos, identityQuaternion, 0, NULL);
                        });
                        sendAllOutgoing();
                        console.log("[Utility] Explode All");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Glass All",
                method: () => {
                    try {
                        scanOtherRigs((obj, pos) => {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                        });
                        sendAllOutgoing();
                        console.log("[Utility] Glass All");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Sky All",
                method: () => {
                    try {
                        scanOtherRigs((obj, pos) => {
                            const up = Vector3.method("op_Addition", 2).invoke(pos, [0, 50, 0]);
                            getTransform(obj).method("set_position").invoke(up);
                        });
                        console.log("[Utility] Sky All");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Big Boom",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), p, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Ragdoll Spam [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - ragdollSpamLast < 60) return;
                    ragdollSpamLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Monster Spawner [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - monsterLast < 300) return;
                    monsterLast = now;
                    try {
                        const mons = ["BigLarry", "VeryScaryMeatMan", "monsters/MeatManFast", "monsters/Fred", "BlackGooGuy", "monsters/White"];
                        const pick = mons[Math.floor(Math.random() * mons.length)];
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Gun Rain",
                keepOn: true,
                enabled: false,
                method: () => {
                    const now = Date.now();
                    if (now - gunRainLast < 300) return;
                    gunRainLast = now;
                    try {
                        const guns = ["SMGCommon", "ShotgunCommon", "ScarCommon", "PistolCommon", "SniperCommon"];
                        const pick = guns[Math.floor(Math.random() * guns.length)];
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [
                            (Math.random() - 0.5) * 2,
                            3,
                            (Math.random() - 0.5) * 2
                        ]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Mega Lag",
                method: () => {
                    try {
                        for (let i = 0; i < 1500; i++) {
                            const go = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL);
                            Destroy(go);
                        }
                        sendAllOutgoing();
                        console.log("[Utility] Mega Lag");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Clear My Spawns",
                method: () => {
                    clearMySpawns();
                    sendAllOutgoing();
                    console.log("[Utility] Cleared spawns");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Bomb All",
                keepOn: true,
                enabled: false,
                method: () => {
                    const now = Date.now();
                    if (now - bombAllLast < 500) return;
                    bombAllLast = now;
                    try {
                        scanOtherRigs((obj, pos) => {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieBomb"), pos, identityQuaternion, 0, NULL);
                        });
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Spawn Asteroid",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Random Name",
                method: () => {
                    try {
                        const names = ["Shrek", "Yoda", "Peppa", "Broccoli", "Monke", "Chungus", "Vegeta", "Kirby", "Blob", "Banana"];
                        const pick = names[Math.floor(Math.random() * names.length)];
                        PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(pick));
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Glass Ring",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        for (let i = 0; i < 8; i++) {
                            const a = (i / 8) * Math.PI * 2;
                            const pos = Vector3.method("op_Addition", 2).invoke(p, [Math.cos(a) * 1.5, 0, Math.sin(a) * 1.5]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Rocket Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rocketRainLast < 350) return;
                    rocketRainLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Rpg"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Asteroid Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - asteroidRainLast < 200) return;
                    asteroidRainLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [(Math.random() - 0.5) * 2, 4, (Math.random() - 0.5) * 2]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Spawn Grenade",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GrenadeGrabbable"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Spawn Rocket",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Rpg"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Glass Box",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const spots = [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
                        for (let i = 0; i < spots.length; i++) {
                            const pos = Vector3.method("op_Addition", 2).invoke(p, spots[i]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Crazy Noise",
                method: () => {
                    try {
                        const sounds = ["Wind", "Confetti", "AMacrena", "DonPollo", "Fein", "Skibidi", "ladyhear", "TylerTheCreator", "TectAudio", "Splash", "NCSTrack", "ImBoutaBombThisPlane"];
                        const pick = sounds[Math.floor(Math.random() * sounds.length)];
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Platform Gun [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - platformGunLast < 200) return;
                    platformGunLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Meteor Ring",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        for (let i = 0; i < 12; i++) {
                            const a = (i / 12) * Math.PI * 2;
                            const pos = Vector3.method("op_Addition", 2).invoke(p, [Math.cos(a) * 3, 4, Math.sin(a) * 3]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Glass Dome",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        for (let i = 0; i < 16; i++) {
                            const a = (i / 16) * Math.PI * 2;
                            const pos = Vector3.method("op_Addition", 2).invoke(p, [Math.cos(a) * 2, 1, Math.sin(a) * 2]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),
        ],
        [ // Overpowered
            new ButtonInfo({
                buttonText: "Slow Mo",
                keepOn: true,
                enabled: false,
                enableMethod: () => { try { Time.method("set_timeScale").invoke(0.3); } catch (e) {} },
                disableMethod: () => { try { Time.method("set_timeScale").invoke(1.0); } catch (e) {} },
            }),

            new ButtonInfo({
                buttonText: "FOV Zoom",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    try {
                        const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                        if (cam != null) cam.method("set_fieldOfView").invoke(40);
                    } catch (e) {}
                },
                disableMethod: () => {
                    try {
                        const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                        if (cam != null) cam.method("set_fieldOfView").invoke(90);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Magnet Hand [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    try {
                        const handPos = leftHandTransform.method("get_position").invoke();
                        const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
                        const local = PhotonNetwork.method("get_LocalPlayer").invoke();
                        let best = null, bestD = Infinity;
                        for (let i = 0; i < objects.length; i++) {
                            try {
                                const obj = objects.get(i);
                                if (obj == null) continue;
                                const name = obj.method("get_name").invoke().content;
                                if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                                const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                                if (pv == null || pv.isNull()) continue;
                                const owner = pv.method("get_Owner").invoke();
                                if (owner == null || local == null || owner.handle.equals(local.handle)) continue;
                                const p = getTransform(obj).method("get_position").invoke();
                                const dx = Number(p.field("x").value) - Number(handPos.field("x").value);
                                const dy = Number(p.field("y").value) - Number(handPos.field("y").value);
                                const dz = Number(p.field("z").value) - Number(handPos.field("z").value);
                                const d = dx * dx + dy * dy + dz * dz;
                                if (d < bestD) { bestD = d; best = obj; }
                            } catch (e) { continue; }
                        }
                        if (best != null) {
                            const p = getTransform(best).method("get_position").invoke();
                            const nx = Number(p.field("x").value) + (Number(handPos.field("x").value) - Number(p.field("x").value)) * 0.08;
                            const ny = Number(p.field("y").value) + (Number(handPos.field("y").value) - Number(p.field("y").value)) * 0.08;
                            const nz = Number(p.field("z").value) + (Number(handPos.field("z").value) - Number(p.field("z").value)) * 0.08;
                            getTransform(best).method("set_position").invoke([nx, ny + 0.4, nz]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Ban Echo",
                keepOn: false,
                method: () => {
                    try {
                        try { PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke()); } catch (e) {}
                        const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
                        if (others && others.length > 0) {
                            for (let i = 0; i < others.length; i++) {
                                const player = others.get(i);
                                try {
                                    const ownerId = Number(player.method("get_ActorNumber").invoke());
                                    PhotonNetwork.method("DestroyPlayerObjects", 2).invoke(ownerId, true);
                                } catch (e) {}
                                kickPlayerObj(player);
                            }
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Asteroid Fan [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - gwAsteroidLast < 250) return;
                    gwAsteroidLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        const dir = rightHandTransform.method("get_forward").invoke();
                        for (let k = -1; k <= 1; k++) {
                            const off = [0, k * 0.12, 0];
                            const spawn = Vector3.method("op_Addition", 2).invoke(pos, off);
                            try { PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), spawn, identityQuaternion, 0, NULL); } catch (e) {}
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),
            new ButtonInfo({
                buttonText: "Set Master",
                method: () => {
                    PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Rig Spam",
                method: () => {
                    if (rightSecondary) {
                        const now = Date.now();
                        if (now - lastRunTime >= 0.1) {
                            lastRunTime = now;
                            const clonedrig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer"), getTransform(headCollider).method("get_position").invoke(), identityQuaternion, 0, NULL);
                            const components = clonedrig.method("GetComponents", 0).inflate(Component).invoke();

                            for (let i = 0; i < components.length; i++) {
                                const component = components.get(i);
                                const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();

                                if (name.includes("PhotonVR")) {
                                    setTimeout(function () {
                                        Destroy(component);
                                    }, 800)
                                }
                            }
                        }
                        sendAllOutgoing()
                    }
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - lastRunTime >= 0.1) {
                                lastRunTime = now;
                                const clonedrig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer"), getTransform(gunPointer).method("get_position").invoke(), identityQuaternion, 0, NULL);
                                const components = clonedrig.method("GetComponents", 0).inflate(Component).invoke();

                                for (let i = 0; i < components.length; i++) {
                                    const component = components.get(i);
                                    const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();

                                    if (name.includes("PhotonVR")) {
                                        setTimeout(function () {
                                            Destroy(component);
                                        }, 800)
                                    }
                                }
                            }
                            sendAllOutgoing()
                        }
                    }
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Rig Spam (Name Only)",
                method: () => {
                    if (rightSecondary) {
                        const now = Date.now();
                        if (now - lastRunTime >= 0.1) {
                            lastRunTime = now;
                            const clonedrig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("PhotonVR/Player"), getTransform(headCollider).method("get_position").invoke(), identityQuaternion, 0, NULL);
                            const components = clonedrig.method("GetComponents", 0).inflate(Component).invoke();

                            for (let i = 0; i < components.length; i++) {
                                const component = components.get(i);
                                const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();

                                if (name.includes("PhotonVR")) {
                                    setTimeout(function () {
                                        Destroy(component);
                                    }, 800)
                                }
                            }
                        }
                        sendAllOutgoing()
                    }
                },
                keepOn: true,
            }),

            new ButtonInfo({
                buttonText: "Lock Server",
                method: () => {
                    const room = PhotonNetwork.method("get_CurrentRoom").invoke();
                    room.method("set_IsOpen").invoke(false);
                    room.method("set_IsVisible").invoke(false);
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Unlock Server",
                method: () => {
                    const room = PhotonNetwork.method("get_CurrentRoom").invoke();
                    room.method("set_IsOpen").invoke(true);
                    room.method("set_IsVisible").invoke(true);
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Fling Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const ray = gunData.ray;
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            let targetPos = null;
                            try {
                                if (ray != null && !ray.isNull()) {
                                    const hitCollider = ray.method("get_collider").invoke();
                                    if (hitCollider != null && !hitCollider.isNull()) {
                                        const hitGo = hitCollider.method("get_gameObject").invoke();
                                        const pv = getComponentInParent(hitGo, PhotonViewClass);
                                        if (pv != null && !pv.isNull()) {
                                            const owner = pv.method("get_Owner").invoke();
                                            const local = PhotonNetwork.method("get_LocalPlayer").invoke();
                                            if (owner != null && local != null && !owner.handle.equals(local.handle)) {
                                                targetPos = getTransform(gunPointer).method("get_position").invoke();
                                            }
                                        }
                                    }
                                }
                            } catch (e) { console.log("Fling Gun target check error: " + e); }

                            if (targetPos != null) {
                                PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), targetPos, identityQuaternion, 0, NULL);
                                sendAllOutgoing()
                                ClearRPC()
                            }
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Ragdoll Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Ragdoll Spammer [RT]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing()
                    };;
                },
            }),

            new ButtonInfo({
                buttonText: "Fighter Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Miner Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonMiner"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Hammer Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            const playerSpawned = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFling"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Crash All",
                method: () => {
                    for (let i = 0; i < 1000; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL);
                        Destroy(thingforlag)
                    }
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Destroy All",
                method: () => {
                    PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
                    const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
                    if (others && others.length > 0) {
                        for (let i = 0; i < others.length; i++) {
                            const player = others.get(i);
                            const playerId = Number(player.method("get_ActorNumber").invoke());
                            PhotonNetwork.method("DestroyPlayerObjects", 2).invoke(playerId, false);
                        }
                    }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Giga Ragdoll [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - gigaRagdollLast < 100) return;
                    gigaRagdollLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        for (let i = 0; i < 3; i++) {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Bomb Gun Rapid [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rapidBombLast < 150) return;
                    rapidBombLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieBomb"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Explode Gun Rapid [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rapidExplodeLast < 150) return;
                    rapidExplodeLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Glass Bullet [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - glassBulletLast < 200) return;
                    glassBulletLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Mega Bomb Everyone",
                method: () => {
                    try {
                        scanOtherRigs((obj, pos) => {
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), pos, identityQuaternion, 0, NULL);
                        });
                        sendAllOutgoing();
                        console.log("[OP] Mega Bomb Everyone");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Glass Prison All",
                method: () => {
                    try {
                        scanOtherRigs((obj, pos) => {
                            const spots = [[0.8, 0, 0], [-0.8, 0, 0], [0, 0, 0.8], [0, 0, -0.8], [0, 0.8, 0], [0, 1.6, 0]];
                            for (let i = 0; i < spots.length; i++) {
                                const pr = Vector3.method("op_Addition", 2).invoke(pos, spots[i]);
                                PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pr, identityQuaternion, 0, NULL);
                            }
                        });
                        sendAllOutgoing();
                        console.log("[OP] Glass Prison All");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Ragdoll Meteor [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - meteorRagdollLast < 120) return;
                    meteorRagdollLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Napalm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - napalmLast < 150) return;
                    napalmLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Spaceship Bomb",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Spaceship"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Hellephant Bomb",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Crash Extra",
                method: () => {
                    for (let i = 0; i < 2000; i++) {
                        const thing = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL);
                        Destroy(thing);
                    }
                    sendAllOutgoing();
                    console.log("[OP] Crash Extra");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Rocket Fiesta [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rocketFiestaLast < 200) return;
                    rocketFiestaLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Rpg"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Kick Cannon [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - kickCannonLast < 900) return;
                    kickCannonLast = now;
                    try {
                        const gunData = renderGun();
                        const target = otherFromGunRay(gunData);
                        if (target != null) {
                            const pv = getComponentInParent(target.obj, PhotonViewClass);
                            if (pv != null && !pv.isNull()) {
                                kickPlayerObj(pv.method("get_Owner").invoke());
                            }
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Owner Mode",
                keepOn: false,
                method: () => {
                    try {
                        try { PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke()); } catch (e) {}
                        setCosmeticOn("Mod"); setCosmeticOn("Admin"); setCosmeticOn("Owner"); setCosmeticOn("BoosterTag");
                        spawnKillGun();
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Death Ball",
                keepOn: false,
                method: () => {
                    try {
                        const local = PhotonNetwork.method("get_LocalPlayer").invoke();
                        const localId = local ? Number(local.method("get_ActorNumber").invoke()) : -1;
                        const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
                        for (let i = 0; i < objects.length; i++) {
                            try {
                                const obj = objects.get(i);
                                if (obj == null) continue;
                                const name = obj.method("get_name").invoke().content;
                                if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                                const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                                if (pv == null || pv.isNull()) continue;
                                const owner = pv.method("get_Owner").invoke();
                                if (owner == null) continue;
                                if (Number(owner.method("get_ActorNumber").invoke()) == localId) continue;
                                const pos = getTransform(obj).method("get_position").invoke();
                                PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFling"), pos, identityQuaternion, 0, NULL);
                            } catch (e) { continue; }
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Infinite Hammer",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("BanHammer"); setBanHammerActive(true); },
                disableMethod: () => { setCosmeticOff("BanHammer"); setBanHammerActive(false); },
            }),

            new ButtonInfo({
                buttonText: "Glass Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - gwGlassLast < 150) return;
                    gwGlassLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        for (let k = 0; k < 3; k++) {
                            const off = [(Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.3];
                            const spawn = Vector3.method("op_Addition", 2).invoke(pos, off);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), spawn, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Asteroid Call [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - gwAsteroidCallLast < 400) return;
                    gwAsteroidCallLast = now;
                    try {
                        const objects = Resources.method("FindObjectsOfTypeAll").inflate(GameObject).invoke();
                        const local = PhotonNetwork.method("get_LocalPlayer").invoke();
                        const localId = local ? Number(local.method("get_ActorNumber").invoke()) : -1;
                        for (let i = 0; i < objects.length; i++) {
                            try {
                                const obj = objects.get(i);
                                if (obj == null) continue;
                                const name = obj.method("get_name").invoke().content;
                                if (name.indexOf("BaboonNetworkPlayer") === -1) continue;
                                const pv = obj.method("GetComponent", 1).inflate(PhotonViewClass).invoke();
                                if (pv == null || pv.isNull()) continue;
                                const owner = pv.method("get_Owner").invoke();
                                if (owner == null) continue;
                                if (Number(owner.method("get_ActorNumber").invoke()) == localId) continue;
                                const pos = getTransform(obj).method("get_position").invoke();
                                const above = Vector3.method("op_Addition", 2).invoke(pos, [0, 6, 0]);
                                PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), above, identityQuaternion, 0, NULL);
                            } catch (e) { continue; }
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),
        ],
        [ // Guns
            new ButtonInfo({
                buttonText: "SMG",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SMGCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Shotgun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ShotgunCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Scar",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ScarCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "GrenadeLauncher",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GrenadeGrabbable"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Pistol",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("PistolCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Sniper",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SniperCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Flare",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("FlareGun"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Rpg",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Rpg"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "RpgMisslie",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Missile"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "SuperSoakerGun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SuperSoakerGun"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Asteroid Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwAstLast < 120) return;
                            gwAstLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Wind Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwWindLast < 150) return;
                            gwWindLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Wind"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Flare Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwFlareLast < 150) return;
                            gwFlareLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Lightning Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwLightLast < 200) return;
                            gwLightLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("LightningHammer"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Explosion Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwBigExplLast < 200) return;
                            gwBigExplLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigExplosion"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Ragdoll Cannon",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwRagdollLast < 120) return;
                            gwRagdollLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Glass Cannon",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwGlassLast < 150) return;
                            gwGlassLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Boogie Cannon",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwBoogieLast < 180) return;
                            gwBoogieLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieBomb"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Exploder",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwExplodeLast < 180) return;
                            gwExplodeLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Space Cannon",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwSpaceLast < 250) return;
                            gwSpaceLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Spaceship"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Elephant Cannon",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwElephantLast < 250) return;
                            gwElephantLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Player Spawner",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwMonkeyLast < 250) return;
                            gwMonkeyLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Kick Gun",
                method: () => {
                    if (rightGrab) {
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwKickLast < 400) return;
                            gwKickLast = now;
                            spawnKickBall();
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Ban Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwBanLast < 800) return;
                            gwBanLast = now;
                            const target = otherFromGunRay(gunData);
                            if (target != null) {
                                const pv = getComponentInParent(target.obj, PhotonViewClass);
                                if (pv != null && !pv.isNull()) {
                                    const owner = pv.method("get_Owner").invoke();
                                    try {
                                        const ownerId = Number(owner.method("get_ActorNumber").invoke());
                                        PhotonNetwork.method("DestroyPlayerObjects", 2).invoke(ownerId, true);
                                    } catch (e) {}
                                    kickPlayerObj(owner);
                                }
                            }
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Drag Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwDragLast < 500) return;
                            gwDragLast = now;
                            const target = otherFromGunRay(gunData);
                            if (target != null) {
                                const handPos = rightHandTransform.method("get_position").invoke();
                                const fwd = rightHandTransform.method("get_forward").invoke();
                                const dest = Vector3.method("op_Addition", 2).invoke(handPos, Vector3.method("op_Multiply", 2).invoke(fwd, 1.5));
                                getTransform(target.obj).method("set_position").invoke(dest);
                            }
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Sticky Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwStickyLast < 500) return;
                            gwStickyLast = now;
                            const target = otherFromGunRay(gunData);
                            if (target != null) {
                                PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieBomb"), target.pos, identityQuaternion, 0, NULL);
                                sendAllOutgoing();
                            }
                        }
                    }
                },
            }),
        ],
        [ // Boomboxes
            new ButtonInfo({
                buttonText: "Zvvacksboombox",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ZvvacksBoombox"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "OwnerBoombox",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("OwnerBoombox"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                            ClearRPC()
                        };;
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Boombox Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - boomStormLast < 200) return;
                    boomStormLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [(Math.random() - 0.5) * 2, 4, (Math.random() - 0.5) * 2]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ZvvacksBoombox"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Boombox Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - boomboxRainLast < 250) return;
                    boomboxRainLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("OwnerBoombox"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Spawn Boombox",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ZvvacksBoombox"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Boombox Cannon",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - gwBoomboxLast < 200) return;
                            gwBoomboxLast = now;
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("OwnerBoombox"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        }
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Boombox Launcher [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    const now = Date.now();
                    if (now - boomboxLauncherLast < 250) return;
                    boomboxLauncherLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ZvvacksBoombox"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),
        ],
        [ // Effects
            new ButtonInfo({
                buttonText: "Fart [T]",
                method: () => {
                    if (rightTrigger) {
                        const RandomFart = AssemblyCSharp.class("RandomFart");
                        const GC = Il2Cpp.gc.choose(RandomFart)[0];
                        if (GC) GC.method("FartNOW").invoke();
                    };;
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Wind [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Wind"), rightHandTransform.method("get_position").invoke(), rightHandTransform.method("get_rotation").invoke(), 0, NULL);
                        sendAllOutgoing()
                        ClearRPC()
                    };;
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Flare [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), rightHandTransform.method("get_position").invoke(), rightHandTransform.method("get_rotation").invoke(), 0, NULL);
                        sendAllOutgoing()
                        ClearRPC()
                    };;
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Lighting [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        const rot = rightHandTransform.method("get_rotation").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("LightningHammer"), pos, rot, 0, NULL);
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Explosion [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigExplosion"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Hellephant [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Spaceship [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke()
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Spaceship"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing()
                        ClearRPC()
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Confetti Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Confetti"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Macarena Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("AMacrena"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "DonPollo Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("DonPollo"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Fein Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Catnap VS Skibidi Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Skibidi"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "LadyHear Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ladyhear"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "TylerTheCreator Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TylerTheCreator"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Tect Talking Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TectAudio"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Splash Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Plane Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ImBoutaBombThisPlane"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "NCSTrack Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke()
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("NCSTrack"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing()
                    ClearRPC()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Wind Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - windStormLast < 150) return;
                    windStormLast = now;
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Wind"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Confetti Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - confettiRainLast < 300) return;
                    confettiRainLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Confetti"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Flare Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - flareStormLast < 150) return;
                    flareStormLast = now;
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Explosion Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - explRainLast < 300) return;
                    explRainLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [0, 4, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigExplosion"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Random Sound Blast",
                method: () => {
                    try {
                        const sounds = ["Wind", "Confetti", "AMacrena", "DonPollo", "Fein", "Skibidi", "ladyhear", "TylerTheCreator", "TectAudio", "Splash", "NCSTrack", "ImBoutaBombThisPlane"];
                        const pick = sounds[Math.floor(Math.random() * sounds.length)];
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Dance Party [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - danceLast < 250) return;
                    danceLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("AMacrena"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Spaceship Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - spaceRainLast < 300) return;
                    spaceRainLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 4, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Spaceship"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Rave Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - raveLast < 300) return;
                    raveLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("NCSTrack"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Macarena Blast",
                method: () => {
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("AMacrena"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Sound Mega [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - megaSoundLast < 400) return;
                    megaSoundLast = now;
                    try {
                        const sounds = ["Wind", "Confetti", "AMacrena", "DonPollo", "Fein", "Skibidi", "Flare", "Splash", "NCSTrack"];
                        const pos = rightHandTransform.method("get_position").invoke();
                        for (let i = 0; i < 3; i++) {
                            const pick = sounds[Math.floor(Math.random() * sounds.length)];
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Confetti Shot",
                method: () => {
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Confetti"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Splash Shot",
                method: () => {
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Sound Launcher [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    const now = Date.now();
                    if (now - soundLauncherLast < 250) return;
                    soundLauncherLast = now;
                    try {
                        const sounds = ["Wind", "Confetti", "AMacrena", "DonPollo", "Fein", "Skibidi", "Flare", "Splash", "NCSTrack"];
                        const pick = sounds[Math.floor(Math.random() * sounds.length)];
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),
        ],
        [ // Monsters
            new ButtonInfo({
                buttonText: "BigLarry Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigLarry"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "MeatMan Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("VeryScaryMeatMan"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "MeatManFast Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/MeatManFast"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Fred Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string('monsters/Fred'), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "BlackGooGuy Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BlackGooGuy"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "White Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;

                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke()
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/White"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing()
                        };;
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Destroy All Monsters",
                method: () => {
                    const names = [
                        "BigLarry",
                        "MeatMan",
                        "MeatManFast",
                        "Fred",
                        "BlackGooGoo",
                        "White"
                    ]; 
                    const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
                    const findObjectsOfType = GameObject.method("FindObjectsOfType");
                    const objects = findObjectsOfType.invoke(GameObject.type.object);
                    for (let i = 0; i < objects.length; i++) {
                        const obj = objects.get(i);
                        if (!obj || obj.isNull()) continue;
                        const name = obj.method("get_name").invoke().content;
                        if (names.includes(name)) {
                            Object.method("Destroy", 1).invoke(obj);
                        }
                    }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "BigLarry Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - larryRainLast < 400) return;
                    larryRainLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigLarry"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Meat Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - meatStormLast < 300) return;
                    meatStormLast = now;
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("VeryScaryMeatMan"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Fred Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - fredRainLast < 400) return;
                    fredRainLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/Fred"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Goo Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - gooStormLast < 350) return;
                    gooStormLast = now;
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BlackGooGuy"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "White Storm [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - whiteStormLast < 350) return;
                    whiteStormLast = now;
                    try {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/White"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "MeatFast Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - meatFastRainLast < 400) return;
                    meatFastRainLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/MeatManFast"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Monster Mega",
                method: () => {
                    try {
                        const mons = ["BigLarry", "VeryScaryMeatMan", "monsters/MeatManFast", "monsters/Fred", "BlackGooGuy", "monsters/White"];
                        const p = rigidbody.method("get_position").invoke();
                        for (let i = 0; i < 20; i++) {
                            const pick = mons[Math.floor(Math.random() * mons.length)];
                            const pos = Vector3.method("op_Addition", 2).invoke(p, [(Math.random() - 0.5) * 10, 5 + Math.random() * 5, (Math.random() - 0.5) * 10]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Summon Hell Beast",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Hellephant"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Monster Launcher [LG]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!leftGrab) return;
                    const now = Date.now();
                    if (now - monsterLauncherLast < 350) return;
                    monsterLauncherLast = now;
                    try {
                        const mons = ["BigLarry", "VeryScaryMeatMan", "monsters/MeatManFast", "monsters/Fred", "BlackGooGuy", "monsters/White"];
                        const pick = mons[Math.floor(Math.random() * mons.length)];
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(pick), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),
        ],
        [ // Staff Items
            new ButtonInfo({
                buttonText: "Thor Kick Hammer",
                keepOn: true,
                enabled: false,
                enableMethod: () => { thorKickEnabled = false; setCosmeticOff("Kick"); },
                disableMethod: () => { thorKickEnabled = false; setCosmeticOff("Kick"); },
                method: () => {
                    try {
                        if (rightPrimary && !thorKickLastPrimary) {
                            thorKickEnabled = !thorKickEnabled;
                            if (thorKickEnabled) { setCosmeticOn("Kick"); }
                            else { setCosmeticOff("Kick"); }
                        }
                        thorKickLastPrimary = rightPrimary;
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Lightning Hammer",
                keepOn: true,
                enabled: false,
                enableMethod: () => { lightningHammerEnabled = false; setCosmeticOff("LightningHammer"); },
                disableMethod: () => { lightningHammerEnabled = false; setCosmeticOff("LightningHammer"); },
                method: () => {
                    try {
                        if (rightPrimary && !lightningHammerLastPrimary) {
                            lightningHammerEnabled = !lightningHammerEnabled;
                            if (lightningHammerEnabled) { setCosmeticOn("LightningHammer"); }
                            else { setCosmeticOff("LightningHammer"); }
                        }
                        lightningHammerLastPrimary = rightPrimary;
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Kick Hammer",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Kick"); },
                disableMethod: () => { setCosmeticOff("Kick"); },
            }),

            new ButtonInfo({
                buttonText: "Fake Explode Kick",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("FakeExplodeKick"); },
                disableMethod: () => { setCosmeticOff("FakeExplodeKick"); },
            }),

            new ButtonInfo({
                buttonText: "Explode Kick",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Kick");
                    setCosmeticOn("ExplodeKick");
                },
                disableMethod: () => {
                    setCosmeticOff("Kick");
                    setCosmeticOff("ExplodeKick");
                },
            }),

            new ButtonInfo({
                buttonText: "Booster Tag",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("BoosterTag"); },
                disableMethod: () => { setCosmeticOff("BoosterTag"); },
            }),

            new ButtonInfo({
                buttonText: "Staff Tag",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Mod"); },
                disableMethod: () => { setCosmeticOff("Mod"); },
            }),

            new ButtonInfo({
                buttonText: "Admin Tag",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Admin"); },
                disableMethod: () => { setCosmeticOff("Admin"); },
            }),

            new ButtonInfo({
                buttonText: "Owner Tag",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Owner"); },
                disableMethod: () => { setCosmeticOff("Owner"); },
            }),

new ButtonInfo({
    buttonText: "KILL GUN",
    enableMethod: () => {
        spawnKillGun();
        try {
            const PhotonVRManagerClass = AssemblyCSharp.class("Photon.VR.PhotonVRManager");
            const manager = PhotonVRManagerClass.method("get_Manager").invoke();
            if (manager && !manager.isNull()) {
                try {
                    manager.method("SetCosmetic").invoke(
                        Il2Cpp.string("PistillsBro"),
                        Il2Cpp.string("PistillsBro")
                    );
                } catch (_) {
                    PhotonVRManagerClass.method("SetCosmetic", 2).invoke(
                        Il2Cpp.string("PistillsBro"),
                        Il2Cpp.string("PistillsBro")
                    );
                }
            }
        } catch (e) {}
        sendAllOutgoing();
    },
    disableMethod: () => {
        removeKillGun();
        try {
            const PhotonVRManagerClass = AssemblyCSharp.class("Photon.VR.PhotonVRManager");
            const manager = PhotonVRManagerClass.method("get_Manager").invoke();
            if (manager && !manager.isNull()) {
                try {
                    manager.method("SetCosmetic").invoke(
                        Il2Cpp.string("PistillsBro"),
                        Il2Cpp.string("")
                    );
                } catch (_) {
                    PhotonVRManagerClass.method("SetCosmetic", 2).invoke(
                        Il2Cpp.string("PistillsBro"),
                        Il2Cpp.string("")
                    );
                }
            }
        } catch (e) {}
        sendAllOutgoing();
    },
    method: () => {
        updateKillGun();
        fireKillGun();
    },
    keepOn: true,
    enabled: false,
}),

new ButtonInfo({
    buttonText: "Unequip All",
    method: () => {
        try {
            const AssemblyCSharp =
                Il2Cpp.domain.assembly("Assembly-CSharp").image;

            const PhotonVRManagerClass =
                AssemblyCSharp.class("Photon.VR.PhotonVRManager");

            const manager =
                PhotonVRManagerClass.method("get_Manager").invoke();

            if (!manager || manager.isNull()) {
                console.log("[Cosmetic] No manager");
                return;
            }

            const types = [
                "Kick",
                "Mod",
                "Admin",
                "ExplodeKick",
                "Owner",
                "RPG",
                "Booster",
                "Camera",
                "YT_100K_Plaque",
                "LeFart",
                "TopHat",
                "Pan",
                "AngyFace",
                "Tie",
                "Cone",
                "Banana",
                "Blood",
                "LightningHammer",
                "FakeExplodeKick",
                "BoosterTag",
                "PistillsBro"
            ];

            for (const type of types) {
                try {
                    manager.method("SetCosmetic").invoke(
                        Il2Cpp.string(type),
                        Il2Cpp.string("")
                    );
                } catch (_) {
                    try {
                        PhotonVRManagerClass.method("SetCosmetic", 2).invoke(
                            Il2Cpp.string(type),
                            Il2Cpp.string("")
                        );
                    } catch (e) {
                        console.log("[Cosmetic] Failed:", type, e);
                    }
                }
            }

            console.log("[Cosmetic] Unequipped all");
        } catch (e) {
            console.log("[Cosmetic] Unequip All error:", e);
        }
    },

    keepOn: false,
}),

            new ButtonInfo({
                buttonText: "RPG Backpack",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("RPG"); },
                disableMethod: () => { setCosmeticOff("RPG"); },
            }),

            new ButtonInfo({
                buttonText: "Camera Rig",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Camera"); },
                disableMethod: () => { setCosmeticOff("Camera"); },
            }),

            new ButtonInfo({
                buttonText: "YT Plaque",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("YT_100K_Plaque"); },
                disableMethod: () => { setCosmeticOff("YT_100K_Plaque"); },
            }),

            new ButtonInfo({
                buttonText: "Top Hat",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("TopHat"); },
                disableMethod: () => { setCosmeticOff("TopHat"); },
            }),

            new ButtonInfo({
                buttonText: "Pan Hat",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Pan"); },
                disableMethod: () => { setCosmeticOff("Pan"); },
            }),

            new ButtonInfo({
                buttonText: "Banana",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Banana"); },
                disableMethod: () => { setCosmeticOff("Banana"); },
            }),

            new ButtonInfo({
                buttonText: "Tie",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Tie"); },
                disableMethod: () => { setCosmeticOff("Tie"); },
            }),

            new ButtonInfo({
                buttonText: "Cone",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Cone"); },
                disableMethod: () => { setCosmeticOff("Cone"); },
            }),

            new ButtonInfo({
                buttonText: "LeFart Horn",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("LeFart"); },
                disableMethod: () => { setCosmeticOff("LeFart"); },
            }),

            new ButtonInfo({
                buttonText: "Angry Face",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("AngyFace"); },
                disableMethod: () => { setCosmeticOff("AngyFace"); },
            }),

            new ButtonInfo({
                buttonText: "Thor Kit",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("ThorKickHammer"); setCosmeticOn("LightningHammer"); },
                disableMethod: () => { setCosmeticOff("ThorKickHammer"); setCosmeticOff("LightningHammer"); },
            }),

            new ButtonInfo({
                buttonText: "God Slayer",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Kick"); setCosmeticOn("ExplodeKick"); setCosmeticOn("FakeExplodeKick"); },
                disableMethod: () => { setCosmeticOff("Kick"); setCosmeticOff("ExplodeKick"); setCosmeticOff("FakeExplodeKick"); },
            }),

            new ButtonInfo({
                buttonText: "Ban Hammer",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("BanHammer"); setBanHammerActive(true); },
                disableMethod: () => { setCosmeticOff("BanHammer"); setBanHammerActive(false); },
            }),

            new ButtonInfo({
                buttonText: "Ban Hammer 2",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("BanHammer2"); setBanHammerActive(true); },
                disableMethod: () => { setCosmeticOff("BanHammer2"); setBanHammerActive(false); },
            }),

            new ButtonInfo({
                buttonText: "Mod Supremacy",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Mod"); setCosmeticOn("Admin"); setCosmeticOn("Owner"); setCosmeticOn("BoosterTag"); },
                disableMethod: () => { setCosmeticOff("Mod"); setCosmeticOff("Admin"); setCosmeticOff("Owner"); setCosmeticOff("BoosterTag"); },
            }),

            new ButtonInfo({
                buttonText: "RPG Wizard",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("RPG"); setCosmeticOn("RPG2"); },
                disableMethod: () => { setCosmeticOff("RPG"); setCosmeticOff("RPG2"); },
            }),

            new ButtonInfo({
                buttonText: "Dev Gear",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Developer"); setCosmeticOn("Management"); },
                disableMethod: () => { setCosmeticOff("Developer"); setCosmeticOff("Management"); },
            }),

            new ButtonInfo({
                buttonText: "Tank Titan",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Tank"); },
                disableMethod: () => { setCosmeticOff("Tank"); },
            }),

            new ButtonInfo({
                buttonText: "Pistil Blaster",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("PistillsBro"); },
                disableMethod: () => { setCosmeticOff("PistillsBro"); },
            }),

            new ButtonInfo({
                buttonText: "Kick King",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Kick2"); setCosmeticOn("Fling2"); },
                disableMethod: () => { setCosmeticOff("Kick2"); setCosmeticOff("Fling2"); },
            }),

            new ButtonInfo({
                buttonText: "Pee Blast",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Pee"); },
                disableMethod: () => { setCosmeticOff("Pee"); },
            }),

            new ButtonInfo({
                buttonText: "Tect Vibes",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Tect"); },
                disableMethod: () => { setCosmeticOff("Tect"); },
            }),

            new ButtonInfo({
                buttonText: "Launcher Pack",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("JmanLauncher2"); setCosmeticOn("KittyLauncher3"); },
                disableMethod: () => { setCosmeticOff("JmanLauncher2"); setCosmeticOff("KittyLauncher3"); },
            }),

            new ButtonInfo({
                buttonText: "Full Youtuber",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Camera"); setCosmeticOn("YT_100K_Plaque"); setCosmeticOn("YtBadge2"); },
                disableMethod: () => { setCosmeticOff("Camera"); setCosmeticOff("YT_100K_Plaque"); setCosmeticOff("YtBadge2"); },
            }),

            new ButtonInfo({
                buttonText: "Creator Kit",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("YtBadge2"); setCosmeticOn("TiktokBadge"); setCosmeticOn("VideoStarBadge1"); },
                disableMethod: () => { setCosmeticOff("YtBadge2"); setCosmeticOff("TiktokBadge"); setCosmeticOff("VideoStarBadge1"); },
            }),

            new ButtonInfo({
                buttonText: "VideoStar Set",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("VideoStarBadge1"); setCosmeticOn("VideoStarBadge2"); setCosmeticOn("VideoStarBadge3");
                    setCosmeticOn("VideoStarBadge4"); setCosmeticOn("VideoStarBadge5"); setCosmeticOn("VideoStarBadge6");
                },
                disableMethod: () => {
                    setCosmeticOff("VideoStarBadge1"); setCosmeticOff("VideoStarBadge2"); setCosmeticOff("VideoStarBadge3");
                    setCosmeticOff("VideoStarBadge4"); setCosmeticOff("VideoStarBadge5"); setCosmeticOff("VideoStarBadge6");
                },
            }),

            new ButtonInfo({
                buttonText: "Fart Cannon",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("LeFart"); setCosmeticOn("Pee"); },
                disableMethod: () => { setCosmeticOff("LeFart"); setCosmeticOff("Pee"); },
            }),

            new ButtonInfo({
                buttonText: "Rage Kit",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("AngyFace"); setCosmeticOn("Blood"); setCosmeticOn("LeFart"); },
                disableMethod: () => { setCosmeticOff("AngyFace"); setCosmeticOff("Blood"); setCosmeticOff("LeFart"); },
            }),

            new ButtonInfo({
                buttonText: "Ultra Kit",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("ThorKickHammer"); setCosmeticOn("LightningHammer"); setCosmeticOn("Kick");
                    setCosmeticOn("ExplodeKick"); setCosmeticOn("BanHammer"); setCosmeticOn("RPG");
                },
                disableMethod: () => {
                    setCosmeticOff("ThorKickHammer"); setCosmeticOff("LightningHammer"); setCosmeticOff("Kick");
                    setCosmeticOff("ExplodeKick"); setCosmeticOff("BanHammer"); setCosmeticOff("RPG");
                },
            }),

            new ButtonInfo({
                buttonText: "Sovereign Hat",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("TopHat"); setCosmeticOn("Cone"); setCosmeticOn("Owner"); },
                disableMethod: () => { setCosmeticOff("TopHat"); setCosmeticOff("Cone"); setCosmeticOff("Owner"); },
            }),

            new ButtonInfo({
                buttonText: "Ban Claw",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("BanHammer"); setBanHammerActive(true); },
                disableMethod: () => { setCosmeticOff("BanHammer"); setBanHammerActive(false); },
            }),

            new ButtonInfo({
                buttonText: "Hype Runner",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("JmanLauncher2"); setCosmeticOn("Kick"); setCosmeticOn("Booster"); },
                disableMethod: () => { setCosmeticOff("JmanLauncher2"); setCosmeticOff("Kick"); setCosmeticOff("Booster"); },
            }),

            new ButtonInfo({
                buttonText: "Nuke Kit",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("ExplodeKick"); setCosmeticOn("FakeExplodeKick"); setCosmeticOn("BanHammer2"); },
                disableMethod: () => { setCosmeticOff("ExplodeKick"); setCosmeticOff("FakeExplodeKick"); setCosmeticOff("BanHammer2"); },
            }),

            new ButtonInfo({
                buttonText: "Fast Kick",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Kick2"); setCosmeticOn("Fling2"); setCosmeticOn("Kick"); },
                disableMethod: () => { setCosmeticOff("Kick2"); setCosmeticOff("Fling2"); setCosmeticOff("Kick"); },
            }),

            new ButtonInfo({
                buttonText: "Torch",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Developer"); setCosmeticOn("Management"); setCosmeticOn("LeFart"); },
                disableMethod: () => { setCosmeticOff("Developer"); setCosmeticOff("Management"); setCosmeticOff("LeFart"); },
            }),

            new ButtonInfo({
                buttonText: "Magma",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Tank"); setCosmeticOn("Tect"); },
                disableMethod: () => { setCosmeticOff("Tank"); setCosmeticOff("Tect"); },
            }),

            new ButtonInfo({
                buttonText: "Moon Boots",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Booster"); setCosmeticOn("BoosterTag"); setCosmeticOn("TopHat"); },
                disableMethod: () => { setCosmeticOff("Booster"); setCosmeticOff("BoosterTag"); setCosmeticOff("TopHat"); },
            }),

            new ButtonInfo({
                buttonText: "Royalty",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Owner"); setCosmeticOn("Camera"); setCosmeticOn("LeFart"); },
                disableMethod: () => { setCosmeticOff("Owner"); setCosmeticOff("Camera"); setCosmeticOff("LeFart"); },
            }),

            new ButtonInfo({
                buttonText: "Banner",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("YtBadge2"); setCosmeticOn("TiktokBadge"); setCosmeticOn("VideoStarBadge1"); },
                disableMethod: () => { setCosmeticOff("YtBadge2"); setCosmeticOff("TiktokBadge"); setCosmeticOff("VideoStarBadge1"); },
            }),

            new ButtonInfo({
                buttonText: "Armory",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("ThorKickHammer"); setCosmeticOn("LightningHammer"); setCosmeticOn("RPG"); },
                disableMethod: () => { setCosmeticOff("ThorKickHammer"); setCosmeticOff("LightningHammer"); setCosmeticOff("RPG"); },
            }),

            new ButtonInfo({
                buttonText: "Drill",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("RPG2"); setCosmeticOn("Kick2"); setCosmeticOn("ThorKickHammer"); },
                disableMethod: () => { setCosmeticOff("RPG2"); setCosmeticOff("Kick2"); setCosmeticOff("ThorKickHammer"); },
            }),

            new ButtonInfo({
                buttonText: "Warband",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Mod"); setCosmeticOn("Admin"); setCosmeticOn("Owner"); setCosmeticOn("BoosterTag"); },
                disableMethod: () => { setCosmeticOff("Mod"); setCosmeticOff("Admin"); setCosmeticOff("Owner"); setCosmeticOff("BoosterTag"); },
            }),

            new ButtonInfo({
                buttonText: "Party",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("AngyFace"); setCosmeticOn("Blood"); setCosmeticOn("LeFart"); setCosmeticOn("BanHammer"); },
                disableMethod: () => { setCosmeticOff("AngyFace"); setCosmeticOff("Blood"); setCosmeticOff("LeFart"); setCosmeticOff("BanHammer"); },
            }),

            new ButtonInfo({
                buttonText: "Mythic",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Kick"); setCosmeticOn("ExplodeKick"); setCosmeticOn("BanHammer"); setCosmeticOn("BanHammer2");
                    setCosmeticOn("RPG"); setCosmeticOn("RPG2"); setBanHammerActive(true);
                },
                disableMethod: () => {
                    setCosmeticOff("Kick"); setCosmeticOff("ExplodeKick"); setCosmeticOff("BanHammer"); setCosmeticOff("BanHammer2");
                    setCosmeticOff("RPG"); setCosmeticOff("RPG2"); setBanHammerActive(false);
                },
            }),
        ],
        [ // Cosmetics
            new ButtonInfo({
                buttonText: "YouTube Badge",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    try {
                        try {
                            const handlerClass = AssemblyCSharp.class("TemporaryCosmeticHandler");
                            const localPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
                            const rpcField = handlerClass.field("CosmeticEnable");
                            if (rpcField && rpcField.value && !rpcField.value.isNull()) {
                                rpcField.value.invoke(localPlayer, Il2Cpp.string("YtBadge2"));
                            }
                        } catch (e) { console.log("[Cosmetics] Badge enable RPC: " + e); }
                        forceCosmeticState("YtBadge2", true);
                    } catch (e) { console.log("[Cosmetics] Badge enable error: " + e); }
                },
                disableMethod: () => {
                    try {
                        try {
                            const handlerClass = AssemblyCSharp.class("TemporaryCosmeticHandler");
                            const localPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
                            const rpcField = handlerClass.field("CosmeticDisable");
                            if (rpcField && rpcField.value && !rpcField.value.isNull()) {
                                rpcField.value.invoke(localPlayer, Il2Cpp.string("YtBadge2"));
                            }
                        } catch (e) { console.log("[Cosmetics] Badge disable RPC: " + e); }
                        forceCosmeticState("YtBadge2", false);
                    } catch (e) { console.log("[Cosmetics] Badge disable error: " + e); }
                },
            }),

            new ButtonInfo({
                buttonText: "Booster Pack",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Booster"); },
                disableMethod: () => { setCosmeticOff("Booster"); },
            }),

            new ButtonInfo({
                buttonText: "Blood Splatter",
                keepOn: true,
                enabled: false,
                enableMethod: () => { setCosmeticOn("Blood"); },
                disableMethod: () => { setCosmeticOff("Blood"); },
            }),

            new ButtonInfo({
                buttonText: "Full Tagger",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Mod");
                    setCosmeticOn("Admin");
                    setCosmeticOn("Owner");
                    setCosmeticOn("BoosterTag");
                },
                disableMethod: () => {
                    setCosmeticOff("Mod");
                    setCosmeticOff("Admin");
                    setCosmeticOff("Owner");
                    setCosmeticOff("BoosterTag");
                },
            }),

            new ButtonInfo({
                buttonText: "Kick Bundle",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Kick");
                    setCosmeticOn("ExplodeKick");
                    setCosmeticOn("FakeExplodeKick");
                },
                disableMethod: () => {
                    setCosmeticOff("Kick");
                    setCosmeticOff("ExplodeKick");
                    setCosmeticOff("FakeExplodeKick");
                },
            }),

            new ButtonInfo({
                buttonText: "Hats Bundle",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("TopHat");
                    setCosmeticOn("Cone");
                    setCosmeticOn("Pan");
                },
                disableMethod: () => {
                    setCosmeticOff("TopHat");
                    setCosmeticOff("Cone");
                    setCosmeticOff("Pan");
                },
            }),

            new ButtonInfo({
                buttonText: "Tags Bundle",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Mod");
                    setCosmeticOn("Admin");
                    setCosmeticOn("Owner");
                },
                disableMethod: () => {
                    setCosmeticOff("Mod");
                    setCosmeticOff("Admin");
                    setCosmeticOff("Owner");
                },
            }),

            new ButtonInfo({
                buttonText: "Faces Bundle",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("AngyFace");
                    setCosmeticOn("Blood");
                },
                disableMethod: () => {
                    setCosmeticOff("AngyFace");
                    setCosmeticOff("Blood");
                },
            }),

            new ButtonInfo({
                buttonText: "Explode Bundle",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("ExplodeKick");
                    setCosmeticOn("FakeExplodeKick");
                },
                disableMethod: () => {
                    setCosmeticOff("ExplodeKick");
                    setCosmeticOff("FakeExplodeKick");
                },
            }),

            new ButtonInfo({
                buttonText: "Youtuber Kit",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Camera");
                    setCosmeticOn("YT_100K_Plaque");
                },
                disableMethod: () => {
                    setCosmeticOff("Camera");
                    setCosmeticOff("YT_100K_Plaque");
                },
            }),

            new ButtonInfo({
                buttonText: "Food Combo",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Banana");
                    setCosmeticOn("Tie");
                },
                disableMethod: () => {
                    setCosmeticOff("Banana");
                    setCosmeticOff("Tie");
                },
            }),

            new ButtonInfo({
                buttonText: "TikTok Badge",
                keepOn: true,
                enabled: false,
                enableMethod: () => { forceCosmeticState("TiktokBadge", true); },
                disableMethod: () => { forceCosmeticState("TiktokBadge", false); },
            }),

            new ButtonInfo({
                buttonText: "VideoStar Badge",
                keepOn: true,
                enabled: false,
                enableMethod: () => { forceCosmeticState("VideoStarBadge1", true); },
                disableMethod: () => { forceCosmeticState("VideoStarBadge1", false); },
            }),

            new ButtonInfo({
                buttonText: "Crew Badge",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Mod"),
            }),

            new ButtonInfo({
                buttonText: "Elite Badge",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Admin"),
            }),

            new ButtonInfo({
                buttonText: "Royal Badge",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Owner"),
            }),

            new ButtonInfo({
                buttonText: "Booster Badge",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Booster"),
            }),

            new ButtonInfo({
                buttonText: "VIP Booster",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("BoosterTag"),
            }),

            new ButtonInfo({
                buttonText: "Thunder Kick",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Kick"),
            }),

            new ButtonInfo({
                buttonText: "Mega Slam",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("ExplodeKick"),
            }),

            new ButtonInfo({
                buttonText: "Ghost Kick",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("FakeExplodeKick"),
            }),

            new ButtonInfo({
                buttonText: "Kick 2 Power",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Kick2"),
            }),

            new ButtonInfo({
                buttonText: "Fling Power",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("Fling2"),
            }),

            new ButtonInfo({
                buttonText: "Hammer Time",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("BanHammer"),
            }),

            new ButtonInfo({
                buttonText: "Hammer 2",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("BanHammer2"),
            }),

            new ButtonInfo({
                buttonText: "RPG Rockets",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("RPG"),
            }),

            new ButtonInfo({
                buttonText: "RPG 2",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("RPG2"),
            }),

            new ButtonInfo({
                buttonText: "Thor Power",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("ThorKickHammer"),
            }),

            new ButtonInfo({
                buttonText: "Lightning",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("LightningHammer"),
            }),

            new ButtonInfo({
                buttonText: "Launcher Power",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("JmanLauncher2"),
            }),

            new ButtonInfo({
                buttonText: "Kitty Launch",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("KittyLauncher3"),
            }),

            new ButtonInfo({
                buttonText: "Pistil Power",
                keepOn: true,
                enabled: false,
                method: cosmeticTrigger("PistillsBro"),
            }),

            new ButtonInfo({
                buttonText: "Toggle (Keep On)",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    setCosmeticOn("Kick"); setCosmeticOn("Mod"); setCosmeticOn("Admin"); setCosmeticOn("ExplodeKick");
                    setCosmeticOn("Owner"); setCosmeticOn("RPG"); setCosmeticOn("Booster"); setCosmeticOn("Camera");
                    setCosmeticOn("YT_100K_Plaque"); setCosmeticOn("LeFart"); setCosmeticOn("TopHat"); setCosmeticOn("Pan");
                    setCosmeticOn("AngyFace"); setCosmeticOn("Banana"); setCosmeticOn("Blood"); setCosmeticOn("LightningHammer");
                    setCosmeticOn("FakeExplodeKick"); setCosmeticOn("BoosterTag"); setCosmeticOn("PistillsBro"); setCosmeticOn("Kick2");
                    setCosmeticOn("ThorKickHammer"); setCosmeticOn("RPG2"); setCosmeticOn("Pee"); setCosmeticOn("Fling2");
                    setCosmeticOn("Tect"); setCosmeticOn("Developer"); setCosmeticOn("Management"); setCosmeticOn("Tank");
                    setCosmeticOn("JmanLauncher2"); setCosmeticOn("KittyLauncher3"); setCosmeticOn("YtBadge2"); setCosmeticOn("TiktokBadge");
                    setCosmeticOn("VideoStarBadge1"); setCosmeticOn("VideoStarBadge2"); setCosmeticOn("VideoStarBadge3");
                    setCosmeticOn("VideoStarBadge4"); setCosmeticOn("VideoStarBadge5"); setCosmeticOn("VideoStarBadge6");
                    setCosmeticOn("BanHammer"); setCosmeticOn("BanHammer2"); setCosmeticOn("Cone"); setCosmeticOn("Tie");
                },
                disableMethod: () => { clearAllCosmetics(); },
            }),
        ],
        [ // Mods
            new ButtonInfo({
                buttonText: "Kill All",
                method: () => {
                    killAllPlayers();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Ghost Monkey",
                keepOn: true,
                enabled: false,
                method: () => {
                    try {
                        if (rightPrimary && !ghostMonkeyOn) {
                            ghostMonkeyOn = true;
                            applyGhost();
                        }
                        if (!rightPrimary && ghostMonkeyOn) {
                            ghostMonkeyOn = false;
                            applyGhost();
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Big Monkey",
                keepOn: true,
                enabled: false,
                enableMethod: () => { bigMonkey = true; applyMonkeyScale(); },
                disableMethod: () => { bigMonkey = false; applyMonkeyScale(); },
            }),

            new ButtonInfo({
                buttonText: "Small Monkey",
                keepOn: true,
                enabled: false,
                enableMethod: () => { smallMonkey = true; applyMonkeyScale(); },
                disableMethod: () => { smallMonkey = false; applyMonkeyScale(); },
            }),

            new ButtonInfo({
                buttonText: "Zero Gravity",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    try { rigidbody.method("set_useGravity").invoke(false); } catch (e) {}
                },
                disableMethod: () => {
                    try { rigidbody.method("set_useGravity").invoke(true); } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "High Jump [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            if (Number(v.field("y").value) < 6) {
                                rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 9, Number(v.field("z").value)]);
                            }
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Grapple [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightTrigger) {
                        try {
                            const target = rayTargetFromHand();
                            if (target == null) return;
                            const p = rigidbody.method("get_position").invoke();
                            const vel = [
                                (Number(target.field("x").value) - Number(p.field("x").value)) * 6,
                                (Number(target.field("y").value) - Number(p.field("y").value)) * 6 + 4,
                                (Number(target.field("z").value) - Number(p.field("z").value)) * 6
                            ];
                            rigidbody.method("set_velocity").invoke(vel);
                        } catch (e) {}
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Spin Monkey",
                keepOn: true,
                enabled: false,
                method: () => {
                    try {
                        getTransform(GTPlayer).method("Rotate", 2).invoke([0, 1, 0], 90 * deltaTime);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "NoCollide",
                keepOn: true,
                enabled: false,
                enableMethod: () => { noCollideOn = true; toggleColliders(false); },
                disableMethod: () => { noCollideOn = false; toggleColliders(true); },
            }),

            new ButtonInfo({
                buttonText: "Asteroid Fling [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - astGunLastFire < 150) return;
                    astGunLastFire = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Teleport to Aim [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !telePrev) {
                        try {
                            const target = rayTargetFromHand();
                            if (target != null) rigidbody.method("set_position").invoke(target);
                        } catch (e) {}
                    }
                    telePrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Rocket Jump [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !rocketPrev) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 18, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    rocketPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Glass Wall [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightTrigger && !glassPrev) {
                        try {
                            const gunData = renderGun();
                            const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing();
                        } catch (e) {}
                    }
                    glassPrev = rightTrigger;
                },
            }),

            new ButtonInfo({
                buttonText: "Giant Hands",
                keepOn: true,
                enabled: false,
                enableMethod: () => { giantHandsOn = true; applyGiantHands(); },
                disableMethod: () => { giantHandsOn = false; applyGiantHands(); },
            }),

            new ButtonInfo({
                buttonText: "Kick All",
                method: () => {
                    try {
                        try { PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke()); } catch (e) {}
                        const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
                        if (others && others.length > 0) {
                            for (let i = 0; i < others.length; i++) {
                                const player = others.get(i);
                                try { PhotonNetwork.method("KickPlayer").invoke(player); } catch (e) {}
                                try { PhotonNetwork.method("CloseConnection").invoke(player); } catch (e) {}
                            }
                        }
                        sendAllOutgoing();
                    } catch (e) { console.log("[Kick All] error: " + e); }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Cam Spin [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                        if (cam != null) {
                            cam.method("get_transform").invoke().method("Rotate", 2).invoke([0, 0, 1], 560 * deltaTime);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Speed Boost [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, 15);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Float",
                keepOn: true,
                enabled: false,
                enableMethod: () => { floatOn = true; },
                disableMethod: () => { floatOn = false; },
                method: () => {
                    try {
                        const v = rigidbody.method("get_velocity").invoke();
                        if (Number(v.field("y").value) < 0) {
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 0, Number(v.field("z").value)]);
                        }
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Moon Jump [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (rightPrimary && !moonPrev) {
                        try {
                            const v = rigidbody.method("get_velocity").invoke();
                            rigidbody.method("set_velocity").invoke([Number(v.field("x").value), 14, Number(v.field("z").value)]);
                        } catch (e) {}
                    }
                    moonPrev = rightPrimary;
                },
            }),

            new ButtonInfo({
                buttonText: "Drunk Monkey",
                keepOn: true,
                enabled: false,
                enableMethod: () => { drunkMonkeyOn = true; },
                disableMethod: () => { drunkMonkeyOn = false; },
                method: () => {
                    try {
                        const t = getTransform(GTPlayer);
                        t.method("Rotate", 1).invoke([
                            (Math.random() - 0.5) * 3,
                            (Math.random() - 0.5) * 3,
                            (Math.random() - 0.5) * 3
                        ]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Spawn Baboon",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) { console.log("[Spawn Baboon] error: " + e); }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Bomb Rain [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - bombLast < 600) return;
                    bombLast = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        const above = Vector3.method("op_Addition", 2).invoke(target, [0, 3, 0]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieBomb"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Wall of Glass",
                method: () => {
                    try {
                        const start = rightHandTransform.method("get_position").invoke();
                        const fwd = rightHandTransform.method("get_forward").invoke();
                        const base = Vector3.method("op_Addition", 2).invoke(start, Vector3.method("op_Multiply", 2).invoke(fwd, 2));
                        for (let i = -2; i <= 2; i++) {
                            const pos = Vector3.method("op_Addition", 2).invoke(base, [i * 0.55, 0, 0]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                    } catch (e) { console.log("[Wall of Glass] error: " + e); }
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Flat Monkey",
                keepOn: true,
                enabled: false,
                enableMethod: () => { flatMonkey = true; applyFlat(); },
                disableMethod: () => { flatMonkey = false; applyFlat(); },
            }),

            new ButtonInfo({
                buttonText: "Stretch Monkey",
                keepOn: true,
                enabled: false,
                enableMethod: () => { stretchMonkey = true; applyStretch(); },
                disableMethod: () => { stretchMonkey = false; applyStretch(); },
            }),

            new ButtonInfo({
                buttonText: "Drop From Sky",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        rigidbody.method("set_position").invoke([Number(p.field("x").value), Number(p.field("y").value) + 3, Number(p.field("z").value)]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "RPG Blast [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rpgLast < 300) return;
                    rpgLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Rpg"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Grenade Launcher [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - grenadeLast < 300) return;
                    grenadeLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GrenadeGrabbable"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Random Spin",
                method: () => {
                    try {
                        getTransform(GTPlayer).method("Rotate", 1).invoke([
                            Math.random() * 360,
                            Math.random() * 360,
                            Math.random() * 360
                        ]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Fling All",
                method: () => {
                    flingAllPlayers();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Snipe Shot [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - ghostLastFire < 250) return;
                    ghostLastFire = now;
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Backslide [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    try {
                        let fwd = null;
                        try {
                            const cam = UnityEngineCore.class("UnityEngine.Camera").method("get_main").invoke();
                            if (cam != null) fwd = cam.method("get_transform").invoke().method("get_forward").invoke();
                        } catch (e) {}
                        if (fwd == null) fwd = getTransform(headCollider).method("get_forward").invoke();
                        const vel = Vector3.method("op_Multiply", 2).invoke(fwd, -15);
                        rigidbody.method("set_velocity").invoke(vel);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Ice Slip",
                keepOn: true,
                enabled: false,
                method: () => {
                    const now = Date.now();
                    if (now - slipLast < 300) return;
                    slipLast = now;
                    try {
                        const ang = Math.random() * Math.PI * 2;
                        const v = rigidbody.method("get_velocity").invoke();
                        rigidbody.method("set_velocity").invoke([Math.cos(ang) * 10, Number(v.field("y").value), Math.sin(ang) * 10]);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Mega Stretch",
                keepOn: true,
                enabled: false,
                enableMethod: () => {
                    try {
                        const t = GTPlayer.method("get_transform").invoke();
                        const s = t.method("get_localScale").invoke();
                        megaStretchBase = [Number(s.field("x").value), Number(s.field("y").value), Number(s.field("z").value)];
                        t.method("set_localScale").invoke([megaStretchBase[0] * 0.4, megaStretchBase[1] * 3, megaStretchBase[2] * 0.4]);
                    } catch (e) {}
                },
                disableMethod: () => {
                    try {
                        if (megaStretchBase != null) {
                            GTPlayer.method("get_transform").invoke().method("set_localScale").invoke(megaStretchBase);
                        }
                        megaStretchBase = null;
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Teleport Bomb",
                method: () => {
                    try {
                        const target = rayTargetFromHand();
                        if (target == null) return;
                        rigidbody.method("set_position").invoke(target);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), target, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Nuke",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        for (let i = 0; i < 30; i++) {
                            const a = (i / 30) * Math.PI * 2;
                            const r = (i % 3) * 2 + 1;
                            const pos = Vector3.method("op_Addition", 2).invoke(p, [Math.cos(a) * r, (i % 5) * 0.5, Math.sin(a) * r]);
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BoogieExplode"), pos, identityQuaternion, 0, NULL);
                        }
                        sendAllOutgoing();
                        console.log("[Nuke] Boom");
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Rain Mode [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rainModeLast < 200) return;
                    rainModeLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [(Math.random() - 0.5) * 3, 4, (Math.random() - 0.5) * 3]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Meteor Shower [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - meteorShowerLast < 200) return;
                    meteorShowerLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        const above = Vector3.method("op_Addition", 2).invoke(p, [(Math.random() - 0.5) * 4, 5, (Math.random() - 0.5) * 4]);
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SmallAsteroid"), above, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Guard Rail [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - guardLast < 400) return;
                    guardLast = now;
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GlassBlock S"), [Number(p.field("x").value), Number(p.field("y").value) - 1.5, Number(p.field("z").value)], identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "RPG Cannon [RT]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightTrigger) return;
                    const now = Date.now();
                    if (now - rpgCannonLast < 250) return;
                    rpgCannonLast = now;
                    try {
                        const gunData = renderGun();
                        const pos = getTransform(gunData.gunPointer).method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Rpg"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing();
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Turbo Spin [A]",
                keepOn: true,
                enabled: false,
                method: () => {
                    if (!rightPrimary) return;
                    try {
                        getTransform(GTPlayer).method("Rotate", 2).invoke([0, 1, 0], 720 * deltaTime);
                    } catch (e) {}
                },
            }),

            new ButtonInfo({
                buttonText: "Lift Off",
                method: () => {
                    try {
                        const p = rigidbody.method("get_position").invoke();
                        rigidbody.method("set_position").invoke([Number(p.field("x").value), Number(p.field("y").value) + 3, Number(p.field("z").value)]);
                    } catch (e) {}
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Random Scale",
                method: () => {
                    try {
                        const t = GTPlayer.method("get_transform").invoke();
                        const s = t.method("get_localScale").invoke();
                        const m = 0.3 + Math.random() * 2.7;
                        t.method("set_localScale").invoke([Number(s.field("x").value) * m, Number(s.field("y").value) * m, Number(s.field("z").value) * m]);
                    } catch (e) {}
                },
                keepOn: false,
            }),
        ],
        [ // Scary
            new ButtonInfo({
                buttonText: "Broken Neck",
                keepOn: true,
                enabled: false,
                enableMethod: () => { brokenNeckOn = true; },
                disableMethod: () => { brokenNeckOn = false; applyBrokenNeck(); },
            }),

            new ButtonInfo({
                buttonText: "Ghost Monkey [Hold X]",
                keepOn: true,
                enabled: false,
                enableMethod: () => { scaryGhostArmed = true; },
                disableMethod: () => { scaryGhostArmed = false; },
            }),

            new ButtonInfo({
                buttonText: "Ghost Name Spam",
                keepOn: true,
                enabled: false,
                enableMethod: () => { ghostNameSpamOn = true; },
                disableMethod: () => { ghostNameSpamOn = false; },
            }),

            new ButtonInfo({
                buttonText: "Invis Monkey [Hold B]",
                keepOn: true,
                enabled: false,
                enableMethod: () => { invisMonkeyArmed = true; },
                disableMethod: () => { invisMonkeyArmed = false; },
            }),

            new ButtonInfo({
                buttonText: "DAISY09",
                method: () => {
                    try {
                        const now = Date.now();
                        if (now - daisyLast < 400) return;
                        daisyLast = now;
                        playDaisy();
                    } catch (e) { console.log("daisy: " + e); }
                },
                keepOn: false,
            }),
        ],
    ];

    let buttonMap: Map<string, ButtonInfo> = new Map();
    buttons.flat().forEach(button => {
        buttonMap.set(button.buttonText, button);
    });

    function getIndex(buttonText: string): ButtonInfo {
        return buttonMap.get(buttonText);
    }

    const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
    ButtonActivation.implementation = function (collider) {
        const rawName = this.method("get_name").invoke().toString();

        if (rawName.length > 1 && rawName[1] == "@") {
            if (collider.handle.equals(referenceCollider.handle)) {
                const goName = rawName.substring(2, rawName.length - 1);
                const _time = Time.method("get_time").invoke();

                if (_time > buttonClickDelay) {
                    buttonClickDelay = _time + 0.05;

                    if (!__huss_unlocked) {
                        if (_time < __huss_lockUntil) {
                            reloadMenu();
                            return;
                        }
                        if (goName == "ENTER") {
                            if (!__huss_pendingKey) {
                                if (passwordInput.length >= 8) {
                                    __huss_pendingKey = true;
                                    __huss_pendingAt = _time;
                                    send({ type: "validate", key: passwordInput.toUpperCase() });
                                    send({ type: "debug", m: "ENTER sent " + passwordInput.toUpperCase() });
                                } else {
                                    __huss_lockUntil = _time + 10;
                                    __huss_lockMsg = "WRONG KEY";
                                    passwordInput = "";
                                    send({ type: "debug", m: "ENTER too short" });
                                }
                            }
                            reloadMenu();
                            return;
                        }
                        if (goName == "BKS") {
                            if (passwordInput.length > 0) passwordInput = passwordInput.substring(0, passwordInput.length - 1);
                            reloadMenu();
                            return;
                        }
                        if (goName == "CLR") {
                            passwordInput = "";
                            reloadMenu();
                            return;
                        }
                        if (/^[A-Za-z0-9]$/.test(goName)) {
                            if (passwordInput.length < 8) passwordInput += goName.toLowerCase();
                            reloadMenu();
                            return;
                        }
                        reloadMenu();
                        return;
                    }

                    if (goName == "SearchKey") {
                        searchMode = !searchMode;
                        searchQuery = "";
                        currentPage = 0;
                        reloadMenu();
                        return;
                    }

                    if (searchMode) {
                        if (goName == "BKS") {
                            if (searchQuery.length > 0) searchQuery = searchQuery.substring(0, searchQuery.length - 1);
                            currentPage = 0;
                            reloadMenu();
                            return;
                        }
                        if (goName == "CLR") {
                            searchQuery = "";
                            currentPage = 0;
                            reloadMenu();
                            return;
                        }
                        if (goName == "SPC") {
                            if (searchQuery.length < 8 && searchQuery[searchQuery.length - 1] != " ") searchQuery += " ";
                            currentPage = 0;
                            reloadMenu();
                            return;
                        }
                        if (/^[A-Za-z]$/.test(goName)) {
                            if (searchQuery.length < 8) searchQuery += goName.toUpperCase();
                            currentPage = 0;
                            reloadMenu();
                            return;
                        }
                    }

                    const button = getIndex(goName)
                    if (button) {
                        if (searchMode && ["Settings", "Movement", "Utility", "Overpowered", "Guns NOT WORKING", "boomboxs", "Effects", "Monsters", "Staff", "Cosmetics", "Mods", "Scary", "Home", "Leave"].indexOf(button.buttonText) !== -1) {
                            searchMode = false;
                            searchQuery = "";
                            currentPage = 0;
                        }
                        if (button.keepOn) {
                            button.enabled = !button.enabled;

                            if (button?.enabled) {
                                button.enableMethod?.();
                            } else {
                                button?.disableMethod?.();
                            }

                        } else {
                            button?.method?.();
                        }

                        reloadMenu();
                    }
                }
            }

            return;
        }

        return this.method("OnTriggerEnter").invoke(collider);
    };

    const LateUpdate = GorillaTagger.method("Update");

    LateUpdate.implementation = function () {

        OVRInputHandler.update();

        leftPrimary = OVRInputHandler.leftControllerPrimaryButton
        leftSecondary = OVRInputHandler.leftControllerSecondaryButton;

        rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
        rightSecondary = OVRInputHandler.rightControllerSecondaryButton;

        leftGrab = OVRInputHandler.leftGrab;
        rightGrab = OVRInputHandler.rightGrab;

        leftTrigger = OVRInputHandler.leftControllerTriggerButton;
        rightTrigger = OVRInputHandler.rightControllerTriggerButton;

        deltaTime = Time.method("get_deltaTime").invoke();
        time = Time.method("get_time").invoke();

        if (__huss_pendingReply != null && __huss_pendingKey) {
            const reply = __huss_pendingReply;
            __huss_pendingReply = null;
            __huss_pendingKey = false;
            if (!__huss_unlocked) {
                if (reply.ok) {
                    __huss_unlocked = true;
                    passwordInput = "";
                    send({ type: "debug", m: "UNLOCKED ok" });
                } else {
                    __huss_lockUntil = time + 10;
                    __huss_lockMsg = reply.status == "used" ? "KEY ALREADY USED" : "WRONG KEY";
                    passwordInput = "";
                    send({ type: "debug", m: "reply not ok status=" + reply.status });
                }
                if (menu != null) reloadMenu();
            }
        } else if (__huss_pendingKey && time > __huss_pendingAt + 4) {
            __huss_pendingKey = false;
            __huss_lockUntil = time + 10;
            __huss_lockMsg = "WRONG KEY";
            passwordInput = "";
            if (menu != null) reloadMenu();
        }

        updateKickBalls();
        updateBanHammerRig();
        updateScaryMods();
        updateDaisy();

        if (leftSecondary) {
            if (menu == null) {
                renderMenu();
            } else {
                recenterMenu();
            }
        } else {
            if (menu != null) {
                Destroy(menu);
                menu = null;
            }
        }

        if (menu == null) {
            if (reference != null) {
                Destroy(reference);
                reference = null;
            }
            if (refDot != null) {
                Destroy(refDot);
                refDot = null;
            }
        } else {
            if (reference == null) {
                renderReference();
            }
        }

        if (refDot != null) {
            try {
                getTransform(refDot).method("set_rotation").invoke(getTransform(headCollider).method("get_rotation").invoke());
            } catch (e) { console.log("refDot rot error: " + e); }
        }

        try {
            if (GunPointer != null) {
                if (!(GunPointer.method("get_activeSelf").invoke())) {
                    Destroy(GunPointer);
                    GunPointer = null;
                }
                else
                    GunPointer.method("SetActive").invoke(false);
            }

            let lineObj = GunLine.method("get_gameObject").invoke();
            if (lineObj != null) {
                if (!(lineObj.method("get_activeSelf").invoke())) {
                    Destroy(lineObj);
                    GunLine = null;
                }
                else
            
       lineObj.method("SetActive").invoke(false);
            }
        } catch { }

        buttons.flat()
            .filter(button => button.enabled)
            .forEach(button => {
                if (button.method) {
                    try {
                        button.method();
                    } catch (error) {
                        console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
                        console.error('Error stack:', error.stack);
                        console.error('Button object:', button);

                        if (error.stack) {
                            const stackLines = error.stack.split('\n');
                            if (stackLines.length > 1) {
                                console.error('Error occurred at:', stackLines[1].trim());
                            }
                        }
                    }
                }
            });

        return LateUpdate.invoke();
    };
    console.log(`Compiled ${new Date().toISOString()}`);

}, "main");
