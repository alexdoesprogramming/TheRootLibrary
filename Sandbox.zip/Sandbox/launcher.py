import os
import sys
import time

import frida

PROCESS_NAME = "Scary Baboon: SANDBOX"
BASE = os.path.dirname(os.path.abspath(__file__))
BRIDGE_FILE = os.path.join(BASE, "frida-il2cpp-bridge.js")
MOD_FILE = os.path.join(BASE, "baboon.js")

script = None


def on_message(message, data):
    if message.get("type") == "send":
        print(message.get("payload"))
    elif message.get("type") == "error":
        print(message.get("stack", message.get("description", message)))
    else:
        print(message)


def main():
    global script
    device = frida.get_usb_device(timeout=5)
    pid = None
    for proc in device.enumerate_processes():
        if proc.name.lower() == PROCESS_NAME.lower():
            pid = proc.pid
            break
    if pid is None:
        print(f"Could not find {PROCESS_NAME} running on the USB device.")
        sys.exit(1)
    session = device.attach(pid)
    with open(BRIDGE_FILE, "r", encoding="utf-8") as f:
        bridge_src = f.read()
    with open(MOD_FILE, "r", encoding="utf-8") as f:
        mod_src = f.read()
    script = session.create_script(bridge_src + "\n" + mod_src)
    script.on("message", on_message)
    script.load()
    print(f"Loaded. Menu active - no key needed.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    script.unload()


if __name__ == "__main__":
    main()