@echo off
python launcher.py
echo loaded
pause
echo Closing...
