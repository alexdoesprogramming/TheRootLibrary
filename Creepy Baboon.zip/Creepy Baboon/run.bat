@echo off
title Creepy Baboon - Nexon Menu (Frida)
echo ========================================
echo  Creepy Baboon - Nexon Menu (Frida)
echo  Keep this window open while you play!
echo ========================================
echo.
echo Attaching frida to CreepyBaboon...
echo.
frida -U -l "%~dp0frida-il2cpp-bridge.js" -l "%~dp0CreepyBaboon menu.js" --runtime=v8 "CreepyBaboon"
pause
