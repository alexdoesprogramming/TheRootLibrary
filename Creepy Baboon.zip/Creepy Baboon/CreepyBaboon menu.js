"use strict";
let canrunrgbthisframeorsmth = true;
let skiddyState = false;
let rgbrig = false;
let thingforfling = null;
let flyspeed = 5.0;
let hue = 0;
let playerScale = 1.0;
let lastRunTime = 0;
const strobecooldown = 500;
const rgbcooldown = 300;
const destroycooldown = 250;
let lastdickettime = 0;
let invisible = false;
let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;
let menuButtonList = [];
let leftPrimary = false;
let leftSecondary = false;
let rightPrimary = false;
let rightSecondary = false;
let leftGrab = false;
let rightGrab = false;
let leftTrigger = false;
let rightTrigger = false;
let wasRightTrigger = false;
let wasRightTriggerFling = false;
let wasRightTriggerKick = false;
let wasRightTriggerRig = false;
let deltaTime = 0.0;
let time = 0.0;
let previousGhostKey = false;
let previousInvisKey = false;
let previousNoclipKey = false;
let perviousTeleportKey = false;
let smoothTurnEnabled = false;
let snapTurnEnabled = false;
let snapTurnThreshold = 0.7;
let snapTurnCooldown = 0.0;
let snapTurnAngle = 30.0;
let wasSnapTurnActive = false;
let turnSpeed = 90.0;
let closePosition = null;
let tagGunDelay = 0.0;
let leftPlatform = null;
let rightPlatform = null;
let noclipEnabled = false;
let lvT = null;
let rvT = null;
// Pink theme
let bgColor = [0.22, 0.0, 0.12, 1.0];
let textColor = [1.0, 0.9, 0.95, 1.0];
let buttonColor = [0.38, 0.0, 0.22, 1.0];
let buttonPressedColor = [1.0, 0.25, 0.6, 1.0];
const SPAWNABLE_ITEMS = [
    "ArmyGrenadeItem", "BoomboxItem", "MolotovItem", "DirtySnowBallItem", "GrapplingHookItem", "MolotovItemUltimate Variant", "SkateBoardItem"
];
let currentItem = SPAWNABLE_ITEMS[0];
let currentIndex = 0;
let flingEnabled = true;
let flingForce = 10.0;
let menuName = "Nexon Untitled CB";
let themeIndex = 0;
let textGradientSpeed = 2.4;
let menuTextFrameCounter = 0;
let animatedMenuTexts = [];
try {
    const fs = require("fs");
    const CONFIG_PATH = "C:\\Users\\draco\\Downloads\\Creepy Baboon frida mod\\menu-config.txt";
    if (fs.existsSync(CONFIG_PATH)) {
        const cfgText = fs.readFileSync(CONFIG_PATH, "utf8");
        const lines = cfgText.split(/\r?\n/);
        for (const raw of lines) {
            const line = raw.trim();
            if (line === "" || line.startsWith("#") || line.startsWith(">>") || line.startsWith("====")) continue;
            const eq = line.indexOf("=");
            if (eq <= 0) continue;
            const key = line.substring(0, eq).trim();
            let val = line.substring(eq + 1).trim();
            if (key === "menuName") {
                val = val.replace(/^"|"$/g, "");
                menuName = val;
            } else if (key === "bgColor" || key === "textColor" || key === "buttonColor" || key === "buttonPressedColor") {
                const nums = val.replace(/[\[\]]/g, "").split(",").map(n => parseFloat(n.trim()));
                if (nums.length === 4 && nums.every(n => !isNaN(n))) {
                    if (key === "bgColor") bgColor = nums;
                    else if (key === "textColor") textColor = nums;
                    else if (key === "buttonColor") buttonColor = nums;
                    else buttonPressedColor = nums;
                }
            }
        }
        if (typeof console !== "undefined" && console.log) console.log("[Config] Loaded menu-config.txt -> menuName='" + menuName + "'");
    }
} catch (e) { }
class XRInputHandler {
    constructor() {
        this.rightThumbstickX = 0.0;
        this.InputDevices = Il2Cpp.domain
            .assembly("UnityEngine.XRModule")
            .image.class("UnityEngine.XR.InputDevices");
        this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
        try {
            this.tryGetFeatureValueFloat = this.InputDevices.method("TryGetFeatureValue_float", 3);
        }
        catch (_) {
            this.tryGetFeatureValueFloat = null;
        }
        this.buttonStates = new Map();
    }
    update() {
        this.updateControllerStates(1); // left controller
        this.updateControllerStates(2); // right controller
        this.rightThumbstickX = this.getThumbstickX(2);
    }
    getThumbstickX(controllerId) {
        if (!this.tryGetFeatureValueFloat)
            return 0.0;
        try {
            const valuePtr = Il2Cpp.alloc(4);
            const feature = Il2Cpp.string("Primary2DAxis");
            const success = this.tryGetFeatureValueFloat.invoke(uint64(controllerId), feature, valuePtr);
            if (success) {
                return valuePtr.readFloat();
            }
        }
        catch (_) { }
        return 0.0;
    }
    updateControllerStates(controllerId) {
        const features = [
            "PrimaryButton",
            "SecondaryButton",
            "GripButton",
            "TriggerButton",
            "MenuButton"
        ];
        features.forEach(feature => {
            const key = `${controllerId}_${feature}`;
            this.buttonStates.set(key, this.getButtonState(controllerId, feature));
        });
    }
    getButtonState(deviceId, featureName) {
        try {
            const valuePtr = Il2Cpp.alloc(1);
            const feature = Il2Cpp.string(featureName);
            const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
            if (success) {
                return valuePtr.readU8() !== 0;
            }
        }
        catch (_) { }
        return false;
    }
    isButtonPressed(controllerId, feature) {
        return this.buttonStates.get(`${controllerId}_${feature}`) || false;
    }
    // Renamed getters
    get leftControllerPrimaryButton() { return this.isButtonPressed(1, "PrimaryButton"); }
    get leftControllerSecondaryButton() { return this.isButtonPressed(1, "SecondaryButton"); }
    get rightControllerPrimaryButton() { return this.isButtonPressed(2, "PrimaryButton"); }
    get rightControllerSecondaryButton() { return this.isButtonPressed(2, "SecondaryButton"); }
    get leftGrab() { return this.isButtonPressed(1, "GripButton"); }
    get rightGrab() { return this.isButtonPressed(2, "GripButton"); }
    get leftControllerTriggerButton() { return this.isButtonPressed(1, "TriggerButton"); }
    get rightControllerTriggerButton() { return this.isButtonPressed(2, "TriggerButton"); }
    get controllerMenuButton() {
        return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
    }
}
Il2Cpp.perform(() => {
    try {
        const lookupAssembly = (name) => {
            try {
                return Il2Cpp.domain.assembly(name).image;
            } catch (_) {
                return null;
            }
        };
        const images = {
            "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
            "PhotonRealtime": Il2Cpp.domain.assembly("PhotonRealtime").image,
            "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
            "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
            "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
            "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
            "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image,
            "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
            "Enver.GardenGame": lookupAssembly("Enver.GardenGame"),
            "EasyInputs": lookupAssembly("EasyInputs"),
        };
        const classOf = (image, name) => {
            try {
                if (image == null) return null;
                try {
                    return image.class(name);
                } catch (_) { }
                for (const klass of image.classes) {
                    try {
                        if (klass.fullName === name || klass.name === name) return klass;
                    } catch (_) { }
                }
                return null;
            }
            catch (_) {
                console.log("[!] class not found (skipped): " + name);
                return null;
            }
        };
        const AssemblyCSharp = images["Assembly-CSharp"];
        const PhotonRealtime = images["PhotonRealtime"];
        const UnityEngineCore = images["UnityEngine.CoreModule"];
        const PhotonUnityNetworking = images["PhotonUnityNetworking"];
        const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
        const UnityEngineUI = images["UnityEngine.UI"];
        const UnityEngineUIModule = images["UnityEngine.UIModule"];
        const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
        const EnverGardenGame = images["Enver.GardenGame"];
        const GameAssemblyImage = EnverGardenGame != null ? EnverGardenGame : images["Assembly-CSharp"];
        const BoxColliderClass = classOf(UnityEnginePhysics, "UnityEngine.BoxCollider");
        const GTPlayerClass = classOf(GameAssemblyImage, "GorillaLocomotion.Player");
        const GorillaReportButton = classOf(GameAssemblyImage, "button");
        const GTPlayer = GTPlayerClass != null ? GTPlayerClass.method("get_Instance").invoke() : null;
        const PhotonNetwork = classOf(PhotonUnityNetworking, "Photon.Pun.PhotonNetwork");
        const PlayerGrab = classOf(PhotonRealtime, "Photon.Realtime.Room");
        const VolcanicEruption = classOf(EnverGardenGame, "Enver.Features.Environment.VolcanicEruption.VolcanicEruption");
        const VolcanicRockClass = classOf(EnverGardenGame, "Enver.Features.Environment.VolcanicEruption.VolcanicRock");
        const UsernameControllerClass = classOf(EnverGardenGame, "BwahVR.Controllers.UsernameController");
        //const PhotonNetworkController = AssemblyCSharp.class("MatchMaking.RoomConnectionStateMachine").field("instance").value;
        const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
        const Object = UnityEngineCore.class("UnityEngine.Object");
        const Component = UnityEngineCore.class("UnityEngine.Component");
        const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
        const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
        const Time = UnityEngineCore.class("UnityEngine.Time");
        const Resources = UnityEngineCore.class("UnityEngine.Resources");
        const Material = UnityEngineCore.class("UnityEngine.Material");
        const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
        const Shader = UnityEngineCore.class("UnityEngine.Shader");
        const Color = UnityEngineCore.class("UnityEngine.Color");
        const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
        const LineRenderer = UnityEngineCore.class("UnityEngine.LineRenderer");
        const PlayerPrefs = UnityEngineCore.class("UnityEngine.PlayerPrefs");
        const Mesh = UnityEngineCore.class("UnityEngine.Mesh");
        const MeshFilter = UnityEngineCore.class("UnityEngine.MeshFilter");
        const MeshCollider = UnityEnginePhysics.class("UnityEngine.MeshCollider");
        const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
        const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
        const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
        const Physics = UnityEnginePhysics.class("UnityEngine.Physics");
        const Ray = UnityEngineCore.class("UnityEngine.Ray");
        const RaycastHit = UnityEnginePhysics.class("UnityEngine.RaycastHit");
        const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
        const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
        const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
        const Text = UnityEngineUI.class("UnityEngine.UI.Text");
        const Font = UnityEngineTextRendering.class("UnityEngine.Font");
        const GorillaTagger = GTPlayer;
        const findShader = (names) => {
            for (const name of names) {
                try {
                    const s = Shader.method("Find").invoke(Il2Cpp.string(name));
                    if (s != null && !s.isNull())
                        return s;
                }
                catch (_) { }
            }
            return null;
        };
        const UberShader = findShader(["Universal Render Pipeline/Unlit", "Unlit/Color", "Universal Render Pipeline/Lit", "Sprites/Default"]);
        const TextShader = findShader(["GUI/Text Shader", "Universal Render Pipeline/Unlit", "Legacy Shaders/Diffuse"]);
        const zeroVector = Vector3.field("zeroVector").value;
        const oneVector = Vector3.field("oneVector").value;
        const identityQuaternion = Quaternion.field("identityQuaternion").value;
        const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
        const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
        const headCollider = GorillaTagger.field("headCollider").value;
        const bodyCollider = GorillaTagger.field("bodyCollider").value;
        const vAdd = Vector3.method("op_Addition", 2);
        const vMul = Vector3.method("op_Multiply", 2);
        const OVRInputHandler = new XRInputHandler();
        function resolveGameFont() {
            try {
                const TMPFontAssetClass = findClassByNameDomainWide("TMP_FontAsset");
                if (TMPFontAssetClass != null) {
                    const tmpFonts = Il2Cpp.gc.choose(TMPFontAssetClass);
                    for (let i = 0; i < tmpFonts.length; i++) {
                        try {
                            const src = tmpFonts[i].field("sourceFontFile").value;
                            if (src != null && !src.isNull()) {
                                try {
                                    console.log("[Font] using game font via TMP_FontAsset: " + src.method("get_name").invoke().toString());
                                }
                                catch (e) { }
                                return src;
                            }
                        }
                        catch (e) { }
                    }
                }
            }
            catch (e) { }
            try {
                const liveFonts = Il2Cpp.gc.choose(Font);
                for (let i = 0; i < liveFonts.length; i++) {
                    try {
                        const name = liveFonts[i].method("get_name").invoke().toString();
                        if (name && name.toLowerCase() !== "arial") {
                            console.log("[Font] using live game Font instance: " + name);
                            return liveFonts[i];
                        }
                    }
                    catch (e) { }
                }
                if (liveFonts.length > 0) {
                    console.log("[Font] using first live Font instance (fallback)");
                    return liveFonts[0];
                }
            }
            catch (e) { }
            console.log("[Font] no game font found, falling back to built-in Arial");
            return Resources.method("GetBuiltinResource", 1).inflate(Font).invoke(Il2Cpp.string("Arial.ttf"));
        }
        const arial = resolveGameFont();
        let rigidbody = null;
        for (const field of GTPlayerClass.fields) {
            if (field.type.name == "UnityEngine.Rigidbody") {
                rigidbody = GTPlayer.field(field.name).value;
                break;
            }
        }
        function applyPlayerScale(scale) {
            playerScale = scale;
            for (const field of GTPlayerClass.fields) {
                try {
                    const fn = field.name.toLowerCase();
                    if (field.type.name === "System.Single") {
                        if (fn.includes("scale"))
                            GTPlayer.field(field.name).value = playerScale;
                    }
                }
                catch (_) { }
            }
            try {
                GTPlayer.field("scale").value = playerScale;
            }
            catch (_) { }
        }
        function overflowSeedSize() {
            try {
                const seedClassNames = new Set();
                for (const klass of EnverGardenGame.classes) {
                    try {
                        if (klass.name.toLowerCase().includes("seed"))
                            seedClassNames.add(klass.name);
                    }
                    catch (_) { }
                }
                if (seedClassNames.size === 0) {
                    console.log("[Seed Overflow] no classes with 'seed' in the name found");
                    return;
                }
                const overflowValue = 9223372036854775808n; // Int64.MaxValue + 1 (wraps to Int64.MinValue on assignment)
                const sizeFieldWords = ["size", "count", "quantity", "stacksize", "amount"];
                let patched = 0;
                for (const name of seedClassNames) {
                    const cls = classOf(EnverGardenGame, name);
                    if (cls == null)
                        continue;
                    let instances = [];
                    try {
                        instances = Il2Cpp.gc.choose(cls);
                    }
                    catch (_) {
                        continue;
                    }
                    for (let i = 0; i < instances.length; i++) {
                        const inst = instances[i];
                        for (const field of cls.fields) {
                            try {
                                const tn = field.type.name;
                                if (tn !== "System.Int64" && tn !== "System.UInt64")
                                    continue;
                                const fn = field.name.toLowerCase();
                                if (!sizeFieldWords.some(w => fn.includes(w)))
                                    continue;
                                inst.field(field.name).value = overflowValue;
                                console.log(`[Seed Overflow] set ${name}.${field.name} (instance ${i}) to ${overflowValue}`);
                                patched++;
                            }
                            catch (_) { }
                        }
                    }
                }
                console.log(`[Seed Overflow] patched ${patched} field(s) across ${seedClassNames.size} seed-related class(es)`);
            }
            catch (e) {
                console.log("[Seed Overflow] error: " + e);
            }
        }
        function Destroy(object) {
            Object.method("Destroy", 1).invoke(object);
        }
        function SetName(name) {
            try {
                PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name));
            }
            catch (e) { }
            if (UsernameControllerClass != null) {
                try {
                    const controllers = Object.method("FindObjectsOfType").inflate(UsernameControllerClass).invoke();
                    for (let i = 0; i < controllers.length; i++) {
                        try {
                            controllers.get(i).method("SetUsernameText").invoke(Il2Cpp.string(name));
                        }
                        catch (e) { }
                    }
                }
                catch (e) { }
                try {
                    UsernameControllerClass.method("RequestUsernameUpdate").invoke(Il2Cpp.string(name));
                }
                catch (e) { }
            }
        }
        function getComponent(obj, type) {
            return obj.method("GetComponent", 1).inflate(type).invoke();
        }
        function addComponent(obj, type) {
            if (type == null) return null;
            return obj.method("AddComponent", 1).inflate(type).invoke();
        }
        function getComponentInParent(obj, type) {
            return obj.method("GetComponentInParent", 0).inflate(type).invoke();
        }
        function getOrAddComponent(obj, type) {
            let returnType = getComponent(obj, type);
            if (returnType != null && returnType != undefined) {
                return returnType;
            }
            return addComponent(obj, type);
        }
        function setPlayerColor(color) {
            PlayerPrefs.method("SetFloat").invoke("redValue", color[0]);
            PlayerPrefs.method("SetFloat").invoke("greenValue", color[1]);
            PlayerPrefs.method("SetFloat").invoke("blueValue", color[2]);
            PlayerPrefs.method("Save").invoke();
            GorillaTagger.method("UpdateColor").invoke(color[0], color[1], color[2]);
            GorillaTagger.method("get_myVRRig").invoke().method("SendRPC").invoke(0, color);
        }
        function spawnItem(itemName) {
            if (!rightTrigger)
                return;
            const now = Date.now();
            if (now - lastdickettime < 200)
                return;
            lastdickettime = now;
            Il2Cpp.perform(() => {
                try {
                    const obj = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(itemName), rightHandTransform.method("get_position").invoke(), rightHandTransform.method("get_rotation").invoke(), 0, NULL);
                    if (flingEnabled) {
                        const rb = obj.method("GetComponent", 1).inflate(Rigidbody).invoke();
                        if (rb != null) {
                            rb.method("set_velocity").invoke(Vector3.method("op_Multiply", 2).invoke(rightHandTransform.method("get_forward").invoke(), flingForce));
                        }
                    }
                    sendAllOutgoing();
                }
                catch (e) { }
            });
        }
        function NoclipHold() {
            try {
                if (rightTrigger && !previousNoclipKey) {
                    toggleColliders(false);
                }
                if (!rightTrigger && previousNoclipKey) {
                    toggleColliders(true);
                }
                previousNoclipKey = rightTrigger;
            } catch (e) { }
        }
        let armLength = 1.0;
        function toggleLongArms() {
            const on = armLength <= 1.0;
            const scale = on ? [1.15, 1.15, 1.15] : [1, 1, 1];
            for (const hand of [leftHandTransform, rightHandTransform]) {
                let t = hand;
                for (let i = 0; i < 2; i++) {
                    try {
                        const p = t.method("get_parent").invoke();
                        if (p == null || p.isNull()) break;
                        p.method("set_localScale").invoke(scale);
                        t = p;
                    } catch (e) { break; }
                }
            }
            armLength = on ? 1.15 : 1.0;
            if (reference != null) { try { Destroy(reference); } catch (e) { } reference = null; }
        }
        function Platforms() {
            try {
                if (leftGrab) {
                    if (leftPlatform == null) {
                        const handPosition = leftHandTransform.method("get_position").invoke();
                        leftPlatform = createObject(Vector3.method("op_Addition", 2).invoke(handPosition, [0.01, -0.035, 0.0]), leftHandTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, buttonPressedColor);
                    }
                } else {
                    if (leftPlatform != null) {
                        Destroy(leftPlatform);
                        leftPlatform = null;
                    }
                }
                if (rightGrab) {
                    if (rightPlatform == null) {
                        const handPosition = rightHandTransform.method("get_position").invoke();
                        rightPlatform = createObject(Vector3.method("op_Addition", 2).invoke(handPosition, [0.0, -0.035, 0.0]), rightHandTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, buttonPressedColor);
                    }
                } else {
                    if (rightPlatform != null) {
                        Destroy(rightPlatform);
                        rightPlatform = null;
                    }
                }
            } catch (e) { }
        }
        function Fly() {
            if (rightSecondary) {
                rigidbody.method("set_velocity").invoke(Vector3.field("zeroVector").value);
                const transform = getTransform(GorillaTagger);
                let forward = getTransform(rightHandTransform).method("get_forward").invoke();
                let position = transform.method("get_position").invoke();
                forward = Vector3.method("op_Multiply", 2).invoke(forward, flyspeed * deltaTime);
                position = Vector3.method("op_Addition", 2).invoke(position, forward);
                transform.method("set_position").invoke(position);
            }
        }
        function getTransform(obj) {
            return obj.method("get_transform").invoke();
        }
        function world2Player(position) {
            position = Vector3.method("op_Subtraction", 2).invoke(position, getTransform(bodyCollider).method("get_position").invoke());
            position = Vector3.method("op_Addition", 2).invoke(position, getTransform(GorillaTagger).method("get_position").invoke());
            return position;
        }
        function teleportPlayer(position) {
            // Teleport method removed due to dump changes, using direct transform manipulation
            getTransform(GorillaTagger).method("set_position").invoke(world2Player(position));
        }
        function hsl2Rgb(h, s, l) {
            s /= 100;
            l /= 100;
            const k = (n) => (n + h / 30) % 12;
            const a = s * Math.min(l, 1 - l);
            const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
            return [
                Math.round(255 * f(0)),
                Math.round(255 * f(8)),
                Math.round(255 * f(4))
            ];
        }
        function getSmoothColor() {
            hue = (hue + 0.5) % 360;
            const [r, g, b] = hsl2Rgb(hue, 100, 50);
            return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
        }
        function toHexByte(v) {
            return Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, "0");
        }
        function canGradient(text) {
            return !text.includes("<color=") && text.length > 1;
        }
        function gradientText(text, colorA, colorB) {
            if (!canGradient(text))
                return text;
            let result = "";
            for (let i = 0; i < text.length; i++) {
                const ch = text[i];
                if (ch === " ") {
                    result += ch;
                    continue;
                }
                const t = i / (text.length - 1);
                const r = colorA[0] + (colorB[0] - colorA[0]) * t;
                const g = colorA[1] + (colorB[1] - colorA[1]) * t;
                const b = colorA[2] + (colorB[2] - colorA[2]) * t;
                result += `<color=#${toHexByte(r)}${toHexByte(g)}${toHexByte(b)}>${ch}</color>`;
            }
            return result;
        }
        function animatedGradientText(text, colorA, colorB, phase) {
            if (!canGradient(text))
                return text;
            let result = "";
            let visibleIndex = 0;
            for (let i = 0; i < text.length; i++) {
                const ch = text[i];
                if (ch === " ") {
                    result += ch;
                    continue;
                }
                const wave = 0.5 + 0.5 * Math.sin(phase + visibleIndex * 0.48);
                const r = colorA[0] + (colorB[0] - colorA[0]) * wave;
                const g = colorA[1] + (colorB[1] - colorA[1]) * wave;
                const b = colorA[2] + (colorB[2] - colorA[2]) * wave;
                result += `<color=#${toHexByte(r)}${toHexByte(g)}${toHexByte(b)}>${ch}</color>`;
                visibleIndex++;
            }
            return result;
        }
        function updateAnimatedMenuText() {
            if (menu == null || animatedMenuTexts.length === 0)
                return;
            menuTextFrameCounter++;
            if (menuTextFrameCounter % 2 !== 0)
                return;
            for (const item of animatedMenuTexts) {
                try {
                    if (!item.component || item.component.isNull?.())
                        continue;
                    item.component.method("set_text").invoke(Il2Cpp.string(item.render(time * textGradientSpeed + item.phase)));
                }
                catch (_) { }
            }
        }
        function renderMenuText(canvasObject, text = "", color = [1, 1, 1, 1], pos = zeroVector, size = oneVector, animate = null) {
            const titleObj = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject));
            titleObj.method("set_layer").invoke(2);
            { const bc = getComponent(titleObj, BoxCollider); if (bc != null) Destroy(bc); }
            const title = addComponent(titleObj, Text);
            const phase = animatedMenuTexts.length * 0.73;
            title.method("set_text").invoke(Il2Cpp.string(animate ? animate.render(time * textGradientSpeed + phase) : text));
            title.method("set_font").invoke(arial);
            title.method("set_fontSize").invoke(1);
            title.method("set_color").invoke(color);
            title.method("set_fontStyle").invoke(2);
            title.method("set_alignment").invoke(4);
            title.method("set_resizeTextForBestFit").invoke(true);
            title.method("set_resizeTextMinSize").invoke(0);
            const rectTransform = getComponent(title, RectTransform);
            rectTransform.method("set_sizeDelta").invoke(size);
            rectTransform.method("set_position").invoke(pos);
            rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0));
            if (animate) {
                animatedMenuTexts.push({ component: title, render: animate.render, phase });
            }
        }
        const roundedMeshCache = new Map();
        function getRoundedBoxMesh(width, height, cornerRadius) {
            const normalizedY = Math.max(0.001, Math.min(0.46, cornerRadius / Math.max(width, 0.001)));
            const normalizedZ = Math.max(0.001, Math.min(0.46, cornerRadius / Math.max(height, 0.001)));
            const cacheKey = normalizedY.toFixed(4) + ":" + normalizedZ.toFixed(4);
            const cached = roundedMeshCache.get(cacheKey);
            if (cached && !cached.isNull?.())
                return cached;
            const perimeter = [];
            const cornerSegments = 10;
            const corners = [
                [0.5 - normalizedY, 0.5 - normalizedZ, 0, Math.PI * 0.5],
                [-0.5 + normalizedY, 0.5 - normalizedZ, Math.PI * 0.5, Math.PI],
                [-0.5 + normalizedY, -0.5 + normalizedZ, Math.PI, Math.PI * 1.5],
                [0.5 - normalizedY, -0.5 + normalizedZ, Math.PI * 1.5, Math.PI * 2],
            ];
            for (const [centerY, centerZ, startAngle, endAngle] of corners) {
                for (let segment = 0; segment <= cornerSegments; segment++) {
                    const t = segment / cornerSegments;
                    const angle = startAngle + (endAngle - startAngle) * t;
                    perimeter.push([centerY + Math.cos(angle) * normalizedY, centerZ + Math.sin(angle) * normalizedZ]);
                }
            }
            const vertices = [];
            for (const [y, z] of perimeter)
                vertices.push([0.5, y, z]);
            for (const [y, z] of perimeter)
                vertices.push([-0.5, y, z]);
            const ringCount = perimeter.length;
            const frontCenter = vertices.length;
            vertices.push([0.5, 0, 0]);
            const backCenter = vertices.length;
            vertices.push([-0.5, 0, 0]);
            const triangles = [];
            for (let index = 0; index < ringCount; index++) {
                const next = (index + 1) % ringCount;
                triangles.push(frontCenter, index, next);
                triangles.push(backCenter, next + ringCount, index + ringCount);
                triangles.push(index, index + ringCount, next + ringCount);
                triangles.push(index, next + ringCount, next);
            }
            const vertexArray = Il2Cpp.array(Vector3, vertices.length);
            for (let index = 0; index < vertices.length; index++) {
                vertexArray.set(index, Il2Cpp.fromFridaValue(vertices[index], Vector3.type));
            }
            const triangleArray = Il2Cpp.array(Il2Cpp.corlib.class("System.Int32"), triangles);
            const mesh = Mesh.alloc();
            mesh.method(".ctor", 0).invoke();
            mesh.method("set_vertices").invoke(vertexArray);
            mesh.method("set_triangles").invoke(triangleArray);
            mesh.method("RecalculateBounds", 0).invoke();
            mesh.method("RecalculateNormals", 0).invoke();
            roundedMeshCache.set(cacheKey, mesh);
            return mesh;
        }
        function menuCornerRadius(scale) {
            const width = scale[1];
            const height = scale[2];
            return Math.min(Math.min(width, height) * 0.28, 0.06);
        }
        function createObject(pos = zeroVector, rot = identityQuaternion, scale = oneVector, primitiveType = 3, colorArr = [1, 1, 1, 1], parent = null, cornerRadius = 0) {
            const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);
            const renderer = getComponent(obj, Renderer);
            if (colorArr[3] == 0) {
                renderer.method("set_enabled").invoke(false);
            }
            else {
                const material = renderer.method("get_material").invoke();
                if (UberShader != null)
                    material.method("set_shader").invoke(UberShader);
                material.method("set_color").invoke(colorArr);
            }
            if (cornerRadius > 0 && primitiveType === 3) {
                try {
                    getComponent(obj, MeshFilter).method("set_sharedMesh").invoke(getRoundedBoxMesh(scale[1], scale[2], cornerRadius));
                }
                catch (_) { }
            }
            const transform = getTransform(obj);
            if (parent != null) {
                transform.method("SetParent", 2).invoke(parent, false);
            }
            transform.method("set_position").invoke(pos);
            transform.method("set_rotation").invoke(rot);
            transform.method("set_localScale").invoke(scale);
            return obj;
        }
        function sendAllOutgoing() {
            PhotonNetwork.method("SendAllOutgoingCommands").invoke();
        }
        function renderMenu() {
            menuButtonList = [];
            menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
            menu.method("set_layer").invoke(2);
            Destroy(getComponent(menu, BoxCollider));
            const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 1, 1], 3, bgColor, getTransform(menu), menuCornerRadius([0.1, 1, 1]));
            menuBackground.method("set_layer").invoke(2);
            Destroy(getComponent(menuBackground, BoxCollider));
            const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
            canvasObject.method("set_layer").invoke(2);
            const canvas = addComponent(canvasObject, Canvas);
            Destroy(getComponent(canvasObject, BoxCollider));
            const canvasScaler = addComponent(canvasObject, CanvasScaler);
            addComponent(canvasObject, GraphicRaycaster);
            canvas.method("set_renderMode").invoke(2);
            canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);
            renderMenuText(canvasObject, `${gradientText(menuName, textColor, buttonPressedColor)}<color=grey>[</color><color=white>${currentPage + 1}</color><color=grey>]</color>`, textColor, [0.11, 0, 0.175], [1, 0.1], canGradient(menuName) ? { render: (phase) => `${animatedGradientText(menuName, textColor, buttonPressedColor, phase)}<color=grey>[</color><color=white>${currentPage + 1}</color><color=grey>]</color>` } : null);
            const disconnectButton = createObject([0.1, 0.0, 0.225], identityQuaternion, [0.09, 0.9, 0.08], 3, buttonColor, getTransform(menu), menuCornerRadius([0.09, 0.9, 0.08]));
            disconnectButton.method("set_name").invoke(Il2Cpp.string("@Disconnect"));
            disconnectButton.method("set_layer").invoke(2);
            { const bc = getComponent(disconnectButton, BoxCollider); if (bc != null) Destroy(bc); }
            menuButtonList.push({ name: "Disconnect", obj: disconnectButton, collider: null });
            renderMenuText(canvasObject, "Disconnect", textColor, [0.11, 0, 0.225], [1, 0.1]);
            {
                const pageButton = createObject([0.1, 0.2, 0], identityQuaternion, [0.09, 0.2, 0.9], 3, buttonColor, getTransform(menu), menuCornerRadius([0.09, 0.2, 0.9]));
                pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));
                pageButton.method("set_layer").invoke(2);
                { const bc = getComponent(pageButton, BoxCollider); if (bc != null) Destroy(bc); }
                menuButtonList.push({ name: "PreviousPage", obj: pageButton, collider: null });
                renderMenuText(canvasObject, "<", textColor, [0.11, 0.2, 0], [1, 0.1]);
            }
            {
                const pageButton = createObject([0.1, -0.2, 0], identityQuaternion, [0.09, 0.2, 0.9], 3, buttonColor, getTransform(menu), menuCornerRadius([0.09, 0.2, 0.9]));
                pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));
                pageButton.method("set_layer").invoke(2);
                { const bc = getComponent(pageButton, BoxCollider); if (bc != null) Destroy(bc); }
                menuButtonList.push({ name: "NextPage", obj: pageButton, collider: null });
                renderMenuText(canvasObject, ">", textColor, [0.11, -0.2, 0], [1, 0.1]);
            }
            let i = 0;
            const targetMods = buttons[currentCategory]
                .slice(currentPage * 8)
                .slice(0, 8);
            targetMods.forEach((buttonData, index) => {
                const button = createObject([0.105, 0, 0.13 - (i * 0.04)], identityQuaternion, [0.09, 0.9, 0.08], 3, buttonColor, getTransform(menu), menuCornerRadius([0.09, 0.9, 0.08]));
                button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));
                button.method("set_layer").invoke(2);
                { const bc = getComponent(button, BoxCollider); if (bc != null) Destroy(bc); }
                menuButtonList.push({ name: buttonData.buttonText, obj: button, collider: null });
                renderMenuText(canvasObject, gradientText(buttonData.buttonText, textColor, buttonPressedColor), textColor, [0.11, 0, 0.13 - (i * 0.04)], [1, 0.1], canGradient(buttonData.buttonText) ? { render: (phase) => animatedGradientText(buttonData.buttonText, textColor, buttonPressedColor, phase) } : null);
                updateButtonColor(button, buttonData);
                i++;
            });
            recenterMenu();
        }
        function renderReference() {
            reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.010], 0, bgColor, rightHandTransform);
            referenceCollider = getComponent(reference, Collider);
            if (referenceCollider != null) referenceCollider.method("set_isTrigger").invoke(true);
            getTransform(reference).method("set_localPosition").invoke([-0.025, -0.00, 0.125]);
            reference.method("set_layer").invoke(2);
            addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
        }
        let gunLocked = false;
        let lockTarget = null;
        let GunPointer = null;
        let GunLine = null;
        function renderGun(overrideLayerMask = null) {
            const StartPosition = rightHandTransform.method("get_position").invoke();
            const Direction = rightHandTransform.method("get_forward").invoke();
            const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
            const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);
            const layerMask = overrideLayerMask || -3180559;
            const hits = Physics.method("RaycastAll", 4).invoke(rayStartPosition, Direction, 512.0, layerMask);
            let finalDistance = Infinity;
            let finalRay = null;
            for (const hit of hits) {
                const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
                if (distance < finalDistance) {
                    finalRay = hit;
                    finalDistance = distance;
                }
            }
            let EndPosition;
            if (gunLocked) {
                EndPosition = getTransform(lockTarget).method("get_position").invoke();
            }
            else if (finalRay != null) {
                EndPosition = finalRay.method("get_point").invoke();
            }
            else {
                const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
                EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
            }
            if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
                const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
                EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
            }
            if (GunPointer == null) {
                GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
            }
            GunPointer.method("SetActive").invoke(true);
            const pointerTransform = getTransform(GunPointer);
            pointerTransform.method("set_position").invoke(EndPosition);
            const PointerRenderer = getComponent(GunPointer, Renderer);
            const material = PointerRenderer.method("get_material").invoke();
            material.method("set_shader").invoke(TextShader);
            const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : bgColor;
            material.method("set_color").invoke(pointerColor);
            const collider = getComponent(GunPointer, Collider);
            if (collider != null) {
                Destroy(collider);
            }
            if (GunLine == null) {
                const lineObj = createObject(zeroVector, identityQuaternion, oneVector, 0, [0, 0, 0, 0]);
                GunLine = addComponent(lineObj, LineRenderer);
            }
            else {
                GunLine.method("get_gameObject").invoke().method("SetActive").invoke(true);
            }
            const lineMaterial = GunLine.method("get_material").invoke();
            lineMaterial.method("set_shader").invoke(TextShader);
            GunLine.method("set_startColor").invoke(bgColor);
            GunLine.method("set_endColor").invoke(bgColor);
            const lineWidth = 0.025;
            GunLine.method("set_startWidth").invoke(lineWidth);
            GunLine.method("set_endWidth").invoke(lineWidth);
            GunLine.method("set_positionCount").invoke(2);
            GunLine.method("set_useWorldSpace").invoke(true);
            //GunLine.method("set_numCapVertices").invoke(10);
            GunLine.method("SetPosition").invoke(0, StartPosition);
            GunLine.method("SetPosition").invoke(1, EndPosition);
            if (rightTrigger || gunLocked) {
                const Step = 10;
                GunLine.method("set_positionCount").invoke(Step);
                GunLine.method("SetPosition").invoke(0, StartPosition);
                for (let i = 1; i < (Step - 1); i++) {
                    const t = i / (Step - 1);
                    const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);
                    const randomValue = Math.random();
                    let offset = zeroVector;
                    if (randomValue > 0.75) {
                        offset = [
                            (Math.random() * 0.2) - 0.1,
                            (Math.random() * 0.2) - 0.1,
                            (Math.random() * 0.2) - 0.1
                        ];
                    }
                    const finalPosition = Vector3.method("op_Addition").invoke(Position, offset);
                    GunLine.method("SetPosition").invoke(i, finalPosition);
                }
                GunLine.method("SetPosition").invoke(Step - 1, EndPosition);
            }
            return { ray: finalRay, gunPointer: GunPointer };
        }
        function hideGun() {
            try {
                if (GunPointer != null)
                    GunPointer.method("SetActive").invoke(false);
            }
            catch (e) { }
            try {
                const lineObj = GunLine.method("get_gameObject").invoke();
                if (lineObj != null && !lineObj.isNull())
                    lineObj.method("SetActive").invoke(false);
            }
            catch (e) { }
        }
        function recenterMenu() {
            let menuPosition = leftHandTransform.method("get_position").invoke();
            let menuRotation = leftHandTransform.method("get_rotation").invoke();
            menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0));
            const menuTransform = getTransform(menu);
            menuTransform.method("set_position").invoke(menuPosition);
            menuTransform.method("set_rotation").invoke(menuRotation);
        }
        function reloadMenu() {
            if (menu != null) {
                Object.method("Destroy", 1).invoke(menu);
                menu = null;
            }
            animatedMenuTexts.length = 0;
        }
        function updateButtonColor(button, buttonData) {
            const RendererClass = Il2Cpp.domain
                .assembly("UnityEngine.CoreModule")
                .image
                .class("UnityEngine.Renderer");
            const renderer = getComponent(button, RendererClass);
            if (!renderer) {
                return;
            }
            const material = renderer.method("get_material").invoke();
            material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
        }
        function playButtonSound() {
            //LocalRig.method("PlayHandTapLocal").invoke(8, false, 0.3 );
            //GorillaTagger.method("StartVibration").invoke(false, 0.5, 0.075);
        }
        function toggleColliders(enabled) {
            const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();
            for (let i = 0; i < meshColliders.length; i++) {
                const meshCollider = meshColliders.get(i);
                meshCollider.method("set_enabled").invoke(enabled);
            }
        }
        class ButtonInfo {
            constructor(config) {
                this.buttonText = config.buttonText;
                this.method = config.method;
                this.enableMethod = config.enableMethod;
                this.disableMethod = config.disableMethod;
                this.isTogglable = config.isTogglable ?? true;
                this.toolTip = config.toolTip ?? null;
                this.enabled = config.enabled ?? false;
            }
        }
        let currentCategory = 0;
        let currentPage = 0;
        let growthSize = 10.0;
        let growthBoostOn = false;
        const SprinklerAbility = classOf(EnverGardenGame, "Enver.Features.GearSprinklerAbility");
        const growthBoost = (model) => {
            if (!growthBoostOn || model == null || model.isNull())
                return;
            try {
                const base = model.field("TargetScale").value;
                let valid = true;
                try {
                    valid = (base.field("x").value > 0.001) || (base.field("y").value > 0.001) || (base.field("z").value > 0.001);
                }
                catch (e) {
                    valid = true;
                }
                if (!valid)
                    return;
                const target = vMul.invoke(base, growthSize);
                model.field("TargetScale").value = target;
                if (SprinklerAbility != null)
                    SprinklerAbility.method("SaveGrowable").invoke(model);
            }
            catch (e) { }
        };
        const installGrowthBoost = (cls) => {
            if (cls == null)
                return;
            try {
                const init = cls.method("EveryoneInitialize");
                init.implementation = function () {
                    const res = this.method("EveryoneInitialize").invoke();
                    growthBoost(this);
                    return res;
                };
            }
            catch (e) { }
        };
        installGrowthBoost(classOf(EnverGardenGame, "Enver.Features.Plant"));
        installGrowthBoost(classOf(EnverGardenGame, "Enver.Features.Crop"));
        const StaffItemClass = classOf(EnverGardenGame, "Enver.Features.StaffManagement.StaffItem");
        let staffNoCooldown = false;
        let staffRapidFire = false;
        const zeroStaffCooldown = (obj) => {
            try {
                obj.field("coolDownSeconds").value = 0.0;
            }
            catch (e) { }
            try {
                obj.field("_currentTimer").value = 0.0;
            }
            catch (e) { }
            try {
                obj.field("AllowAction").value = true;
            }
            catch (e) { }
        };
        if (StaffItemClass != null) {
            try {
                const sUpd = StaffItemClass.method("Update");
                sUpd.implementation = function () {
                    try {
                        if (staffNoCooldown) {
                            this.field("coolDownSeconds").value = 0.0;
                            this.field("_currentTimer").value = 0.0;
                            this.field("AllowAction").value = true;
                        }
                        if (staffRapidFire) {
                            let gripHeld = false;
                            try {
                                const node = this.field("xrNode").value;
                                const n = node.field("value__").value;
                                if (n == 4)
                                    gripHeld = leftGrab;
                                else if (n == 5)
                                    gripHeld = rightGrab;
                                else
                                    gripHeld = leftGrab || rightGrab;
                            }
                            catch (e) {
                                gripHeld = leftGrab || rightGrab;
                            }
                            if (gripHeld) {
                                this.field("coolDownSeconds").value = 0.0;
                                this.field("_currentTimer").value = 0.0;
                                this.field("AllowAction").value = true;
                                try {
                                    this.method("PerformAction").invoke();
                                }
                                catch (e) { }
                            }
                        }
                    }
                    catch (e) { }
                    return this.method("Update").invoke();
                };
            }
            catch (e) { }
        }
        const lastNetworkName = { v: null };
        try {
            const pni = PhotonNetwork.method("Instantiate", 5);
            pni.implementation = function (prefabName, pos, rot, group, data) {
                try {
                    lastNetworkName.v = prefabName.toString();
                }
                catch (e) { }
                return pni.invoke(prefabName, pos, rot, group, data);
            };
        }
        catch (e) { }
        let logPhotonEvents = false;
        function readEventMember(photonEvent, name) {
            try {
                return photonEvent.method("get_" + name).invoke();
            }
            catch (_) { }
            try {
                return photonEvent.field(name).value;
            }
            catch (_) { }
            return undefined;
        }
        let photonEventLogErrorShown = false;
        function installOnEventHook(cls, label) {
            if (cls == null)
                return;
            try {
                const oe = cls.method("OnEvent", 1);
                oe.implementation = function (photonEvent) {
                    try {
                        const code = readEventMember(photonEvent, "Code");
                        if (code == WEATHER_SYNC_EVENT_CODE) {
                            const payload = readEventMember(photonEvent, "CustomData");
                            const id = payload != null ? payload.toString() : "";
                            const wec = getWeatherEventController();
                            if (wec != null) {
                                if (id === "__CLEAR__") {
                                    try {
                                        wec.method("ClearWeather").invoke();
                                    }
                                    catch (e) { }
                                }
                                else {
                                    try {
                                        wec.method("ApplyWeather", 1).invoke(Il2Cpp.string(id));
                                    }
                                    catch (e) { }
                                }
                                console.log(`[Weather Sync] received ${id} via ${label}`);
                            }
                        }
                    }
                    catch (_) { }
                    if (logPhotonEvents) {
                        try {
                            const code = readEventMember(photonEvent, "Code");
                            const sender = readEventMember(photonEvent, "Sender");
                            const data = readEventMember(photonEvent, "CustomData") ?? readEventMember(photonEvent, "Parameters");
                            let dataStr = "<n/a>";
                            try {
                                dataStr = (data == null || data.isNull?.()) ? "<null>" : data.toString();
                            }
                            catch (_) { }
                            console.log(`[Photon Event] (${label}) code=${code} sender=${sender} data=${dataStr}`);
                        }
                        catch (e) {
                            if (!photonEventLogErrorShown) {
                                photonEventLogErrorShown = true;
                                console.log("[Photon Event] log error (shown once): " + e);
                            }
                        }
                    }
                    return this.method("OnEvent", 1).invoke(photonEvent);
                };
            }
            catch (e) {
                console.log(`[Photon Event] failed to hook OnEvent on ${label}: ${e}`);
            }
        }
        const LoadBalancingClient = classOf(PhotonRealtime, "Photon.Realtime.LoadBalancingClient");
        installOnEventHook(LoadBalancingClient, "LoadBalancingClient");
        const WeatherManagerClass = classOf(EnverGardenGame, "Enver.Features.Environment.Weather.WeatherManager");
        const WeatherEventControllerClass = classOf(EnverGardenGame, "Enver.Features.Environment.Weather.WeatherEventController");
        const WeatherEventClass = classOf(EnverGardenGame, "Enver.Features.Environment.Weather.WeatherEvent");
        function getWeatherManagerInstance() {
            try {
                const instances = Il2Cpp.gc.choose(WeatherManagerClass);
                return instances.length > 0 ? instances[0] : null;
            }
            catch (e) {
                return null;
            }
        }
        function getWeatherEventController() {
            const wm = getWeatherManagerInstance();
            if (wm == null)
                return null;
            try {
                return wm.method("GetEventController").invoke();
            }
            catch (e) {
                return null;
            }
        }
        function getWeatherEventList() {
            const wec = getWeatherEventController();
            if (wec == null)
                return [];
            try {
                const list = wec.method("GetWeatherEvents").invoke();
                const count = list.method("get_Count").invoke();
                const out = [];
                for (let i = 0; i < count; i++) {
                    try {
                        out.push(list.method("get_Item").invoke(i));
                    }
                    catch (e) { }
                }
                return out;
            }
            catch (e) {
                return [];
            }
        }
        function getWeatherEventId(weatherEvent) {
            try {
                return weatherEvent.field("weatherId").value.toString();
            }
            catch (e) { }
            try {
                return weatherEvent.field("id").value.toString();
            }
            catch (e) { }
            return "<unknown>";
        }
        function findClassByNameDomainWide(simpleName) {
            try {
                const assemblies = Il2Cpp.domain.assemblies;
                for (let i = 0; i < assemblies.length; i++) {
                    try {
                        const image = assemblies[i].image;
                        for (const klass of image.classes) {
                            if (klass.name === simpleName)
                                return klass;
                        }
                    }
                    catch (_) { }
                }
            }
            catch (_) { }
            return null;
        }
        const PlayerModManagerClass = classOf(EnverGardenGame, "Enver.Features.GameMods.PlayerMods.PlayerModManager");
        function getPlayerModManagerInstance() {
            try {
                return PlayerModManagerClass.method("get_Instance").invoke();
            }
            catch (e) {
                return null;
            }
        }
        function togglePlayerMod(className) {
            try {
                const cls = classOf(EnverGardenGame, "Enver.Features.GameMods.PlayerMods." + className);
                if (cls == null) {
                    console.log(`[Player Mods] class not found: ${className}`);
                    return;
                }
                const instances = Il2Cpp.gc.choose(cls);
                if (instances.length === 0) {
                    console.log(`[Player Mods] no live instance of ${className}`);
                    return;
                }
                const mgr = getPlayerModManagerInstance();
                if (mgr == null) {
                    console.log("[Player Mods] no live PlayerModManager instance");
                    return;
                }
                mgr.method("ToggleMod", 1).invoke(instances[0]);
                console.log(`[Player Mods] toggled ${className}`);
            }
            catch (e) {
                console.log(`[Player Mods] toggle error for ${className}: ` + e);
            }
        }
        const WEATHER_SYNC_EVENT_CODE = 191;
        const RaiseEventOptionsClass = classOf(PhotonRealtime, "Photon.Realtime.RaiseEventOptions");
        const SendOptionsClass = findClassByNameDomainWide("SendOptions");
        let weatherSyncErrorShown = false;
        function raiseWeatherSyncEvent(payload) {
            try {
                if (RaiseEventOptionsClass == null || SendOptionsClass == null) {
                    if (!weatherSyncErrorShown) {
                        weatherSyncErrorShown = true;
                        console.log("[Weather Sync] RaiseEventOptions/SendOptions class not found, cannot network weather");
                    }
                    return;
                }
                const options = RaiseEventOptionsClass.field("Default").value;
                let sendOptions;
                try {
                    sendOptions = SendOptionsClass.field("SendReliable").value;
                }
                catch (_) {
                    sendOptions = { Reliability: true };
                }
                const sent = PhotonNetwork.method("RaiseEvent", 4).invoke(WEATHER_SYNC_EVENT_CODE, Il2Cpp.string(payload), options, sendOptions);
                console.log(`[Weather Sync] RaiseEvent(${payload}) returned ${sent}`);
            }
            catch (e) {
                if (!weatherSyncErrorShown) {
                    weatherSyncErrorShown = true;
                    console.log("[Weather Sync] RaiseEvent error (shown once): " + e);
                }
            }
        }
        function applyWeatherNetworked(id) {
            try {
                const wec = getWeatherEventController();
                if (wec == null) {
                    console.log("[Weather] no live WeatherEventController instance");
                    return;
                }
                wec.method("ApplyWeather", 1).invoke(Il2Cpp.string(id));
                console.log(`[Weather] applied ${id}`);
            }
            catch (e) {
                console.log("[Weather] apply error: " + e);
            }
            raiseWeatherSyncEvent(id);
        }
        function clearWeatherNetworked() {
            try {
                const wec = getWeatherEventController();
                if (wec != null)
                    wec.method("ClearWeather").invoke();
            }
            catch (e) {
                console.log("[Weather] clear error: " + e);
            }
            raiseWeatherSyncEvent("__CLEAR__");
        }
        const RocketLauncherClass = classOf(EnverGardenGame, "Enver.Features.StaffManagement.RocketLauncher.RocketLauncherStaffItem");
        const RocketProjectileClass = classOf(EnverGardenGame, "Enver.Features.StaffManagement.RocketLauncher.RocketProjectile");
        const rocketSwarmCount = 10;
        if (RocketLauncherClass != null) {
            try {
                const pa = RocketLauncherClass.method("PerformAction");
                pa.implementation = function () {
                    try {
                        this.method("PerformAction").invoke();
                    }
                    catch (e) { }
                    try {
                        const prefab = this.field("rocket").value;
                        const start = this.field("startPoint").value;
                        if (prefab == null || prefab.isNull() || start == null || start.isNull())
                            return;
                        const speed = this.field("launchSpeed").value;
                        const dist = this.field("maxDistance").value;
                        const basePos = start.method("get_position").invoke();
                        const right = start.method("get_right").invoke();
                        const fwd = start.method("get_forward").invoke();
                        const rot = start.method("get_rotation").invoke();
                        let rocketName = lastNetworkName.v;
                        if (rocketName == null) {
                            try {
                                rocketName = prefab.method("get_gameObject").invoke().method("get_name").invoke().toString();
                            }
                            catch (e) { }
                        }
                        const tempGo = GameObject.method("CreatePrimitive").invoke(3);
                        const tempT = tempGo.method("get_transform").invoke();
                        try {
                            const bc = tempGo.method("GetComponent", 1).inflate(BoxCollider).invoke();
                            if (bc != null)
                                Object.method("Destroy", 1).invoke(bc);
                            tempT.method("set_rotation").invoke(rot);
                            for (let k = 0; k < rocketSwarmCount; k++) {
                                try {
                                    const fan = (k - (rocketSwarmCount - 1) / 2) * 0.35;
                                    const offPos = Vector3.method("op_Addition", 2).invoke(basePos, Vector3.method("op_Addition", 2).invoke(Vector3.method("op_Multiply", 2).invoke(right, fan), Vector3.method("op_Multiply", 2).invoke(fwd, k * 1.0)));
                                    tempT.method("set_position").invoke(offPos);
                                    let r = null;
                                    let networked = false;
                                    if (rocketName != null) {
                                        try {
                                            const netGo = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(rocketName), offPos, rot, 0, null);
                                            if (netGo != null && !netGo.isNull()) {
                                                r = netGo.method("GetComponent").inflate(RocketProjectileClass).invoke();
                                                networked = true;
                                            }
                                            else {
                                                console.log("[rock] PhotonNetwork.Instantiate returned null for '" + rocketName + "'");
                                            }
                                        }
                                        catch (e) { }
                                    }
                                    if (r == null) {
                                        r = Object.method("Instantiate", 1).invoke(prefab);
                                        if (r != null) {
                                            const rt = r.method("get_transform").invoke();
                                            rt.method("set_position").invoke(offPos);
                                            rt.method("set_rotation").invoke(rot);
                                        }
                                    }
                                    if (r != null)
                                        r.method("Launch").invoke(tempT, speed, dist);
                                    if (k == 0)
                                        console.log("[rock] swarm using '" + rocketName + "' -> " + (networked ? "networked" : "local"));
                                }
                                catch (e) { }
                            }
                        }
                        finally {
                            try {
                                Object.method("Destroy", 1).invoke(tempGo);
                            }
                            catch (e) { }
                        }
                    }
                    catch (e) { }
                };
            }
            catch (e) { }
        }
        let lastdickettime = 0;
        function fireVolcanoRock() {
            if (!rightTrigger)
                return;
            const now = Date.now();
            if (now - lastdickettime < 200)
                return;
            lastdickettime = now;
            Il2Cpp.perform(() => {
                try {
                    if (VolcanicEruption == null)
                        return;
                    const eruptions = Object.method("FindObjectsOfType").inflate(VolcanicEruption).invoke();
                    let er = null;
                    if (eruptions != null && eruptions.length > 0)
                        er = eruptions.get(0);
                    if (er == null) {
                        console.log("[rock] no VolcanicEruption found in scene");
                        return;
                    }
                    try {
                        er.field("_allowEruption").value = true;
                    }
                    catch (e) { }
                    const pos = rightHandTransform.method("get_position").invoke();
                    const x = pos.field("x").value;
                    const z = pos.field("z").value;
                    let isMaster = false;
                    try {
                        isMaster = PhotonNetwork.method("get_IsMasterClient").invoke();
                    }
                    catch (e) { }
                    try {
                        er.method("RpcLaunchRock").invoke(0, x, z);
                    }
                    catch (e) {
                        console.log("[rock] RpcLaunchRock error: " + e);
                    }
                    if (!isMaster && VolcanicRockClass != null) {
                        try {
                            const prefab = er.field("eruptionRockPrefab").value;
                            if (prefab != null && !prefab.isNull()) {
                                const rock = Object.method("Instantiate", 1).invoke(prefab);
                                if (rock != null) {
                                    const rt = rock.method("get_transform").invoke();
                                    rt.method("set_position").invoke(pos);
                                    const fwd = rightHandTransform.method("get_forward").invoke();
                                    const end = Vector3.method("op_Addition", 2).invoke(pos, Vector3.method("op_Multiply", 2).invoke(fwd, 40));
                                    rock.method("Launch").invoke(pos, end, 6.0);
                                }
                            }
                        }
                        catch (e) { }
                    }
                }
                catch (e) { }
            });
        }
        let placeAnywhereOn = false;
        let stealGunOn = false;
        let stealTimer = 0;
        const BPM = classOf(EnverGardenGame, "Enver.Features.BwahPropertyManager");
        const spoofOwnerRef = (ownerUserId) => {
            try {
                if (ownerUserId == null || ownerUserId.isNull == null)
                    return;
                const local = PhotonNetwork.method("get_LocalPlayer").invoke();
                const uid = local.method("get_UserId").invoke().toString();
                ownerUserId.value = Il2Cpp.string(uid);
            }
            catch (e) { }
        };
        if (BPM != null) {
            try {
                const hPlot = BPM.method("IsInsideOtherPlayersPlotXZ");
                hPlot.implementation = function (worldPos, userId) {
                    if (placeAnywhereOn)
                        return false;
                    return this.method("IsInsideOtherPlayersPlotXZ").invoke(worldPos, userId);
                };
            }
            catch (e) { }
            try {
                const hBanned = BPM.method("IsInBannedZone");
                hBanned.implementation = function (worldPos) {
                    if (placeAnywhereOn)
                        return false;
                    return this.method("IsInBannedZone").invoke(worldPos);
                };
            }
            catch (e) { }
            try {
                const hAny = BPM.method("IsInsideAnyProperty");
                hAny.implementation = function (worldPos, ownerUserId) {
                    if (placeAnywhereOn) {
                        spoofOwnerRef(ownerUserId);
                        return true;
                    }
                    return this.method("IsInsideAnyProperty").invoke(worldPos, ownerUserId);
                };
            }
            catch (e) { }
            try {
                const hOwner = BPM.method("TryGetPropertyOwnerAt");
                hOwner.implementation = function (worldPos, ownerUserId) {
                    if (placeAnywhereOn) {
                        spoofOwnerRef(ownerUserId);
                        return true;
                    }
                    return this.method("TryGetPropertyOwnerAt").invoke(worldPos, ownerUserId);
                };
            }
            catch (e) { }
        }
        function stealAllPlants() {
            const now = Date.now();
            if (now - stealTimer < 300)
                return;
            stealTimer = now;
            Il2Cpp.perform(() => {
                try {
                    const UDM = classOf(EnverGardenGame, "Enver.Features.UserDataManager");
                    if (UDM == null)
                        return;
                    const trans = UDM.method("get_Transaction").invoke();
                    if (trans == null || trans.isNull())
                        return;
                    let stolen = 0, mine = 0, failed = 0;
                    for (const viewName of [
                        "Enver.Features.PlantView",
                        "Enver.Features.CropView"
                    ]) {
                        const vc = classOf(EnverGardenGame, viewName);
                        if (vc == null)
                            continue;
                        const views = Object.method("FindObjectsOfType").inflate(vc).invoke();
                        for (let i = 0; i < views.length; i++) {
                            try {
                                const model = views.get(i).method("get_Model").invoke();
                                if (model == null || model.isNull())
                                    continue;
                                let isMine = false;
                                try {
                                    isMine = model.method("get_IsMine").invoke();
                                }
                                catch (e) { }
                                if (isMine) {
                                    mine++;
                                    continue;
                                }
                                try {
                                    model.method("set_IsMine").invoke(true);
                                }
                                catch (e) { }
                                const ok = trans.method("MoveToInventory").invoke(model);
                                if (ok)
                                    stolen++;
                                else
                                    failed++;
                            }
                            catch (e) { }
                        }
                    }
                    try {
                        UDM.method("Save").invoke(true);
                    }
                    catch (e) { }
                    console.log("[steal] moved " + stolen + " to inventory, " + failed + " failed, skipped " + mine + " already-mine");
                }
                catch (e) { }
            });
        }
        const NPE = classOf(EnverGardenGame, "Enver.Features.WavyEvent.NetworkedPlayerEffect");
        if (NPE != null) {
            try {
                const rk = NPE.method("RpcKickPlayer");
                rk.implementation = function () { };
            }
            catch (e) { }
            try {
                const rf = NPE.method("RpcApplyFling");
                rf.implementation = function (dir, f, u) { };
            }
            catch (e) { }
        }
        const localActorNumber = () => {
            try {
                return PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
            }
            catch (e) {
                return -1;
            }
        };
        const localRigRoot = () => {
            try {
                let t = getTransform(GorillaTagger);
                while (t != null) {
                    try {
                        const p = t.method("get_parent").invoke();
                        if (p == null || p.isNull())
                            break;
                        t = p;
                    }
                    catch (e) {
                        break;
                    }
                }
                if (t != null && !t.isNull())
                    return t.method("get_gameObject").invoke();
            }
            catch (e) { }
            return null;
        };
        const npeIsLocal = (e, localActor, myRoot) => {
            try {
                const pv = e.method("get_PhotonView").invoke();
                if (pv != null && !pv.isNull()) {
                    try {
                        if (pv.method("get_IsMine").invoke())
                            return true;
                    }
                    catch (err) { }
                    try {
                        const owner = pv.method("get_Owner").invoke();
                        if (owner != null && !owner.isNull()) {
                            const a = owner.method("get_ActorNumber").invoke();
                            if (a != null && a == localActor)
                                return true;
                        }
                    }
                    catch (err) { }
                }
            }
            catch (err) { }
            if (myRoot != null) {
                try {
                    let t = e.method("get_transform").invoke();
                    while (t != null) {
                        try {
                            const p = t.method("get_parent").invoke();
                            if (p == null || p.isNull())
                                break;
                            t = p;
                        }
                        catch (e2) {
                            break;
                        }
                    }
                    if (t != null && !t.isNull()) {
                        const go = t.method("get_gameObject").invoke();
                        if (go != null && !go.isNull()) {
                            try {
                                if (go.handle.equals(myRoot.handle))
                                    return true;
                            }
                            catch (e2) { }
                        }
                    }
                }
                catch (err) { }
            }
            return false;
        };
        function kickAllPlayers() {
            Il2Cpp.perform(() => {
                try {
                    if (NPE == null)
                        return;
                    const effects = Object.method("FindObjectsOfType").inflate(NPE).invoke();
                    const localActor = localActorNumber();
                    const myRoot = localRigRoot();
                    let kicked = 0;
                    for (let i = 0; i < effects.length; i++) {
                        try {
                            const e = effects.get(i);
                            if (npeIsLocal(e, localActor, myRoot))
                                continue;
                            e.method("KickPlayer").invoke();
                            kicked++;
                        }
                        catch (err) { }
                    }
                    console.log("[kick] kicked " + kicked + " players");
                }
                catch (e) { }
            });
        }
        function kickAimedPlayer() {
            Il2Cpp.perform(() => {
                try {
                    if (NPE == null)
                        return;
                    const StartPosition = getTransform(rightHandTransform).method("get_position").invoke();
                    const Direction = rightHandTransform.method("get_forward").invoke();
                    const layerMask = -3180559;
                    const hits = Physics.method("RaycastAll", 4).invoke(StartPosition, Direction, 512.0, layerMask);
                    let hitGo = null;
                    for (const hit of hits) {
                        try {
                            const c = hit.method("get_collider").invoke();
                            if (c == null || c.isNull()) continue;
                            const go = c.method("get_gameObject").invoke();
                            if (go != null && !go.isNull()) { hitGo = go; break; }
                        } catch (e2) { }
                    }
                    if (hitGo == null) { console.log("[kickgun] no target hit"); return; }
                    let hitPoint = null;
                    try { hitPoint = hits.get(0).method("get_point").invoke(); } catch (e3) { }
                    const effects = Object.method("FindObjectsOfType").inflate(NPE).invoke();
                    const localActor = localActorNumber();
                    const myRoot = localRigRoot();
                    let targetNpe = null;
                    let bestDist = Infinity;
                    for (let i = 0; i < effects.length; i++) {
                        const e = effects.get(i);
                        if (npeIsLocal(e, localActor, myRoot)) continue;
                        let ePos = null;
                        try { ePos = e.method("get_transform").invoke().method("get_position").invoke(); } catch (e4) { continue; }
                        if (ePos == null) continue;
                        let d = Infinity;
                        if (hitPoint != null) {
                            try { d = Vector3.method("Distance").invoke(hitPoint, ePos); } catch (e5) { }
                        }
                        else {
                            try { d = Vector3.method("Distance").invoke(ePos, StartPosition); } catch (e5) { }
                        }
                        if (d < bestDist) { bestDist = d; targetNpe = e; }
                    }
                    if (targetNpe == null) { console.log("[kickgun] no player matched aim"); return; }
                    console.log("[kickgun] target dist=" + bestDist);
                    let targetPlayer = null;
                    let targetView = null;
                    try {
                        targetView = targetNpe.method("get_PhotonView").invoke();
                        if (targetView != null && !targetView.isNull()) {
                            try { targetPlayer = targetView.method("get_Owner").invoke(); } catch (e7) { }
                        }
                    } catch (e7) { }
                    let tries = [];
                    try {
                        PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke());
                        tries.push("SetMasterClient");
                    } catch (e8) { }
                    try { targetNpe.method("RpcKickPlayer").invoke(); tries.push("NPE.RpcKickPlayer"); } catch (e9) { }
                    if (targetPlayer != null && !targetPlayer.isNull()) {
                        try { PhotonNetwork.method("KickPlayer").invoke(targetPlayer); tries.push("PhotonNetwork.KickPlayer"); } catch (e10) { }
                        try { PhotonNetwork.method("CloseConnection").invoke(targetPlayer); tries.push("PhotonNetwork.CloseConnection"); } catch (e11) { }
                        try { targetPlayer.method("KickPlayer").invoke(); tries.push("Player.KickPlayer"); } catch (e12) { }
                    }
                    try { sendAllOutgoing(); } catch (e13) { }
                    console.log("[kickgun] attempted: " + tries.join(", "));
                }
                catch (e) { console.log("[kickgun] error: " + e); }
            });
        }
        function flingAllPlayers() {
            Il2Cpp.perform(() => {
                try {
                    if (NPE == null)
                        return;
                    const effects = Object.method("FindObjectsOfType").inflate(NPE).invoke();
                    const localActor = localActorNumber();
                    const myRoot = localRigRoot();
                    const myPos = getTransform(GorillaTagger).method("get_position").invoke();
                    let flung = 0;
                    for (let i = 0; i < effects.length; i++) {
                        try {
                            const e = effects.get(i);
                            if (npeIsLocal(e, localActor, myRoot))
                                continue;
                            const theirPos = e.method("get_transform").invoke().method("get_position").invoke();
                            let away = Vector3.method("op_Subtraction", 2).invoke(theirPos, myPos);
                            try {
                                const n = away.method("get_normalized").invoke();
                                if (n != null)
                                    away = n;
                            }
                            catch (err) { }
                            let dir = away;
                            try {
                                const up = Vector3.field("upVector").value;
                                dir = Vector3.method("op_Addition", 2).invoke(away, Vector3.method("op_Multiply", 2).invoke(up, 0.6));
                            }
                            catch (err) { }
                            e.method("ApplyFling").invoke(dir, 18.0, 8.0);
                            flung++;
                        }
                        catch (err) { }
                    }
                    console.log("[fling] flung " + flung + " players");
                }
                catch (e) { }
            });
        }
        function giveMoneyAll() {
            Il2Cpp.perform(() => {
                try {
                    const UDM = classOf(EnverGardenGame, "Enver.Features.UserDataManager");
                    if (UDM == null)
                        return;
                    const soft = UDM.method("get_SoftCurrency").invoke();
                    if (soft == null || soft.isNull()) {
                        console.log("[money] no soft currency handler");
                        return;
                    }
                    const amount = 2147483647;
                    try {
                        soft.method("set_Current").invoke(amount);
                    }
                    catch (e) { }
                    try {
                        UDM.method("Save").invoke(true);
                    }
                    catch (e) { }
                    try {
                        const Cuc = classOf(EnverGardenGame, "BwahVR.Controllers.CurrencyUIController");
                        if (Cuc != null) {
                            const cs = Object.method("FindObjectsOfType").inflate(Cuc).invoke();
                            for (let i = 0; i < cs.length; i++) {
                                try {
                                    cs.get(i).method("UpdateCurrencyDisplays").invoke(0, amount);
                                }
                                catch (e) { }
                            }
                        }
                    }
                    catch (e) { }
                    console.log("[money] set BwahCoins to " + amount);
                }
                catch (e) { }
            });
        }
        function scanCosmetics() {
            Il2Cpp.perform(() => {
                try {
                    const CC = classOf(AssemblyCSharp, "Assembly-CSharp.Cosmetics");
                    if (CC == null) { console.log("[Cosmetics] Cosmetics class not found"); return; }
                    const instances = Object.method("FindObjectsOfType").inflate(CC).invoke();
                    console.log("[Cosmetics] Found " + instances.length + " cosmetics");
                    for (let i = 0; i < instances.length; i++) {
                        const c = instances.get(i);
                        try {
                            const name = c.field("CosmeticName").value;
                            const type = c.field("CosmeticType").value;
                            const tag = c.field("HandTag").value;
                            console.log("[Cosmetics]   [" + type + "] " + name + " (tag=" + tag + ")");
                        } catch (e) { }
                    }
                } catch (e) { console.log("[Cosmetics] scan error: " + e); }
            });
        }
        function equipCosmetic(slot) {
            Il2Cpp.perform(() => {
                try {
                    const PVRC = classOf(AssemblyCSharp, "Assembly-CSharp.PhotonVRCosmeticsChanger");
                    if (PVRC == null) { console.log("[Cosmetics] PhotonVRCosmeticsChanger not found"); return; }
                    const CC = classOf(AssemblyCSharp, "Assembly-CSharp.Cosmetics");
                    const instances = Object.method("FindObjectsOfType").inflate(PVRC).invoke();
                    if (instances.length === 0) { console.log("[Cosmetics] No PhotonVRCosmeticsChanger instances"); return; }
                    const changer = instances.get(0);
                    const cosmeticsList = changer.field("Cosmetics").value;
                    if (cosmeticsList == null || cosmeticsList.isNull()) { console.log("[Cosmetics] Cosmetics field null"); return; }
                    let found = null;
                    const count = cosmeticsList.method("get_Count").invoke();
                    for (let i = 0; i < count; i++) {
                        const item = cosmeticsList.method("get_Item").invoke(i);
                        if (item == null || item.isNull()) continue;
                        try {
                            const ct = item.field("CosmeticType").value.toString();
                            if (ct.toLowerCase() === slot.toLowerCase()) { found = item; break; }
                        } catch (e) { }
                    }
                    if (found == null) { console.log("[Cosmetics] No cosmetic found for slot: " + slot); return; }
                    try {
                        changer.method("ChangeCosmetics").invoke(found);
                        console.log("[Cosmetics] Equipped " + slot + " via ChangeCosmetics");
                    } catch (e1) {
                        try {
                            const name = found.field("CosmeticName").value.toString();
                            changer.method("ChangeCosmetics").invoke(Il2Cpp.string(name));
                            console.log("[Cosmetics] Equipped " + slot + " via ChangeCosmetics(string)");
                        } catch (e2) {
                            try {
                                changer.method("ChangeCosmetics").invoke();
                                console.log("[Cosmetics] Called ChangeCosmetics() no args");
                            } catch (e3) { console.log("[Cosmetics] equip error for " + slot + ": " + e3); }
                        }
                    }
                } catch (e) { console.log("[Cosmetics] equip error: " + e); }
            });
        }
        function spawnRigGun() {
            Il2Cpp.perform(() => {
                try {
                    const pos = getTransform(rightHandTransform).method("get_position").invoke();
                    const fwd = rightHandTransform.method("get_forward").invoke();
                    const spawn = Vector3.method("op_Addition", 2).invoke(pos, Vector3.method("op_Multiply", 2).invoke(fwd, 0.5));
                    const names = ["BaboonNetworkPlayer", "Player", "NetworkPlayer", "BaboonPlayer"];
                    let spawned = false;
                    for (const nm of names) {
                        try {
                            const go = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(nm), spawn, identityQuaternion, 0, null);
                            if (go != null && !go.isNull()) { spawned = true; console.log("[riggun] spawned " + nm); break; }
                        } catch (e) { }
                    }
                    if (!spawned) console.log("[riggun] no prefab matched, tried: " + names.join(", "));
                    sendAllOutgoing();
                } catch (e) { console.log("[riggun] error: " + e); }
            });
        }
        function dumpCosmeticClasses() {
            Il2Cpp.perform(() => {
                try {
                    const targets = ["PhotonVRCosmeticsChanger", "Cosmetics", "Cosmetic", "BetterCosmetics", "ChangeHeadCosmetic", "ChangeBodyCosmetic", "ChangeFaceCosmetic", "ChangeLeftCosmetic", "ChangeRightCosmetic", "ChangeWingsCosmetic", "ChangeBadgeCosmetic", "ChangeTagCosmetic", "PlayFabCosmeticHelper", "item"];
                    const assemblies = Il2Cpp.domain.assemblies;
                    for (let a = 0; a < assemblies.length; a++) {
                        let image;
                        try { image = assemblies[a].image; } catch (e) { continue; }
                        if (assemblies[a].name !== "Assembly-CSharp") continue;
                        for (const klass of image.classes) {
                            const name = klass.name || "";
                            if (targets.indexOf(name) === -1) continue;
                            let methods = [];
                            for (const m of klass.methods) {
                                try { methods.push(m.name); } catch (e) { }
                            }
                            let fields = [];
                            for (const fld of klass.fields) {
                                try { fields.push(fld.name); } catch (e) { }
                            }
                            console.log("[CosMgr] CLASS " + name);
                            console.log("[CosMgr]   methods: " + methods.join(", "));
                            console.log("[CosMgr]   fields:  " + fields.join(", "));
                        }
                    }
                    console.log("[Dump] done");
                } catch (e) { console.log("[Dump] error: " + e); }
            });
        }
        function dumpPrefabNames() {
            Il2Cpp.perform(() => {
                try {
                    let found = 0;
                    let resImage = null;
                    try { resImage = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image; } catch (e) { }
                    if (resImage != null) {
                        let resources = null;
                        try { resources = resImage.class("UnityEngine.Resources"); } catch (e) { }
                        if (resources == null) { for (const k of resImage.classes) { if (k.name === "Resources") { resources = k; break; } } }
                        if (resources != null) {
                            try {
                                const all = resources.method("GetAllObjects").invoke();
                                if (all != null) {
                                    for (let i = 0; i < all.length; i++) {
                                        try {
                                            const o = all.get(i);
                                            const n = o.method("get_name").invoke();
                                            const nm = n != null ? n : "";
                                            if (nm.length > 0) { console.log("[Asset] " + nm); found++; }
                                        } catch (e2) { }
                                    }
                                }
                            } catch (e3) { console.log("[Asset] GetAllObjects error: " + e3); }
                        }
                    }
                    console.log("[Asset] total asset names found: " + found);
                } catch (e) { console.log("[Asset] error: " + e); }
            });
        }
        function openStaffRoom() {
            Il2Cpp.perform(() => {
                try {
                    const SAC = classOf(EnverGardenGame, "Enver.Features.StaffManagement.StaffAccessController");
                    if (SAC == null) return;
                    try { SAC.field("_isStaffMember").value = true; } catch (e) { }
                    const controllers = Object.method("FindObjectsOfType").inflate(SAC).invoke();
                    for (let i = 0; i < controllers.length; i++) {
                        const c = controllers.get(i);
                        try { c.method("SetStaffDoors").invoke(); } catch (e) { }
                        try { c.method("GetInventoryStaffItems").invoke(); } catch (e) { }
                        try { c.method("SetStaffMember").invoke(true); } catch (e) { }
                    }
                } catch (e) { }
            });
        }
        function addGold() {
            Il2Cpp.perform(() => {
                try {
                    const UDM = classOf(EnverGardenGame, "Enver.Features.UserDataManager");
                    if (UDM == null) return;
                    const add = (prefix) => {
                        try {
                            const handler = UDM.method(prefix + "SoftCurrency").invoke();
                            if (handler == null || handler.isNull()) return;
                            let cur = 0;
                            try { cur = handler.method("get_Current").invoke(); } catch (e) { }
                            try { handler.method("set_Current").invoke(cur + 100); } catch (e) { }
                        } catch (e) { }
                    };
                    add("get_");
                    try {
                        const hard = UDM.method("get_HardCurrency").invoke();
                        if (hard != null && !hard.isNull()) {
                            let cur = 0;
                            try { cur = hard.method("get_Current").invoke(); } catch (e) { }
                            try { hard.method("set_Current").invoke(cur + 100); } catch (e) { }
                        }
                    } catch (e) { }
                    try { UDM.method("Save").invoke(true); } catch (e) { }
                    try {
                        const Cuc = classOf(EnverGardenGame, "BwahVR.Controllers.CurrencyUIController");
                        if (Cuc != null) {
                            const cs = Object.method("FindObjectsOfType").inflate(Cuc).invoke();
                            for (let i = 0; i < cs.length; i++) {
                                try {
                                    const ucc = cs.get(i);
                                    let nc = 0;
                                    try { nc = ucc.method("get_Current").invoke(); } catch (e) { }
                                    try { ucc.method("UpdateCurrencyDisplays").invoke(0, nc + 100); } catch (e) { }
                                    try { ucc.method("UpdateCurrencyDisplays").invoke(1, nc + 100); } catch (e) { }
                                } catch (e) { }
                            }
                        }
                    } catch (e) { }
                    console.log("[money] +100 gold");
                }
                catch (e) { }
            });
        }
        function jetskiOnTrigger() {
            if (!rightTrigger)
                return;
            spawnJetSki();
        }
        function nukeOnTrigger() {
            if (!rightTrigger)
                return;
            spawnNuke();
        }
        try {
            const VS = classOf(EnverGardenGame, "Enver.Features.Rideable.Shop.VRVehicleSpawner");
            if (VS != null) {
                const dv = VS.method("DespawnActiveVehicle");
                dv.implementation = function () { };
            }
        }
        catch (e) { }
        function spawnJetSki() {
            Il2Cpp.perform(() => {
                try {
                    const VSV = classOf(EnverGardenGame, "Enver.Features.Rideable.Shop.VehicleShopView");
                    if (VSV == null)
                        return;
                    const views = Object.method("FindObjectsOfType").inflate(VSV).invoke();
                    let view = null;
                    for (let v = 0; v < views.length; v++) {
                        try {
                            view = views.get(v);
                            if (view != null && !view.isNull())
                                break;
                        }
                        catch (e) { }
                    }
                    if (view == null)
                        return;
                    const list = view.field("vehicles").value;
                    if (list == null || list.isNull())
                        return;
                    const count = list.method("get_Count").invoke();
                    let entry = null;
                    for (let i = 0; i < count; i++) {
                        try {
                            const en = list.method("get_Item").invoke(i);
                            if (en == null || en.isNull())
                                continue;
                            let nmStr = "";
                            try {
                                const nm = en.field("displayName").value;
                                if (nm != null)
                                    nmStr = String(nm.toString()).toLowerCase();
                            }
                            catch (e) { }
                            let skuStr = "";
                            try {
                                const sku = en.field("vehicleSku").value;
                                if (sku != null)
                                    skuStr = String(sku.toString()).toLowerCase();
                            }
                            catch (e) { }
                            if (nmStr.indexOf("jet") >= 0 || nmStr.indexOf("ski") >= 0 || skuStr.indexOf("jet") >= 0 || skuStr.indexOf("ski") >= 0) {
                                entry = en;
                                break;
                            }
                            if (entry == null)
                                entry = en;
                        }
                        catch (e) { }
                    }
                    if (entry == null)
                        return;
                    const prefab = entry.field("vehiclePrefab").value;
                    if (prefab == null || prefab.isNull())
                        return;
                    const spawner = view.field("vehicleSpawner").value;
                    if (spawner == null || spawner.isNull())
                        return;
                    const pos = rightHandTransform.method("get_position").invoke();
                    const rot = rightHandTransform.method("get_rotation").invoke();
                    try {
                        spawner.method("SetVehicle").invoke(prefab, entry.field("vehicleHintPrefab").value, entry.field("spawnType").value, entry.field("portSpawnPoints").value, entry.field("waterSurface").value, entry.field("spawnSurfaceLayers").value, entry.field("requiredSurfaceTag").value);
                    }
                    catch (e) { }
                    try {
                        spawner.method("SpawnVehicleAt").invoke(pos, rot);
                    }
                    catch (e) { }
                }
                catch (e) { }
            });
        }
        function spawnNuke() {
            Il2Cpp.perform(() => {
                try {
                    const NukeModClass = classOf(EnverGardenGame, "Enver.Features.GameMods.PlayerMods.NukeMod");
                    const PMM = classOf(EnverGardenGame, "Enver.Features.GameMods.PlayerMods.PlayerModManager");
                    if (NukeModClass == null)
                        return;
                    const pos = rightHandTransform.method("get_position").invoke();
                    const rot = rightHandTransform.method("get_rotation").invoke();
                    let nukeMod = null;
                    if (PMM != null) {
                        try {
                            const mgr = PMM.method("get_Instance").invoke();
                            if (mgr != null && !mgr.isNull()) {
                                const modsData = mgr.field("modsData").value;
                                if (modsData != null && !modsData.isNull()) {
                                    const mods = modsData.method("GetAvailableMods").invoke();
                                    if (mods != null && !mods.isNull()) {
                                        const cnt = mods.method("get_Count").invoke();
                                        for (let i = 0; i < cnt; i++) {
                                            try {
                                                const m = mods.method("get_Item").invoke(i);
                                                if (m == null || m.isNull())
                                                    continue;
                                                let tn = "";
                                                let tfn = "";
                                                try {
                                                    tn = String(m.type.name);
                                                }
                                                catch (e) { }
                                                try {
                                                    tfn = String(m.type.fullName);
                                                }
                                                catch (e) { }
                                                if (tn == "NukeMod" || tfn == "Enver.Features.GameMods.PlayerMods.NukeMod") {
                                                    nukeMod = m;
                                                    break;
                                                }
                                            }
                                            catch (e) { }
                                        }
                                    }
                                }
                            }
                        }
                        catch (e) { }
                    }
                    if (nukeMod == null) {
                        try {
                            const found = Object.method("FindObjectsOfType").inflate(NukeModClass).invoke();
                            if (found != null && found.length > 0)
                                nukeMod = found.get(0);
                        }
                        catch (e) { }
                        if (nukeMod == null) {
                            try {
                                const all = Resources.method("FindObjectsOfTypeAll").inflate(NukeModClass).invoke();
                                if (all != null && all.length > 0)
                                    nukeMod = all.get(0);
                            }
                            catch (e) { }
                        }
                    }
                    const prefab = nukeMod != null ? nukeMod.field("nukePrefab").value : null;
                    let prefabName = null;
                    if (nukeMod != null) {
                        try {
                            prefabName = nukeMod.field("nukePrefabName").value;
                            if (prefabName != null)
                                prefabName = prefabName.toString();
                        }
                        catch (e) { }
                    }
                    if (prefabName == null && prefab != null && !prefab.isNull()) {
                        try {
                            prefabName = prefab.method("get_gameObject").invoke().method("get_name").invoke().toString();
                        }
                        catch (e) { }
                    }
                    if (prefabName != null) {
                        try {
                            const netGo = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(prefabName), pos, rot, 0, null);
                            if (netGo != null && !netGo.isNull())
                                return;
                        }
                        catch (e) { }
                    }
                    let activated = false;
                    if (nukeMod != null) {
                        try {
                            const nowTime = Time.method("get_time").invoke();
                            try {
                                nukeMod.field("_nextAllowedTime").value = nowTime - 1;
                            }
                            catch (e) { }
                            try {
                                nukeMod.field("isActive").value = false;
                            }
                            catch (e) { }
                            try {
                                nukeMod.field("spawnPosition").value = pos;
                            }
                            catch (e) { }
                        }
                        catch (e) { }
                        try {
                            nukeMod.method("ActivateMod").invoke();
                            try {
                                activated = nukeMod.field("isActive").value;
                            }
                            catch (e) {
                                activated = true;
                            }
                        }
                        catch (e) {
                            activated = false;
                        }
                    }
                    if (!activated && prefab != null && !prefab.isNull()) {
                        try {
                            const go = Object.method("Instantiate", 1).invoke(prefab);
                            if (go != null) {
                                const gt = go.method("get_transform").invoke();
                                gt.method("set_position").invoke(pos);
                                gt.method("set_rotation").invoke(rot);
                            }
                        }
                        catch (e) { }
                    }
                }
                catch (e) { }
            });
        }
        function crashJetskis() {
            Il2Cpp.perform(() => {
                try {
                    const VSV = classOf(EnverGardenGame, "Enver.Features.Rideable.Shop.VehicleShopView");
                    if (VSV == null)
                        return;
                    const views = Object.method("FindObjectsOfType").inflate(VSV).invoke();
                    let view = null;
                    for (let v = 0; v < views.length; v++) {
                        try {
                            view = views.get(v);
                            if (view != null && !view.isNull())
                                break;
                        }
                        catch (e) { }
                    }
                    if (view == null)
                        return;
                    const list = view.field("vehicles").value;
                    if (list == null || list.isNull())
                        return;
                    const count = list.method("get_Count").invoke();
                    let entry = null;
                    for (let i = 0; i < count; i++) {
                        try {
                            const en = list.method("get_Item").invoke(i);
                            if (en == null || en.isNull())
                                continue;
                            let nmStr = "";
                            try {
                                const nm = en.field("displayName").value;
                                if (nm != null)
                                    nmStr = String(nm.toString()).toLowerCase();
                            }
                            catch (e) { }
                            if (nmStr.indexOf("jet") >= 0 || nmStr.indexOf("ski") >= 0) {
                                entry = en;
                                break;
                            }
                            if (entry == null)
                                entry = en;
                        }
                        catch (e) { }
                    }
                    if (entry == null)
                        return;
                    const spawner = view.field("vehicleSpawner").value;
                    if (spawner == null || spawner.isNull())
                        return;
                    try {
                        spawner.method("SetVehicle").invoke(entry.field("vehiclePrefab").value, entry.field("vehicleHintPrefab").value, entry.field("spawnType").value, entry.field("portSpawnPoints").value, entry.field("waterSurface").value, entry.field("spawnSurfaceLayers").value, entry.field("requiredSurfaceTag").value);
                    }
                    catch (e) {
                        return;
                    }
                    const pos = Vector3.method("op_Addition", 2).invoke(Vector3.method("op_Multiply", 2).invoke(Vector3.field("rightVector").value, 100), Vector3.method("op_Multiply", 2).invoke(Vector3.field("upVector").value, -100));
                    const rot = identityQuaternion;
                    for (let i = 0; i < 555; i++) {
                        try {
                            spawner.method("SpawnVehicleAt").invoke(pos, rot);
                        }
                        catch (e) { }
                    }
                    const JetSkiClass = classOf(EnverGardenGame, "Enver.Features.Rideable.JetSkiController");
                    if (JetSkiClass != null) {
                        try {
                            const jetskis = Object.method("FindObjectsOfType").inflate(JetSkiClass).invoke();
                            for (let i = 0; i < jetskis.length; i++) {
                                try {
                                    const go = jetskis.get(i).method("get_gameObject").invoke();
                                    if (go != null && !go.isNull())
                                        Object.method("Destroy", 1).invoke(go);
                                }
                                catch (e) { }
                            }
                        }
                        catch (e) { }
                    }
                }
                catch (e) { }
            });
        }
        const buttons = [
            [
                new ButtonInfo({
                    buttonText: "Settings",
                    method: () => currentCategory = 2,
                    isTogglable: false,
                    toolTip: "Opens the settings category."
                }),
                new ButtonInfo({
                    buttonText: "Movement",
                    method: () => currentCategory = 3,
                    isTogglable: false,
                    toolTip: "Opens the movement category."
                }),
                new ButtonInfo({
                    buttonText: "Name Mods",
                    method: () => currentCategory = 4,
                    isTogglable: false,
                    toolTip: "Opens the name mods category."
                }),
                new ButtonInfo({
                    buttonText: "OP Mods",
                    method: () => currentCategory = 5,
                    isTogglable: false,
                    toolTip: "Opens the OP mods category."
                }),
                new ButtonInfo({
                    buttonText: "Credits",
                    method: () => currentCategory = 7,
                    isTogglable: false,
                    toolTip: "Opens the credits category."
                }),
                new ButtonInfo({
                    buttonText: "Cosmetics",
                    method: () => currentCategory = 6,
                    isTogglable: false,
                    toolTip: "Opens the cosmetics category."
                }),
                new ButtonInfo({
                    buttonText: "Spawn",
                    method: () => currentCategory = 8,
                    isTogglable: false,
                    toolTip: "Opens the spawn category."
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Disconnect",
                }),
                new ButtonInfo({
                    buttonText: "PreviousPage",
                    method: () => {
                        const lastPage = Math.ceil(buttons[currentCategory].length / 8) - 1;
                        currentPage--;
                        if (currentPage < 0)
                            currentPage = lastPage;
                    },
                    isTogglable: false
                }),
                new ButtonInfo({
                    buttonText: "NextPage",
                    method: () => {
                        const lastPage = Math.ceil(buttons[currentCategory].length / 8) - 1;
                        currentPage++;
                        currentPage %= lastPage + 1;
                    },
                    isTogglable: false
                })
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit Settings",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "Freeze Player in Menu [BROKEN]",
                    enabled: false,
                    method: () => {
                        if (menu != null) {
                            if (closePosition == null) {
                                closePosition = getTransform(rigidbody).method("get_position").invoke();
                            }
                            else {
                                getTransform(rigidbody).method("set_position").invoke(closePosition);
                                rigidbody.method("set_velocity").invoke(zeroVector);
                            }
                        }
                        else {
                            closePosition = null;
                        }
                    },
                    toolTip: "Freezes your character while in the menu."
                }),
                new ButtonInfo({
                    buttonText: "Dump Cosmetics Classes",
                    method: () => dumpCosmeticClasses(),
                    isTogglable: false,
                    toolTip: "Logs all potential cosmetic/hat/staff class names from the live game"
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit Movement Mods",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "Fly [B]",
                    method: () => {
                        Fly();
                    },
                }),
                new ButtonInfo({
                    buttonText: "Noclip [Hold RT]",
                    method: () => NoclipHold(),
                    toolTip: "Hold the right trigger to noclip your whole body"
                }),
                new ButtonInfo({
                    buttonText: "Long Arms",
                    method: () => toggleLongArms(),
                    isTogglable: false,
                    toolTip: "Toggle long arms"
                }),
                new ButtonInfo({
                    buttonText: "Platforms [G]",
                    method: () => Platforms(),
                    toolTip: "Hold grips to spawn platforms under your hands"
                }),
                new ButtonInfo({
                    buttonText: "Toggle Gravity",
                    method: () => {
                        const current = rigidbody.method("get_useGravity").invoke();
                        rigidbody.method("set_useGravity").invoke(!current);
                    },
                }),
                new ButtonInfo({
                    buttonText: "Bwah Scaler [T]",
                    toolTip: "Right trigger to grow, left trigger to shrink your player scale",
                    method: () => {
                        if (rightTrigger) {
                            applyPlayerScale(Math.min(playerScale + 0.05, 10.0));
                        }
                        else if (leftTrigger) {
                            applyPlayerScale(Math.max(playerScale - 0.05, 0.1));
                        }
                    },
                    isTogglable: true,
                }),
                new ButtonInfo({
                    buttonText: "Reset Scale",
                    method: () => applyPlayerScale(1.0),
                    isTogglable: false,
                    toolTip: "Resets your player scale to default"
                }),
                new ButtonInfo({
                    buttonText: "TP to Gun",
                    method: () => {
                        try {
                            if (rightGrab) {
                                const gunData = renderGun();
                                const gunPointer = gunData.gunPointer;
                                if (rightTrigger && !perviousTeleportKey) {
                                    const pos = getTransform(gunPointer).method("get_position").invoke();
                                    const px = pos.field("x").value;
                                    const py = pos.field("y").value;
                                    const pz = pos.field("z").value;
                                    try {
                                        rigidbody.method("set_velocity").invoke(zeroVector);
                                    }
                                    catch (e) { }
                                    try {
                                        rigidbody.method("set_position").invoke(pos);
                                    }
                                    catch (e) { }
                                    try {
                                        getTransform(GTPlayer.method("get_gameObject").invoke()).method("set_position").invoke(pos);
                                    }
                                    catch (e) { }
                                    try {
                                        getTransform(headCollider).method("set_position").invoke([px, py + 0.5, pz]);
                                    }
                                    catch (e) { }
                                }
                            }
                            else {
                                hideGun();
                            }
                        }
                        catch (e) { }
                        perviousTeleportKey = rightTrigger;
                    },
                    isTogglable: true,
                    enableMethod: () => {
                        try {
                            if (GunPointer != null)
                                GunPointer.method("SetActive").invoke(true);
                        }
                        catch (e) { }
                    },
                    disableMethod: () => {
                        hideGun();
                    },
                    toolTip: "Hold right grip, then pull the trigger to teleport to wherever you're aiming"
                }),
                new ButtonInfo({
                    buttonText: "Smooth Turn",
                    enableMethod: () => { smoothTurnEnabled = true; snapTurnEnabled = false; },
                    disableMethod: () => { smoothTurnEnabled = false; },
                    isTogglable: true,
                    toolTip: "Right thumbstick smoothly rotates your view"
                }),
                new ButtonInfo({
                    buttonText: "Snap Turn",
                    enableMethod: () => { snapTurnEnabled = true; smoothTurnEnabled = false; },
                    disableMethod: () => { snapTurnEnabled = false; },
                    isTogglable: true,
                    toolTip: "Right thumbstick snaps you in 30 degree increments"
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit Name Mods",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "set nexon is tuff name",
                    method: () => {
                        Il2Cpp.perform(() => {
                            try {
                                SetName("<size=15><color=purple>NEXON IS TUFF");
                            }
                            catch (e) { }
                        });
                    },
                    isTogglable: true,
                    toolTip: "Set your name to nexon is tuff"
                }),
                new ButtonInfo({
                    buttonText: "Gay name",
                    method: () => {
                        Il2Cpp.perform(() => {
                            try {
                                SetName("<size=300><color=#FFFFFF>im GAY!!!");
                            }
                            catch (e) {
                            }
                        });
                    },
                    isTogglable: true,
                    toolTip: "Become Gay"
                }),
                new ButtonInfo({
                    buttonText: "Owner Name",
                    method: () => {
                        Il2Cpp.perform(() => {
                            try {
                                SetName("<size=30><color=white>NEXON<size=20><color=yellow>[OWNER]</color></size>");
                            }
                            catch (e) {
                            }
                        });
                    },
                    isTogglable: true,
                    toolTip: "Become the OWNER"
                }),
                new ButtonInfo({
                    buttonText: "Dev Name",
                    method: () => {
                        Il2Cpp.perform(() => {
                            try {
                                SetName("<size=23><color=white>NEXON</color></size>\n<size=20><color=blue>[DEVELOPER]</color></size>");
                            }
                            catch (e) {
                            }
                        });
                    },
                    isTogglable: true,
                    toolTip: "Become a Dev"
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit OP mods",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "Giant Mod",
                    method: () => togglePlayerMod("GiantMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in Giant mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Mini Mod",
                    method: () => togglePlayerMod("MiniMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in Mini mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Invisibility Mod",
                    method: () => togglePlayerMod("InvisibilityMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in Invisibility mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "No Clip Fly Mod",
                    method: () => togglePlayerMod("NoClipFlyMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in No Clip Fly mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Low Gravity Mod",
                    method: () => togglePlayerMod("LowGravityMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in Low Gravity mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Long Legs Mod",
                    method: () => togglePlayerMod("LongLegsMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in Long Legs mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Nuke Mod [Built-in]",
                    method: () => togglePlayerMod("NukeMod"),
                    isTogglable: false,
                    toolTip: "Toggles the game's built-in Nuke mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Randomize Weather Mod",
                    method: () => togglePlayerMod("RandomizeWeatherMod"),
                    isTogglable: false,
                    toolTip: "Toggles the built-in Randomize Weather mod directly via PlayerModManager, bypassing the Mod Menu IAP gate"
                }),
                new ButtonInfo({
                    buttonText: "Open Staff [Room]",
                    method: () => openStaffRoom(),
                    isTogglable: false,
                    toolTip: "Mark you as a staff member and opens/disappears the staff room doors"
                }),
                new ButtonInfo({
                    buttonText: "All Staff Items",
                    method: () => {
                        Il2Cpp.perform(() => {
                            try {
                                const SPI = classOf(EnverGardenGame, "Enver.Features.StaffManagement.StaffPreviewItem");
                                const SAC = classOf(EnverGardenGame, "Enver.Features.StaffManagement.StaffAccessController");
                                if (SAC == null)
                                    return;
                                try {
                                    SAC.field("_isStaffMember").value = true;
                                }
                                catch (e) { }
                                const controllers = Object.method("FindObjectsOfType").inflate(SAC).invoke();
                                for (let i = 0; i < controllers.length; i++) {
                                    const c = controllers.get(i);
                                    try {
                                        c.method("SetStaffDoors").invoke();
                                    }
                                    catch (e) { }
                                    try {
                                        c.method("GetInventoryStaffItems").invoke();
                                    }
                                    catch (e) { }
                                }
                                for (let i = 0; i < controllers.length; i++) {
                                    const c = controllers.get(i);
                                    const data = c.field("staffItemData").value;
                                    if (data == null || data.isNull())
                                        continue;
                                    const count = data.method("get_Count").invoke();
                                    for (let j = 0; j < count; j++) {
                                        try {
                                            const item = data.method("get_Item").invoke(j);
                                            const spawnPoint = item.field("itemSpawnPoint").value;
                                            let spawnPos = null, spawnRot = null;
                                            if (spawnPoint != null && !spawnPoint.isNull()) {
                                                spawnPos = spawnPoint.method("get_position").invoke();
                                                spawnRot = spawnPoint.method("get_rotation").invoke();
                                            }
                                            else {
                                                spawnPos = rightHandTransform.method("get_position").invoke();
                                                spawnRot = rightHandTransform.method("get_rotation").invoke();
                                            }
                                            const previewPrefab = item.field("itemPreviewPrefab").value;
                                            if (SPI != null && previewPrefab != null && !previewPrefab.isNull()) {
                                                const preview = Object.method("Instantiate", 1).invoke(previewPrefab);
                                                if (preview != null) {
                                                    preview.method("Initialize").invoke(item);
                                                    const t = preview.method("get_transform").invoke();
                                                    t.method("set_position").invoke(spawnPos);
                                                    t.method("set_rotation").invoke(spawnRot);
                                                }
                                            }
                                            else {
                                                const staffPrefab = item.field("staffItem").value;
                                                if (staffPrefab != null && !staffPrefab.isNull()) {
                                                    const spawned = Object.method("Instantiate", 1).invoke(staffPrefab);
                                                    if (spawned != null) {
                                                        zeroStaffCooldown(spawned);
                                                        const t = spawned.method("get_transform").invoke();
                                                        t.method("set_position").invoke(spawnPos);
                                                        t.method("set_rotation").invoke(spawnRot);
                                                    }
                                                }
                                            }
                                        }
                                        catch (e) { }
                                    }
                                }
                            }
                            catch (e) { }
                        });
                    },
                    isTogglable: false,
                    toolTip: "Unlock staff, open doors, spawn every staff item in the staff room"
                }),
                new ButtonInfo({
                    buttonText: "No cooldown on staff gun / rocket launcher",
                    enableMethod: () => { staffNoCooldown = true; },
                    disableMethod: () => { staffNoCooldown = false; },
                    isTogglable: true,
                    toolTip: "Remove the fire delay on staff weapons"
                }),
                new ButtonInfo({
                    buttonText: "Rapid fire",
                    enableMethod: () => { staffRapidFire = true; },
                    disableMethod: () => { staffRapidFire = false; },
                    isTogglable: true,
                    toolTip: "Hold your grip down to loop-fire the staff weapon"
                }),
                new ButtonInfo({
                    buttonText: "Kick all",
                    method: () => kickAllPlayers(),
                    isTogglable: false,
                    toolTip: "Kicks every player using the staff kick effect"
                }),
                new ButtonInfo({
                    buttonText: "Fling all",
                    method: () => flingAllPlayers(),
                    isTogglable: false,
                    toolTip: "Flings every player away using the staff gun effect"
                }),
                new ButtonInfo({
                    buttonText: "Max Money",
                    method: () => giveMoneyAll(),
                    isTogglable: false,
                    toolTip: "Set your BwahCoins to the 32-bit max (2,147,483,647)"
                }),
                new ButtonInfo({
                    buttonText: "Add Gold [100]",
                    method: () => addGold(),
                    isTogglable: false,
                    toolTip: "Adds 100 gold (BwahCoins) each click"
                }),
                new ButtonInfo({
                    buttonText: "Spawn Jetski [T]",
                    method: () => jetskiOnTrigger(),
                    isTogglable: true,
                    toolTip: "Spawns the jetski near you through the game spawner"
                }),
                new ButtonInfo({
                    buttonText: "Spawn nuke",
                    method: () => nukeOnTrigger(),
                    isTogglable: true,
                    toolTip: "Drops a nuke at your right hand using NukeMod (no cooldown)"
                }),
                new ButtonInfo({
                    buttonText: "fling gun",
                    method: () => {
                        try {
                            if (rightGrab) {
                                renderGun();
                                if (rightTrigger && !wasRightTriggerFling) {
                                    flingAllPlayers();
                                }
                            }
                            else {
                                hideGun();
                            }
                        }
                        catch (e) { }
                        wasRightTriggerFling = rightTrigger;
                    },
                    isTogglable: true,
                    enableMethod: () => {
                        try {
                            if (GunPointer != null)
                                GunPointer.method("SetActive").invoke(true);
                        }
                        catch (e) { }
                    },
                    disableMethod: () => {
                        hideGun();
                    },
                    toolTip: "Hold right grip, then pull the trigger to fling all players"
                }),
                new ButtonInfo({
                    buttonText: "kick gun",
                    method: () => {
                        try {
                            if (rightGrab) {
                                renderGun();
                                if (rightTrigger && !wasRightTriggerKick) {
                                    kickAimedPlayer();
                                }
                            }
                            else {
                                hideGun();
                            }
                        }
                        catch (e) { }
                        wasRightTriggerKick = rightTrigger;
                    },
                    isTogglable: true,
                    enableMethod: () => {
                        try {
                            if (GunPointer != null)
                                GunPointer.method("SetActive").invoke(true);
                        }
                        catch (e) { }
                    },
                    disableMethod: () => {
                        hideGun();
                    },
                    toolTip: "Hold right grip, then pull the trigger to kick all players"
                }),
                new ButtonInfo({
                    buttonText: "rig gun",
                    method: () => {
                        try {
                            if (rightGrab) {
                                renderGun();
                                if (rightTrigger && !wasRightTriggerRig) {
                                    spawnRigGun();
                                }
                            }
                            else {
                                hideGun();
                            }
                        }
                        catch (e) { }
                        wasRightTriggerRig = rightTrigger;
                    },
                    isTogglable: true,
                    enableMethod: () => {
                        try {
                            if (GunPointer != null)
                                GunPointer.method("SetActive").invoke(true);
                        }
                        catch (e) { }
                    },
                    disableMethod: () => {
                        hideGun();
                    },
                    toolTip: "Hold right grip, then pull the trigger to spawn a rig"
                }),
                new ButtonInfo({
                    buttonText: "Crasher",
                    method: () => crashJetskis(),
                    isTogglable: false,
                    toolTip: "Spawns 400 jetskis at (100, -100, 0) then destroys them all"
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit Cosmetics",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "Scan Cosmetics",
                    method: () => scanCosmetics(),
                    isTogglable: false,
                    toolTip: "Logs all cosmetic names currently loaded in the game"
                }),
                new ButtonInfo({
                    buttonText: "Equip Head",
                    method: () => equipCosmetic("Head"),
                    isTogglable: false,
                    toolTip: "Equip a head cosmetic"
                }),
                new ButtonInfo({
                    buttonText: "Equip Body",
                    method: () => equipCosmetic("Body"),
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "Equip Face",
                    method: () => equipCosmetic("Face"),
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "Equip Left Hand",
                    method: () => equipCosmetic("Left"),
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "Equip Right Hand",
                    method: () => equipCosmetic("Right"),
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "Equip Wings",
                    method: () => equipCosmetic("Wings"),
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "Equip Badge",
                    method: () => equipCosmetic("Badge"),
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "Equip Tag",
                    method: () => equipCosmetic("Tag"),
                    isTogglable: false,
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit Credits",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "exploding - menu",
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "nexon - adding more mods",
                    isTogglable: false,
                }),
                new ButtonInfo({
                    buttonText: "ii - template",
                    isTogglable: false,
                }),
            ],
            [
                new ButtonInfo({
                    buttonText: "Exit Spawn",
                    method: () => currentCategory = 0,
                    isTogglable: false,
                    toolTip: "Returns you back to the main category."
                }),
                new ButtonInfo({
                    buttonText: "Dump Asset Names",
                    method: () => dumpPrefabNames(),
                    isTogglable: false,
                    toolTip: "Logs all loaded asset/prefab names so we can find dead bodies and items"
                }),
                new ButtonInfo({
                    buttonText: "Spawn Rocket",
                    method: () => spawnItem("Rocket"),
                    isTogglable: false,
                    toolTip: "Spawns a rocket in front of you"
                }),
                new ButtonInfo({
                    buttonText: "Spawn Ball",
                    method: () => spawnItem("Ball"),
                    isTogglable: false,
                    toolTip: "Spawns a ball in front of you"
                }),
                new ButtonInfo({
                    buttonText: "Spawn Banana",
                    method: () => spawnItem("Banana"),
                    isTogglable: false,
                    toolTip: "Spawns a banana in front of you"
                }),
                new ButtonInfo({
                    buttonText: "Spawn Dead Body",
                    method: () => spawnItem("DeadBody"),
                    isTogglable: false,
                    toolTip: "Spawns a dead body in front of you (prefab name may vary)"
                }),
            ],
        ];
        let buttonMap = new Map();
        buttons.flat().forEach(button => {
            buttonMap.set(button.buttonText, button);
        });
        function getIndex(buttonText) {
            return buttonMap.get(buttonText);
        }
        function clickButton(name) {
            const _time = Time.method("get_time").invoke();
            if (_time < buttonClickDelay) return;
            const button = getIndex(name);
            if (button) {
                buttonClickDelay = _time + 0.2;
                if (button.isTogglable) {
                    button.enabled = !button.enabled;
                    if (button?.enabled) {
                        button.enableMethod?.();
                    }
                    else {
                        button?.disableMethod?.();
                    }
                }
                else {
                    button?.method?.();
                }
                reloadMenu();
                playButtonSound();
            }
        }
        let menuHoverState = {};
        let lastMenuCheckTime = 0.0;
        function menuButtonHit(mb, refLocal) {
            try {
                const t = getTransform(mb.obj);
                const lp = t.method("get_localPosition").invoke();
                const ls = t.method("get_localScale").invoke();
                const lx = lp.field("x").value, ly = lp.field("y").value, lz = lp.field("z").value;
                const hx = Math.abs(ls.field("x").value) * 0.5 + 0.04;
                const hy = Math.abs(ls.field("y").value) * 0.5 + 0.04;
                const hz = Math.abs(ls.field("z").value) * 0.5 + 0.04;
                const rx = refLocal.field("x").value, ry = refLocal.field("y").value, rz = refLocal.field("z").value;
                return Math.abs(rx - lx) <= hx && Math.abs(ry - ly) <= hy && Math.abs(rz - lz) <= hz;
            } catch (_) { return false; }
        }
        function updateMenuButtons() {
            if (menu == null || reference == null) return;
            try {
                const now = Time.method("get_time").invoke();
                if (now - lastMenuCheckTime < 0.03) return;
                lastMenuCheckTime = now;
                const menuTransform = getTransform(menu);
                const refPos = getTransform(reference).method("get_position").invoke();
                const refLocal = menuTransform.method("InverseTransformPoint", 1).invoke(refPos);
                for (const mb of menuButtonList) {
                    try {
                        const inside = menuButtonHit(mb, refLocal);
                        const wasInside = menuHoverState[mb.name] === true;
                        if (inside && !wasInside) {
                            clickButton(mb.name);
                        }
                        menuHoverState[mb.name] = inside;
                    } catch (_) {}
                }
            } catch (_) {}
        }
        const Update = GTPlayer.method("Update");
        Update.implementation = function () {
            updateMenuButtons();
            OVRInputHandler.update();
            leftPrimary = OVRInputHandler.leftControllerPrimaryButton;
            leftSecondary = OVRInputHandler.leftControllerSecondaryButton;
            rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
            rightSecondary = OVRInputHandler.rightControllerSecondaryButton;
            leftGrab = OVRInputHandler.leftGrab;
            rightGrab = OVRInputHandler.rightGrab;
            leftTrigger = OVRInputHandler.leftControllerTriggerButton;
            rightTrigger = OVRInputHandler.rightControllerTriggerButton;
            deltaTime = Time.method("get_deltaTime").invoke();
            time = Time.method("get_time").invoke();
            updateAnimatedMenuText();
            if (leftPrimary) {
                if (menu == null) {
                    renderMenu();
                }
                else {
                    recenterMenu();
                }
            }
            else {
                if (menu != null) {
                    Destroy(menu);
                    menu = null;
                    animatedMenuTexts.length = 0;
                }
            }
            if (menu == null) {
                if (reference != null) {
                    Destroy(reference);
                    reference = null;
                }
            }
            else {
                if (reference == null) {
                    renderReference();
                }
            }
            buttons.flat()
                .filter(button => button.enabled)
                .forEach(button => {
                if (button.method) {
                    try {
                        button.method();
                    }
                    catch (error) {
                        console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
                        console.error('Error stack:', error.stack);
                        console.error('Button object:', button);
                        if (error.stack) {
                            const stackLines = error.stack.split('\n');
                            if (stackLines.length > 1) {
                                console.error('Error occurred at:', stackLines[1].trim());
                            }
                        }
                    }
                }
            });
            // Smooth / Snap turn (right thumbstick)
            try {
                if (smoothTurnEnabled && !snapTurnEnabled) {
                    const stickX = OVRInputHandler.rightThumbstickX;
                    if (Math.abs(stickX) > 0.1) {
                        const rot = Quaternion.method("Euler").invoke(0.0, -stickX * turnSpeed * deltaTime, 0.0);
                        const headPos = getTransform(headCollider).method("get_position").invoke();
                        const playerTransform = getTransform(GorillaTagger);
                        const playerPos = playerTransform.method("get_position").invoke();
                        const offset = Vector3.method("op_Subtraction", 2).invoke(playerPos, headPos);
                        const rotated = Quaternion.method("op_Multiply", 2).invoke(rot, offset);
                        playerTransform.method("set_position").invoke(Vector3.method("op_Addition", 2).invoke(headPos, rotated));
                        playerTransform.method("set_rotation").invoke(Quaternion.method("op_Multiply", 2).invoke(rot, playerTransform.method("get_rotation").invoke()));
                    }
                }
                if (snapTurnEnabled) {
                    const stickX = OVRInputHandler.rightThumbstickX;
                    const snapActive = Math.abs(stickX) > snapTurnThreshold;
                    const now = Time.method("get_time").invoke();
                    if (snapActive && !wasSnapTurnActive && now > snapTurnCooldown) {
                        const dir = stickX > 0 ? 1.0 : -1.0;
                        const rot = Quaternion.method("Euler").invoke(0.0, -dir * snapTurnAngle, 0.0);
                        const headPos = getTransform(headCollider).method("get_position").invoke();
                        const playerTransform = getTransform(GorillaTagger);
                        const playerPos = playerTransform.method("get_position").invoke();
                        const offset = Vector3.method("op_Subtraction", 2).invoke(playerPos, headPos);
                        const rotated = Quaternion.method("op_Multiply", 2).invoke(rot, offset);
                        playerTransform.method("set_position").invoke(Vector3.method("op_Addition", 2).invoke(headPos, rotated));
                        playerTransform.method("set_rotation").invoke(Quaternion.method("op_Multiply", 2).invoke(rot, playerTransform.method("get_rotation").invoke()));
                        snapTurnCooldown = now + 0.3;
                    }
                    wasSnapTurnActive = snapActive;
                }
            }
            catch (_) { }
            return Update.invoke();
        };
        console.log(`

     ••╹   ┏┓     • ┓  ┳┳┓      
     ┓┓ ┏  ┗┓╋┓┏┏┓┓┏┫  ┃┃┃┏┓┏┓┓┏
     ┗┗ ┛  ┗┛┗┗┻┣┛┗┗┻  ┛ ┗┗ ┛┗┗┻
                ┛               
    ii's Stupid Menu Quest 1.1.0
    Compiled ${new Date().toISOString()}
`);
    }
    catch (e) {
        console.log("[!] mod init error: " + e);
    }
}, "main");
