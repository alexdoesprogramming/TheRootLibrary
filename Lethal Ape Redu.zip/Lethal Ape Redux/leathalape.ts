declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const UnityEngine: any;

let rigidbody = null

let thingforfling = null

let hue = 0;

let lastRunTime = 0;
const destroycooldown = 250;
const rgbcooldown = 100;

let invisible = false

let buttonClickDelay = 0.0;
let menu = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let previousGhostKey = false;
let previousInvisKey = false;
let previousNoclipKey = false;
let perviousTeleportKey = false;

let closePosition = null;
let tagGunDelay = 0.0;

let leftPlatform = null;
let rightPlatform = null;

let lvT = null;
let rvT = null;

let bgColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
let bgColor2: [number, number, number, number] = [9.0, 9.0, 9.0, 1.0];
let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];

let buttonColor: [number, number, number, number] = [0.1, 0.1, 0.1, 1.0];
let buttonPressedColor: [number, number, number, number] = [0.7, 0.7, 0.7, 1.0];

let menuName: string = "J0ker Client";
let themeIndex = 0;

class XRInputHandler {
    private InputDevices: any;
    private tryGetFeatureValue: any;
    private buttonStates: Map<string, boolean>;

    constructor() {
        this.InputDevices = Il2Cpp.domain
            .assembly("UnityEngine.XRModule")
            .image.class("UnityEngine.XR.InputDevices");

        this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
        this.buttonStates = new Map();
    }

    update() {
        this.updateControllerStates(1); // left controller
        this.updateControllerStates(2); // right controller
    }

    private updateControllerStates(controllerId: number) {
        const features = [
            "PrimaryButton",
            "SecondaryButton",
            "GripButton",
            "TriggerButton",
            "MenuButton"
        ];

        features.forEach(feature => {
            const key = `${controllerId}_${feature}`;
            this.buttonStates.set(key, this.getButtonState(controllerId, feature));
        });
    }

    private getButtonState(deviceId: number, featureName: string): boolean {
        try {
            const valuePtr = Il2Cpp.alloc(1);
            const feature = Il2Cpp.string(featureName);
            const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
            if (success) {
                return valuePtr.readU8() !== 0;
            }
        } catch (_) { }
        return false;
    }

    isButtonPressed(controllerId: number, feature: string): boolean {
        return this.buttonStates.get(`${controllerId}_${feature}`) || false;
    }

    // Renamed getters
    get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
    get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
    get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
    get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
    get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
    get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
    get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
    get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
    get controllerMenuButton(): boolean {
        return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
    }
}

Il2Cpp.perform(() => {
    const images = {
        "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
        "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
        "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
        "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
        "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
        "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
        "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
        "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image
    };
    const AssemblyCSharp = images["Assembly-CSharp"];
    const UnityEngineCore = images["UnityEngine.CoreModule"];
    const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
    const UnityEngineUI = images["UnityEngine.UI"];
    const UnityEngineUIModule = images["UnityEngine.UIModule"];
    const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
    const PhotonUnityNetworking = images["PhotonUnityNetworking"];
    const LethalApeGame = Il2Cpp.domain.assembly("LethalApe.Game").image;
    const GTPlayerClass = LethalApeGame.class("LethalApeR.Locomotion.Player");
    const GTPlayer = GTPlayerClass.method("get_Instance").invoke();
    const GorillaReportButton = LethalApeGame.class("LethalApeR.ModMenuButton");
    const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
    const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
    const Object = UnityEngineCore.class("UnityEngine.Object");
    const Component = UnityEngineCore.class("UnityEngine.Component");
    const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
    const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
    const Time = UnityEngineCore.class("UnityEngine.Time");
    const Resources = UnityEngineCore.class("UnityEngine.Resources");
    const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
    const Shader = UnityEngineCore.class("UnityEngine.Shader");
    const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
    const MeshCollider = UnityEnginePhysics.class("UnityEngine.Collider");
    const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
    const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
    const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
    const Physics = UnityEnginePhysics.class("UnityEngine.Physics");
    const PhotonVRManager = LethalApeGame.class("LethalApeR.Networking.PhotonVRManager");

    const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
    const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
    const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
    const Text = UnityEngineUI.class("UnityEngine.UI.Text");
    const Font = UnityEngineTextRendering.class("UnityEngine.Font");
    const GorillaTagger = GTPlayer

    for (const field of GTPlayerClass.fields) {
        if (field.type.name == "UnityEngine.Rigidbody") {
            rigidbody = GTPlayer.field(field.name).value
        }
    }

    const UberShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Unlit"));
    const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

    const zeroVector = Vector3.field("zeroVector").value;
    const oneVector = Vector3.field("oneVector").value;
    const identityQuaternion = Quaternion.field("identityQuaternion").value;

    const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
    const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
    const headCollider = GorillaTagger.field("headCollider").value;

    const OVRInputHandler = new XRInputHandler();

    const arial = Resources
        .method("GetBuiltinResource", 1)
        .inflate(Font)
        .invoke(Il2Cpp.string("Arial.ttf"));

    function Destroy(object) {
        Object.method("Destroy", 1).invoke(object);
    }

    function getComponent(obj: any, type) {
        return obj.method("GetComponent", 1).inflate(type).invoke();
    }

    function addComponent(obj: any, type) {
        return obj.method("AddComponent", 1).inflate(type).invoke();
    }

    function getComponentInParent(obj: any, type) {
        return obj.method("GetComponentInParent", 0).inflate(type).invoke();
    }

    function getTransform(obj: any) {
        return obj.method("get_transform").invoke();
    }

    function sendAllOutgoing() {
        PhotonNetwork.method("SendAllOutgoingCommands").invoke();
    }

    function spawnPrefabAtGun(prefabName: string) {
        if (rightGrab) {
            const gunData = renderGun();
            const gunPointer = gunData.gunPointer;

            if (rightTrigger) {
                const pos = getTransform(gunPointer).method("get_position").invoke()
                PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string(prefabName), pos, identityQuaternion, 0, NULL);
                sendAllOutgoing()
            };;
        }
    }

    function renderMenuText(
        canvasObject,
        text: string = "",
        color: [number, number, number, number] = [1, 1, 1, 1],
        pos = zeroVector,
        size = oneVector
    ) {
        const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
        getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
        title.method("set_text").invoke(Il2Cpp.string(text));
        title.method("set_font").invoke(arial);
        title.method("set_fontSize").invoke(1);
        title.method("set_color").invoke(color);
        title.method("set_fontStyle").invoke(3);
        title.method("set_alignment").invoke(4);
        title.method("set_resizeTextForBestFit").invoke(true);
        title.method("set_resizeTextMinSize").invoke(0);

        const rectTransform = getComponent(title, RectTransform);
        rectTransform.method("set_sizeDelta").invoke(size);
        rectTransform.method("set_position").invoke(pos);
        rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0))
    }
    function createObject(
        pos = zeroVector,
        rot = identityQuaternion,
        scale = oneVector,
        primitiveType: number = 3,
        colorArr: [number, number, number, number] = [1, 1, 1, 1],
        parent = null
    ) {
        const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);

        const renderer = getComponent(obj, Renderer);

        if (colorArr[3] == 0) {
            renderer.method("set_enabled").invoke(false);
        } else {
            const material = renderer.method("get_material").invoke();
            material.method("set_shader").invoke(UberShader);
            material.method("set_color").invoke(colorArr);
        }

        const transform = getTransform(obj);
        if (parent != null) {
            transform.method("SetParent", 2).invoke(parent, false);
        }

        transform.method("set_position").invoke(pos);
        transform.method("set_rotation").invoke(rot);
        transform.method("set_localScale").invoke(scale);

        return obj;
    }

    //#region Mods

    //#region  Movement

    function GhostRig() {
        if (rightSecondary) {
            const now = Date.now();
            if (now - lastRunTime >= 500) {
                lastRunTime = now;
                ghost = !ghost;
                const getManagerMethod = PhotonVRManager.method("get_Manager");
                const managerInstance = getManagerMethod.invoke();
                const localPlayer = managerInstance.field("LocalPlayer").value;
                localPlayer.method("set_enabled").invoke(!ghost);
            }
        }
    }

    let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
    const platColors: [number, number, number, number][] = [
        [0.0, 0.0, 0.0, 1.0],       // Black
        [9.0, 9.0, 9.0, 1.0],       // Bright white
        [9.0, 0.0, 0.0, 1.0],       // Red
        [0.0, 9.0, 0.0, 1.0],       // Green
        [0.0, 0.0, 9.0, 1.0],       // Blue
        [5.0, 5.0, 0.0, 1.0],       // Yellow
        [9.0, 0.5, 9.0, 1.0],       // Magenta
    ];
    let platL = null;
    let platR = null;
    let plater = 0;

    function Platforms() {
        if (leftGrab) {
            if (platL == null) {
                const handTransform = leftHandTransform;
                platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platL != null) {
                Destroy(platL);
                platL = null;
            }
        }

        if (rightGrab) {
            if (platR == null) {
                const handTransform = rightHandTransform;
                platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platR != null) {
                Destroy(platR);
                platR = null;
            }
        }
    }

    //#endregion

    const equippedCosmetics: { [type: string]: string } = {};

    function SetCosmetic(cosmetic: string, type: string) {
        try {
            const managerClass = LethalApeGame.class(
                "LethalApeR.Networking.PhotonVRManager"
            );

            const manager = managerClass
                .method("get_Manager")
                .invoke();

            if (manager == null) {
                console.log("[Cosmetics] PhotonVRManager is null");
                return;
            }

            const setCosmetic = managerClass.method("SetCosmetic", 3);

            // Unequip the previous cosmetic in this slot/type
            const previous = equippedCosmetics[type];

            if (previous && previous !== cosmetic) {
                console.log(
                    `[Cosmetics] Unequipping ${previous} from ${type}`
                );

                setCosmetic.invoke(
                    Il2Cpp.string(type),
                    Il2Cpp.string(previous),
                    false
                );
            }

            // Equip the new cosmetic
            console.log(
                `[Cosmetics] Equipping ${cosmetic} (${type})`
            );

            setCosmetic.invoke(
                Il2Cpp.string(type),
                Il2Cpp.string(cosmetic),
                true
            );

            // Remember what is equipped in this type
            equippedCosmetics[type] = cosmetic;

        } catch (e) {
            console.log("[Cosmetics] SetCosmetic error:", e);
        }
    }


    function dumpClass(className: string) {
        try {
            const klass = LethalApeGame.class(className);

            console.log(`========== ${className} ==========`);

            console.log("---------- Fields ----------");
            for (const field of klass.fields) {
                try {
                    console.log(
                        `[Field] ${field.name} | type=${field.type.name}`
                    );
                } catch (e) {
                    console.log(`[Field] ${field.name} | type=<unknown>`);
                }
            }

            console.log("---------- Methods ----------");
            for (const method of klass.methods) {
                try {
                    console.log(
                        `[Method] ${method.name} | params=${method.parameterCount}`
                    );

                    for (let i = 0; i < method.parameterCount; i++) {
                        try {
                            console.log(
                                `    [Param ${i}] ${method.parameter(i).name} | type=${method.parameter(i).type.name}`
                            );
                        } catch (_) {
                            console.log(`    [Param ${i}] <unknown>`);
                        }
                    }
                } catch (e) {
                    console.log(`[Method] <error dumping method>`);
                }
            }

            console.log(`========== END ${className} ==========`);

            return klass;
        } catch (e) {
            console.log(`[Class Dumper] Failed to dump ${className}: ${e}`);
            return null;
        }
    }

    function dumpMethodParams(klass: any, methodName: string) {
        try {
            const method = klass.method(methodName);

            console.log(`========== ${methodName} ==========`);

            console.log(`Parameter count: ${method.parameterCount}`);

            for (let i = 0; i < method.parameterCount; i++) {
                try {
                    const p = method.parameters[i];

                    console.log(
                        `[Param ${i}] name=${p.name} | type=${p.type.name}`
                    );
                } catch (e) {
                    console.log(`[Param ${i}] failed: ${e}`);
                }
            }

            console.log("================================");
        } catch (e) {
            console.log(`[Dump] Failed: ${e}`);
        }
    }

    //#endregion

    function renderMenu() {
        menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
        Destroy(getComponent(menu, BoxCollider))

        const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu))
        Destroy(getComponent(menuBackground, BoxCollider))

        const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu))
        Destroy(getComponent(menuBackground2, BoxCollider))

        const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
        const canvas = addComponent(canvasObject, Canvas);
        Destroy(getComponent(canvasObject, BoxCollider))

        const canvasScaler = addComponent(canvasObject, CanvasScaler);
        addComponent(canvasObject, GraphicRaycaster);
        canvas.method("set_renderMode").invoke(2);
        canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);

        const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));

        addComponent(homeButton, GorillaReportButton);
        getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);

        renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

        const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));

        addComponent(leaveButton, GorillaReportButton);
        getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);

        renderMenuText(canvasObject, "Leave", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);

        renderMenuText(canvasObject, menuName + ` - Page [ <color=cyan>${currentPage + 1} </color>]`, textColor, [0.11, 0, 0.155], [1, .1]);
        {
            const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));


            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, "<", textColor, [0.11, 0.17, 0], [1, 0.1]);
        }

        {
            const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));


            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, ">", textColor, [0.11, -0.17, 0], [1, 0.1]);
        }

        let i = 0;
        const targetMods = buttons[currentCategory]
            .slice(currentPage * 6)
            .slice(0, 6);

        targetMods.forEach((buttonData) => {
            const button = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
            const button2 = createObject([0.105, 0, 0.11 - (i * 0.04)], identityQuaternion, [0.08, 0.82, 0.09], 3, bgColor2, getTransform(menu));
            button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));

            addComponent(button, GorillaReportButton);
            getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.11 - (i * 0.04)], [1, 0.1]);
            updateButtonColor(button, buttonData);
            i++;
        });

        recenterMenu();
    }

    function renderReference() {
        reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, rightHandTransform)
        referenceCollider = getComponent(reference, Collider);

        getTransform(reference).method("set_localPosition").invoke([0.01, -0.05, 0.1]);
        reference.method("set_layer").invoke(2);
        addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
    }

    let gunLocked = false;
    let lockTarget = null;
    let GunPointer = null;
    let GunLine = null;
    function renderGun(overrideLayerMask = null) {
        const StartPosition = rightHandTransform.method("get_position").invoke();
        const Direction = rightHandTransform.method("get_forward").invoke();

        const DirectionDivided = Vector3.method("op_Division").invoke(Direction, 4);
        const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionDivided);

        const layerMask = overrideLayerMask || -3180559;

        const hits = Physics.method("RaycastAll", 4).invoke(
            rayStartPosition,  // origin (Vector3)
            Direction,         // direction (Vector3)
            512.0,            // maxDistance (float)
            layerMask         // layerMask (int)
        );

        let finalDistance = Infinity;
        let finalRay = null;
        for (const hit of hits) {
            const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
            if (distance < finalDistance) {
                finalRay = hit;
                finalDistance = distance;
            }
        }

        let EndPosition;
        if (gunLocked) {
            EndPosition = getTransform(lockTarget).method("get_position").invoke();
        } else {
            EndPosition = finalRay.method("get_point").invoke();
        }

        if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
            const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
            EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
        }

        if (GunPointer == null) {
            GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
        }

        GunPointer.method("SetActive").invoke(true);
        const pointerTransform = getTransform(GunPointer);
        pointerTransform.method("set_position").invoke(EndPosition);

        const PointerRenderer = getComponent(GunPointer, Renderer);
        const material = PointerRenderer.method("get_material").invoke();

        material.method("set_shader").invoke(TextShader);

        const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
        material.method("set_color").invoke(pointerColor);

        const collider = getComponent(GunPointer, Collider);
        if (collider != null) {
            Destroy(collider);
        }


        if (rightTrigger || gunLocked) {
            const Step = 10;
            for (let i = 1; i < (Step - 1); i++) {
                const t = i / (Step - 1);
                const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);

                const randomValue = Math.random();
                let offset = zeroVector;

                if (randomValue > 0.75) {
                    offset = [
                        (Math.random() * 0.2) - 0.1,
                        (Math.random() * 0.2) - 0.1,
                        (Math.random() * 0.2) - 0.1
                    ];
                }

            }

        }

        return { ray: finalRay, gunPointer: GunPointer };
    }

    function recenterMenu() {
        let menuPosition = leftHandTransform.method("get_position").invoke();
        let menuRotation = leftHandTransform.method("get_rotation").invoke();

        menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0))

        const menuTransform = getTransform(menu);
        menuTransform.method("set_position").invoke(menuPosition);
        menuTransform.method("set_rotation").invoke(menuRotation);
    }

    function reloadMenu() {
        if (menu != null) {
            Object.method("Destroy", 1).invoke(menu);
            menu = null;
        }
    }

    function updateButtonColor(button, buttonData) {
        const RendererClass = Il2Cpp.domain
            .assembly("UnityEngine.CoreModule")
            .image
            .class("UnityEngine.Renderer");

        const renderer = getComponent(button, RendererClass);
        if (!renderer) {
            return;
        }

        const material = renderer.method("get_material").invoke();
        material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
    }

    function toggleColliders(enabled) {
        const meshColliders = Object.method("FindObjectsOfType").inflate(MeshCollider).invoke();

        for (let i = 0; i < meshColliders.length; i++) {
            const meshCollider = meshColliders.get(i);
            meshCollider.method("set_enabled").invoke(enabled);
        }
    }

    interface ButtonInfoConfig {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn?: boolean;
        enabled?: boolean;
    }

    class ButtonInfo {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn: boolean;
        enabled: boolean;

        constructor(config: ButtonInfoConfig) {
            this.buttonText = config.buttonText;
            this.method = config.method;
            this.enableMethod = config.enableMethod;
            this.disableMethod = config.disableMethod;
            this.keepOn = config.keepOn ?? true;
            this.enabled = config.enabled ?? false;
        }
    }

    function hsl2Rgb(h, s, l) {
        s /= 100;
        l /= 100;
        const k = (n) => (n + h / 30) % 12;
        const a = s * Math.min(l, 1 - l);
        const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
        return [
            Math.round(255 * f(0)),
            Math.round(255 * f(8)),
            Math.round(255 * f(4))
        ];
    }

    function getSmoothColor() {
        hue = (hue + 0.5) % 360;
        const [r, g, b] = hsl2Rgb(hue, 100, 50);
        return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
    }

    let currentCategory = 0;
    let currentPage = 0;
    let flyspeed = 5.0;
    let ghost = false;

    const buttons: ButtonInfo[][] = [
        [ // Home
            new ButtonInfo({
                buttonText: "Settings",
                method: () => currentCategory = 2,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Movement Mods",
                method: () => currentCategory = 3,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Misc Mods",
                method: () => currentCategory = 4,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Rig Mods",
                method: () => currentCategory = 5,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Cosmetic Mods",
                method: () => currentCategory = 6,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "OP Mods",
                method: () => currentCategory = 7,
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Prefabs",
                method: () => { currentCategory = 8, currentPage = 0 },
                keepOn: false,
            }),
        ],
        [ // Menu Buttons
            new ButtonInfo({
                buttonText: "Leave",
                method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Home",
                method: () => {
                    currentCategory = 0
                    currentPage = 0
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PreviousPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

                    currentPage--;
                    if (currentPage < 0)
                        currentPage = lastPage;
                },
                keepOn: false
            }),
            new ButtonInfo({
                buttonText: "NextPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;

                    currentPage++;
                    currentPage %= lastPage + 1;
                },
                keepOn: false
            })
        ],
        [ // Settings
            new ButtonInfo({
                buttonText: `Fly Speed+`,
                method: () => {
                    flyspeed += 1;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: `Fly Speed-`,
                method: () => {
                    flyspeed -= 1;
                    reloadMenu();
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Platform Color",
                method: () => {
                    plater = (plater + 1) % platColors.length;
                    platColor = platColors[plater];
                },
                keepOn: false
            }),
        ],
        [ // Movement Mods
            new ButtonInfo({
                buttonText: "Fly [B]",
                method: () => {
                    if (rightSecondary) {
                        const leftRightVector = rightHandTransform.method("get_forward").invoke();
                        const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, flyspeed);
                        rigidbody.method("set_linearVelocity").invoke(leftForce);
                    }
                },
            }),

            new ButtonInfo({
                buttonText: "Platforms [G]",
                method: () => {
                    Platforms()
                },
            }),

            new ButtonInfo({
                buttonText: "No Clip",
                method: () => {
                    if (rightTrigger && !previousNoclipKey) {
                        toggleColliders(false);
                    }

                    if (!rightTrigger && previousNoclipKey) {
                        toggleColliders(true);
                    }

                    previousNoclipKey = rightTrigger;
                },
            }),

            new ButtonInfo({
                buttonText: "Zero Gravity",
                method: () => {
                    const force = Vector3.method("op_Multiply", 2).invoke(Vector3.field("upVector").value, (deltaTime * (6.66 / deltaTime)));
                    rigidbody.method("AddForce", 2).invoke(force, 5);
                },
            }),

            new ButtonInfo({
                buttonText: "Invert Gravity",
                method: () => {
                    const force = Vector3.method("op_Multiply", 2).invoke(Vector3.field("upVector").value, (deltaTime * (9.81 / deltaTime)));
                    rigidbody.method("AddForce", 2).invoke(force, 5);
                },
            }),

            new ButtonInfo({
                buttonText: "High Gravity",
                method: () => {
                    const force = Vector3.method("op_Multiply", 2).invoke(Vector3.field("downVector").value, (deltaTime * (7.77 / deltaTime)));
                    rigidbody.method("AddForce", 2).invoke(force, 5);
                },
            }),
        ],
        [ // Misc Mods
            new ButtonInfo({
                buttonText: "Open Staff",
                method: () => {
                    Destroy(GameObject.method("Find").invoke(Il2Cpp.string("StaffDoor")));
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "J0kerClient Name",
                method: () => {
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=30><sprite=12>J0ker Client<sprite=12>"))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "J0kerModZ Name",
                method: () => {
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string("<size=30><sprite=12>J0kerModZ<sprite=12>"))
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "RGB",
                method: () => {
                    const now = Date.now();

                    if (now - lastRunTime >= rgbcooldown) {
                        lastRunTime = now;

                        try {
                            const color = getSmoothColor();

                            PhotonVRManager
                                .method("SetColour")
                                .invoke([
                                    color.r,
                                    color.g,
                                    color.b,
                                    color.a
                                ]);

                        } catch (_) { }
                    }
                },
                keepOn: true,
            }),
        ],
        [ // Rig Mods
            new ButtonInfo({
                buttonText: "Ghost Rig [B]",
                method: () => {
                    GhostRig()
                },
            }),

            new ButtonInfo({
                buttonText: "Grab Rig [G]",

                disableMethod: () => {
                    try {
                        const manager = PhotonVRManager
                            .method("get_Manager")
                            .invoke();

                        if (manager == null)
                            return;

                        const localRig = manager.field("LocalPlayer").value;

                        if (localRig != null) {
                            localRig
                                .method("set_enabled")
                                .invoke(true);
                        }
                    } catch (_) { }
                },

                method: () => {
                    try {
                        // Always get a fresh manager + LocalPlayer
                        const manager = PhotonVRManager
                            .method("get_Manager")
                            .invoke();

                        if (manager == null)
                            return;

                        const localRig = manager.field("LocalPlayer").value;

                        if (localRig == null)
                            return;

                        if (rightGrab) {
                            const handPosition = rightHandTransform
                                .method("get_position")
                                .invoke();

                            const handRotation = rightHandTransform
                                .method("get_rotation")
                                .invoke();

                            localRig
                                .method("set_enabled")
                                .invoke(false);

                            const rigTransform = getTransform(localRig);

                            rigTransform
                                .method("set_position")
                                .invoke(handPosition);

                            rigTransform
                                .method("set_rotation")
                                .invoke(handRotation);
                        }
                        else {
                            localRig
                                .method("set_enabled")
                                .invoke(true);
                        }

                    } catch (e) {
                        console.log("[Grab Rig] " + e);
                    }
                },

                keepOn: true,
            }),
        ],
        [ // Cosmetics
            new ButtonInfo({
                buttonText: "Owner Tag",
                method: () => {
                    SetCosmetic("OWNER_TITLE", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Dev Tag",
                method: () => {
                    SetCosmetic("DEVELOPER_TITLE", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Mod Tag",
                method: () => {
                    SetCosmetic("MODERATOR_TITLE", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Admin Tag",
                method: () => {
                    SetCosmetic("ADMIN_TITLE", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Beta Tester Tag",
                method: () => {
                    SetCosmetic("BETATESTER_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "VIP Tag",
                method: () => {
                    SetCosmetic("VIP_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "CC Tag",
                method: () => {
                    SetCosmetic("CONTENTCREATOR_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Manager Tag",
                method: () => {
                    SetCosmetic("COMMUNITYMANAGER_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "RealApe Tag",
                method: () => {
                    SetCosmetic("REALAPE_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "GodApe Tag",
                method: () => {
                    SetCosmetic("GODAPE_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "DedicatedApe Tag",
                method: () => {
                    SetCosmetic("DEDICATEDAPE_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "ActiveApe Tag",
                method: () => {
                    SetCosmetic("ACTIVEAPE_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "ActiveApe Tag",
                method: () => {
                    SetCosmetic("ACTIVEAPE_TAG", "NameTag");
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "TEAPOT",
                method: () => SetCosmetic("TEAPOT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PARTYHAT",
                method: () => SetCosmetic("PARTYHAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BANANA",
                method: () => SetCosmetic("BANANA", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "DEVIL_HORNS",
                method: () => SetCosmetic("DEVIL_HORNS", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HALO",
                method: () => SetCosmetic("HALO", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HEADPHONES",
                method: () => SetCosmetic("HEADPHONES", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PAN",
                method: () => SetCosmetic("PAN", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PLUNGER",
                method: () => SetCosmetic("PLUNGER", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SHANKA",
                method: () => SetCosmetic("SHANKA", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "TOPHAT",
                method: () => SetCosmetic("TOPHAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SNOWMAN_HAT",
                method: () => SetCosmetic("SNOWMAN_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MINERHAT",
                method: () => SetCosmetic("MINERHAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "EASTER_EARS",
                method: () => SetCosmetic("EASTER_EARS", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "CONE",
                method: () => SetCosmetic("CONE", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "DISCORD_CAP",
                method: () => SetCosmetic("DISCORD_CAP", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BOOSTER_CAP",
                method: () => SetCosmetic("BOOSTER_CAP", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GOLDEN_CAP",
                method: () => SetCosmetic("GOLDEN_CAP", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "RED_CAP",
                method: () => SetCosmetic("RED_CAP", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GREEN_CAP",
                method: () => SetCosmetic("GREEN_CAP", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "JMAN_HAIR",
                method: () => SetCosmetic("JMAN_HAIR", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BEACHBALL",
                method: () => SetCosmetic("BEACHBALL", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MAFIA_HAT",
                method: () => SetCosmetic("MAFIA_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "VIP_HAT",
                method: () => SetCosmetic("VIP_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "WHITE_HAT",
                method: () => SetCosmetic("WHITE_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COCONUT",
                method: () => SetCosmetic("COCONUT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SIXSEVEN_HAIR",
                method: () => SetCosmetic("SIXSEVEN_HAIR", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GGS_HAT",
                method: () => SetCosmetic("GGS_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "ELF_HAT",
                method: () => SetCosmetic("ELF_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SANTA_HAT",
                method: () => SetCosmetic("SANTA_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PUMKIN",
                method: () => SetCosmetic("PUMKIN", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GSA_SKIMASK",
                method: () => SetCosmetic("GSA_SKIMASK", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GSA_SKIMASK_WHITE",
                method: () => SetCosmetic("GSA_SKIMASK_WHITE", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "INVITECROWN",
                method: () => SetCosmetic("INVITECROWN", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "DISCOBALL",
                method: () => SetCosmetic("DISCOBALL", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COWBOY_DESERT",
                method: () => SetCosmetic("COWBOY_DESERT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COWBOY_CLASSIC",
                method: () => SetCosmetic("COWBOY_CLASSIC", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COWBOY_WIDEBRIM_BROWN",
                method: () => SetCosmetic("COWBOY_WIDEBRIM_BROWN", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COWBOY_BANDED_BROWN",
                method: () => SetCosmetic("COWBOY_BANDED_BROWN", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COWBOY_BANDED_GRAY",
                method: () => SetCosmetic("COWBOY_BANDED_GRAY", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "COWBOY_WIDEBRIM_BLACK",
                method: () => SetCosmetic("COWBOY_WIDEBRIM_BLACK", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HACKER_HAT",
                method: () => SetCosmetic("HACKER_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SKIBIDI_TOILET",
                method: () => SetCosmetic("SKIBIDI_TOILET", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SUPERMAN_HAIR",
                method: () => SetCosmetic("SUPERMAN_HAIR", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "EGG_SHELL",
                method: () => SetCosmetic("EGG_SHELL", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FLOWER_CROWN",
                method: () => SetCosmetic("FLOWER_CROWN", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "DURAG",
                method: () => SetCosmetic("DURAG", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BMA_MASK",
                method: () => SetCosmetic("BMA_MASK", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "CC_CAP",
                method: () => SetCosmetic("CC_CAP", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MILITARY_HELMET (OLD)",
                method: () => SetCosmetic("MILITARY_HELMET (OLD)", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MILITARY_HELMET",
                method: () => SetCosmetic("MILITARY_HELMET", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PJ_BONNET",
                method: () => SetCosmetic("PJ_BONNET", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BRANDOO_HAIR",
                method: () => SetCosmetic("BRANDOO_HAIR", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BUCKETHAT",
                method: () => SetCosmetic("BUCKETHAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "US_LIBERTY_HAT",
                method: () => SetCosmetic("US_LIBERTY_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "US_UNC_SAM_HAT",
                method: () => SetCosmetic("US_UNC_SAM_HAT", "Head"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "ANGRY_EYEBROWS",
                method: () => SetCosmetic("ANGRY_EYEBROWS", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SKI_GOGGLES",
                method: () => SetCosmetic("SKI_GOGGLES", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SUNGLASSES",
                method: () => SetCosmetic("SUNGLASSES", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "EASTER_CARROT",
                method: () => SetCosmetic("EASTER_CARROT", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GGS_MASK",
                method: () => SetCosmetic("GGS_MASK", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SANTA_BEARD",
                method: () => SetCosmetic("SANTA_BEARD", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "2026_GLASSES",
                method: () => SetCosmetic("2026_GLASSES", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "EYEOFRAH",
                method: () => SetCosmetic("EYEOFRAH", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HACKER_MASK",
                method: () => SetCosmetic("HACKER_MASK", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "US_GLASSES",
                method: () => SetCosmetic("US_GLASSES", "Face"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "CC_SHIRT",
                method: () => SetCosmetic("CC_SHIRT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BACKPACK",
                method: () => SetCosmetic("BACKPACK", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "NITRO_CHAIN",
                method: () => SetCosmetic("NITRO_CHAIN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "EASTER_SWEATER",
                method: () => SetCosmetic("EASTER_SWEATER", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MAFIA_SUIT",
                method: () => SetCosmetic("MAFIA_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "VIP_SUIT",
                method: () => SetCosmetic("VIP_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SNOWMAN",
                method: () => SetCosmetic("SNOWMAN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "WHITE_SUIT",
                method: () => SetCosmetic("WHITE_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "JMAN_TAPE",
                method: () => SetCosmetic("JMAN_TAPE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "JETPACK",
                method: () => SetCosmetic("JETPACK", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GUARD_SUIT",
                method: () => SetCosmetic("GUARD_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "ELF_SUIT",
                method: () => SetCosmetic("ELF_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SANTA_SUIT",
                method: () => SetCosmetic("SANTA_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FRONTMAN_BLACK",
                method: () => SetCosmetic("FRONTMAN_BLACK", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FRONTMAN_WHITE",
                method: () => SetCosmetic("FRONTMAN_WHITE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HAZMAT_BLACK",
                method: () => SetCosmetic("HAZMAT_BLACK", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HAZMAT_WHITE",
                method: () => SetCosmetic("HAZMAT_WHITE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MERCH",
                method: () => SetCosmetic("MERCH", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HAWAII_SHIRT_1",
                method: () => SetCosmetic("HAWAII_SHIRT_1", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "HAWAII_SHIRT_2",
                method: () => SetCosmetic("HAWAII_SHIRT_2", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BOOMBOX",
                method: () => SetCosmetic("BOOMBOX", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BIGBANANA",
                method: () => SetCosmetic("BIGBANANA", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GGS_SPIKARMOR",
                method: () => SetCosmetic("GGS_SPIKARMOR", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GSA_PUFFERJACKET",
                method: () => SetCosmetic("GSA_PUFFERJACKET", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GSA_CHAIN",
                method: () => SetCosmetic("GSA_CHAIN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FNAF_BEAR",
                method: () => SetCosmetic("FNAF_BEAR", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FNAF_CHICKEN",
                method: () => SetCosmetic("FNAF_CHICKEN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FNAF_BUNNY",
                method: () => SetCosmetic("FNAF_BUNNY", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FNAF_NIGHT_BEAR",
                method: () => SetCosmetic("FNAF_NIGHT_BEAR", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FNAF_NIGHT_CHICKEN",
                method: () => SetCosmetic("FNAF_NIGHT_CHICKEN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FNAF_NIGHT_BUNNY",
                method: () => SetCosmetic("FNAF_NIGHT_BUNNY", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FREEMAN_SUIT",
                method: () => SetCosmetic("FREEMAN_SUIT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GOLDBAR",
                method: () => SetCosmetic("GOLDBAR", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "IRONMAN",
                method: () => SetCosmetic("IRONMAN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SUPERMAN_CAPE",
                method: () => SetCosmetic("SUPERMAN_CAPE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BUNNY_SUIT1",
                method: () => SetCosmetic("BUNNY_SUIT1", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "BUNNY_SUIT2",
                method: () => SetCosmetic("BUNNY_SUIT2", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "WARCAPE",
                method: () => SetCosmetic("WARCAPE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "NEONCAPE",
                method: () => SetCosmetic("NEONCAPE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MILITARY_VEST (OLD)",
                method: () => SetCosmetic("MILITARY_VEST (OLD)", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "MILITARY_VEST",
                method: () => SetCosmetic("MILITARY_VEST", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PJ_COAT",
                method: () => SetCosmetic("PJ_COAT", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "TROPICAL_TSHIRT_BLUE",
                method: () => SetCosmetic("TROPICAL_TSHIRT_BLUE", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "TROPICAL_TSHIRT_GREEN",
                method: () => SetCosmetic("TROPICAL_TSHIRT_GREEN", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "WC_PORTUGAL",
                method: () => SetCosmetic("WC_PORTUGAL", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "WC_ARGENTINA",
                method: () => SetCosmetic("WC_ARGENTINA", "Body"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SPIDERMAN_FACE",
                method: () => SetCosmetic("SPIDERMAN_FACE", "Special"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "VENOM_FACE",
                method: () => SetCosmetic("VENOM_FACE", "Special"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "US_FLAG",
                method: () => SetCosmetic("US_FLAG", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SPARKLER",
                method: () => SetCosmetic("SPARKLER", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FRONTMANBLACK_REVOLVER",
                method: () => SetCosmetic("FRONTMANBLACK_REVOLVER", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "SWORD",
                method: () => SetCosmetic("SWORD", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GGS_SCYTHE",
                method: () => SetCosmetic("GGS_SCYTHE", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GUARD_SMG",
                method: () => SetCosmetic("GUARD_SMG", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "CANDYCANE",
                method: () => SetCosmetic("CANDYCANE", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "WATERGUN",
                method: () => SetCosmetic("WATERGUN", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "KICK_HAMMER",
                method: () => SetCosmetic("KICK_HAMMER", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "GUNSLOL_PLUSHIE",
                method: () => SetCosmetic("GUNSLOL_PLUSHIE", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "ADMIN_GUN",
                method: () => SetCosmetic("ADMIN_GUN", "RightHand"),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "FREEMAN_BAT",
                method: () => SetCosmetic("FREEMAN_BAT", "RightHand"),
                keepOn: false,
            }),
        ],
        [ // OP Mods
            new ButtonInfo({
                buttonText: "Set Master",
                method: () => {
                    PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Lag All",
                method: () => {
                    for (let i = 0; i < 5000; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("prefabs/grabbables/ANTI_ENTITY"), [400.0, -400.0, 0.0], identityQuaternion, 0, NULL)
                        Destroy(thingforlag)
                    }
                    sendAllOutgoing()
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "Destroy All",
                method: () => {
                    const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
                    if (others && others.length > 0) {
                        for (let i = 0; i < others.length; i++) {
                            const player = others.get(i);
                            PhotonNetwork.method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke())
                            PhotonNetwork.method("DestroyPlayerObjects").invoke(player);
                        }
                    }
                },
                keepOn: false,
            }),
        ],
        [ // Prefabs
            new ButtonInfo({
                buttonText: "ANTI_ENTITY",
                method: () => spawnPrefabAtGun("prefabs/grabbables/ANTI_ENTITY"),
            }),
            new ButtonInfo({
                buttonText: "BACK PACK",
                method: () => spawnPrefabAtGun("prefabs/grabbables/BACKPACK"),
            }),
            new ButtonInfo({
                buttonText: "BIGBACKPACK",
                method: () => spawnPrefabAtGun("prefabs/grabbables/BIGBACKPACK"),
            }),
            new ButtonInfo({
                buttonText: "BOOM BOX",
                method: () => spawnPrefabAtGun("prefabs/grabbables/BOOMBOX"),
            }),
            new ButtonInfo({
                buttonText: "BOOMBOX_BLUE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/BOOMBOX_BLUE"),
            }),
            new ButtonInfo({
                buttonText: "CARDBOX_M",
                method: () => spawnPrefabAtGun("prefabs/grabbables/CARDBOX_M"),
            }),
            new ButtonInfo({
                buttonText: "COALORE1",
                method: () => spawnPrefabAtGun("prefabs/grabbables/COALORE1"),
            }),
            new ButtonInfo({
                buttonText: "COALORE2",
                method: () => spawnPrefabAtGun("prefabs/grabbables/COALORE2"),
            }),
            new ButtonInfo({
                buttonText: "COALORE3",
                method: () => spawnPrefabAtGun("prefabs/grabbables/COALORE3"),
            }),
            new ButtonInfo({
                buttonText: "CRYSTAL",
                method: () => spawnPrefabAtGun("prefabs/grabbables/CRYSTAL"),
            }),
            new ButtonInfo({
                buttonText: "DIAMOND",
                method: () => spawnPrefabAtGun("prefabs/grabbables/DIAMOND"),
            }),
            new ButtonInfo({
                buttonText: "DIAMONDORE1",
                method: () => spawnPrefabAtGun("prefabs/grabbables/DIAMONDORE1"),
            }),
            new ButtonInfo({
                buttonText: "DIAMONDORE2",
                method: () => spawnPrefabAtGun("prefabs/grabbables/DIAMONDORE2"),
            }),
            new ButtonInfo({
                buttonText: "DIAMONDORE3",
                method: () => spawnPrefabAtGun("prefabs/grabbables/DIAMONDORE3"),
            }),
            new ButtonInfo({
                buttonText: "FUSE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/FUSE"),
            }),
            new ButtonInfo({
                buttonText: "GOLD",
                method: () => spawnPrefabAtGun("prefabs/grabbables/GOLD"),
            }),
            new ButtonInfo({
                buttonText: "GOLDORE1",
                method: () => spawnPrefabAtGun("prefabs/grabbables/GOLDORE1"),
            }),
            new ButtonInfo({
                buttonText: "GOLDORE2",
                method: () => spawnPrefabAtGun("prefabs/grabbables/GOLDORE2"),
            }),
            new ButtonInfo({
                buttonText: "GOLDORE3",
                method: () => spawnPrefabAtGun("prefabs/grabbables/GOLDORE3"),
            }),
            new ButtonInfo({
                buttonText: "GRAPPLER",
                method: () => spawnPrefabAtGun("prefabs/grabbables/GRAPPLER"),
            }),
            new ButtonInfo({
                buttonText: "GRENADE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/GRENADE"),
            }),
            new ButtonInfo({
                buttonText: "KEYCARD-FLOOR3",
                method: () => spawnPrefabAtGun("prefabs/grabbables/KEYCARD-FLOOR3"),
            }),
            new ButtonInfo({
                buttonText: "KEYCARD-SEC2",
                method: () => spawnPrefabAtGun("prefabs/grabbables/KEYCARD-SEC2"),
            }),
            new ButtonInfo({
                buttonText: "KEYCARD-SEC3",
                method: () => spawnPrefabAtGun("prefabs/grabbables/KEYCARD-SEC3"),
            }),
            new ButtonInfo({
                buttonText: "LANDMINE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/LANDMINE"),
            }),
            new ButtonInfo({
                buttonText: "OBSIDIANORE1",
                method: () => spawnPrefabAtGun("prefabs/grabbables/OBSIDIANORE1"),
            }),
            new ButtonInfo({
                buttonText: "OBSIDIANORE2",
                method: () => spawnPrefabAtGun("prefabs/grabbables/OBSIDIANORE2"),
            }),
            new ButtonInfo({
                buttonText: "OBSIDIANORE3",
                method: () => spawnPrefabAtGun("prefabs/grabbables/OBSIDIANORE3"),
            }),
            new ButtonInfo({
                buttonText: "OMNITOOL",
                method: () => spawnPrefabAtGun("prefabs/grabbables/OMNITOOL"),
            }),
            new ButtonInfo({
                buttonText: "PICKAXE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/PICKAXE"),
            }),
            new ButtonInfo({
                buttonText: "RED_FLASHLIGHT",
                method: () => spawnPrefabAtGun("prefabs/grabbables/RED_FLASHLIGHT"),
            }),
            new ButtonInfo({
                buttonText: "ROCKETAMMO",
                method: () => spawnPrefabAtGun("prefabs/grabbables/ROCKETAMMO"),
            }),
            new ButtonInfo({
                buttonText: "ROCKETHAND",
                method: () => spawnPrefabAtGun("prefabs/grabbables/ROCKETHAND"),
            }),
            new ButtonInfo({
                buttonText: "ROCKETLAUNCHER",
                method: () => spawnPrefabAtGun("prefabs/grabbables/ROCKETLAUNCHER"),
            }),
            new ButtonInfo({
                buttonText: "SMOKE_GRENADE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/SMOKE_GRENADE"),
            }),
            new ButtonInfo({
                buttonText: "SOCKAPE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/SOCKAPE"),
            }),
            new ButtonInfo({
                buttonText: "SOCKAPE_BLUE",
                method: () => spawnPrefabAtGun("prefabs/grabbables/SOCKAPE_BLUE"),
            }),
            new ButtonInfo({
                buttonText: "SOCKAPE_RGB",
                method: () => spawnPrefabAtGun("prefabs/grabbables/SOCKAPE_RGB"),
            }),
            new ButtonInfo({
                buttonText: "YELLOW_FLASHLIGHT",
                method: () => spawnPrefabAtGun("prefabs/grabbables/YELLOW_FLASHLIGHT"),
            }),
            new ButtonInfo({
                buttonText: "CoalOre",
                method: () => spawnPrefabAtGun("prefabs/ores/CoalOre"),
            }),
            new ButtonInfo({
                buttonText: "DiamondOre",
                method: () => spawnPrefabAtGun("prefabs/ores/DiamondOre"),
            }),
            new ButtonInfo({
                buttonText: "GoldOre",
                method: () => spawnPrefabAtGun("prefabs/ores/GoldOre"),
            }),
            new ButtonInfo({
                buttonText: "ObsidianOre",
                method: () => spawnPrefabAtGun("prefabs/ores/ObsidianOre"),
            }),
            new ButtonInfo({
                buttonText: "NetDoor",
                method: () => spawnPrefabAtGun("prefabs/props/interactable/NetDoor"),
            }),
        ],
    ];

    let buttonMap: Map<string, ButtonInfo> = new Map();
    buttons.flat().forEach(button => {
        buttonMap.set(button.buttonText, button);
    });

    function getIndex(buttonText: string): ButtonInfo {
        return buttonMap.get(buttonText);
    }

    const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
    ButtonActivation.implementation = function (collider) {
        const rawName = this.method("get_name").invoke().toString();

        if (rawName.length > 1 && rawName[1] == "@") {
            if (collider.handle.equals(referenceCollider.handle)) {
                const goName = rawName.substring(2, rawName.length - 1);
                const _time = Time.method("get_time").invoke();

                if (_time > buttonClickDelay) {
                    buttonClickDelay = _time + 0.2;

                    const button = getIndex(goName)
                    if (button) {
                        if (button.keepOn) {
                            button.enabled = !button.enabled;

                            if (button?.enabled) {
                                button.enableMethod?.();
                            } else {
                                button?.disableMethod?.();
                            }

                        } else {
                            button?.method?.();
                        }

                        reloadMenu();
                    }
                }
            }

            return;
        }

        return this.method("OnTriggerEnter").invoke(collider);
    };

    const LateUpdate = GorillaTagger.method("Update");

    LateUpdate.implementation = function () {

        OVRInputHandler.update();

        leftPrimary = OVRInputHandler.leftControllerPrimaryButton
        leftSecondary = OVRInputHandler.leftControllerSecondaryButton;

        rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
        rightSecondary = OVRInputHandler.rightControllerSecondaryButton;

        leftGrab = OVRInputHandler.leftGrab;
        rightGrab = OVRInputHandler.rightGrab;

        leftTrigger = OVRInputHandler.leftControllerTriggerButton;
        rightTrigger = OVRInputHandler.rightControllerTriggerButton;

        deltaTime = Time.method("get_deltaTime").invoke();
        time = Time.method("get_time").invoke();

        if (leftSecondary) {
            if (menu == null) {
                renderMenu();
            } else {
                recenterMenu();
            }
        } else {
            if (menu != null) {
                Destroy(menu);
                menu = null;
            }
        }

        if (menu == null) {
            if (reference != null) {
                Destroy(reference);
                reference = null;
            }
        } else {
            if (reference == null) {
                renderReference();
            }
        }

        try {
            if (GunPointer != null) {
                if (!(GunPointer.method("get_activeSelf").invoke())) {
                    Destroy(GunPointer);
                    GunPointer = null;
                }
                else
                    GunPointer.method("SetActive").invoke(false);
            }

            let lineObj = GunLine.method("get_gameObject").invoke();
            if (lineObj != null) {
                if (!(lineObj.method("get_activeSelf").invoke())) {
                    Destroy(lineObj);
                    GunLine = null;
                }
                else
                    lineObj.method("SetActive").invoke(false);
            }
        } catch { }

        buttons.flat()
            .filter(button => button.enabled)
            .forEach(button => {
                if (button.method) {
                    try {
                        button.method();
                    } catch (error) {
                        console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
                        console.error('Error stack:', error.stack);
                        console.error('Button object:', button);

                        if (error.stack) {
                            const stackLines = error.stack.split('\n');
                            if (stackLines.length > 1) {
                                console.error('Error occurred at:', stackLines[1].trim());
                            }
                        }
                    }
                }
            });

        return LateUpdate.invoke();
    };
    console.log(`Compiled ${new Date().toISOString()}`);

}, "main");