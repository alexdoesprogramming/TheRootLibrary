@echo off
title Lethal Ape Frida Menu
color 0A

:START
cls
echo ==========================================
echo       Lethal Ape Frida Menu
echo ==========================================
echo.
echo Starting Frida injection...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$p = Start-Process frida -ArgumentList '-U -l frida-il2cpp-bridge.js -l leathalape.ts LethalApeR' -NoNewWindow -PassThru; ^
while (!$p.HasExited) { ^
    Start-Sleep -Milliseconds 500 ^
}; ^
exit $p.ExitCode"

echo.
echo Frida stopped.
echo Restarting menu...
echo.

timeout /t 2 /nobreak >nul
goto START